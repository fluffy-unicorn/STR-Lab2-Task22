#include <stdio.h> 
#include <assert.h>
#include <math.h>
#include <stdlib.h>

    extern void __VERIFIER_error(int);

	// inputs
	int inputs[] = {4,5,2,14,8,10,3,6,7,9,12,13,11,15,1};

	void errorCheck();
	void calculate_output(int);
	void calculate_outputm1(int);
	void calculate_outputm2(int);
	void calculate_outputm3(int);
	void calculate_outputm4(int);
	void calculate_outputm5(int);
	void calculate_outputm6(int);
	void calculate_outputm7(int);
	void calculate_outputm8(int);
	void calculate_outputm9(int);
	void calculate_outputm10(int);
	void calculate_outputm11(int);
	void calculate_outputm12(int);
	void calculate_outputm13(int);
	void calculate_outputm14(int);
	void calculate_outputm15(int);
	void calculate_outputm16(int);
	void calculate_outputm17(int);
	void calculate_outputm18(int);
	void calculate_outputm19(int);
	void calculate_outputm20(int);
	void calculate_outputm21(int);
	void calculate_outputm22(int);
	void calculate_outputm23(int);
	void calculate_outputm24(int);
	void calculate_outputm25(int);
	void calculate_outputm26(int);
	void calculate_outputm27(int);
	void calculate_outputm28(int);
	void calculate_outputm29(int);
	void calculate_outputm30(int);
	void calculate_outputm31(int);
	void calculate_outputm32(int);
	void calculate_outputm33(int);
	void calculate_outputm34(int);
	void calculate_outputm35(int);
	void calculate_outputm36(int);
	void calculate_outputm37(int);
	void calculate_outputm38(int);
	void calculate_outputm39(int);
	void calculate_outputm40(int);
	void calculate_outputm41(int);
	void calculate_outputm42(int);
	void calculate_outputm43(int);
	void calculate_outputm44(int);
	void calculate_outputm45(int);
	void calculate_outputm46(int);
	void calculate_outputm47(int);
	void calculate_outputm48(int);
	void calculate_outputm49(int);
	void calculate_outputm50(int);
	void calculate_outputm51(int);
	void calculate_outputm52(int);
	void calculate_outputm53(int);
	void calculate_outputm54(int);
	void calculate_outputm55(int);
	void calculate_outputm56(int);
	void calculate_outputm57(int);
	void calculate_outputm58(int);
	void calculate_outputm59(int);
	void calculate_outputm60(int);
	void calculate_outputm61(int);
	void calculate_outputm62(int);
	void calculate_outputm63(int);
	void calculate_outputm64(int);
	void calculate_outputm65(int);
	void calculate_outputm66(int);
	void calculate_outputm67(int);
	void calculate_outputm68(int);
	void calculate_outputm69(int);
	void calculate_outputm70(int);
	void calculate_outputm71(int);
	void calculate_outputm72(int);
	void calculate_outputm73(int);
	void calculate_outputm74(int);
	void calculate_outputm75(int);
	void calculate_outputm76(int);
	void calculate_outputm77(int);
	void calculate_outputm78(int);
	void calculate_outputm79(int);
	void calculate_outputm80(int);
	void calculate_outputm81(int);
	void calculate_outputm82(int);
	void calculate_outputm83(int);
	void calculate_outputm84(int);
	void calculate_outputm85(int);
	void calculate_outputm86(int);
	void calculate_outputm87(int);
	void calculate_outputm88(int);
	void calculate_outputm89(int);
	void calculate_outputm90(int);
	void calculate_outputm91(int);
	void calculate_outputm92(int);
	void calculate_outputm93(int);
	void calculate_outputm94(int);
	void calculate_outputm95(int);
	void calculate_outputm96(int);
	void calculate_outputm97(int);
	void calculate_outputm98(int);
	void calculate_outputm99(int);
	void calculate_outputm100(int);
	void calculate_outputm101(int);
	void calculate_outputm102(int);
	void calculate_outputm103(int);
	void calculate_outputm104(int);
	void calculate_outputm105(int);
	void calculate_outputm106(int);
	void calculate_outputm107(int);
	void calculate_outputm108(int);
	void calculate_outputm109(int);
	void calculate_outputm110(int);
	void calculate_outputm111(int);
	void calculate_outputm112(int);
	void calculate_outputm113(int);
	void calculate_outputm114(int);
	void calculate_outputm115(int);
	void calculate_outputm116(int);
	void calculate_outputm117(int);
	void calculate_outputm118(int);
	void calculate_outputm119(int);
	void calculate_outputm120(int);
	void calculate_outputm121(int);
	void calculate_outputm122(int);
	void calculate_outputm123(int);
	void calculate_outputm124(int);
	void calculate_outputm125(int);
	void calculate_outputm126(int);
	void calculate_outputm127(int);
	void calculate_outputm128(int);
	void calculate_outputm129(int);
	void calculate_outputm130(int);
	void calculate_outputm131(int);
	void calculate_outputm132(int);
	void calculate_outputm133(int);
	void calculate_outputm134(int);
	void calculate_outputm135(int);
	void calculate_outputm136(int);
	void calculate_outputm137(int);
	void calculate_outputm138(int);
	void calculate_outputm139(int);
	void calculate_outputm140(int);
	void calculate_outputm141(int);
	void calculate_outputm142(int);
	void calculate_outputm143(int);
	void calculate_outputm144(int);
	void calculate_outputm145(int);
	void calculate_outputm146(int);
	void calculate_outputm147(int);
	void calculate_outputm148(int);
	void calculate_outputm149(int);
	void calculate_outputm150(int);
	void calculate_outputm151(int);
	void calculate_outputm152(int);
	void calculate_outputm153(int);
	void calculate_outputm154(int);
	void calculate_outputm155(int);
	void calculate_outputm156(int);
	void calculate_outputm157(int);
	void calculate_outputm158(int);
	void calculate_outputm159(int);
	void calculate_outputm160(int);
	void calculate_outputm161(int);
	void calculate_outputm162(int);
	void calculate_outputm163(int);
	void calculate_outputm164(int);
	void calculate_outputm165(int);
	void calculate_outputm166(int);
	void calculate_outputm167(int);
	void calculate_outputm168(int);
	void calculate_outputm169(int);
	void calculate_outputm170(int);
	void calculate_outputm171(int);
	void calculate_outputm172(int);
	void calculate_outputm173(int);
	void calculate_outputm174(int);
	void calculate_outputm175(int);
	void calculate_outputm176(int);
	void calculate_outputm177(int);
	void calculate_outputm178(int);
	void calculate_outputm179(int);
	void calculate_outputm180(int);
	void calculate_outputm181(int);
	void calculate_outputm182(int);
	void calculate_outputm183(int);
	void calculate_outputm184(int);
	void calculate_outputm185(int);
	void calculate_outputm186(int);
	void calculate_outputm187(int);
	void calculate_outputm188(int);
	void calculate_outputm189(int);
	void calculate_outputm190(int);
	void calculate_outputm191(int);
	void calculate_outputm192(int);
	void calculate_outputm193(int);
	void calculate_outputm194(int);
	void calculate_outputm195(int);
	void calculate_outputm196(int);
	void calculate_outputm197(int);
	void calculate_outputm198(int);
	void calculate_outputm199(int);
	void calculate_outputm200(int);
	void calculate_outputm201(int);
	void calculate_outputm202(int);
	void calculate_outputm203(int);
	void calculate_outputm204(int);
	void calculate_outputm205(int);
	void calculate_outputm206(int);
	void calculate_outputm207(int);
	void calculate_outputm208(int);
	void calculate_outputm209(int);
	void calculate_outputm210(int);
	void calculate_outputm211(int);
	void calculate_outputm212(int);
	void calculate_outputm213(int);
	void calculate_outputm214(int);
	void calculate_outputm215(int);
	void calculate_outputm216(int);
	void calculate_outputm217(int);
	void calculate_outputm218(int);
	void calculate_outputm219(int);
	void calculate_outputm220(int);
	void calculate_outputm221(int);
	void calculate_outputm222(int);
	void calculate_outputm223(int);
	void calculate_outputm224(int);
	void calculate_outputm225(int);
	void calculate_outputm226(int);
	void calculate_outputm227(int);
	void calculate_outputm228(int);
	void calculate_outputm229(int);
	void calculate_outputm230(int);
	void calculate_outputm231(int);
	void calculate_outputm232(int);
	void calculate_outputm233(int);
	void calculate_outputm234(int);
	void calculate_outputm235(int);
	void calculate_outputm236(int);
	void calculate_outputm237(int);
	void calculate_outputm238(int);
	void calculate_outputm239(int);
	void calculate_outputm240(int);
	void calculate_outputm241(int);
	void calculate_outputm242(int);
	void calculate_outputm243(int);
	void calculate_outputm244(int);
	void calculate_outputm245(int);
	void calculate_outputm246(int);
	void calculate_outputm247(int);
	void calculate_outputm248(int);
	void calculate_outputm249(int);
	void calculate_outputm250(int);
	void calculate_outputm251(int);
	void calculate_outputm252(int);
	void calculate_outputm253(int);
	void calculate_outputm254(int);
	void calculate_outputm255(int);
	void calculate_outputm256(int);
	void calculate_outputm257(int);
	void calculate_outputm258(int);
	void calculate_outputm259(int);
	void calculate_outputm260(int);
	void calculate_outputm261(int);
	void calculate_outputm262(int);
	void calculate_outputm263(int);
	void calculate_outputm264(int);
	void calculate_outputm265(int);
	void calculate_outputm266(int);
	void calculate_outputm267(int);
	void calculate_outputm268(int);
	void calculate_outputm269(int);
	void calculate_outputm270(int);
	void calculate_outputm271(int);
	void calculate_outputm272(int);
	void calculate_outputm273(int);
	void calculate_outputm274(int);

	 int a1728405119 = -13;
	 int a296421163  = 32;
	 int a1166237008 = -96;
	 int a999024345 = 112;
	 int a1774184757 = -145;
	 int a362219248 = 5;
	 int a119997292 = 3;
	 int a1440713788 = 11;
	 int a721272783 = 16;
	 int a2026977784 = 8;
	 int a1947180632 = 94;
	 int a1574467713 = 6;
	 int a2041520547  = 34;
	 int a1255449606 = -132;
	 int a1305578599  = 32;
	 int a260539918 = -26;
	 int a2073482783  = 33;
	 int a153258473 = 28;
	 int a1125477212  = 33;
	 int a34679179 = -52;
	 int a1032084261  = 34;
	 int a1875686186 = 12;
	 int a834646264 = 7;
	 int a263638061 = 11;
	 int a1895857334 = 12;
	 int a813082108 = 51;
	 int a541588245  = 33;
	 int a153649526  = 35;
	 int a1180594800  = 33;
	 int a822442096 = -40;
	 int a601495656  = 33;
	 int a1301446006 = 107;
	 int a1983740902  = 33;
	 int a1075307847  = 35;
	 int a263219509 = 9;
	 int a961167689 = 10;
	 int a1241576728 = 7;
	 int a63333937 = 1;
	 int a2087535773 = 4;
	 int a2087632595  = 36;
	 int a617559344 = 406;
	 int a1675035970 = 192;
	 int a965340096  = 34;
	 int a1249952537 = 5;
	 int a1018383389 = 121;
	 int a302110279  = 33;
	 int a709568404  = 33;
	 int a566060042 = 95;
	 int a369798198  = 34;
	 int a1257505051 = 20;
	 int a1111616318  = 33;
	 int a1644957382  = 33;
	 int a76745981  = 33;
	 int a1942901885  = 33;
	 int a1521644128 = 10;
	 int a2004613952 = 10;
	 int a2140773614  = 32;
	 int a260339255 = 77;
	 int a1240243570 = 7;
	 int a1318526106  = 33;
	 int a1985899004 = 290;
	 int a1352986605 = 332;
	 int a266166646 = 143;
	 int a983758263 = 36;
	 int a1550739565 = 11;
	 int a1756173294 = 230;
	 int a1213722969 = 7;
	 int a1826277115 = 62;
	 int a1964635488  = 35;
	 int a1783229935 = 14;
	 int a404763935 = 11;
	 int a2130193413 = 10;
	 int a1895304149  = 33;
	 int a1597554373  = 34;
	 int a80157050 = 6;
	 int a1354435613  = 34;
	 int a247580515  = 36;
	 int a757937656 = 5;
	 int a1254983042 = 147;
	 int a824591188 = 105;
	 int a1912617323 = 15;
	 int a100021342 = -13;
	 int a1830659124 = 10;
	 int a26346326  = 33;
	 int a823982083 = 294;
	 int a1211013485  = 33;
	 int a707417839 = 274;
	 int a190525986 = 10;
	 int a2061425267 = 11;
	 int a703247202  = 32;
	 int a1478681170 = 4;
	 int a1625516355 = -101;
	 int a537754274  = 36;
	 int a2097567994  = 35;
	 int a1959068056 = 9;
	 int a1357285245 = 7;
	 int a4442917 = 6;
	 int a1891437507  = 32;
	 int a263151501  = 33;
	 int a268551986  = 32;
	 int a1569588614 = 111;
	 int cf = 1;
	 int a356054071 = 188;
	 int a217799639 = -153;
	 int a1077149355 = 8;
	 int a1700231631 = 9;
	 int a1260876233 = 205;
	 int a1683451995 = 3;
	 int a1916853335 = 6;
	 int a1667689532  = 33;
	 int a1210910088 = 2;
	 int a350392085 = 10;
	 int a786258498 = 9;
	 int a803418896 = 91;
	 int a708839806  = 33;
	 int a811861560  = 36;
	 int a1474668405 = -163;
	 int a1345687529 = -199;
	 int a620988906  = 35;
	 int a2130183577 = 125;
	 int a1323955799  = 36;
	 int a661990791 = 9;
	 int a620105235 = -170;
	 int a1012466188  = 32;
	 int a524719993  = 33;
	 int a548050643  = 34;
	 int a104481388 = 12;
	 int a1151361287 = 215;
	 int a1969216760  = 32;
	 int a30494462 = 34;
	 int a341216798 = 189;
	 int a1661512523  = 34;
	 int a778006913 = 2;
	 int a578474405 = 137;
	 int a160322672 = 115;
	 int a1337636546 = 243;
	 int a1348848030 = 10;
	 int a358386401 = 3;
	 int a2104091782 = 9;
	 int a707706067 = 1;
	 int a1844895357 = 1;
	 int a1761958712 = 0;
	 int a698359753 = 0;
	 int a1711183540 = 0;
	 int a1451139861 = 1;
	 int a639488566 = 1;
	 int a854924571 = 0;
	 int a1835250293 = 0;
	 int a213897350 = 0;
	 int a462273359 = 0;
	 int a1329406336 = 0;
	 int a990043066 = 3;
	 int a419312954 = 1;
	 int a1054543477 = 1;
	 int a156979206 = 3;
	 int a1785777793 = 3;
	 int a295012665 = 2;
	 int a1933720537 = 0;
	 int a1224489519 = 0;
	 int a1233331030 = 3;
	 int a1186775761 = 1;
	 int a789762657 = 2;
	 int a456906074 = 0;
	 int a170107731 = 2;


	void errorCheck() {
	    if((((a119997292 == 6 && a1305578599 == 36) && ((197 < a341216798) && (234 >= a341216798))) && a983758263 <=  -6)){
	    cf = 0;
	    __VERIFIER_error(0);
	    }
	    if((((94 < a1728405119 && a524719993 == 32) && a721272783 == 11) && ((-6 < a983758263) && (203 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(1);
	    }
	    if((((a703247202 == 32 && 76 < a803418896) && a721272783 == 10) && ((-6 < a983758263) && (203 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(2);
	    }
	    if((((a369798198 == 33 && a1700231631 == 6) && a721272783 == 17) && ((-6 < a983758263) && (203 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(3);
	    }
	    if((((a1213722969 == 10 && a834646264 == 6) && a341216798 <=  197) && a983758263 <=  -6)){
	    cf = 0;
	    __VERIFIER_error(4);
	    }
	    if((((a2004613952 == 6 && ((5 < a803418896) && (76 >= a803418896))) && a721272783 == 10) && ((-6 < a983758263) && (203 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(5);
	    }
	    if((((a1323955799 == 35 && ((148 < a1352986605) && (317 >= a1352986605))) && a1895857334 == 6) && ((203 < a983758263) && (406 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(6);
	    }
	    if((((a350392085 == 9 && a404763935 == 11) && 178 < a1826277115) && 406 < a983758263)){
	    cf = 0;
	    __VERIFIER_error(7);
	    }
	    if((((a369798198 == 34 && a263219509 == 8) && ((-158 < a1826277115) && (53 >= a1826277115))) && 406 < a983758263)){
	    cf = 0;
	    __VERIFIER_error(8);
	    }
	    if((((a1213722969 == 8 && a834646264 == 6) && a341216798 <=  197) && a983758263 <=  -6)){
	    cf = 0;
	    __VERIFIER_error(9);
	    }
	    if((((a834646264 == 12 && a965340096 == 35) && ((53 < a1826277115) && (178 >= a1826277115))) && 406 < a983758263)){
	    cf = 0;
	    __VERIFIER_error(10);
	    }
	    if((((a757937656 == 6 && a2097567994 == 32) && a721272783 == 15) && ((-6 < a983758263) && (203 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(11);
	    }
	    if((((a268551986 == 32 && a263219509 == 6) && ((-158 < a1826277115) && (53 >= a1826277115))) && 406 < a983758263)){
	    cf = 0;
	    __VERIFIER_error(12);
	    }
	    if((((a834646264 == 7 && a965340096 == 35) && ((53 < a1826277115) && (178 >= a1826277115))) && 406 < a983758263)){
	    cf = 0;
	    __VERIFIER_error(13);
	    }
	    if((((a1969216760 == 32 && a2004613952 == 8) && a1895857334 == 7) && ((203 < a983758263) && (406 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(14);
	    }
	    if((((a834646264 == 11 && a965340096 == 35) && ((53 < a1826277115) && (178 >= a1826277115))) && 406 < a983758263)){
	    cf = 0;
	    __VERIFIER_error(15);
	    }
	    if((((a369798198 == 33 && a1521644128 == 3) && 298 < a341216798) && a983758263 <=  -6)){
	    cf = 0;
	    __VERIFIER_error(16);
	    }
	    if((((a541588245 == 34 && a2097567994 == 36) && a721272783 == 15) && ((-6 < a983758263) && (203 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(17);
	    }
	    if((((a1240243570 == 12 && a965340096 == 33) && ((53 < a1826277115) && (178 >= a1826277115))) && 406 < a983758263)){
	    cf = 0;
	    __VERIFIER_error(18);
	    }
	    if((((a707417839 <=  -28 && a1075307847 == 36) && a721272783 == 13) && ((-6 < a983758263) && (203 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(19);
	    }
	    if((((((-6 < a1474668405) && (87 >= a1474668405)) && a404763935 == 12) && 178 < a1826277115) && 406 < a983758263)){
	    cf = 0;
	    __VERIFIER_error(20);
	    }
	    if((((a1728405119 <=  -7 && 87 < a1474668405) && a721272783 == 16) && ((-6 < a983758263) && (203 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(21);
	    }
	    if((((270 < a362219248 && a369798198 == 33) && a1895857334 == 8) && ((203 < a983758263) && (406 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(22);
	    }
	    if((((a1667689532 == 34 && a2004613952 == 11) && a1895857334 == 7) && ((203 < a983758263) && (406 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(23);
	    }
	    if((((a358386401 == 7 && a965340096 == 36) && ((53 < a1826277115) && (178 >= a1826277115))) && 406 < a983758263)){
	    cf = 0;
	    __VERIFIER_error(24);
	    }
	    if((((a1964635488 == 33 && ((-160 < a1474668405) && (-6 >= a1474668405))) && a721272783 == 16) && ((-6 < a983758263) && (203 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(25);
	    }
	    if((((94 < a1728405119 && a1569588614 <=  -89) && a721272783 == 12) && ((-6 < a983758263) && (203 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(26);
	    }
	    if((((a965340096 == 36 && a1521644128 == 5) && 298 < a341216798) && a983758263 <=  -6)){
	    cf = 0;
	    __VERIFIER_error(27);
	    }
	    if((((a1700231631 == 3 && a1756173294 <=  76) && ((234 < a341216798) && (298 >= a341216798))) && a983758263 <=  -6)){
	    cf = 0;
	    __VERIFIER_error(28);
	    }
	    if((((a1323955799 == 32 && ((148 < a1352986605) && (317 >= a1352986605))) && a1895857334 == 6) && ((203 < a983758263) && (406 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(29);
	    }
	    if((((a296421163 == 32 && 169 < a153258473) && a1895857334 == 9) && ((203 < a983758263) && (406 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(30);
	    }
	    if((((a1348848030 == 13 && ((-174 < a803418896) && (5 >= a803418896))) && a721272783 == 10) && ((-6 < a983758263) && (203 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(31);
	    }
	    if((((a1354435613 == 34 && ((76 < a1756173294) && (113 >= a1756173294))) && ((234 < a341216798) && (298 >= a341216798))) && a983758263 <=  -6)){
	    cf = 0;
	    __VERIFIER_error(32);
	    }
	    if((((((-1 < a1337636546) && (77 >= a1337636546)) && ((113 < a1756173294) && (221 >= a1756173294))) && ((234 < a341216798) && (298 >= a341216798))) && a983758263 <=  -6)){
	    cf = 0;
	    __VERIFIER_error(33);
	    }
	    if((((a1700231631 == 10 && a1756173294 <=  76) && ((234 < a341216798) && (298 >= a341216798))) && a983758263 <=  -6)){
	    cf = 0;
	    __VERIFIER_error(34);
	    }
	    if((((a263638061 == 8 && a153649526 == 33) && a1826277115 <=  -158) && 406 < a983758263)){
	    cf = 0;
	    __VERIFIER_error(35);
	    }
	    if((((a1521644128 == 5 && a965340096 == 32) && ((53 < a1826277115) && (178 >= a1826277115))) && 406 < a983758263)){
	    cf = 0;
	    __VERIFIER_error(36);
	    }
	    if((((a1574467713 == 5 && ((73 < a1569588614) && (167 >= a1569588614))) && a721272783 == 12) && ((-6 < a983758263) && (203 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(37);
	    }
	    if((((a1969216760 == 33 && a2097567994 == 34) && a721272783 == 15) && ((-6 < a983758263) && (203 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(38);
	    }
	    if((((a1661512523 == 32 && a1521644128 == 9) && 298 < a341216798) && a983758263 <=  -6)){
	    cf = 0;
	    __VERIFIER_error(39);
	    }
	    if((((a811861560 == 36 && a1305578599 == 34) && ((197 < a341216798) && (234 >= a341216798))) && a983758263 <=  -6)){
	    cf = 0;
	    __VERIFIER_error(40);
	    }
	    if((((a1969216760 == 33 && ((-4 < a1257505051) && (19 >= a1257505051))) && a1895857334 == 10) && ((203 < a983758263) && (406 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(41);
	    }
	    if((((a263638061 == 7 && a1574467713 == 1) && a1895857334 == 11) && ((203 < a983758263) && (406 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(42);
	    }
	    if((((a1683451995 == 4 && a2004613952 == 12) && a1895857334 == 7) && ((203 < a983758263) && (406 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(43);
	    }
	    if((((a834646264 == 8 && a965340096 == 35) && ((53 < a1826277115) && (178 >= a1826277115))) && 406 < a983758263)){
	    cf = 0;
	    __VERIFIER_error(44);
	    }
	    if((((((13 < a1260876233) && (198 >= a1260876233)) && a2004613952 == 13) && a1895857334 == 7) && ((203 < a983758263) && (406 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(45);
	    }
	    if((((a1875686186 == 12 && a2087632595 == 35) && a1895857334 == 13) && ((203 < a983758263) && (406 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(46);
	    }
	    if((((a1661512523 == 36 && a1521644128 == 9) && 298 < a341216798) && a983758263 <=  -6)){
	    cf = 0;
	    __VERIFIER_error(47);
	    }
	    if((((270 < a362219248 && a2004613952 == 10) && a1895857334 == 7) && ((203 < a983758263) && (406 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(48);
	    }
	    if((((a369798198 == 35 && a1521644128 == 3) && 298 < a341216798) && a983758263 <=  -6)){
	    cf = 0;
	    __VERIFIER_error(49);
	    }
	    if((((a1597554373 == 33 && 167 < a1569588614) && a721272783 == 12) && ((-6 < a983758263) && (203 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(50);
	    }
	    if((((((-1 < a1337636546) && (77 >= a1337636546)) && a2004613952 == 9) && a1895857334 == 7) && ((203 < a983758263) && (406 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(51);
	    }
	    if((((a1474668405 <=  -160 && ((-186 < a1345687529) && (-72 >= a1345687529))) && a721272783 == 14) && ((-6 < a983758263) && (203 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(52);
	    }
	    if((((a1032084261 == 35 && a834646264 == 8) && a341216798 <=  197) && a983758263 <=  -6)){
	    cf = 0;
	    __VERIFIER_error(53);
	    }
	    if((((((53 < a823982083) && (149 >= a823982083)) && a834646264 == 7) && a341216798 <=  197) && a983758263 <=  -6)){
	    cf = 0;
	    __VERIFIER_error(54);
	    }
	    if((((((157 < a707417839) && (268 >= a707417839)) && ((85 < a1352986605) && (148 >= a1352986605))) && a1895857334 == 6) && ((203 < a983758263) && (406 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(55);
	    }
	    if((((a961167689 == 7 && ((-34 < a1257505051) && (-4 >= a1257505051))) && a1895857334 == 10) && ((203 < a983758263) && (406 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(56);
	    }
	    if((((a1728405119 <=  -7 && a524719993 == 32) && a721272783 == 11) && ((-6 < a983758263) && (203 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(57);
	    }
	    if((((a1574467713 == 2 && 19 < a1257505051) && a1895857334 == 10) && ((203 < a983758263) && (406 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(58);
	    }
	    if((((236 < a1337636546 && a834646264 == 5) && a341216798 <=  197) && a983758263 <=  -6)){
	    cf = 0;
	    __VERIFIER_error(59);
	    }
	    if((((a757937656 == 4 && a2097567994 == 32) && a721272783 == 15) && ((-6 < a983758263) && (203 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(60);
	    }
	    if((((a822442096 <=  -101 && a2041520547 == 36) && a1895857334 == 12) && ((203 < a983758263) && (406 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(61);
	    }
	    if((((a1895857334 == 10 && a1700231631 == 8) && a721272783 == 17) && ((-6 < a983758263) && (203 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(62);
	    }
	    if((((a1597554373 == 36 && a1075307847 == 35) && a721272783 == 13) && ((-6 < a983758263) && (203 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(63);
	    }
	    if((((a661990791 == 8 && a1305578599 == 35) && ((197 < a341216798) && (234 >= a341216798))) && a983758263 <=  -6)){
	    cf = 0;
	    __VERIFIER_error(64);
	    }
	    if((((a268551986 == 34 && a263219509 == 6) && ((-158 < a1826277115) && (53 >= a1826277115))) && 406 < a983758263)){
	    cf = 0;
	    __VERIFIER_error(65);
	    }
	    if((((a1895857334 == 10 && a524719993 == 36) && a721272783 == 11) && ((-6 < a983758263) && (203 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(66);
	    }
	    if((((a1912617323 == 10 && a263219509 == 5) && ((-158 < a1826277115) && (53 >= a1826277115))) && 406 < a983758263)){
	    cf = 0;
	    __VERIFIER_error(67);
	    }
	    if((((a1574467713 == 4 && ((73 < a1569588614) && (167 >= a1569588614))) && a721272783 == 12) && ((-6 < a983758263) && (203 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(68);
	    }
	    if((((a1597554373 == 33 && a1075307847 == 35) && a721272783 == 13) && ((-6 < a983758263) && (203 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(69);
	    }
	    if((((a350392085 == 6 && a404763935 == 11) && 178 < a1826277115) && 406 < a983758263)){
	    cf = 0;
	    __VERIFIER_error(70);
	    }
	    if((((29 < a34679179 && a404763935 == 13) && 178 < a1826277115) && 406 < a983758263)){
	    cf = 0;
	    __VERIFIER_error(71);
	    }
	    if((((a548050643 == 32 && a404763935 == 14) && 178 < a1826277115) && 406 < a983758263)){
	    cf = 0;
	    __VERIFIER_error(72);
	    }
	    if((((((-160 < a1474668405) && (-6 >= a1474668405)) && a1574467713 == 3) && a1895857334 == 11) && ((203 < a983758263) && (406 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(73);
	    }
	    if((((((-139 < a1255449606) && (37 >= a1255449606)) && a153649526 == 34) && a1826277115 <=  -158) && 406 < a983758263)){
	    cf = 0;
	    __VERIFIER_error(74);
	    }
	    if((((a661990791 == 8 && a263219509 == 11) && ((-158 < a1826277115) && (53 >= a1826277115))) && 406 < a983758263)){
	    cf = 0;
	    __VERIFIER_error(75);
	    }
	    if((((a1077149355 == 9 && a1521644128 == 7) && 298 < a341216798) && a983758263 <=  -6)){
	    cf = 0;
	    __VERIFIER_error(76);
	    }
	    if((((a757937656 == 3 && ((-72 < a1345687529) && (75 >= a1345687529))) && a721272783 == 14) && ((-6 < a983758263) && (203 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(77);
	    }
	    if((((a965340096 == 36 && a1574467713 == 8) && a1895857334 == 11) && ((203 < a983758263) && (406 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(78);
	    }
	    if((((a1895857334 == 7 && a524719993 == 36) && a721272783 == 11) && ((-6 < a983758263) && (203 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(79);
	    }
	    if((((a661990791 == 11 && a263219509 == 11) && ((-158 < a1826277115) && (53 >= a1826277115))) && 406 < a983758263)){
	    cf = 0;
	    __VERIFIER_error(80);
	    }
	    if((((a1521644128 == 3 && a965340096 == 32) && ((53 < a1826277115) && (178 >= a1826277115))) && 406 < a983758263)){
	    cf = 0;
	    __VERIFIER_error(81);
	    }
	    if((((a1474668405 <=  -160 && a404763935 == 12) && 178 < a1826277115) && 406 < a983758263)){
	    cf = 0;
	    __VERIFIER_error(82);
	    }
	    if((((a1891437507 == 32 && 75 < a1345687529) && a721272783 == 14) && ((-6 < a983758263) && (203 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(83);
	    }
	    if((((((196 < a617559344) && (416 >= a617559344)) && a1700231631 == 10) && a721272783 == 17) && ((-6 < a983758263) && (203 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(84);
	    }
	    if((((a757937656 == 8 && ((-72 < a1345687529) && (75 >= a1345687529))) && a721272783 == 14) && ((-6 < a983758263) && (203 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(85);
	    }
	    if((((a1348848030 == 9 && 317 < a1352986605) && a1895857334 == 6) && ((203 < a983758263) && (406 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(86);
	    }
	    if((((a1574467713 == 2 && ((73 < a1569588614) && (167 >= a1569588614))) && a721272783 == 12) && ((-6 < a983758263) && (203 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(87);
	    }
	    if((((((234 < a341216798) && (298 >= a341216798)) && a965340096 == 34) && ((53 < a1826277115) && (178 >= a1826277115))) && 406 < a983758263)){
	    cf = 0;
	    __VERIFIER_error(88);
	    }
	    if((((a803418896 <=  -174 && a834646264 == 10) && a341216798 <=  197) && a983758263 <=  -6)){
	    cf = 0;
	    __VERIFIER_error(89);
	    }
	    if((((a1964635488 == 32 && ((-160 < a1474668405) && (-6 >= a1474668405))) && a721272783 == 16) && ((-6 < a983758263) && (203 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(90);
	    }
	    if((((a1683451995 == 6 && a2004613952 == 12) && a1895857334 == 7) && ((203 < a983758263) && (406 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(91);
	    }
	    if((((((73 < a1569588614) && (167 >= a1569588614)) && a1521644128 == 10) && 298 < a341216798) && a983758263 <=  -6)){
	    cf = 0;
	    __VERIFIER_error(92);
	    }
	    if((((a703247202 == 33 && 76 < a803418896) && a721272783 == 10) && ((-6 < a983758263) && (203 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(93);
	    }
	    if((((a1240243570 == 10 && a965340096 == 33) && ((53 < a1826277115) && (178 >= a1826277115))) && 406 < a983758263)){
	    cf = 0;
	    __VERIFIER_error(94);
	    }
	    if((((a1969216760 == 32 && ((-4 < a1257505051) && (19 >= a1257505051))) && a1895857334 == 10) && ((203 < a983758263) && (406 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(95);
	    }
	    if((((((416 < a617559344) && (537 >= a617559344)) && a2041520547 == 34) && a1895857334 == 12) && ((203 < a983758263) && (406 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(96);
	    }
	    if((((a1301446006 <=  64 && a1075307847 == 34) && a721272783 == 13) && ((-6 < a983758263) && (203 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(97);
	    }
	    if((((167 < a1569588614 && a1521644128 == 10) && 298 < a341216798) && a983758263 <=  -6)){
	    cf = 0;
	    __VERIFIER_error(98);
	    }
	    if((((a100021342 <=  3 && ((-6 < a1474668405) && (87 >= a1474668405))) && a721272783 == 16) && ((-6 < a983758263) && (203 >= a983758263)))){
	    cf = 0;
	    __VERIFIER_error(99);
	    }
	}
 void calculate_outputm26(int input) {
    if(((a1125477212 == 32 && a2130183577 <=  103) && ((a1180594800 == 32 && ((( cf==1  && (input == 4)) && a999024345 <=  48) && a2130193413 == 9)) && a63333937 <=  -135))) {
    	cf = 0;
    	a778006913 = (a1241576728 - 4);
    	a1180594800 = 33 ;
    	a1254983042 = (((((((a1254983042 * a2130183577) % 14999) * 2) - 1) / 5) % 101) + 101);
    	a63333937 = (((((a1985899004 * a260539918) % 81) + 17) - 26) - -29);
    	a1675035970 = (((((((a1675035970 * a30494462) % 14999) + 11014) / 5) / 5) % 17) + 189);
    	a813082108 = ((((((a813082108 * a1985899004) % 14999) % 50) + 53) - 24271) + 24272);
    	a1895304149 = 33 ;
    	a1241576728 = (a778006913 + 5);
    	a1125477212 = 33 ;
    	a1318526106 = 33 ;
    	a1644957382 = 33 ;
    	a601495656 = 33 ;
    	a983758263 = (((((((a983758263 * a341216798) % 14999) % 104) + 98) - -1) - 8565) - -8565);
    	a803418896 = ((((((a341216798 * a341216798) % 14999) % 35) + 41) + -1) - -1);
    	a2130183577 = ((((((a2130183577 * a1625516355) % 14999) % 63) + 166) + -7771) - -7772);
    	a721272783 = ((a1210910088 / a2061425267) - -10);
    	a30494462 = (((((((a30494462 * a1985899004) % 14999) - -26000) % 92) + -61) - 13067) - -13144);
    	a4442917 = (a190525986 + -4);
    	a620105235 = ((((((((a620105235 * a63333937) % 14999) % 10) - 170) + 1) * 5) % 10) - 162);
    	a709568404 = 33 ;
    	a786258498 = (a834646264 + 3);
    	a76745981 = 33 ;
    	a26346326 = 33 ;
    	a2004613952 = (a2026977784 - -5);
    	a999024345 = (((((((a999024345 * a1985899004) % 14999) / 5) + 8833) - 13713) % 41) - -120);
    	a2026977784 = (a1210910088 + 7);
    	a1210910088 = ((a2087535773 + a786258498) + -11); 
    	 printf("%d\n", 18); fflush(stdout); 
    } 
}
 void calculate_outputm29(int input) {
    if(((((a786258498 == 8 && ((input == 6) &&  cf==1 )) && a778006913 == 1) && a1211013485 == 32) && (a1959068056 == 8 && (a1478681170 == 3 && a620105235 <=  -182)))) {
    	cf = 0;
    	a1625516355 = (((((((a983758263 * a341216798) % 14999) - -11124) - 19921) * 1) % 13) + -93);
    	a1151361287 = ((((((a1254983042 * a983758263) % 14999) / 5) + -27885) % 86) + 212);
    	a302110279 = 33 ;
    	a1018383389 = ((((((a1675035970 * a341216798) % 14999) - -2639) - -10057) % 74) - -93); 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((a1318526106 == 32 && a1180594800 == 32) && a1210910088 == 1) && (a601495656 == 32 && ((a260539918 <=  -44 && ( cf==1  && (input == 9))) && a1644957382 == 32)))) {
    	cf = 0;
    	a1018383389 = ((((((a983758263 * a341216798) % 14999) + -12399) * 1) % 74) - -91);
    	a302110279 = 33 ;
    	a1625516355 = (((((((a1675035970 * a30494462) % 14999) % 13) - 93) - 3) / 5) - 82);
    	a1151361287 = ((((((a999024345 * a30494462) % 14999) % 86) - -162) * 1) + -1); 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((a1895304149 == 32 && a2073482783 == 32) && a4442917 == 5) && (((a1180594800 == 32 && ( cf==1  && (input == 11))) && a26346326 == 32) && a1830659124 == 9))) {
    	cf = 0;
    	a30494462 = ((((((a341216798 * a63333937) % 14999) % 92) + 32) + -18731) + 18730);
    	a1254983042 = (((((((a1254983042 * a341216798) % 14999) % 101) + 100) / 5) - -5599) + -5470);
    	a813082108 = (((((((a813082108 * a260539918) % 14999) % 50) - -53) - 2750) + 16873) + -14122);
    	a983758263 = ((((((((a983758263 * a999024345) % 14999) % 104) + 99) * 5) - -11879) % 104) + 39);
    	a4442917 = ((a1478681170 + a1959068056) + -5);
    	a721272783 = (a1478681170 - -11);
    	a778006913 = ((a786258498 / a1830659124) - -2);
    	a63333937 = ((((((a63333937 * a2130183577) % 14999) % 81) + -51) - -28437) - 28439);
    	a2073482783 = 33 ;
    	a999024345 = (((((a1018383389 * a1018383389) % 41) - -63) - 12) + 10);
    	a1210910088 = ((a1213722969 + a1241576728) + -15);
    	a26346326 = 33 ;
    	a1895304149 = 33 ;
    	a1675035970 = (((((((a1675035970 * a30494462) % 14999) + 12173) / 5) / 5) % 17) + 188);
    	a620105235 = (((((((a620105235 * a1625516355) % 14999) - -7092) + 4420) - 31325) % 10) + -168);
    	a1891437507 = 35 ;
    	a1644957382 = 33 ;
    	a1345687529 = ((((((a341216798 * a983758263) % 14999) % 14962) + 15037) - 0) + 1);
    	a2130183577 = ((((((a2130183577 * a1151361287) % 14999) + -1987) % 63) - -167) + -1);
    	a1478681170 = (a1830659124 + -5); 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((((a813082108 <=  3 && a260539918 <=  -44) && a263151501 == 32) && a1675035970 <=  171) && (a708839806 == 32 && (a1211013485 == 32 && ((input == 12) &&  cf==1 ))))) {
    	cf = 0;
    	a1018383389 = (((((((a2130183577 * a30494462) % 14999) * 2) % 74) + 92) / 5) - -89);
    	a302110279 = 33 ;
    	a1151361287 = (((((((a30494462 * a260539918) % 14999) % 86) + 126) / 5) + -23513) - -23670);
    	a1625516355 = (((((((a63333937 * a260539918) % 14999) % 13) - 104) * 9) / 10) - -1); 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm31(int input) {
    if(((a778006913 == 1 && ((input == 5) &&  cf==1 )) && (a1916853335 == 5 && ((a1249952537 == 4 && (a1211013485 == 32 && a1018383389 <=  17)) && a1180594800 == 32)))) {
    	cf = 0;
    	a2026977784 = (a2061425267 + -1);
    	a217799639 = (((((((a341216798 * a341216798) % 14999) % 28) + -28) - 2) * 9) / 10);
    	a1625516355 = (((((((a1625516355 * a813082108) % 14999) % 37) + -42) * 5) % 37) + -35);
    	a999024345 = (((((((a999024345 * a217799639) % 14999) % 64) + 195) * 1) + -7578) + 7578);
    	a708839806 = 34 ;
    	a2004613952 = (a1249952537 + 4);
    	a1180594800 = 34 ;
    	a1895857334 = ((a1830659124 + a1830659124) + -11);
    	a76745981 = 34 ;
    	a1985899004 = ((((((a341216798 * a341216798) % 14999) % 76) - -447) - 12978) + 12979);
    	a1675035970 = (((((((a341216798 * a341216798) % 14999) * 2) + 3) * 1) % 51) - -260);
    	a983758263 = ((((((a983758263 * a1254983042) % 14999) + 6911) * 1) % 101) + 249);
    	a2130193413 = ((a2061425267 / a2061425267) - -10);
    	a2073482783 = 33 ;
    	a778006913 = (a2026977784 - 6);
    	a1969216760 = 36 ;
    	a709568404 = 34 ;
    	a30494462 = (((((((a30494462 * a1625516355) % 14999) % 85) - -189) + -23295) * 1) + 23265);
    	a1210910088 = (a2026977784 + -6);
    	a263151501 = 34 ;
    	a1018383389 = ((((((((a1018383389 * a1151361287) % 14999) - 12398) % 21) - -189) * 5) % 21) - -184);
    	a786258498 = (a2026977784 + 1);
    	a2087535773 = ((a2004613952 - a1830659124) - -6);
    	a1249952537 = ((a1916853335 + a786258498) + -9);
    	a1254983042 = (((((((a2130183577 * a1985899004) % 14999) + -29273) % 105) + 379) + -18049) - -18025);
    	a4442917 = (a2061425267 + -3);
    	a1241576728 = (a2130193413 - 3);
    	a1125477212 = 34 ;
    	a1774184757 = ((((((a1774184757 * a813082108) % 14999) + 13443) % 66) - -103) * 1);
    	a813082108 = (((((((a813082108 * a1254983042) % 14999) % 50) - -54) / 5) * 10) / 2);
    	a1644957382 = 34 ;
    	a302110279 = 34 ;
    	a26346326 = 34 ;
    	a1478681170 = ((a778006913 * a1959068056) + -19);
    	a1151361287 = ((((((a260539918 * a823982083) % 14999) + 6994) % 20) + 271) - -1);
    	a1959068056 = ((a1210910088 / a190525986) - -10);
    	a601495656 = 34 ;
    	a1895304149 = 34 ;
    	a190525986 = ((a834646264 / a2061425267) + 11);
    	a1830659124 = ((a2061425267 / a2026977784) - -10);
    	a1211013485 = 34 ;
    	a63333937 = ((((((a63333937 * a620105235) % 14999) % 106) + 136) - -2) + -1);
    	a2061425267 = (a786258498 + 2); 
    	 printf("%d\n", 26); fflush(stdout); 
    } if((((a2061425267 == 10 && a1916853335 == 5) && a2087535773 == 3) && ((a63333937 <=  -135 && (((input == 12) &&  cf==1 ) && a263151501 == 32)) && a1151361287 <=  75))) {
    	cf = 0;
    	a1305578599 = 33 ;
    	a1830659124 = (a2026977784 + 4);
    	a341216798 = ((((((((a341216798 * a260539918) % 14999) % 18) - -215) + 1) * 5) % 18) + 216);
    	a813082108 = (((((a813082108 * a999024345) % 14999) + -14995) * 1) + -5);
    	a104481388 = (a190525986 + 4);
    	a1180594800 = 34 ;
    	a620105235 = (((((a1774184757 * a217799639) % 14999) + -28381) * 1) - 765);
    	a260539918 = (((((a30494462 * a823982083) % 14999) - 6138) - 2840) / 5);
    	a1478681170 = ((a2061425267 + a834646264) + -12);
    	a1151361287 = ((((((a1151361287 * a63333937) % 14999) * 2) % 20) + 271) - 1);
    	a1211013485 = 32 ;
    	a2130183577 = (((((a1675035970 * a1675035970) % 14999) - 14914) + -57) - 20);
    	a1644957382 = 32 ;
    	a999024345 = (((((((a999024345 * a1018383389) % 14999) + 14129) - 935) + -19803) % 64) - -196);
    	a63333937 = (((((a63333937 * a1254983042) % 14999) + -26643) + 26189) - 19324); 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a2073482783 == 32 && a1983740902 == 32) && ((a2130193413 == 9 && ((a30494462 <=  -62 && ((input == 14) &&  cf==1 )) && a26346326 == 32)) && a190525986 == 9))) {
    	a1844895357 -= (a1844895357 - 20) < a1844895357 ? 6 : 0;
    	cf = 0;
    	a266166646 = (((((((a823982083 * a999024345) % 14999) + -7217) % 19) + 332) / 5) - -260);
    	a1125477212 = 34 ;
    	a1210910088 = ((a1478681170 * a1478681170) - 6);
    	a2087535773 = (a834646264 + -2);
    	a1774184757 = ((((((a1774184757 * a1254983042) % 14999) + 12575) * 1) % 66) + 95);
    	a1895857334 = ((a2026977784 * a778006913) - -6);
    	a26346326 = 34 ;
    	a2087632595 = 34 ;
    	a778006913 = (a190525986 - 6);
    	a2061425267 = (a1210910088 + 9);
    	a813082108 = (((((((a813082108 * a1625516355) % 14999) % 69) + 174) / 5) + -3552) - -3675);
    	a2026977784 = a2130193413;
    	a983758263 = (((((((a983758263 * a266166646) % 14999) + 17360) % 101) - -247) / 5) - -173);
    	a2073482783 = 34 ;
    	a217799639 = (((((((a341216798 * a341216798) % 14999) * 2) + -2) - 1) % 28) - 29);
    	a786258498 = ((a2061425267 + a1478681170) - 5);
    	a2130193413 = (a1895857334 + -2);
    	a1895304149 = 34 ;
    	a1254983042 = ((((((a217799639 * a2130183577) % 105) - -309) / 5) * 10) / 2);
    	a620105235 = ((((((a813082108 * a813082108) % 14999) % 94) - 90) + 15650) - 15639);
    	a1916853335 = (a2061425267 - 5);
    	a1018383389 = ((((((a1018383389 * a260539918) % 14999) - -13685) % 21) - -189) + 2);
    	a63333937 = ((((((a63333937 * a1151361287) % 14999) % 106) - -137) - 5890) - -5890);
    	a260539918 = ((((((a341216798 * a341216798) % 14999) % 73) + 66) - 1) - 0);
    	a1644957382 = 34 ;
    	a1625516355 = (((((((a1625516355 * a999024345) % 14999) % 37) - 42) + -19448) / 5) - -3859);
    	a1959068056 = (a190525986 + 1);
    	a1985899004 = (((((((a341216798 * a341216798) % 14999) - 4393) - 8195) * 1) % 76) - -447);
    	a708839806 = 34 ;
    	a1249952537 = (a1830659124 - 3);
    	a1983740902 = 34 ;
    	a263151501 = 34 ;
    	a190525986 = (a1241576728 - -5);
    	a302110279 = 34 ;
    	a999024345 = ((((((a266166646 * a341216798) % 14999) * 2) % 64) - -196) * 1);
    	a1180594800 = 34 ;
    	a1211013485 = 34 ;
    	a30494462 = (((((((a30494462 * a2130183577) % 14999) % 85) + 210) - -1) + 7717) - 7716);
    	a4442917 = ((a1916853335 * a1478681170) + -14);
    	a1675035970 = ((((((a341216798 * a341216798) % 14999) - -2890) % 51) + 260) - -1);
    	a1241576728 = (a786258498 + -2);
    	a1318526106 = 34 ;
    	a76745981 = 34 ;
    	a709568404 = 34 ;
    	a601495656 = 34 ;
    	a1151361287 = ((((((a1985899004 * a217799639) % 14999) % 20) + 270) - -2) + -1);
    	a1830659124 = (a2061425267 - 1);
    	a1478681170 = (a1210910088 - -2); 
    	 printf("%d\n", 26); fflush(stdout); 
    } 
}
 void calculate_outputm33(int input) {
    if(((a1125477212 == 32 && (a620105235 <=  -182 && a1151361287 <=  75)) && (((a190525986 == 9 && ((input == 6) &&  cf==1 )) && a1249952537 == 4) && a1241576728 == 6))) {
    	cf = 0;
    	a1254983042 = (((((((a1985899004 * a1625516355) % 14999) % 105) - -307) / 5) + -4666) + 4879);
    	a263638061 = ((a4442917 * a4442917) + -14);
    	a1211013485 = 34 ;
    	a1985899004 = ((((((((a1985899004 * a1254983042) % 14999) + 7155) % 76) - -448) + 4172) * 1) / 10);
    	a30494462 = (((((((a30494462 * a813082108) % 14999) - -13176) - -1154) / 5) % 85) + 209);
    	a2073482783 = 34 ;
    	a1895857334 = ((a1241576728 * a778006913) + 5);
    	a217799639 = ((((((((a217799639 * a1151361287) % 14999) * 2) % 28) - 30) * 5) % 28) + -7);
    	a2061425267 = (a1210910088 + 11);
    	a620105235 = (((((((a620105235 * a1625516355) % 14999) / 5) + -24876) - 3708) % 94) + -64);
    	a1895304149 = 34 ;
    	a999024345 = ((((((a999024345 * a1254983042) % 14999) % 64) - -196) + 2132) - 2132);
    	a2130183577 = ((((((a1254983042 * a63333937) % 14999) - 12667) % 12) + 244) - 1);
    	a708839806 = 34 ;
    	a26346326 = 34 ;
    	a190525986 = ((a1895857334 - a1895857334) + 11);
    	a778006913 = (a2061425267 + -9);
    	a1983740902 = 34 ;
    	a1574467713 = ((a1249952537 / a2026977784) + 1);
    	a1318526106 = 34 ;
    	a1249952537 = (a786258498 - 2);
    	a260539918 = (((((((a30494462 * a1985899004) % 14999) + -28042) % 73) - -83) - 14663) + 14690);
    	a1675035970 = (((((((a341216798 * a2130183577) % 14999) - 1530) / 5) + -7728) % 51) + 299);
    	a1125477212 = 34 ;
    	a601495656 = 34 ;
    	a1644957382 = 34 ;
    	a2026977784 = (a1210910088 + 8);
    	a1241576728 = (a2130193413 - 3);
    	a63333937 = (((((((a341216798 * a1774184757) % 14999) % 106) - -135) - 0) + -8167) - -8169);
    	a263151501 = 34 ;
    	a302110279 = 34 ;
    	a813082108 = ((((((a1254983042 * a1985899004) % 14999) - 12477) / 5) % 69) + 173);
    	a983758263 = ((((((((a983758263 * a341216798) % 14999) - -14121) % 101) + 305) * 5) % 101) + 208);
    	a1959068056 = (a1478681170 + 7);
    	a2087535773 = (a1574467713 + 4);
    	a4442917 = a1916853335;
    	a709568404 = 34 ;
    	a1151361287 = (((((((a341216798 * a1774184757) % 14999) % 20) - -271) + 1) / 5) + 229);
    	a1478681170 = ((a1210910088 + a1210910088) - -3);
    	a786258498 = (a834646264 + 2);
    	a1830659124 = ((a1895857334 + a1916853335) - 7);
    	a1625516355 = (((((((a1625516355 * a1985899004) % 14999) - -17650) * 1) * 1) % 37) + -46);
    	a1210910088 = (a834646264 - 5); 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((((input == 13) &&  cf==1 ) && a1210910088 == 1) && a999024345 <=  48) && (a1151361287 <=  75 && (a1644957382 == 32 && (a1249952537 == 4 && a2026977784 == 7))))) {
    	cf = 0;
    	a1125477212 = 34 ;
    	a1574467713 = ((a1959068056 * a2026977784) - 55);
    	a1151361287 = ((((((((a1151361287 * a217799639) % 14999) % 20) - -270) * 5) * 5) % 20) - -262);
    	a2073482783 = 34 ;
    	a813082108 = (((((((a813082108 * a63333937) % 14999) % 69) - -174) + -1) + 10820) + -10818);
    	a1644957382 = 34 ;
    	a2087535773 = ((a1959068056 * a1249952537) - 27);
    	a1241576728 = (a1574467713 - -7);
    	a263638061 = (a1210910088 - -10);
    	a260539918 = ((((((a1151361287 * a1774184757) % 14999) % 73) + 66) + -1) - 0);
    	a601495656 = 34 ;
    	a2061425267 = ((a190525986 + a1574467713) + 2);
    	a190525986 = (a786258498 - -3);
    	a302110279 = 34 ;
    	a2130183577 = ((((((((a63333937 * a620105235) % 14999) % 12) + 231) + 0) / 5) * 51) / 10);
    	a709568404 = 34 ;
    	a1959068056 = ((a778006913 / a778006913) - -9);
    	a1983740902 = 34 ;
    	a983758263 = (((((((a983758263 * a341216798) % 14999) - -4572) + 992) * 1) % 101) + 304);
    	a30494462 = ((((((((a30494462 * a2130183577) % 14999) % 85) - -210) - 1) * 5) % 85) + 187);
    	a1830659124 = (a834646264 + 3);
    	a778006913 = ((a1249952537 + a834646264) - 9);
    	a1985899004 = ((((((a1985899004 * a1625516355) % 14999) % 76) - -447) * 1) + 0);
    	a1675035970 = ((((((((a1151361287 * a1985899004) % 14999) % 51) + 240) + 1) / 5) * 45) / 10);
    	a620105235 = (((((((a620105235 * a983758263) % 14999) / 5) / 5) - -17322) % 94) + -69);
    	a26346326 = 34 ;
    	a4442917 = (a2087535773 + 2);
    	a1625516355 = (((((((a1675035970 * a1985899004) % 14999) % 37) - 67) + 16) - -1603) - 1631);
    	a1895304149 = 34 ;
    	a708839806 = 34 ;
    	a1211013485 = 34 ;
    	a999024345 = (((((((a999024345 * a1254983042) % 14999) % 64) - -195) + 0) / 5) + 119);
    	a1318526106 = 34 ;
    	a1478681170 = ((a2087535773 + a2130193413) - 11);
    	a1895857334 = (a786258498 + 3);
    	a1249952537 = (a1574467713 - -5);
    	a1210910088 = ((a263638061 - a2130193413) - -3);
    	a2026977784 = (a1916853335 - -2);
    	a786258498 = (a834646264 - -2);
    	a263151501 = 34 ;
    	a1254983042 = (((((((a1254983042 * a63333937) % 14999) / 5) % 105) - -235) * 9) / 10);
    	a217799639 = ((((((a217799639 * a1675035970) % 14999) % 28) + -28) + -1) - 1);
    	a63333937 = (((((((a63333937 * a1774184757) % 14999) % 106) - -93) * 5) % 106) + 92); 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((a1254983042 <=  -2 && ((((input == 15) &&  cf==1 ) && a1249952537 == 4) && a26346326 == 32)) && a1318526106 == 32) && (a1478681170 == 3 && a2026977784 == 7))) {
    	a1224489519 -= (a1224489519 - 20) < a1224489519 ? 2 : 0;
    	cf = 0;
    	a1675035970 = (((((((a813082108 * a813082108) % 14999) % 51) - -259) / 5) - -3879) - 3668);
    	a263151501 = 34 ;
    	a1125477212 = 34 ;
    	a1213722969 = (a1478681170 - -8);
    	a30494462 = (((((((a30494462 * a1675035970) % 14999) % 85) - -209) / 5) + 24267) + -24106);
    	a1151361287 = ((((((a1151361287 * a813082108) % 14999) % 20) + 271) * 1) + -1);
    	a1018383389 = ((((((a813082108 * a813082108) % 14999) % 21) - -189) - 29597) + 29596);
    	a1241576728 = (a2130193413 + -3);
    	a2073482783 = 34 ;
    	a1254983042 = (((((((a813082108 * a1675035970) % 14999) + -9483) + 15355) * 1) % 105) - -309);
    	a1830659124 = (a1241576728 + 3);
    	a63333937 = ((((((a1625516355 * a1018383389) % 14999) - -22071) + 1011) % 106) + 128);
    	a1959068056 = ((a1213722969 - a834646264) - -7);
    	a1826277115 = ((((((a1774184757 * a341216798) % 14999) % 14921) + -15078) - 1) * 1);
    	a2061425267 = 12;
    	a1985899004 = ((((((a1985899004 * a1151361287) % 14999) % 76) + 448) - 1) - -1);
    	a1774184757 = ((((((a1254983042 * a63333937) % 14999) - -3582) % 66) + 81) + -41);
    	a1318526106 = 34 ;
    	a4442917 = ((a1916853335 - a1241576728) + 8);
    	a217799639 = (((((((a217799639 * a1826277115) % 14999) + -29533) * 1) * 1) % 28) + -30);
    	a1249952537 = (a1478681170 - -3);
    	a709568404 = 34 ;
    	a2026977784 = (a2061425267 + -3);
    	a601495656 = 34 ;
    	a153649526 = 36 ;
    	a1211013485 = 34 ;
    	a786258498 = (a190525986 - -1);
    	a2130183577 = ((((((a813082108 * a1675035970) % 14999) / 5) / 5) % 12) + 242);
    	a26346326 = 34 ;
    	a2087535773 = (a1478681170 + 2);
    	a1210910088 = (a834646264 + -5);
    	a620105235 = ((((((a2130183577 * a260539918) % 14999) % 94) + -64) - 2) - -2);
    	a1644957382 = 34 ;
    	a778006913 = (a1959068056 - 7);
    	a76745981 = 34 ;
    	a708839806 = 34 ;
    	a1625516355 = ((((((a1625516355 * a620105235) % 14999) % 37) - 42) - 4222) - -4222);
    	a983758263 = ((((((a983758263 * a813082108) % 14999) % 14796) + 15202) / 5) + 19231);
    	a190525986 = ((a1210910088 / a2026977784) + 11);
    	a999024345 = (((((((a999024345 * a30494462) % 14999) * 2) % 64) - -196) - -11073) - 11073);
    	a1983740902 = 34 ;
    	a1478681170 = (a1213722969 + -6);
    	a1895304149 = 34 ;
    	a813082108 = (((((((a813082108 * a1151361287) % 14999) - 14202) % 69) + 174) + 18209) + -18208); 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a1959068056 == 8 && (a709568404 == 32 && (a1985899004 <=  174 && (a1318526106 == 32 && ((((input == 8) &&  cf==1 ) && a2073482783 == 32) && a1983740902 == 32)))))) {
    	cf = 0;
    	a721272783 = ((a1478681170 / a778006913) + 8);
    	a1210910088 = (a721272783 - 9);
    	a1728405119 = ((((((a341216798 * a341216798) % 14999) * 2) % 14996) - 15002) * 1);
    	a983758263 = ((((((a983758263 * a1625516355) % 14999) - -160) % 104) - 5) - -44);
    	a786258498 = (a1959068056 + 1);
    	a30494462 = ((((((a30494462 * a999024345) % 14999) % 92) - -31) - -1) + 1);
    	a1895304149 = 33 ;
    	a26346326 = 33 ;
    	a76745981 = 33 ;
    	a524719993 = 32 ;
    	a2087535773 = ((a1241576728 / a1241576728) - -3);
    	a1985899004 = (((((((a1985899004 * a999024345) % 14999) / 5) % 98) - -273) / 5) - -201);
    	a217799639 = (((((((a217799639 * a983758263) % 14999) + 4848) % 69) + -128) - -15391) + -15391);
    	a1625516355 = ((((((a813082108 * a813082108) % 14999) + -5674) / 5) % 13) - 94);
    	a1241576728 = a2026977784;
    	a778006913 = (a1830659124 - 7);
    	a190525986 = (a834646264 + 2);
    	a813082108 = (((((((a813082108 * a999024345) % 14999) - 1563) * 1) + 16100) % 50) - -54); 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm34(int input) {
    if(((a263151501 == 32 && (a63333937 <=  -135 && (( cf==1  && (input == 4)) && a1830659124 == 9))) && ((a1895304149 == 32 && a1625516355 <=  -109) && a708839806 == 32))) {
    	a456906074 -= (a456906074 - 20) < a456906074 ? 4 : 0;
    	cf = 0;
    	a721272783 = (a2061425267 + 5);
    	a190525986 = ((a1478681170 * a721272783) - 50);
    	a709568404 = 34 ;
    	a1254983042 = ((((((a217799639 * a341216798) % 14999) + -10385) % 101) + 100) + 1);
    	a263151501 = 34 ;
    	a160322672 = (((((a1018383389 * a813082108) % 14999) + -14956) * 1) / 5);
    	a2097567994 = 33 ;
    	a1959068056 = (a721272783 - 6);
    	a708839806 = 33 ;
    	a1916853335 = ((a721272783 / a1478681170) - -3);
    	a1985899004 = (((((((a217799639 * a1675035970) % 14999) / 5) + 4211) - 22133) % 98) - -363);
    	a1018383389 = ((((((a1254983042 * a356054071) % 14999) * 2) * 1) % 21) + 188);
    	a983758263 = ((((((a983758263 * a341216798) % 14999) % 104) - -99) + -509) + 509);
    	a30494462 = (((((((a30494462 * a983758263) % 14999) - 13704) * 1) / 5) % 92) + 32);
    	a1241576728 = ((a1916853335 - a4442917) + 6);
    	a2026977784 = ((a786258498 + a834646264) + -9);
    	a63333937 = (((((((a63333937 * a1985899004) % 14999) + -90) / 5) * 5) % 81) - 18);
    	a1895304149 = 33 ;
    	a2061425267 = (a2130193413 - -2);
    	a76745981 = 33 ;
    	a1210910088 = (a1916853335 + -4);
    	a260539918 = (((((((a260539918 * a999024345) % 14999) - -23720) - -2084) / 5) % 17) - 25);
    	a302110279 = 34 ;
    	a813082108 = (((((((a341216798 * a1254983042) % 14999) % 50) + 54) * 9) / 10) - -10);
    	a2073482783 = 33 ;
    	a601495656 = 33 ;
    	a2130183577 = ((((((a2130183577 * a160322672) % 14999) - -4144) % 12) + 242) + 2);
    	a786258498 = ((a1830659124 / a1916853335) - -8);
    	a26346326 = 33 ;
    	a1625516355 = ((((((((a1625516355 * a1985899004) % 14999) % 13) + -95) * 5) + 29346) % 13) - 103);
    	a1318526106 = 33 ;
    	a778006913 = (a1916853335 - 4);
    	a4442917 = (a1830659124 + -3);
    	a1830659124 = ((a1210910088 + a2087535773) - -4);
    	a1249952537 = ((a190525986 + a1959068056) - 13); 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((a1018383389 <=  17 && a1210910088 == 1) && ((a601495656 == 32 && ((a260539918 <=  -44 && ( cf==1  && (input == 8))) && a1241576728 == 6)) && a2026977784 == 7))) {
    	a1186775761 += (a1186775761 + 20) > a1186775761 ? 2 : 0;
    	cf = 0;
    	a1211013485 = 32 ;
    	a1916853335 = (a778006913 - -4);
    	a1774184757 = ((((((a30494462 * a1625516355) % 14999) - 22931) - -27406) * 10) / -9);
    	a1985899004 = (((((a260539918 * a356054071) % 14999) + -789) - 10727) * 1);
    	a1254983042 = ((((((a260539918 * a813082108) % 14999) - 15001) - 1) - -16732) - 16730);
    	a1180594800 = 32 ;
    	a1478681170 = (a1916853335 + -2);
    	a834646264 = (a786258498 - 1);
    	a1644957382 = 32 ;
    	a2087535773 = ((a778006913 - a778006913) + 3);
    	a1249952537 = (a2061425267 - 6);
    	a2130193413 = ((a1478681170 / a1830659124) - -9);
    	a2130183577 = (((((((a2130183577 * a260539918) % 14999) + 1984) - -8735) + -9324) % 12) + 242);
    	a1125477212 = 32 ;
    	a999024345 = (((((a1774184757 * a356054071) % 14999) + -2572) - 1897) - 9849);
    	a1675035970 = (((((a1018383389 * a983758263) % 14999) - 6081) - 8885) * 1);
    	a823982083 = (((((((a341216798 * a341216798) % 14999) % 14856) - -15142) + 2) + -18185) - -18185);
    	a1983740902 = 32 ;
    	a620105235 = ((((((a356054071 * a356054071) % 14999) / 5) - -3134) % 94) + -138);
    	a1151361287 = (((((a1774184757 * a1774184757) % 14999) / 5) + -22876) + -6301); 
    	 printf("%d\n", 18); fflush(stdout); 
    } if(((a1210910088 == 1 && (a1318526106 == 32 && ( cf==1  && (input == 11)))) && (((a1959068056 == 8 && a813082108 <=  3) && a190525986 == 9) && a1241576728 == 6))) {
    	a1711183540 -= (a1711183540 - 20) < a1711183540 ? 2 : 0;
    	a1233331030 += (a1233331030 + 20) > a1233331030 ? 2 : 0;
    	a170107731 += (a170107731 + 20) > a170107731 ? 2 : 0;
    	cf = 0;
    	a1895304149 = 33 ;
    	a190525986 = (a2061425267 / a1210910088);
    	a1241576728 = (a834646264 - 2);
    	a2026977784 = ((a2061425267 - a1241576728) - -5);
    	a1625516355 = ((((((a1018383389 * a341216798) % 14999) % 13) - 94) - -27089) + -27089);
    	a1018383389 = ((((((a356054071 * a63333937) % 14999) - 921) % 21) + 201) - -5);
    	a1574467713 = ((a4442917 + a778006913) + 2);
    	a1318526106 = 34 ;
    	a786258498 = (a2130193413 + -1);
    	a30494462 = (((((((a1625516355 * a341216798) % 14999) % 92) - -32) - -4788) - 19216) - -14428);
    	a217799639 = (((((((a217799639 * a1774184757) % 14999) % 69) - 127) * 5) % 69) + -81);
    	a601495656 = 33 ;
    	a26346326 = 33 ;
    	a983758263 = (((((((a983758263 * a356054071) % 14999) % 104) - -98) * 5) % 104) + 99);
    	a260539918 = (((((((a260539918 * a1675035970) % 14999) % 17) - 25) + -1) - -17514) - 17512);
    	a76745981 = 33 ;
    	a721272783 = (a834646264 - -3);
    	a1210910088 = (a1241576728 + -5);
    	a778006913 = (a1959068056 / a1478681170);
    	a1959068056 = ((a2061425267 + a2061425267) + -11);
    	a1830659124 = ((a1249952537 + a786258498) - 3);
    	a708839806 = 34 ;
    	a1569588614 = (((((((a356054071 * a983758263) % 14999) - 109) + -7483) + -4622) % 46) + 119);
    	a2073482783 = 34 ;
    	a2130183577 = ((((((((a2130183577 * a1675035970) % 14999) % 63) - -166) + 1) * 5) % 63) - -118);
    	a4442917 = ((a2026977784 - a2061425267) + 8);
    	a709568404 = 34 ;
    	a63333937 = (((((((a63333937 * a30494462) % 14999) - 12109) - 2145) - -8817) % 106) - -137);
    	a813082108 = ((((((a813082108 * a999024345) % 14999) * 2) % 50) + 53) + 2);
    	a302110279 = 33 ;
    	a263151501 = 33 ;
    	a2061425267 = (a2087535773 + 8); 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm36(int input) {
    if(((a709568404 == 32 && a1774184757 <=  -151) && (((a1151361287 <=  75 && (( cf==1  && (input == 7)) && a999024345 <=  48)) && a26346326 == 32) && a263151501 == 32))) {
    	cf = 0;
    	a999024345 = ((((((a999024345 * a341216798) % 14999) + -10937) % 64) + 195) * 1);
    	a1625516355 = (((((((a813082108 * a30494462) % 14999) - 6619) % 37) + -42) + 2871) - 2871);
    	a1916853335 = (a1210910088 + 6);
    	a2087535773 = ((a834646264 * a1241576728) + -55);
    	a1254983042 = ((((((a1254983042 * a620105235) % 14999) + -28196) / 5) % 105) - -403);
    	a1574467713 = (a2026977784 + -6);
    	a1895857334 = ((a786258498 / a1830659124) + 11);
    	a1241576728 = (a1959068056 - 2);
    	a709568404 = 34 ;
    	a2026977784 = (a778006913 + 8);
    	a1675035970 = (((((((a1985899004 * a1985899004) % 14999) + 10374) + -16126) - 17186) % 51) + 292);
    	a1830659124 = (a1478681170 + 8);
    	a302110279 = 34 ;
    	a1983740902 = 34 ;
    	a620105235 = (((((((a620105235 * a1151361287) % 14999) % 94) - 64) + 5788) + -8539) + 2751);
    	a1644957382 = 34 ;
    	a1478681170 = ((a778006913 + a778006913) + 3);
    	a1125477212 = 34 ;
    	a4442917 = a1916853335;
    	a1895304149 = 34 ;
    	a26346326 = 34 ;
    	a1151361287 = ((((((a1151361287 * a813082108) % 14999) / 5) % 20) - -270) + -1);
    	a1249952537 = (a190525986 + -3);
    	a2130183577 = (((((((a2130183577 * a63333937) % 14999) % 12) + 243) * 1) - -6642) + -6641);
    	a263638061 = (a2130193413 + 2);
    	a601495656 = 34 ;
    	a813082108 = ((((((a999024345 * a999024345) % 14999) % 69) + 174) - -1) + -18);
    	a2130193413 = (a190525986 - -2);
    	a190525986 = (a2061425267 - -1);
    	a983758263 = ((((((a983758263 * a30494462) % 14999) % 101) + 279) - -11) + -25);
    	a708839806 = 34 ;
    	a1211013485 = 34 ;
    	a2073482783 = 34 ;
    	a786258498 = (a778006913 - -9);
    	a63333937 = ((((((a803418896 * a803418896) % 106) - -136) * 5) % 106) - -30);
    	a30494462 = (((((((a30494462 * a260539918) % 14999) - 20196) + -5108) / 5) % 85) - -284);
    	a1318526106 = 34 ;
    	a263151501 = 34 ;
    	a1180594800 = 34 ;
    	a260539918 = ((((((a1774184757 * a1774184757) % 14999) % 73) + 37) + -40) + -3);
    	a2061425267 = (a1210910088 + 11);
    	a1210910088 = (a778006913 - -2);
    	a778006913 = 3; 
    	 printf("%d\n", 17); fflush(stdout); 
    } if(((a260539918 <=  -44 && (( cf==1  && (input == 8)) && a76745981 == 32)) && ((a778006913 == 1 && (a4442917 == 5 && a999024345 <=  48)) && a2061425267 == 10))) {
    	cf = 0;
    	a813082108 = (((((((a813082108 * a620105235) % 14999) + -2581) * 1) - 9745) % 50) + 53);
    	a2130183577 = ((((((a2130183577 * a620105235) % 14999) / 5) % 63) + 166) - 0);
    	a1151361287 = (((((((a1151361287 * a1675035970) % 14999) * 2) * 1) + -3) % 86) + 163);
    	a721272783 = ((a1210910088 + a2061425267) + 3);
    	a1891437507 = 35 ;
    	a1478681170 = (a1916853335 - 1);
    	a30494462 = ((((((a30494462 * a1625516355) % 14999) % 92) + -37) / 5) - -95);
    	a1210910088 = (a834646264 - 8);
    	a1345687529 = ((((((a803418896 * a341216798) % 14999) - -14370) % 14962) - -15037) + 0);
    	a983758263 = (((((((a983758263 * a341216798) % 14999) % 104) - -99) + -1) + -15805) - -15806);
    	a302110279 = 33 ;
    	a26346326 = 33 ;
    	a63333937 = ((((((a63333937 * a1625516355) % 14999) - -2933) % 81) - 81) - 19);
    	a4442917 = (a778006913 - -5);
    	a778006913 = ((a190525986 + a786258498) - 15);
    	a1254983042 = ((((((a1254983042 * a620105235) % 14999) + -13480) % 101) - -100) - -2);
    	a1895304149 = 33 ;
    	a999024345 = ((((((a999024345 * a1018383389) % 14999) / 5) * 5) % 41) + 90);
    	a620105235 = (((((((a620105235 * a1774184757) % 14999) - 11112) % 10) - 171) / 5) + -128); 
    	 printf("%d\n", 17); fflush(stdout); 
    } if(((a263151501 == 32 && (a1774184757 <=  -151 && ((input == 11) &&  cf==1 ))) && ((a786258498 == 8 && (a1895304149 == 32 && a76745981 == 32)) && a1211013485 == 32))) {
    	cf = 0;
    	a1180594800 = 34 ;
    	a1151361287 = ((((((a1985899004 * a63333937) % 14999) / 5) + 15400) % 20) - -254);
    	a190525986 = (a2061425267 - -1);
    	a1211013485 = 34 ;
    	a4442917 = ((a2061425267 - a1210910088) + -2);
    	a2061425267 = (a190525986 - -1);
    	a1318526106 = 34 ;
    	a260539918 = ((((((a260539918 * a1151361287) % 14999) / 5) + -6125) % 73) + 117);
    	a263151501 = 34 ;
    	a1125477212 = 34 ;
    	a2087535773 = ((a1916853335 / a4442917) - -5);
    	a2073482783 = 34 ;
    	a1210910088 = (a786258498 + -5);
    	a1895304149 = 34 ;
    	a26346326 = 34 ;
    	a1625516355 = ((((((a1151361287 * a30494462) % 14999) % 37) + -42) / 5) * 5);
    	a404763935 = ((a2130193413 / a1241576728) + 13);
    	a1959068056 = ((a2130193413 * a190525986) + -89);
    	a778006913 = (a2026977784 - 4);
    	a2130183577 = ((((((((a2130183577 * a620105235) % 14999) % 12) + 243) * 1) * 5) % 12) + 231);
    	a1249952537 = (a4442917 + -1);
    	a999024345 = (((((((a999024345 * a1625516355) % 14999) * 2) - 1) / 5) % 64) + 196);
    	a786258498 = ((a1478681170 / a834646264) + 10);
    	a1826277115 = (((((((a341216798 * a341216798) % 14999) - 7616) / 5) + -6832) * -1) / 10);
    	a1241576728 = (a786258498 + -2);
    	a983758263 = (((((a983758263 * a813082108) % 14999) / 5) - -4483) * 4);
    	a548050643 = 35 ;
    	a813082108 = (((((((a803418896 * a63333937) % 14999) % 69) + 174) + 1) - 8123) + 8122);
    	a1644957382 = 34 ;
    	a2026977784 = (a834646264 + -1);
    	a620105235 = ((((((a803418896 * a1774184757) % 14999) * 2) + -2) % 94) + -64);
    	a30494462 = (((((((a30494462 * a1151361287) % 14999) / 5) % 85) - -209) - -13530) - 13528);
    	a1916853335 = ((a1830659124 * a1830659124) + -74);
    	a709568404 = 34 ;
    	a63333937 = (((((((a63333937 * a1151361287) % 14999) + 8182) % 106) + 135) - 9776) + 9776);
    	a1675035970 = ((((((a1774184757 * a1985899004) % 14999) % 51) - -258) + 3) - 1);
    	a1478681170 = (a1830659124 + -4);
    	a1254983042 = ((((((a1254983042 * a1675035970) % 14999) + -10490) - 2039) % 105) - -400);
    	a217799639 = (((((((a1151361287 * a1985899004) % 14999) % 28) + -55) - 2) + -24175) + 24195);
    	a601495656 = 34 ;
    	a1830659124 = a190525986;
    	a2130193413 = ((a4442917 / a4442917) - -10); 
    	 printf("%d\n", 17); fflush(stdout); 
    } if((((a778006913 == 1 && a620105235 <=  -182) && a1180594800 == 32) && ((a1210910088 == 1 && (((input == 13) &&  cf==1 ) && a1774184757 <=  -151)) && a1254983042 <=  -2))) {
    	cf = 0;
    	a1675035970 = ((((((((a1254983042 * a1254983042) % 14999) % 51) - -213) - -31) - 1726) * -2) / 10);
    	a26346326 = 34 ;
    	a620105235 = ((((((((a1675035970 * a1675035970) % 14999) % 94) + -131) * 5) * 5) % 94) + 3);
    	a30494462 = ((((((a30494462 * a341216798) % 14999) - -484) * 1) % 85) + 211);
    	a813082108 = ((((((a813082108 * a620105235) % 14999) - -11572) % 69) + 173) - 0);
    	a1826277115 = (((((a803418896 * a803418896) % 14921) + -15078) - 1) + -1);
    	a2026977784 = ((a834646264 + a786258498) - 9);
    	a1625516355 = ((((((((a1675035970 * a1675035970) % 14999) - -897) % 37) + -46) / 5) * 89) / 10);
    	a1151361287 = (((((((a1151361287 * a217799639) % 14999) - -6808) % 20) + 271) - -29233) - 29233);
    	a76745981 = 34 ;
    	a190525986 = (a1249952537 + 5);
    	a1213722969 = (a1478681170 - -8);
    	a1895304149 = 34 ;
    	a2130193413 = ((a1249952537 / a1210910088) + 5);
    	a1241576728 = (a2026977784 - a1210910088);
    	a1644957382 = 34 ;
    	a1125477212 = 34 ;
    	a1211013485 = 34 ;
    	a2073482783 = 34 ;
    	a1180594800 = 34 ;
    	a153649526 = 36 ;
    	a2130183577 = ((((((a2130183577 * a1985899004) % 14999) % 12) - -242) + -29999) + 30000);
    	a983758263 = (((((a983758263 * a1774184757) % 14999) - -5109) + 5332) * 1);
    	a1916853335 = (a1210910088 + 6);
    	a1018383389 = ((((((a1254983042 * a1254983042) % 14999) % 21) + 169) * 5) / 5);
    	a2061425267 = (a1210910088 - -11);
    	a1478681170 = (a1830659124 - 4);
    	a2087535773 = (a2061425267 + -7);
    	a786258498 = (a2026977784 + 1);
    	a601495656 = 34 ;
    	a260539918 = ((((((a260539918 * a63333937) % 14999) + -26957) % 73) - -114) + -3);
    	a1830659124 = ((a1916853335 + a4442917) - 1);
    	a778006913 = (a4442917 + -2);
    	a1774184757 = ((((((a1018383389 * a1018383389) % 14999) + 602) % 66) - -59) - -30);
    	a4442917 = (a1959068056 - 3);
    	a1254983042 = ((((((a1254983042 * a1625516355) % 14999) % 105) + 275) + 24) + 5);
    	a709568404 = 34 ;
    	a1318526106 = 34 ;
    	a63333937 = ((((((((a63333937 * a999024345) % 14999) % 106) + 135) + 1484) / 5) * 1) / 10);
    	a999024345 = ((((((a999024345 * a217799639) % 14999) % 64) + 195) / 5) - -173);
    	a263151501 = 34 ;
    	a1210910088 = (a1959068056 + -7); 
    	 printf("%d\n", 17); fflush(stdout); 
    } if(((a1151361287 <=  75 && (a4442917 == 5 && a1125477212 == 32)) && (((a1211013485 == 32 && ( cf==1  && (input == 1))) && a1210910088 == 1) && a2130193413 == 9))) {
    	cf = 0;
    	a1337636546 = (((((((a803418896 * a341216798) % 14999) / 5) / 5) / 5) % 38) - -37);
    	a2087535773 = ((a786258498 / a1478681170) + 3);
    	a63333937 = ((((((((a63333937 * a260539918) % 14999) + 9491) % 106) + 109) / 5) * 15) / 10);
    	a1830659124 = (a778006913 + 10);
    	a1895857334 = ((a4442917 + a1916853335) - 3);
    	a709568404 = 34 ;
    	a778006913 = (a1249952537 + -3);
    	a1211013485 = 34 ;
    	a999024345 = ((((((((a999024345 * a983758263) % 14999) / 5) % 64) - -195) * 5) % 64) + 139);
    	a2004613952 = (a786258498 + 1);
    	a30494462 = (((((((a30494462 * a260539918) % 14999) + -29397) / 5) * 5) % 85) - -291);
    	a1774184757 = (((((((a1774184757 * a2130183577) % 14999) / 5) - -2299) * 5) % 66) - -102);
    	a190525986 = ((a1916853335 + a1959068056) + -4);
    	a263151501 = 34 ;
    	a260539918 = (((((((a260539918 * a983758263) % 14999) % 73) + -3) + 30) * 10) / 9);
    	a2026977784 = (a4442917 - -4);
    	a983758263 = (((((((a983758263 * a1254983042) % 14999) % 101) - -279) / 5) * 10) / 2);
    	a2061425267 = (a2087535773 + 7);
    	a1254983042 = (((((((a1254983042 * a813082108) % 14999) / 5) / 5) - -2458) % 105) - -236); 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm37(int input) {
    if((((((a30494462 <=  -62 && (a1018383389 <=  17 && a1478681170 == 3)) && a813082108 <=  3) && a778006913 == 1) && a999024345 <=  48) && ((input == 8) &&  cf==1 ))) {
    	cf = 0;
    	a302110279 = 33 ;
    	a1213722969 = ((a4442917 + a1830659124) + -3);
    	a1151361287 = (((((((a983758263 * a1675035970) % 14999) / 5) - 15706) + -2742) % 86) - -168);
    	a1018383389 = ((((((((a1018383389 * a260539918) % 14999) % 74) - -93) * 9) / 10) + -27503) + 27512);
    	a834646264 = ((a2061425267 * a2061425267) + -94);
    	a1625516355 = (((((((a620105235 * a30494462) % 14999) / 5) - 22533) + 3372) % 13) + -89); 
    	 printf("%d\n", 19); fflush(stdout); 
    } if(((a30494462 <=  -62 && (a1916853335 == 5 && (( cf==1  && (input == 13)) && a260539918 <=  -44))) && (a1675035970 <=  171 && (a2087535773 == 3 && a2130183577 <=  103)))) {
    	cf = 0;
    	a341216798 = (((((((a341216798 * a983758263) % 14999) - -5839) % 31) - -265) - 4609) + 4609);
    	a1125477212 = 34 ;
    	a1700231631 = ((a2026977784 / a4442917) - -4);
    	a1018383389 = ((((((((a1018383389 * a260539918) % 14999) % 21) - -188) - -3) * 5) % 21) + 186);
    	a601495656 = 34 ;
    	a1180594800 = 34 ;
    	a1916853335 = (a1700231631 + 2);
    	a1756173294 = (((((a983758263 * a803418896) % 14999) + -4914) * 1) / 5);
    	a1830659124 = (a786258498 + 3);
    	a1478681170 = (a1249952537 + 1);
    	a2073482783 = 34 ;
    	a190525986 = (a2087535773 + 8);
    	a63333937 = (((((((a63333937 * a1151361287) % 14999) / 5) % 106) + 137) / 5) - -68);
    	a620105235 = (((((((a803418896 * a1675035970) % 14999) % 10) + -169) / 5) * 51) / 10);
    	a2026977784 = ((a1959068056 * a2130193413) + -63);
    	a2061425267 = (a834646264 - -2);
    	a1210910088 = ((a2087535773 + a1700231631) + -5); 
    	 printf("%d\n", 19); fflush(stdout); 
    } if((((a1675035970 <=  171 && ((a1478681170 == 3 && ( cf==1  && (input == 14))) && a1125477212 == 32)) && a999024345 <=  48) && (a190525986 == 9 && a2061425267 == 10))) {
    	cf = 0;
    	a63333937 = ((((((a63333937 * a1151361287) % 14999) / 5) - 17361) % 106) + 211);
    	a1916853335 = (a2087535773 - -4);
    	a1756173294 = (((((a1774184757 * a1774184757) % 14999) + 9220) + 934) + -31690);
    	a1125477212 = 34 ;
    	a1700231631 = ((a1210910088 - a2026977784) - -11);
    	a620105235 = (((((((a1254983042 * a1151361287) % 14999) - -1487) / 5) + 2766) % 10) - 177);
    	a1180594800 = 34 ;
    	a2073482783 = 34 ;
    	a1830659124 = ((a1959068056 + a786258498) - 5);
    	a1018383389 = (((((((a1018383389 * a803418896) % 14999) % 21) - -189) + 15334) + 754) - 16088);
    	a1210910088 = (a2061425267 + -7);
    	a1478681170 = ((a2061425267 + a1959068056) + -13);
    	a601495656 = 34 ;
    	a341216798 = ((((((a341216798 * a1774184757) % 14999) + -5664) / 5) % 31) - -266);
    	a2026977784 = ((a190525986 - a778006913) + 1);
    	a190525986 = (a1700231631 + 6);
    	a2061425267 = ((a1241576728 - a834646264) + 16); 
    	 printf("%d\n", 26); fflush(stdout); 
    } 
}
 void calculate_outputm38(int input) {
    if((((a1916853335 == 5 && (a709568404 == 32 && (((input == 4) &&  cf==1 ) && a1180594800 == 32))) && a26346326 == 32) && (a217799639 <=  -198 && a63333937 <=  -135))) {
    	a1451139861 -= (a1451139861 - 20) < a1451139861 ? 2 : 0;
    	a419312954 += (a419312954 + 20) > a419312954 ? 1 : 0;
    	cf = 0;
    	a1959068056 = (a1830659124 - 1);
    	a983758263 = ((((((a983758263 * a260539918) % 14999) + 8416) * 1) % 104) + -1);
    	a2026977784 = (a2061425267 - 2);
    	a1180594800 = 33 ;
    	a2097567994 = 32 ;
    	a26346326 = 33 ;
    	a757937656 = ((a1241576728 / a1241576728) - -8);
    	a1985899004 = ((((((a1774184757 * a813082108) % 98) + 272) + -30171) / 5) + 6320);
    	a1895304149 = 33 ;
    	a2130193413 = ((a2087535773 - a2087535773) - -10);
    	a2073482783 = 33 ;
    	a999024345 = ((((((((a1985899004 * a341216798) % 14999) % 41) + 90) * 1) + -614) * -2) / 10);
    	a190525986 = ((a2026977784 + a757937656) + -7);
    	a721272783 = ((a1478681170 + a2087535773) - -9);
    	a30494462 = (((((((a30494462 * a63333937) % 14999) + 5394) % 92) - 61) + 8401) + -8385);
    	a1916853335 = (a778006913 + 5);
    	a1318526106 = 33 ;
    	a708839806 = 33 ;
    	a1983740902 = 33 ;
    	a1241576728 = ((a778006913 * a2087535773) + 4);
    	a1211013485 = 33 ;
    	a1675035970 = ((((((a1675035970 * a63333937) % 14999) / 5) - 5533) % 17) + 204);
    	a4442917 = ((a1249952537 / a2087535773) + 5);
    	a1644957382 = 33 ;
    	a2130183577 = ((((((a2130183577 * a217799639) % 14999) % 63) - -167) + 1) * 1);
    	a1151361287 = (((((a1625516355 * a1625516355) % 86) + 80) * 5) / 5);
    	a620105235 = (((((((a1625516355 * a1985899004) % 14999) % 10) + -170) + -1) - 14318) + 14318);
    	a601495656 = 33 ;
    	a786258498 = (a834646264 + -2);
    	a709568404 = 33 ;
    	a260539918 = ((((((a1254983042 * a30494462) % 17) - 26) - -1) * 9) / 10);
    	a63333937 = (((((((a63333937 * a620105235) % 14999) + 10796) * 1) + -31199) % 81) - 54);
    	a1018383389 = (((((((a1018383389 * a217799639) % 14999) % 74) - -93) + 1) * 9) / 10);
    	a217799639 = (((((a1625516355 * a1151361287) + 16752) % 69) - 127) * 1);
    	a263151501 = 34 ;
    	a302110279 = 33 ;
    	a1478681170 = ((a1959068056 + a4442917) - 11);
    	a2061425267 = (a1210910088 + 9);
    	a1249952537 = (a1830659124 / a1210910088);
    	a76745981 = 33 ;
    	a778006913 = (a834646264 - 9);
    	a2087535773 = (a1959068056 - 5); 
    	 printf("%d\n", 16); fflush(stdout); 
    } if(((((a26346326 == 32 && a1983740902 == 32) && a2087535773 == 3) && a778006913 == 1) && ((a1895304149 == 32 && ( cf==1  && (input == 7))) && a63333937 <=  -135))) {
    	cf = 0;
    	a1213722969 = (a786258498 + 3);
    	a1625516355 = (((((((a217799639 * a999024345) % 14999) / 5) - 23836) * 1) % 13) + -81);
    	a1018383389 = (((((((a1018383389 * a30494462) % 14999) * 2) + 0) / 5) % 74) + 93);
    	a834646264 = (a2130193413 - 3);
    	a1830659124 = (a1241576728 - -3);
    	a302110279 = 33 ;
    	a1254983042 = (((((a620105235 * a2130183577) % 14999) + -15000) / 5) - 19839);
    	a1151361287 = ((((((((a999024345 * a217799639) % 14999) * 2) % 86) - -162) / 5) * 51) / 10);
    	a813082108 = ((((((a824591188 * a260539918) % 14999) + -15000) - -448) + -201) + -245);
    	a1210910088 = (a1478681170 + -2); 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((((a1241576728 == 6 && a1959068056 == 8) && a1478681170 == 3) && a709568404 == 32) && ((a1211013485 == 32 && ( cf==1  && (input == 9))) && a302110279 == 32))) {
    	cf = 0;
    	a1210910088 = a1478681170;
    	a1830659124 = (a1478681170 + 8);
    	a1895857334 = ((a834646264 * a834646264) - 114);
    	a1675035970 = (((((((a1675035970 * a1151361287) % 14999) / 5) * 5) / 5) % 51) - -259);
    	a1895304149 = 34 ;
    	a1644957382 = 34 ;
    	a2073482783 = 34 ;
    	a302110279 = 34 ;
    	a1625516355 = ((((((a824591188 * a824591188) % 14999) % 37) + -43) - -4209) + -4208);
    	a778006913 = ((a1249952537 * a786258498) + -29);
    	a2130193413 = a1830659124;
    	a2004613952 = ((a2087535773 - a1959068056) - -11);
    	a190525986 = ((a778006913 + a2130193413) - 3);
    	a1125477212 = 34 ;
    	a2061425267 = ((a1895857334 + a1478681170) + 2);
    	a1774184757 = (((((((a341216798 * a1625516355) % 14999) % 66) - -103) / 5) + 5888) - 5858);
    	a1983740902 = 34 ;
    	a620105235 = ((((((a260539918 * a63333937) % 14999) / 5) + -14915) % 94) + -3);
    	a813082108 = (((((((a341216798 * a341216798) % 14999) % 69) + 173) / 5) - -3050) + -2856);
    	a566060042 = ((((((a824591188 * a983758263) % 14999) * 2) % 14) + 11) + 3);
    	a1241576728 = (a1895857334 - -1);
    	a26346326 = 34 ;
    	a786258498 = (a1478681170 + 7);
    	a999024345 = (((((((a217799639 * a260539918) % 14999) + 705) % 64) + 150) - 16528) + 16543);
    	a709568404 = 34 ;
    	a1180594800 = 34 ;
    	a1249952537 = ((a2061425267 / a1478681170) - -2);
    	a1959068056 = (a1895857334 - -3);
    	a1211013485 = 34 ;
    	a4442917 = (a1478681170 - -4);
    	a1254983042 = ((((((a620105235 * a217799639) % 14999) % 105) - -307) - 0) - -2);
    	a217799639 = (((((((a217799639 * a30494462) % 14999) % 28) - 34) * 10) / 9) / 5);
    	a1018383389 = ((((((a1018383389 * a63333937) % 14999) % 21) - -190) - -1) - 2);
    	a1916853335 = (a2026977784 + -2);
    	a708839806 = 34 ;
    	a30494462 = (((((((a30494462 * a999024345) % 14999) % 85) - -211) + 1) + -12999) - -12998);
    	a983758263 = (((((((a983758263 * a824591188) % 14999) % 101) - -304) - 0) + -16548) + 16549);
    	a601495656 = 34 ;
    	a263151501 = 34 ;
    	a63333937 = (((((((a63333937 * a1151361287) % 14999) - 4695) % 106) + 170) - -15165) - 15158);
    	a2130183577 = ((((((a2130183577 * a260539918) % 14999) % 12) - -243) + 9910) + -9909); 
    	 printf("%d\n", 20); fflush(stdout); 
    } if(((a1180594800 == 32 && (a1249952537 == 4 && ((input == 10) &&  cf==1 ))) && (a1241576728 == 6 && (a260539918 <=  -44 && (a1644957382 == 32 && a601495656 == 32))))) {
    	cf = 0;
    	a983758263 = ((((((a983758263 * a824591188) % 14999) % 104) - -99) - 1) / 5);
    	a721272783 = (a2061425267 - -3);
    	a1895304149 = 33 ;
    	a1075307847 = 36 ;
    	a1983740902 = 33 ;
    	a263151501 = 33 ;
    	a30494462 = ((((((a30494462 * a983758263) % 14999) % 92) - -30) - 581) - -583);
    	a4442917 = ((a721272783 * a721272783) - 163);
    	a1916853335 = (a778006913 - -5);
    	a1675035970 = (((((((a1675035970 * a824591188) % 14999) / 5) * 5) + -10389) % 17) + 188);
    	a26346326 = 33 ;
    	a707417839 = ((((((a983758263 * a824591188) % 14999) % 14986) + -15013) + -1) + -1);
    	a786258498 = ((a1249952537 + a190525986) + -4); 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm39(int input) {
    if((( cf==1  && (input == 5)) && ((((a30494462 <=  -62 && (a63333937 <=  -135 && a26346326 == 32)) && a1211013485 == 32) && a2073482783 == 32) && a1625516355 <=  -109))) {
    	cf = 0;
    	a26346326 = 33 ;
    	a983758263 = ((((((a983758263 * a341216798) % 14999) % 104) - -98) + -28912) - -28912);
    	a813082108 = ((((((a1166237008 * a1166237008) % 14999) - -11279) / 5) % 50) - -24);
    	a2130183577 = (((((a813082108 * a983758263) % 63) - -167) + -1) - -2);
    	a2073482783 = 33 ;
    	a620105235 = (((((((a30494462 * a983758263) % 14999) / 5) + 4769) * 3) % 10) - 178);
    	a1345687529 = (((((a999024345 * a1625516355) % 14999) / 5) + -195) - -10814);
    	a1895304149 = 33 ;
    	a1151361287 = (((((((a620105235 * a1345687529) % 14999) % 86) - -163) + 22757) * 1) - 22758);
    	a999024345 = (((((a813082108 * a813082108) / 5) * 5) % 41) + 58);
    	a1210910088 = (a2061425267 + -8);
    	a1254983042 = ((((((a1254983042 * a1774184757) % 14999) / 5) - 6006) % 101) + 187);
    	a1675035970 = (((((a813082108 * a813082108) / 5) % 17) + 183) + 7);
    	a1478681170 = ((a1959068056 - a1830659124) - -5);
    	a721272783 = (a1916853335 + 9);
    	a1644957382 = 33 ;
    	a778006913 = ((a2026977784 * a786258498) + -54);
    	a1891437507 = 35 ;
    	a4442917 = (a2026977784 - 1);
    	a63333937 = (((((((a63333937 * a1018383389) % 14999) - -3369) % 81) + -53) + 4024) + -4024);
    	a1625516355 = ((((((((a1625516355 * a1675035970) % 14999) % 13) - 94) * 1) * 5) % 13) - 88);
    	a30494462 = ((((((((a30494462 * a1151361287) % 14999) % 92) + 31) + -1) * 5) % 92) + 30); 
    	 printf("%d\n", 20); fflush(stdout); 
    } if(((a709568404 == 32 && (a1210910088 == 1 && (a1959068056 == 8 && (a1151361287 <=  75 && a708839806 == 32)))) && (a2026977784 == 7 && ((input == 8) &&  cf==1 )))) {
    	cf = 0;
    	a341216798 = ((((((a341216798 * a1166237008) % 14999) % 14850) - -15148) + 0) - -1);
    	a302110279 = 32 ;
    	a190525986 = ((a2026977784 - a834646264) + 14);
    	a1521644128 = (a2061425267 - 5);
    	a1983740902 = 33 ;
    	a1478681170 = ((a4442917 + a1959068056) - 8);
    	a1018383389 = (((((((a1774184757 * a983758263) % 14999) + 6031) % 21) + 169) / 5) + 135);
    	a965340096 = 32 ;
    	a1985899004 = (((((a1151361287 * a1675035970) % 14999) + -14932) - 26) - 6); 
    	 printf("%d\n", 20); fflush(stdout); 
    } if((( cf==1  && (input == 13)) && (a1830659124 == 9 && ((((a813082108 <=  3 && a1249952537 == 4) && a2061425267 == 10) && a1125477212 == 32) && a2087535773 == 3)))) {
    	cf = 0;
    	a1318526106 = 34 ;
    	a1644957382 = 34 ;
    	a63333937 = (((((((a30494462 * a1151361287) % 14999) * 2) % 106) - -137) - -18430) - 18431);
    	a404763935 = ((a4442917 + a1959068056) - -1);
    	a1959068056 = ((a834646264 / a1830659124) - -9);
    	a1895304149 = 34 ;
    	a2073482783 = 34 ;
    	a548050643 = 35 ;
    	a620105235 = (((((((a63333937 * a63333937) % 14999) / 5) + -21876) - 6075) % 94) - 38);
    	a1254983042 = ((((((((a1254983042 * a63333937) % 14999) % 105) + 308) - 2140) * 5) % 105) + 394);
    	a778006913 = (a786258498 + -5);
    	a1916853335 = (a190525986 - 4);
    	a999024345 = (((((((a999024345 * a30494462) % 14999) - -8470) / 5) - -14455) % 64) + 183);
    	a217799639 = ((((((((a63333937 * a1985899004) % 14999) % 28) - 31) * 5) - 5102) % 28) - 8);
    	a2087535773 = ((a1241576728 * a1241576728) + -31);
    	a2026977784 = (a190525986 - 2);
    	a1826277115 = (((((a341216798 * a1166237008) % 14999) / 5) + -26707) - -40704);
    	a1241576728 = (a1830659124 + -1);
    	a983758263 = (((((((a983758263 * a1826277115) % 14999) - -23694) * 10) / 9) + -19365) + 11119);
    	a1210910088 = (a1249952537 + -1);
    	a1125477212 = 34 ;
    	a30494462 = ((((((a999024345 * a1826277115) % 14999) - 26764) % 85) + 210) * 1);
    	a26346326 = 34 ;
    	a260539918 = (((((((a1151361287 * a63333937) % 14999) - -3875) + 10426) / 5) % 73) - -65);
    	a1249952537 = ((a1830659124 / a2061425267) - -6);
    	a601495656 = 34 ;
    	a1625516355 = ((((((a1625516355 * a1151361287) % 14999) - 8200) % 37) - 43) + -1);
    	a708839806 = 34 ;
    	a813082108 = ((((((((a813082108 * a1151361287) % 14999) % 69) - -174) * 5) * 5) % 69) - -171);
    	a1675035970 = (((((((a1151361287 * a813082108) % 14999) % 51) + 258) - -2) + -22434) + 22433);
    	a4442917 = ((a2130193413 - a1478681170) + 1);
    	a2130193413 = (a1830659124 + 2);
    	a786258498 = ((a1830659124 - a2026977784) - -10);
    	a1478681170 = (a1210910088 + 2);
    	a2130183577 = (((((((a1151361287 * a1151361287) % 14999) + 7987) % 12) + 243) + 15898) + -15897);
    	a263151501 = 34 ;
    	a1151361287 = ((((((a1151361287 * a1774184757) % 14999) % 20) - -270) + 17642) - 17641);
    	a709568404 = 34 ;
    	a302110279 = 34 ;
    	a1180594800 = 34 ;
    	a1211013485 = 34 ;
    	a2061425267 = (a2087535773 + 7);
    	a1830659124 = (a834646264 + -1); 
    	 printf("%d\n", 18); fflush(stdout); 
    } if(((((a2061425267 == 10 && (a2130193413 == 9 && (a1254983042 <=  -2 && a786258498 == 8))) && a1625516355 <=  -109) && a1644957382 == 32) && ((input == 14) &&  cf==1 ))) {
    	cf = 0;
    	a302110279 = 33 ;
    	a1151361287 = ((((((a1151361287 * a999024345) % 14999) + -10135) - -11918) % 86) + 163);
    	a834646264 = ((a1478681170 + a1249952537) + -1);
    	a1213722969 = (a786258498 - -3);
    	a1625516355 = (((((((a1625516355 * a1774184757) % 14999) + -22720) % 13) + -84) + -18717) - -18717);
    	a1018383389 = ((((((a620105235 * a620105235) % 14999) - -12016) + -23502) % 74) - -93); 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm1(int input) {
    if(((a813082108 <=  3 && (( cf==1  && a834646264 == 6) && a1254983042 <=  -2)) && (a709568404 == 32 && ((a2130183577 <=  103 && a26346326 == 32) && a1180594800 == 32)))) {
    	if((((a1675035970 <=  171 && (a1644957382 == 32 && a778006913 == 1)) && a786258498 == 8) && (a1210910088 == 1 && (a620105235 <=  -182 && (a1213722969 == 6 &&  cf==1 ))))) {
    		calculate_outputm26(input);
    	} 
    	if((((a2087535773 == 3 && a1675035970 <=  171) && a620105235 <=  -182) && (a26346326 == 32 && (a1210910088 == 1 && (( cf==1  && a1213722969 == 11) && a1959068056 == 8))))) {
    		calculate_outputm29(input);
    	} 
    } 
    if(((a1625516355 <=  -109 && ((( cf==1  && a834646264 == 7) && a190525986 == 9) && a1959068056 == 8)) && (a1774184757 <=  -151 && (a2087535773 == 3 && a601495656 == 32)))) {
    	if((((a1478681170 == 3 && (((286 < a823982083 &&  cf==1 ) && a1018383389 <=  17) && a76745981 == 32)) && a708839806 == 32) && (a813082108 <=  3 && a1644957382 == 32))) {
    		calculate_outputm31(input);
    	} 
    } 
    if(((a1211013485 == 32 && (((a1830659124 == 9 && (a834646264 == 8 &&  cf==1 )) && a26346326 == 32) && a217799639 <=  -198)) && (a4442917 == 5 && a1774184757 <=  -151))) {
    	if((((a1625516355 <=  -109 && (a786258498 == 8 && (( cf==1  && a1032084261 == 36) && a620105235 <=  -182))) && a1249952537 == 4) && (a2087535773 == 3 && a778006913 == 1))) {
    		calculate_outputm33(input);
    	} 
    } 
    if((((a302110279 == 32 && a263151501 == 32) && a4442917 == 5) && (a26346326 == 32 && (a2026977784 == 7 && ((a834646264 == 9 &&  cf==1 ) && a217799639 <=  -198))))) {
    	if((a260539918 <=  -44 && ((a217799639 <=  -198 && ((a1895304149 == 32 && (( cf==1  && 489 < a356054071) && a2073482783 == 32)) && a2130183577 <=  103)) && a263151501 == 32))) {
    		calculate_outputm34(input);
    	} 
    } 
    if(((a4442917 == 5 && ( cf==1  && a834646264 == 10)) && (a2130183577 <=  103 && (a1180594800 == 32 && (a1895304149 == 32 && (a190525986 == 9 && a30494462 <=  -62)))))) {
    	if(((a1211013485 == 32 && (a1830659124 == 9 && ((((-174 < a803418896) && (5 >= a803418896)) &&  cf==1 ) && a260539918 <=  -44))) && ((a1478681170 == 3 && a2087535773 == 3) && a1125477212 == 32))) {
    		calculate_outputm36(input);
    	} 
    	if(((( cf==1  && 76 < a803418896) && a709568404 == 32) && ((((a1675035970 <=  171 && a1249952537 == 4) && a76745981 == 32) && a2026977784 == 7) && a263151501 == 32))) {
    		calculate_outputm37(input);
    	} 
    } 
    if((((a263151501 == 32 && ((a834646264 == 11 &&  cf==1 ) && a1959068056 == 8)) && a1675035970 <=  171) && ((a190525986 == 9 && a778006913 == 1) && a1318526106 == 32))) {
    	if((((a1916853335 == 5 && ( cf==1  && a824591188 <=  37)) && a601495656 == 32) && (a2130183577 <=  103 && ((a1211013485 == 32 && a302110279 == 32) && a1018383389 <=  17)))) {
    		calculate_outputm38(input);
    	} 
    } 
    if(((((a999024345 <=  48 && ( cf==1  && a834646264 == 12)) && a1478681170 == 3) && a1774184757 <=  -151) && (a1254983042 <=  -2 && (a76745981 == 32 && a709568404 == 32)))) {
    	if(((a1625516355 <=  -109 && (((116 < a1166237008 &&  cf==1 ) && a2087535773 == 3) && a1241576728 == 6)) && (a4442917 == 5 && (a778006913 == 1 && a1211013485 == 32)))) {
    		calculate_outputm39(input);
    	} 
    } 
}
 void calculate_outputm40(int input) {
    if(((a786258498 == 8 && (a302110279 == 32 && a4442917 == 5)) && (a76745981 == 32 && ((a1018383389 <=  17 && ((input == 11) &&  cf==1 )) && a708839806 == 32)))) {
    	cf = 0;
    	a2087535773 = (a1959068056 - 3);
    	a813082108 = (((((((a260539918 * a341216798) % 14999) % 69) + 174) - 19844) - -36187) - 16343);
    	a63333937 = (((((((a1985899004 * a1985899004) % 14999) - -3887) * 1) - -9589) % 106) - -137);
    	a263151501 = 34 ;
    	a1983740902 = 34 ;
    	a1249952537 = (a4442917 - -1);
    	a190525986 = ((a4442917 * a2026977784) + -24);
    	a2130183577 = (((((((a217799639 * a30494462) % 14999) + 6104) - -7176) / 5) % 12) - -241);
    	a1830659124 = (a2130193413 - -2);
    	a1644957382 = 34 ;
    	a1675035970 = (((((((a1018383389 * a217799639) % 14999) + 6120) / 5) * 5) % 51) + 258);
    	a1210910088 = (a786258498 - 5);
    	a1916853335 = (a778006913 - -6);
    	a2073482783 = 34 ;
    	a620105235 = ((((((a1254983042 * a1254983042) % 14999) - -7178) % 94) + -68) - 38); 
    	 printf("%d\n", 18); fflush(stdout); 
    } if((((a786258498 == 8 && (a1985899004 <=  174 && a999024345 <=  48)) && a1211013485 == 32) && (a1959068056 == 8 && (a260539918 <=  -44 && ((input == 12) &&  cf==1 ))))) {
    	a156979206 += (a156979206 + 20) > a156979206 ? 1 : 0;
    	cf = 0;
    	a999024345 = (((((((a341216798 * a1675035970) % 14999) / 5) % 64) + 148) * 10) / 9);
    	a1254983042 = (((((((a1254983042 * a2130183577) % 14999) % 105) - -309) - -1) - 25535) - -25534);
    	a1241576728 = ((a2061425267 * a4442917) - 42);
    	a1895857334 = (a2130193413 - -4);
    	a2087632595 = 34 ;
    	a217799639 = (((((((a217799639 * a999024345) % 14999) % 28) - 30) - 1) - 20992) - -20994);
    	a76745981 = 34 ;
    	a2130193413 = ((a778006913 - a1830659124) + 21);
    	a266166646 = (((((a983758263 * a1774184757) % 14999) - 25178) / 5) + -17730);
    	a1478681170 = (a104481388 + -5);
    	a1959068056 = (a2087535773 - -5);
    	a2026977784 = (a778006913 + 8);
    	a786258498 = (a4442917 - -5);
    	a2061425267 = (a1959068056 - -2);
    	a983758263 = (((((((a983758263 * a1625516355) % 14999) / 5) % 101) - -297) * 9) / 10);
    	a26346326 = 34 ;
    	a30494462 = ((((((a30494462 * a1018383389) % 14999) * 2) * 1) % 85) - -211);
    	a1774184757 = (((((((a999024345 * a1985899004) % 14999) % 66) + 101) - -1) + 3535) - 3535);
    	a4442917 = a1916853335;
    	a778006913 = a1210910088; 
    	 printf("%d\n", 17); fflush(stdout); 
    } 
}
 void calculate_outputm41(int input) {
    if(((a1675035970 <=  171 && ((a778006913 == 1 && a1254983042 <=  -2) && a76745981 == 32)) && (a1985899004 <=  174 && (( cf==1  && (input == 4)) && a1125477212 == 32)))) {
    	cf = 0;
    	a834646264 = ((a786258498 + a1241576728) + -8);
    	a1213722969 = (a2087535773 + 8);
    	a1478681170 = ((a2087535773 + a104481388) + -13);
    	a1180594800 = 32 ;
    	a1018383389 = ((((((a1625516355 * a1254983042) % 14999) - 5973) * 3) % 74) - -92);
    	a341216798 = (((((a341216798 * a1675035970) % 14999) - 11965) - 1913) + -1012);
    	a302110279 = 33 ;
    	a1151361287 = ((((((((a1254983042 * a1625516355) % 14999) % 86) + 146) + -44) * 5) % 86) - -136);
    	a1625516355 = (((((((a1625516355 * a260539918) % 14999) + -29645) % 13) + -89) + -2488) - -2483);
    	a999024345 = ((((((a1254983042 * a1774184757) % 14999) - -2880) - 24071) * 10) / 9);
    	a1830659124 = (a1959068056 + 1); 
    	 printf("%d\n", 26); fflush(stdout); 
    } if(((a1249952537 == 4 && ((( cf==1  && (input == 5)) && a1916853335 == 5) && a26346326 == 32)) && (a2026977784 == 7 && (a302110279 == 32 && a708839806 == 32)))) {
    	cf = 0;
    	a1644957382 = 32 ;
    	a63333937 = ((((((a30494462 * a30494462) % 14999) + -7995) / 5) / 5) + -18489);
    	a260539918 = ((((((a1985899004 * a1625516355) % 14999) % 14978) + -15021) * 1) - 2);
    	a813082108 = (((((a1254983042 * a1774184757) % 14999) / 5) + 7181) - 16602);
    	a1211013485 = 32 ;
    	a620105235 = ((((((a1675035970 * a1675035970) % 14999) % 14909) - 15090) - 2) - 0);
    	a2130183577 = ((((((a217799639 * a983758263) % 14999) + -20019) + 1582) * 10) / 9); 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((((input == 3) &&  cf==1 ) && a786258498 == 8) && a1254983042 <=  -2) && (a601495656 == 32 && ((a263151501 == 32 && a4442917 == 5) && a2061425267 == 10)))) {
    	cf = 0;
    	a786258498 = (a2087535773 - -7);
    	a302110279 = 34 ;
    	a2061425267 = ((a786258498 - a1478681170) + 7);
    	a983758263 = (((((((a983758263 * a341216798) % 14999) / 5) - -12670) - 26145) % 101) - -390);
    	a1675035970 = ((((((a1675035970 * a1774184757) % 14999) % 51) + 258) - 0) - 0);
    	a26346326 = 34 ;
    	a1241576728 = (a778006913 + 7);
    	a263151501 = 34 ;
    	a1985899004 = ((((((a1985899004 * a341216798) % 14999) % 76) + 447) + -3556) - -3557);
    	a822442096 = (((((a983758263 * a341216798) % 14999) + 12312) - 30078) + -6903);
    	a1895857334 = ((a1210910088 / a104481388) - -12);
    	a2041520547 = 36 ;
    	a76745981 = 34 ;
    	a1916853335 = (a1830659124 - 4);
    	a778006913 = (a1959068056 + -5);
    	a1254983042 = ((((((a1254983042 * a999024345) % 14999) + 7433) - 12329) % 105) - -396);
    	a1959068056 = (a1210910088 - -9);
    	a2087535773 = (a2061425267 - 7);
    	a30494462 = ((((((a30494462 * a1774184757) % 14999) % 85) - -203) / 5) - -111);
    	a4442917 = a1916853335; 
    	 printf("%d\n", 20); fflush(stdout); 
    } 
}
 void calculate_outputm42(int input) {
    if((((a63333937 <=  -135 && (( cf==1  && (input == 15)) && a2073482783 == 32)) && a4442917 == 5) && ((a190525986 == 9 && a1211013485 == 32) && a601495656 == 32))) {
    	cf = 0;
    	a983758263 = ((((((a983758263 * a1254983042) % 14999) - -2693) + 1021) % 101) + 266);
    	a1683451995 = ((a104481388 + a2087535773) - 14);
    	a26346326 = 34 ;
    	a1985899004 = ((((((a1774184757 * a813082108) % 14999) % 76) + 394) / 5) * 5);
    	a1478681170 = a1683451995;
    	a2004613952 = (a1916853335 - -7);
    	a190525986 = (a1249952537 - -5);
    	a708839806 = 34 ;
    	a2073482783 = 34 ;
    	a1895857334 = (a1830659124 - 2);
    	a2061425267 = (a2026977784 - -3);
    	a620105235 = (((((((a1774184757 * a1018383389) % 14999) + -2433) - 17696) * 1) % 94) - 62);
    	a1254983042 = (((((((a341216798 * a983758263) % 14999) % 105) + 298) + -26854) / 5) - -5538);
    	a1644957382 = 34 ;
    	a1151361287 = ((((((a1625516355 * a260539918) % 14999) % 20) + 271) + 24977) - 24978);
    	a1916853335 = ((a1959068056 * a1241576728) + -41);
    	a1318526106 = 34 ;
    	a1125477212 = 34 ;
    	a778006913 = (a2130193413 + -8);
    	a1959068056 = (a2061425267 - 2);
    	a76745981 = 34 ;
    	a1895304149 = 34 ;
    	a2130183577 = ((((((a2130183577 * a1151361287) % 14999) / 5) % 12) + 243) + 1);
    	a1625516355 = (((((((a1625516355 * a63333937) % 14999) % 37) + -44) + -8) * 9) / 10);
    	a709568404 = 34 ;
    	a1241576728 = ((a786258498 / a1249952537) - -7);
    	a302110279 = 34 ;
    	a1211013485 = 34 ;
    	a63333937 = (((((((a1018383389 * a1774184757) % 14999) / 5) % 106) + 71) * 9) / 10);
    	a601495656 = 33 ;
    	a30494462 = (((((((a30494462 * a1675035970) % 14999) % 85) - -211) * 1) - 22971) + 22971);
    	a217799639 = (((((((a217799639 * a999024345) % 14999) % 28) - 28) - 1) / 5) + -46);
    	a1830659124 = ((a1683451995 * a1210910088) + -4);
    	a2087535773 = a1683451995;
    	a4442917 = (a2061425267 + -5); 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm45(int input) {
    if(((a601495656 == 32 && ((a1151361287 <=  75 && ((input == 9) &&  cf==1 )) && a1125477212 == 32)) && ((a217799639 <=  -198 && a1318526106 == 32) && a1830659124 == 9))) {
    	cf = 0;
    	a1210910088 = (a1916853335 + -3);
    	a302110279 = 33 ;
    	a1895304149 = 33 ;
    	a30494462 = (((((((a30494462 * a1985899004) % 14999) - -771) % 92) - -31) + -24453) + 24453);
    	a721272783 = (a1959068056 + 6);
    	a1345687529 = ((((((a341216798 * a1774184757) % 14999) + 21490) + 5360) * 10) / 9);
    	a1018383389 = ((((((a1018383389 * a2130183577) % 14999) % 74) + 92) - -18957) - 18957);
    	a1675035970 = (((((((a1675035970 * a2130183577) % 14999) % 17) + 188) + 6469) / 5) - 1128);
    	a4442917 = (a119997292 + 1);
    	a1151361287 = (((((((a1151361287 * a63333937) % 14999) / 5) % 86) + 162) - 10396) - -10395);
    	a983758263 = ((((((a983758263 * a1625516355) % 14999) / 5) % 104) + -5) / 5);
    	a1891437507 = 35 ;
    	a26346326 = 33 ;
    	a778006913 = ((a1241576728 / a1478681170) - -1);
    	a1254983042 = (((((((a1254983042 * a2130183577) % 14999) % 101) - -100) + -22632) - 64) - -22697);
    	a1625516355 = (((((((a1625516355 * a1254983042) % 14999) % 13) + -95) / 5) - -10968) + -11046); 
    	 printf("%d\n", 16); fflush(stdout); 
    } 
}
 void calculate_outputm2(int input) {
    if(((a1254983042 <=  -2 && (a1318526106 == 32 && (a217799639 <=  -198 && (a1305578599 == 33 &&  cf==1 )))) && ((a2061425267 == 10 && a1625516355 <=  -109) && a1959068056 == 8))) {
    	if(((a302110279 == 32 && (a1478681170 == 3 && ((a778006913 == 1 && a2026977784 == 7) && a217799639 <=  -198))) && ((a104481388 == 10 &&  cf==1 ) && a260539918 <=  -44))) {
    		calculate_outputm40(input);
    	} 
    	if((((a2073482783 == 32 && (a217799639 <=  -198 && (a26346326 == 32 && (a104481388 == 13 &&  cf==1 )))) && a1985899004 <=  174) && (a1774184757 <=  -151 && a601495656 == 32))) {
    		calculate_outputm41(input);
    	} 
    	if((((a104481388 == 16 &&  cf==1 ) && a1895304149 == 32) && ((a2130183577 <=  103 && (a1959068056 == 8 && (a708839806 == 32 && a1151361287 <=  75))) && a1478681170 == 3))) {
    		calculate_outputm42(input);
    	} 
    } 
    if(((a1830659124 == 9 && (a1254983042 <=  -2 && (a1305578599 == 36 &&  cf==1 ))) && (a1983740902 == 32 && (a302110279 == 32 && (a1985899004 <=  174 && a1210910088 == 1))))) {
    	if((((a1675035970 <=  171 && (a1211013485 == 32 && a1018383389 <=  17)) && a1249952537 == 4) && (a1916853335 == 5 && (a4442917 == 5 && ( cf==1  && a119997292 == 5))))) {
    		calculate_outputm45(input);
    	} 
    } 
}
 void calculate_outputm48(int input) {
    if(((a813082108 <=  3 && ((( cf==1  && (input == 9)) && a26346326 == 32) && a1151361287 <=  75)) && ((a1318526106 == 32 && a786258498 == 8) && a302110279 == 32))) {
    	cf = 0;
    	a1018383389 = (((((a1151361287 * a1756173294) % 14999) - 14991) - 6) / 5);
    	a1625516355 = ((((((((a260539918 * a260539918) % 14999) - 3438) % 13) - 95) * 5) % 13) - 83);
    	a263151501 = 33 ;
    	a217799639 = (((((((a217799639 * a1625516355) % 14999) - -1676) % 69) + -160) * 9) / 10);
    	a709568404 = 33 ;
    	a601495656 = 33 ;
    	a190525986 = (a4442917 + 5);
    	a1830659124 = (a4442917 + 5);
    	a26346326 = 33 ;
    	a1210910088 = (a1830659124 - 8);
    	a2026977784 = (a1830659124 - 2);
    	a1916853335 = ((a4442917 + a4442917) + -4);
    	a302110279 = 33 ;
    	a2061425267 = (a4442917 + 6);
    	a2087535773 = (a4442917 - 1);
    	a786258498 = (a1916853335 - -3);
    	a983758263 = (((((((a983758263 * a999024345) % 14999) % 104) + 99) - -1) - 17859) - -17858);
    	a813082108 = ((((((a813082108 * a1254983042) % 14999) * 2) * 1) % 50) + 53);
    	a1478681170 = (a2026977784 - 4);
    	a1597554373 = 36 ;
    	a1569588614 = ((((((a341216798 * a1756173294) % 14999) % 14916) - -15083) * 1) - -1);
    	a1644957382 = 34 ;
    	a2130193413 = ((a1210910088 - a1249952537) + 12);
    	a2073482783 = 33 ;
    	a30494462 = ((((((a30494462 * a1675035970) % 14999) % 92) - -32) + -1) + 2);
    	a1241576728 = (a190525986 + -3);
    	a1895304149 = 33 ;
    	a721272783 = (a1959068056 + 4);
    	a1959068056 = ((a4442917 * a2061425267) - 46);
    	a778006913 = (a1700231631 + -3);
    	a1249952537 = ((a1478681170 * a2026977784) - 27);
    	a1985899004 = ((((((a1985899004 * a2130183577) % 14999) * 2) / 5) % 98) - -273);
    	a1318526106 = 33 ;
    	a1180594800 = 33 ;
    	a999024345 = (((((((a620105235 * a1625516355) * 1) % 41) - -54) * 5) % 41) - -87);
    	a1675035970 = ((((((a260539918 * a1774184757) % 14999) % 17) + 183) + 2) * 1);
    	a260539918 = (((((((a260539918 * a1756173294) % 14999) + 6603) % 17) - 26) - -26263) - 26263); 
    	 printf("%d\n", 26); fflush(stdout); 
    } if(((a813082108 <=  3 && ((((input == 11) &&  cf==1 ) && a786258498 == 8) && a1318526106 == 32)) && (a1644957382 == 32 && (a76745981 == 32 && a30494462 <=  -62)))) {
    	cf = 0;
    	a1895857334 = a1241576728;
    	a263151501 = 34 ;
    	a1241576728 = ((a1959068056 / a1249952537) + 6);
    	a983758263 = (((((((a983758263 * a1756173294) % 14999) * 2) / 5) * 5) % 101) + 305);
    	a1352986605 = ((((((a1774184757 * a983758263) % 14999) + -4755) / 5) * 10) / 9);
    	a260339255 = ((((((a1352986605 * a1254983042) % 14999) - 11444) - 3552) + 20390) + -20393);
    	a1318526106 = 34 ;
    	a2130193413 = (a1478681170 + 6);
    	a1959068056 = (a2061425267 + -2);
    	a217799639 = (((((((a217799639 * a813082108) % 14999) % 28) + -28) / 5) + -19515) - -19512);
    	a1985899004 = (((((((a1985899004 * a260539918) % 14999) - -8679) % 76) - -447) / 5) - -305);
    	a778006913 = ((a2087535773 * a4442917) + -12);
    	a709568404 = 34 ;
    	a1151361287 = (((((((a341216798 * a341216798) % 14999) % 20) - -253) - -11342) + -38377) + 27048);
    	a1254983042 = ((((((a1254983042 * a2130183577) % 14999) % 105) - -308) - 1) + 1);
    	a1774184757 = ((((((((a1018383389 * a1018383389) % 14999) % 66) - -39) + -4954) / 5) * -1) / 10);
    	a260539918 = (((((((a1151361287 * a1675035970) % 14999) % 73) - -67) - -1) - 4631) - -4628);
    	a999024345 = (((((((a1018383389 * a1018383389) % 14999) - 16871) % 64) + 216) / 5) + 127);
    	a1211013485 = 34 ;
    	a4442917 = ((a1249952537 - a1241576728) - -11);
    	a1644957382 = 34 ;
    	a813082108 = (((((((a2130183577 * a999024345) % 14999) - -13146) % 69) + 174) / 5) + 84);
    	a76745981 = 34 ;
    	a786258498 = (a1210910088 + 7);
    	a30494462 = ((((((a30494462 * a1018383389) % 14999) + 11946) + -20710) % 85) - -254);
    	a1249952537 = ((a1830659124 - a1241576728) + 3);
    	a26346326 = 34 ;
    	a1675035970 = (((((((a1675035970 * a1756173294) % 14999) % 51) - -258) / 5) * 5) + 3); 
    	 printf("%d\n", 19); fflush(stdout); 
    } if(((a709568404 == 32 && ( cf==1  && (input == 12))) && ((a1985899004 <=  174 && ((a1675035970 <=  171 && a786258498 == 8) && a999024345 <=  48)) && a76745981 == 32))) {
    	cf = 0;
    	a63333937 = ((((((a1985899004 * a999024345) % 14999) - 12721) - -22736) % 14932) + -15066);
    	a983758263 = ((((((a983758263 * a1756173294) % 14999) % 101) + 305) + -1) - 0);
    	a1895857334 = (a1249952537 + 5);
    	a1675035970 = ((((((((a1985899004 * a1985899004) % 14999) % 51) - -260) * 1) * 5) % 51) + 231);
    	a1180594800 = 32 ;
    	a263151501 = 34 ;
    	a260539918 = ((((((((a260539918 * a217799639) % 14999) % 73) + 6) * 10) / 9) * 10) / 9);
    	a1254983042 = ((((((a1254983042 * a813082108) % 14999) % 105) - -307) + 0) + 3);
    	a709568404 = 34 ;
    	a160322672 = (((((a341216798 * a341216798) % 14999) + 2262) - 18848) + -10800);
    	a786258498 = (a2061425267 - 2);
    	a30494462 = (((((((a30494462 * a1675035970) % 14999) % 85) - -209) - 0) + 17624) - 17621);
    	a217799639 = ((((((a217799639 * a160322672) % 14999) % 28) + -29) + -2137) - -2136);
    	a1959068056 = (a1210910088 + 7);
    	a1125477212 = 32 ;
    	a153258473 = (((((a160322672 * a983758263) % 14999) - -12529) + -27505) * 1);
    	a1151361287 = ((((((a1151361287 * a1675035970) % 14999) - 4477) % 20) + 271) + 1);
    	a778006913 = ((a4442917 / a1210910088) + 2);
    	a1895304149 = 34 ;
    	a2130183577 = (((((((a2130183577 * a1756173294) % 14999) + -9194) % 12) + 242) / 5) - -195);
    	a1774184757 = ((((((((a1774184757 * a1675035970) % 14999) + -2119) % 66) + 143) / 5) * 49) / 10);
    	a1916853335 = ((a1700231631 / a1895857334) + 5);
    	a4442917 = (a1241576728 + 1);
    	a999024345 = (((((((a999024345 * a1985899004) % 14999) / 5) % 64) + 196) + 11906) - 11906); 
    	 printf("%d\n", 19); fflush(stdout); 
    } 
}
 void calculate_outputm49(int input) {
    if(((a1210910088 == 1 && (a1830659124 == 9 && ((((input == 5) &&  cf==1 ) && a709568404 == 32) && a1478681170 == 3))) && (a260539918 <=  -44 && a1211013485 == 32))) {
    	cf = 0;
    	a190525986 = (a1249952537 + 7);
    	a1210910088 = ((a778006913 / a1959068056) + 3);
    	a260539918 = ((((((a260539918 * a1018383389) % 14999) - 1904) / 5) % 17) - 25);
    	a1895304149 = 34 ;
    	a1018383389 = (((((((a2130183577 * a2130183577) % 14999) * 2) % 74) + 93) * 9) / 10);
    	a263151501 = 34 ;
    	a2130193413 = (a1249952537 - -7);
    	a601495656 = 34 ;
    	a1211013485 = 34 ;
    	a1895857334 = (a2026977784 - -5);
    	a983758263 = (((((((a983758263 * a1675035970) % 14999) % 101) + 304) - 15941) - 7101) - -23042);
    	a1241576728 = (a2087535773 - -5);
    	a2026977784 = (a1210910088 + 6);
    	a369798198 = 33 ;
    	a26346326 = 34 ;
    	a1983740902 = 33 ;
    	a1625516355 = (((((((a1625516355 * a999024345) % 14999) * 2) - 1) / 5) % 13) + -95);
    	a1478681170 = ((a190525986 / a778006913) - 6);
    	a1916853335 = (a1249952537 - -3);
    	a620105235 = (((((((a341216798 * a813082108) % 14999) % 94) + -118) + -20924) - 7346) - -28273);
    	a2041520547 = 32 ;
    	a217799639 = (((((((a217799639 * a30494462) % 14999) / 5) % 28) + -41) - 20449) + 20455);
    	a2087535773 = a4442917;
    	a1985899004 = (((((((a1985899004 * a813082108) % 14999) + -7311) * 1) + -228) % 76) + 448);
    	a1254983042 = (((((((a1254983042 * a1675035970) % 14999) % 105) + 307) * 5) % 105) - -209);
    	a1180594800 = 34 ;
    	a30494462 = ((((((a30494462 * a1675035970) % 14999) - 3583) - -11914) % 85) - -209);
    	a4442917 = (a778006913 - -6);
    	a1830659124 = ((a1210910088 + a1249952537) + 4);
    	a1675035970 = ((((((((a1675035970 * a999024345) % 14999) - 12766) % 51) - -259) * 5) % 51) - -247);
    	a1774184757 = (((((((a30494462 * a1985899004) % 14999) % 66) + 97) * 5) % 66) + 73);
    	a1644957382 = 34 ;
    	a2130183577 = ((((((a1985899004 * a341216798) % 14999) % 12) - -232) - -8) + 1);
    	a778006913 = (a1895857334 + -9);
    	a999024345 = ((((((a999024345 * a813082108) % 14999) + 11668) + 2901) % 64) - -196);
    	a76745981 = 34 ;
    	a63333937 = ((((((a217799639 * a1675035970) % 106) - -192) - 3) * 10) / 9);
    	a709568404 = 34 ;
    	a1125477212 = 34 ;
    	a302110279 = 34 ;
    	a1249952537 = (a2026977784 + -3); 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((((a709568404 == 32 && (a217799639 <=  -198 && (a30494462 <=  -62 && a1018383389 <=  17))) && a26346326 == 32) && (a2087535773 == 3 && ( cf==1  && (input == 6))))) {
    	a639488566 += (a639488566 + 20) > a639488566 ? 6 : 0;
    	cf = 0;
    	a1625516355 = ((((((a1625516355 * a999024345) % 14999) % 37) + -41) - 17672) + 17670);
    	a1675035970 = ((((((((a1018383389 * a999024345) % 14999) % 51) - -260) + -2) * 5) % 51) + 236);
    	a778006913 = (a786258498 - 7);
    	a30494462 = (((((((a30494462 * a1675035970) % 14999) % 85) + 209) - -13667) + 15058) - 28724);
    	a2073482783 = 34 ;
    	a63333937 = ((((((a1625516355 * a1254983042) % 14999) - 26182) - -23400) + 5684) + -21378);
    	a983758263 = (((((((a983758263 * a2130183577) % 14999) % 14796) + 15202) - -1) + -9276) + 9278);
    	a1644957382 = 34 ;
    	a1826277115 = ((((((a1756173294 * a341216798) % 14999) % 105) - 51) + -1) - 1);
    	a1985899004 = (((((((a1985899004 * a983758263) % 14999) * 2) % 76) + 448) + 21072) - 21071);
    	a1916853335 = (a1959068056 - 3);
    	a709568404 = 34 ;
    	a708839806 = 32 ;
    	a302110279 = 34 ;
    	a661990791 = ((a1249952537 + a1830659124) + -3);
    	a263219509 = (a190525986 - -2);
    	a1180594800 = 34 ;
    	a1830659124 = ((a1959068056 * a2061425267) + -109);
    	a1318526106 = 32 ;
    	a76745981 = 32 ;
    	a1151361287 = ((((((((a999024345 * a1625516355) % 14999) - -4155) % 20) - -271) * 5) % 20) - -271);
    	a2130183577 = (((((a2130183577 * a30494462) % 14999) - 12382) - -9390) + -11950);
    	a190525986 = (a1478681170 - -7);
    	a1211013485 = 32 ;
    	a263151501 = 34 ;
    	a1249952537 = (a786258498 - 4);
    	a2130193413 = (a4442917 + 6);
    	a260539918 = (((((((a260539918 * a1756173294) % 14999) % 17) + -26) * 9) / 10) + 1);
    	a1254983042 = (((((((a1254983042 * a1774184757) % 14999) % 105) + 309) + -24859) + 11866) + 12991);
    	a1018383389 = ((((((a1018383389 * a813082108) % 14999) * 2) + -1) % 21) - -190);
    	a2087535773 = (a1241576728 - 1);
    	a999024345 = ((((((a999024345 * a1625516355) % 14999) * 2) / 5) % 64) + 196);
    	a601495656 = 32 ;
    	a1241576728 = (a1249952537 + 2);
    	a1895304149 = 33 ;
    	a217799639 = (((((((a217799639 * a1151361287) % 14999) % 28) - 28) + -2) + -25459) + 25460);
    	a4442917 = (a1210910088 - -6);
    	a26346326 = 34 ;
    	a1210910088 = (a786258498 - 7);
    	a1478681170 = ((a786258498 + a2026977784) + -12);
    	a2026977784 = (a1700231631 + 2); 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((((a1018383389 <=  17 && (a30494462 <=  -62 && a1675035970 <=  171)) && a1916853335 == 5) && a302110279 == 32) && (( cf==1  && (input == 7)) && a1241576728 == 6))) {
    	cf = 0;
    	a601495656 = 33 ;
    	a263151501 = 34 ;
    	a263219509 = (a2087535773 - -6);
    	a709568404 = 34 ;
    	a1826277115 = (((((((a1756173294 * a1756173294) % 14999) + 309) + 2807) / 5) % 105) - 51);
    	a1180594800 = 34 ;
    	a1644957382 = 34 ;
    	a26346326 = 34 ;
    	a1916853335 = (a778006913 + 6);
    	a1151361287 = ((((((((a341216798 * a2130183577) % 14999) % 20) + 269) * 5) + -14000) % 20) + 287);
    	a778006913 = (a2061425267 + -9);
    	a217799639 = ((((((a217799639 * a1675035970) % 14999) % 28) + -29) + 1) - 2);
    	a76745981 = 34 ;
    	a63333937 = ((((((a999024345 * a1151361287) % 14999) / 5) * 5) % 106) + 136);
    	a983758263 = (((((((a983758263 * a1254983042) % 14999) + 8454) / 5) - 16461) * -1) / 10);
    	a2140773614 = 36 ;
    	a2026977784 = a1830659124;
    	a1895304149 = 34 ;
    	a2087535773 = (a2130193413 + -4);
    	a1675035970 = (((((((a2130183577 * a1774184757) % 14999) % 51) - -258) * 5) % 51) - -221);
    	a4442917 = ((a786258498 / a1478681170) + 4);
    	a2130193413 = ((a2026977784 - a1249952537) + 6);
    	a620105235 = (((((a1826277115 * a1774184757) % 94) + -63) + -2) - -2);
    	a999024345 = ((((((((a999024345 * a1826277115) % 14999) % 64) + 196) * 1) * 5) % 64) + 133);
    	a1985899004 = ((((((a1985899004 * a260539918) % 14999) / 5) % 76) + 448) - 1);
    	a1830659124 = ((a2026977784 + a263219509) - 7);
    	a1249952537 = ((a786258498 * a2087535773) - 44);
    	a302110279 = 34 ;
    	a1210910088 = (a190525986 + -6);
    	a2073482783 = 34 ;
    	a1254983042 = (((((((((a1254983042 * a1625516355) % 14999) % 105) - -233) * 9) / 10) * 5) % 105) - -233);
    	a1625516355 = (((((((a1151361287 * a813082108) % 14999) % 37) - 55) / 5) - 11279) - -11259);
    	a260539918 = (((((((a260539918 * a1018383389) % 14999) + 8321) * 1) * 1) % 73) + 67);
    	a1018383389 = ((((((((a1774184757 * a983758263) % 14999) % 21) + 190) * 5) * 5) % 21) + 169);
    	a190525986 = ((a1700231631 + a1916853335) - 2);
    	a2130183577 = ((((((a2130183577 * a813082108) % 14999) + -7751) % 12) + 243) * 1);
    	a1478681170 = ((a1241576728 - a1210910088) + 2);
    	a30494462 = (((((((a30494462 * a217799639) % 14999) % 92) + -28) / 5) + -8020) + 7996);
    	a1211013485 = 33 ;
    	a1241576728 = (a2061425267 - 4); 
    	 printf("%d\n", 16); fflush(stdout); 
    } if(((a601495656 == 32 && (a76745981 == 32 && ( cf==1  && (input == 13)))) && ((a217799639 <=  -198 && (a2130183577 <=  103 && a260539918 <=  -44)) && a778006913 == 1))) {
    	cf = 0;
    	a4442917 = (a778006913 - -5);
    	a2130183577 = ((((((a2130183577 * a217799639) % 14999) % 63) - -166) + -3787) - -3787);
    	a1985899004 = ((((((((a1985899004 * a341216798) % 14999) * 2) % 98) + 272) * 5) % 98) - -188);
    	a601495656 = 34 ;
    	a1348848030 = (a1916853335 - -5);
    	a302110279 = 33 ;
    	a721272783 = (a190525986 + 1);
    	a1983740902 = 34 ;
    	a1180594800 = 34 ;
    	a786258498 = (a4442917 - -3);
    	a2130193413 = ((a721272783 + a4442917) - 5);
    	a778006913 = (a4442917 + -4);
    	a76745981 = 33 ;
    	a1018383389 = ((((((a1018383389 * a63333937) % 14999) % 21) - -189) + -5049) - -5050);
    	a1125477212 = 33 ;
    	a803418896 = (((((((a1756173294 * a1625516355) % 14999) % 89) - 84) / 5) - 1802) - -1750);
    	a263151501 = 33 ;
    	a2073482783 = 34 ;
    	a2061425267 = ((a4442917 - a786258498) - -14);
    	a813082108 = (((((((a620105235 * a999024345) % 14999) % 50) + 53) + 0) - -24939) - 24938);
    	a1241576728 = (a2087535773 + 4);
    	a2087535773 = (a2061425267 - 7);
    	a1959068056 = (a1700231631 - -3);
    	a30494462 = ((((((a30494462 * a1151361287) % 14999) - -12718) % 92) + 32) + 1);
    	a260539918 = (((((((a260539918 * a217799639) % 14999) / 5) + -17990) + -10821) % 73) - -109);
    	a1211013485 = 33 ;
    	a1210910088 = (a1478681170 - 1);
    	a1916853335 = ((a190525986 - a1348848030) - -7);
    	a1254983042 = (((((((a1254983042 * a1625516355) % 14999) % 101) - -78) + -66) * 10) / 9);
    	a1478681170 = (a190525986 + -5);
    	a1675035970 = (((((((a1675035970 * a813082108) % 14999) / 5) / 5) / 5) % 17) - -190);
    	a1644957382 = 33 ;
    	a1625516355 = ((((((a620105235 * a2130183577) % 14999) + 20555) - -4145) % 13) + -94);
    	a2026977784 = ((a1959068056 + a1249952537) - 5);
    	a1895304149 = 33 ;
    	a190525986 = ((a4442917 + a4442917) + -2);
    	a983758263 = (((((((a983758263 * a999024345) % 14999) - -7311) * 1) + -19196) % 104) - -98);
    	a709568404 = 33 ;
    	a1249952537 = (a1830659124 - 4);
    	a1830659124 = (a1959068056 - -2);
    	a217799639 = ((((((a217799639 * a1756173294) % 14999) - -10093) % 28) + -29) - -1);
    	a1774184757 = ((((((a620105235 * a63333937) * 1) % 66) + 102) / 5) - -107);
    	a708839806 = 33 ;
    	a26346326 = 33 ;
    	a999024345 = (((((((a999024345 * a2130183577) % 14999) % 64) + 195) - -2) - -23150) - 23151); 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm51(int input) {
    if(((a709568404 == 32 && (a2026977784 == 7 && ( cf==1  && (input == 2)))) && (a813082108 <=  3 && ((a1125477212 == 32 && a1254983042 <=  -2) && a1211013485 == 32)))) {
    	cf = 0;
    	a63333937 = (((((a1254983042 * a1254983042) % 14999) + -25208) / 5) + -23084);
    	a1318526106 = 32 ;
    	a620105235 = (((((a63333937 * a63333937) % 14999) + 4681) - 32011) * 1);
    	a1644957382 = 32 ;
    	a260539918 = (((((((((a260539918 * a620105235) % 14999) % 17) - 29) * 9) / 10) * 5) % 17) + -19);
    	a1151361287 = (((((((a2130183577 * a2130183577) % 14999) % 86) + 163) / 5) - 24897) + 25002);
    	a2073482783 = 33 ;
    	a2087535773 = ((a778006913 / a2061425267) + 4);
    	a341216798 = (((((a341216798 * a1756173294) % 14999) + -29719) + -97) + -108);
    	a1675035970 = ((((((a813082108 * a813082108) % 14999) - 11937) + 4945) + -275) + -7624);
    	a1774184757 = (((((((a1774184757 * a30494462) % 14999) % 92) + -135) - -19) - 982) + 1012);
    	a1985899004 = ((((((a620105235 * a1254983042) % 14999) % 98) - -201) - -1995) - 1988);
    	a1213722969 = (a1916853335 - -1);
    	a1249952537 = ((a1478681170 - a2026977784) + 9);
    	a1625516355 = ((((((a1625516355 * a999024345) % 14999) % 13) - 95) + 1) + 1);
    	a834646264 = (a1210910088 + a1916853335);
    	a1211013485 = 33 ;
    	a1983740902 = 33 ;
    	a1916853335 = a1241576728;
    	a263151501 = 33 ;
    	a1959068056 = (a1478681170 - -6);
    	a26346326 = 32 ;
    	a217799639 = ((((((a217799639 * a1675035970) % 14999) % 69) - 127) + -1) + -1);
    	a1830659124 = ((a4442917 * a1478681170) + -5);
    	a708839806 = 33 ;
    	a1478681170 = (a1241576728 + -2);
    	a190525986 = (a1241576728 + 4); 
    	 printf("%d\n", 17); fflush(stdout); 
    } if((((a1180594800 == 32 && (a30494462 <=  -62 && a1625516355 <=  -109)) && a1125477212 == 32) && ((((input == 7) &&  cf==1 ) && a76745981 == 32) && a1916853335 == 5))) {
    	cf = 0;
    	a2026977784 = 9;
    	a1774184757 = ((((((a1774184757 * a2130183577) % 14999) / 5) / 5) % 66) - -103);
    	a1260876233 = (((((((a1756173294 * a341216798) % 14999) - 17875) * 1) + 5957) % 53) - 40);
    	a2004613952 = ((a2087535773 + a1210910088) - -9);
    	a778006913 = (a1959068056 - 5);
    	a30494462 = ((((((a30494462 * a1625516355) % 14999) + -13235) * 2) % 85) - -210);
    	a601495656 = 34 ;
    	a2130183577 = ((((((a260539918 * a1254983042) % 14999) + -24662) / 5) % 12) + 249);
    	a1895857334 = (a1916853335 + 2);
    	a1241576728 = ((a2026977784 + a2026977784) + -10);
    	a1249952537 = (a1478681170 + 3);
    	a2087535773 = (a1959068056 - 3);
    	a2061425267 = ((a2026977784 - a2026977784) + 12);
    	a1211013485 = 34 ;
    	a999024345 = ((((((((a999024345 * a217799639) % 14999) % 64) - -196) + -1156) / 5) * -8) / 10);
    	a1895304149 = 34 ;
    	a76745981 = 34 ;
    	a2130193413 = (a1210910088 + 10);
    	a1625516355 = (((((((a260539918 * a813082108) % 14999) / 5) / 5) / 5) % 37) - 41);
    	a1916853335 = (a1241576728 - 1);
    	a217799639 = ((((((a260539918 * a1774184757) % 14999) % 28) - 30) + -12815) - -12814);
    	a1959068056 = (a2026977784 + 1);
    	a983758263 = ((((((a983758263 * a1260876233) % 14999) % 101) - -304) + -9254) + 9254);
    	a786258498 = ((a2061425267 + a778006913) + -5);
    	a1125477212 = 34 ;
    	a1254983042 = (((((((a1254983042 * a813082108) % 14999) % 105) - -308) - 18761) - 917) - -19679);
    	a1180594800 = 34 ;
    	a1210910088 = (a4442917 - 2);
    	a4442917 = (a1830659124 - 4);
    	a709568404 = 34 ;
    	a813082108 = ((((((((a813082108 * a1774184757) % 14999) - -12244) % 69) + 174) * 5) % 69) + 129);
    	a260539918 = (((((((a260539918 * a30494462) % 14999) + 22062) + -27391) / 5) % 73) + 89); 
    	 printf("%d\n", 16); fflush(stdout); 
    } if(((((a1254983042 <=  -2 && a1211013485 == 32) && a601495656 == 32) && a217799639 <=  -198) && (a2026977784 == 7 && (a2061425267 == 10 && ( cf==1  && (input == 11)))))) {
    	cf = 0;
    	a620105235 = ((((((a341216798 * a341216798) % 14999) % 10) - 179) + 2) - 2);
    	a1675035970 = ((((((((a341216798 * a341216798) % 14999) % 17) + 178) * 5) - -14088) % 17) + 188);
    	a601495656 = 33 ;
    	a813082108 = ((((((a1675035970 * a620105235) % 14999) - 7229) + 20244) % 50) + 54);
    	a1644957382 = 33 ;
    	a263151501 = 33 ;
    	a190525986 = (a1959068056 - -2);
    	a4442917 = ((a1249952537 / a1241576728) - -6);
    	a63333937 = (((((((a341216798 * a620105235) % 14999) - -3097) % 81) + -51) + 14837) - 14838);
    	a1151361287 = (((((((a341216798 * a1675035970) % 14999) - 3462) + -23429) / 5) % 86) + 178);
    	a1018383389 = ((((((a1675035970 * a620105235) % 14999) % 74) + 92) + 12808) - 12808);
    	a26346326 = 33 ;
    	a1774184757 = ((((((a1774184757 * a1675035970) % 14999) % 92) + -56) + -19840) - -19837);
    	a1985899004 = ((((((a620105235 * a620105235) % 14999) - -7872) + -20787) % 98) + 273);
    	a1830659124 = (a1959068056 + 2);
    	a260539918 = (((((((a260539918 * a813082108) % 14999) % 17) - 26) * 5) % 17) - 13);
    	a76745981 = 33 ;
    	a778006913 = (a1830659124 + -8);
    	a302110279 = 33 ;
    	a1254983042 = ((((((a1254983042 * a2130183577) % 14999) / 5) % 101) + 101) / 5);
    	a2073482783 = 33 ;
    	a709568404 = 33 ;
    	a1895304149 = 33 ;
    	a708839806 = 33 ;
    	a1916853335 = ((a190525986 + a4442917) + -10);
    	a999024345 = (((((((a999024345 * a1774184757) % 14999) % 41) - -90) - 1) + 6569) + -6568);
    	a983758263 = ((((((a983758263 * a1625516355) % 14999) + 5733) % 104) + -3) / 5);
    	a1180594800 = 33 ;
    	a1983740902 = 33 ;
    	a2130183577 = ((((((a63333937 * a63333937) % 63) + 167) + -26010) - 737) - -26746);
    	a1891437507 = 36 ;
    	a721272783 = ((a1478681170 * a2087535773) - -5);
    	a2130193413 = ((a1241576728 * a1916853335) + -26);
    	a30494462 = ((((((((a30494462 * a217799639) % 14999) % 92) + 20) * 5) + 17125) % 92) + -26);
    	a1478681170 = (a2026977784 + -3);
    	a786258498 = ((a1959068056 * a2087535773) - 15);
    	a1625516355 = (((((((a813082108 * a620105235) % 13) + -83) * 10) / 9) + 14660) + -14657);
    	a1211013485 = 33 ;
    	a2087535773 = (a2061425267 + -6);
    	a1345687529 = (((((a1756173294 * a983758263) - -4002) - -2572) + -24222) - -19281);
    	a1210910088 = (a1916853335 - 4);
    	a2061425267 = (a1959068056 + 3);
    	a217799639 = ((((((a217799639 * a1018383389) % 14999) - -7529) % 69) - 127) + -1);
    	a1125477212 = 33 ;
    	a2026977784 = (a1249952537 + 4);
    	a1241576728 = ((a1249952537 + a4442917) - 3);
    	a1249952537 = (a1916853335 - 1);
    	a1959068056 = 9; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((a1959068056 == 8 && (((input == 15) &&  cf==1 ) && a2130183577 <=  103)) && (((a786258498 == 8 && a999024345 <=  48) && a709568404 == 32) && a813082108 <=  3))) {
    	cf = 0;
    	a1959068056 = 10;
    	a1478681170 = (a1959068056 - 5);
    	a1895857334 = ((a1916853335 / a1916853335) + 10);
    	a2026977784 = (a1478681170 - -4);
    	a1254983042 = (((((((a1151361287 * a620105235) % 14999) * 2) % 105) + 308) - -12019) - 12019);
    	a1241576728 = (a1478681170 + 3);
    	a983758263 = (((((((a983758263 * a1756173294) % 14999) / 5) % 101) - -305) + 24866) + -24865);
    	a1180594800 = 34 ;
    	a30494462 = (((((((a30494462 * a1254983042) % 14999) + 10057) - -7580) / 5) % 85) - -194);
    	a1625516355 = ((((((a1625516355 * a1675035970) % 14999) + -7988) - -13193) % 37) - 42);
    	a778006913 = (a1895857334 - 8);
    	a1125477212 = 34 ;
    	a76745981 = 34 ;
    	a999024345 = ((((((a999024345 * a260539918) % 14999) % 64) - -196) * 1) - -1);
    	a263638061 = ((a2061425267 - a1895857334) + 7);
    	a1574467713 = (a2130193413 - 8);
    	a1249952537 = (a1830659124 + -5);
    	a1210910088 = a778006913;
    	a709568404 = 34 ;
    	a2130183577 = (((((((a2130183577 * a260539918) % 14999) / 5) % 12) - -243) / 5) - -189);
    	a1211013485 = 34 ;
    	a2087535773 = ((a4442917 - a1241576728) + 8);
    	a786258498 = (a778006913 - -7);
    	a1774184757 = (((((((a1774184757 * a217799639) % 14999) % 66) - -50) * 9) / 10) - -24);
    	a601495656 = 34 ;
    	a1895304149 = 34 ;
    	a2130193413 = a190525986;
    	a1916853335 = (a2061425267 - 3);
    	a2061425267 = (a2026977784 - -3);
    	a217799639 = ((((((a217799639 * a813082108) % 14999) * 2) % 28) + -29) + -1);
    	a4442917 = (a1478681170 - -2);
    	a813082108 = (((((((a341216798 * a341216798) % 14999) % 69) + 119) - -7) * 9) / 10);
    	a260539918 = ((((((((a260539918 * a983758263) % 14999) - -23824) % 73) - 1) * 5) % 73) + 67); 
    	 printf("%d\n", 18); fflush(stdout); 
    } 
}
 void calculate_outputm54(int input) {
    if((( cf==1  && (input == 2)) && (a30494462 <=  -62 && ((((a709568404 == 32 && a1916853335 == 5) && a4442917 == 5) && a190525986 == 9) && a999024345 <=  48)))) {
    	cf = 0;
    	a1210910088 = (a1249952537 + -3);
    	a601495656 = 32 ;
    	a1478681170 = (a190525986 - 6);
    	a1644957382 = 32 ;
    	a813082108 = ((((((a341216798 * a1625516355) % 14999) - 6208) * 10) / 9) / 5);
    	a63333937 = (((((a217799639 * a1337636546) % 14999) / 5) + -14601) * 1);
    	a786258498 = (a1241576728 + 2);
    	a1318526106 = 32 ;
    	a2130183577 = (((((a999024345 * a1151361287) % 14999) + -1865) + 7832) - 20928);
    	a263151501 = 32 ;
    	a1959068056 = (a2026977784 - -1);
    	a1018383389 = ((((((a30494462 * a1675035970) % 14999) % 74) - -92) + 3363) - 3362); 
    	 printf("%d\n", 20); fflush(stdout); 
    } if(((a2130193413 == 9 && ((a1675035970 <=  171 && a1983740902 == 32) && a217799639 <=  -198)) && (a1254983042 <=  -2 && (( cf==1  && (input == 6)) && a1211013485 == 32)))) {
    	cf = 0;
    	a1151361287 = ((((((a1151361287 * a1675035970) % 14999) % 86) - -161) / 5) + 193);
    	a341216798 = ((((((a341216798 * a1756173294) % 14999) + -24445) / 5) - -14702) - 25089);
    	a1213722969 = (a2026977784 - -4);
    	a302110279 = 33 ;
    	a834646264 = (a4442917 - -1);
    	a1018383389 = (((((((a2130183577 * a1625516355) % 14999) - -8627) + 4173) - -1227) % 74) + 91);
    	a1625516355 = (((((((a1625516355 * a1254983042) % 14999) - 8407) % 13) + -95) + -2831) - -2830); 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((((a1895304149 == 32 && a620105235 <=  -182) && a26346326 == 32) && a1180594800 == 32) && ((((input == 15) &&  cf==1 ) && a1916853335 == 5) && a778006913 == 1))) {
    	cf = 0;
    	a63333937 = ((((((a620105235 * a620105235) % 14999) + -28401) + 3186) % 81) + 26);
    	a999024345 = (((((((a999024345 * a1756173294) % 14999) + 5131) % 41) - -89) - -17674) - 17672);
    	a983758263 = (((((((a983758263 * a1985899004) % 14999) % 104) - -98) - 2305) + -2260) - -4565);
    	a1895304149 = 33 ;
    	a2130183577 = ((((((a999024345 * a1018383389) % 63) + 124) * 10) / 9) + -7);
    	a813082108 = ((((((a260539918 * a2130183577) % 14999) % 50) + 53) / 5) - -28);
    	a4442917 = ((a778006913 + a2087535773) - -2);
    	a721272783 = (a2026977784 + 7);
    	a2073482783 = 33 ;
    	a778006913 = (a1241576728 - 4);
    	a1891437507 = 35 ;
    	a1345687529 = (((((a983758263 * a341216798) % 14999) / 5) + 9838) - -3833);
    	a1151361287 = ((((((a1151361287 * a1337636546) % 14999) % 86) + 163) + 1) + -1);
    	a1254983042 = ((((((a1254983042 * a813082108) % 14999) + -7672) % 101) + 135) + 33);
    	a302110279 = 33 ;
    	a1478681170 = (a2130193413 + -5);
    	a30494462 = ((((((a30494462 * a983758263) % 14999) * 2) * 1) % 92) - -30);
    	a1644957382 = 33 ;
    	a1625516355 = (((((((a1625516355 * a620105235) % 14999) - 27233) + -2718) + 36435) % 13) + -99);
    	a26346326 = 33 ;
    	a1210910088 = ((a1478681170 / a190525986) - -2);
    	a1675035970 = ((((((((a1675035970 * a620105235) % 14999) % 17) - -189) * 5) - 13284) % 17) + 197);
    	a620105235 = ((((((a620105235 * a2130183577) % 14999) % 10) - 169) - 2) * 1); 
    	 printf("%d\n", 26); fflush(stdout); 
    } 
}
 void calculate_outputm3(int input) {
    if(((a217799639 <=  -198 && (a1254983042 <=  -2 && a263151501 == 32)) && (((( cf==1  && a1756173294 <=  76) && a2087535773 == 3) && a1985899004 <=  174) && a1644957382 == 32))) {
    	if(((a2130183577 <=  103 && ((a1241576728 == 6 && a263151501 == 32) && a1644957382 == 32)) && ((( cf==1  && a1700231631 == 5) && a2130193413 == 9) && a26346326 == 32))) {
    		calculate_outputm48(input);
    	} 
    	if((((a1985899004 <=  174 && (a1700231631 == 6 &&  cf==1 )) && a601495656 == 32) && (a1241576728 == 6 && ((a26346326 == 32 && a1180594800 == 32) && a1916853335 == 5)))) {
    		calculate_outputm49(input);
    	} 
    } 
    if((((a709568404 == 32 && (a1210910088 == 1 && (((76 < a1756173294) && (113 >= a1756173294)) &&  cf==1 ))) && a601495656 == 32) && ((a999024345 <=  48 && a1774184757 <=  -151) && a1249952537 == 4))) {
    	if(((a1774184757 <=  -151 && (a76745981 == 32 && a1916853335 == 5)) && ((a709568404 == 32 && (( cf==1  && a1354435613 == 33) && a1125477212 == 32)) && a786258498 == 8))) {
    		calculate_outputm51(input);
    	} 
    } 
    if((((((113 < a1756173294) && (221 >= a1756173294)) &&  cf==1 ) && a1249952537 == 4) && (a1125477212 == 32 && (a1830659124 == 9 && ((a1151361287 <=  75 && a1254983042 <=  -2) && a1985899004 <=  174))))) {
    	if(((a1625516355 <=  -109 && ((a2073482783 == 32 && (236 < a1337636546 &&  cf==1 )) && a4442917 == 5)) && ((a1254983042 <=  -2 && a302110279 == 32) && a708839806 == 32))) {
    		calculate_outputm54(input);
    	} 
    } 
}
 void calculate_outputm55(int input) {
    if(((a1916853335 == 5 && a1180594800 == 32) && ((((( cf==1  && (input == 2)) && a1249952537 == 4) && a190525986 == 9) && a217799639 <=  -198) && a1644957382 == 32))) {
    	cf = 0;
    	a263219509 = ((a778006913 + a1478681170) + 1);
    	a813082108 = ((((((((a813082108 * a63333937) % 14999) % 69) - -173) + 10518) / 5) * 1) / 10);
    	a620105235 = ((((((a620105235 * a1625516355) % 14999) + 9378) % 94) - 137) + 52);
    	a63333937 = ((((((a1625516355 * a983758263) % 14999) % 106) - -37) - -65) + -1);
    	a999024345 = (((((((a999024345 * a1018383389) % 14999) * 2) + 0) + 1) % 64) + 195);
    	a709568404 = 34 ;
    	a1254983042 = (((((((a1254983042 * a1625516355) % 14999) % 105) - -242) + 15) + -8272) - -8301);
    	a1985899004 = (((((((a260539918 * a813082108) % 14999) * 2) * 1) / 5) % 76) - -447);
    	a1826277115 = (((((((a983758263 * a341216798) % 14999) + 10112) % 105) - 52) + 7810) + -7809);
    	a1912617323 = ((a263219509 * a2026977784) - 21);
    	a2130193413 = ((a1959068056 + a1916853335) + -4);
    	a30494462 = ((((((a30494462 * a260539918) % 14999) - 8695) % 85) + 209) * 1);
    	a217799639 = ((((((((a1985899004 * a813082108) % 14999) % 28) - 57) + 11) * 5) % 28) + -24);
    	a1211013485 = 34 ;
    	a1830659124 = ((a2061425267 - a263219509) + 4);
    	a302110279 = 34 ;
    	a1774184757 = ((((((((a1774184757 * a217799639) % 14999) % 66) - -45) * 5) * 5) % 66) - -40);
    	a2026977784 = (a1959068056 - 1);
    	a1151361287 = (((((((a1151361287 * a999024345) % 14999) - 7830) % 20) - -271) + 9568) - 9567);
    	a1644957382 = 34 ;
    	a1180594800 = 34 ;
    	a1675035970 = (((((((a1675035970 * a217799639) % 14999) % 51) - -258) + 2) - -23194) + -23193);
    	a2087535773 = ((a1916853335 + a1249952537) - 4);
    	a1249952537 = ((a1521644128 + a1916853335) + -2);
    	a1895304149 = 34 ;
    	a190525986 = (a1916853335 - -6);
    	a778006913 = (a786258498 + -7);
    	a4442917 = (a1916853335 - -2);
    	a1478681170 = (a1959068056 + -5);
    	a1018383389 = (((((a813082108 * a1625516355) - 4073) - 5810) % 21) + 189);
    	a2130183577 = ((((((a2130183577 * a260539918) % 14999) / 5) * 5) % 12) - -243);
    	a1241576728 = ((a1210910088 / a1210910088) - -7);
    	a1916853335 = (a2130193413 + -4);
    	a983758263 = ((((((a983758263 * a1826277115) % 14999) % 14796) + 15202) - 0) * 1); 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a76745981 == 32 && ( cf==1  && (input == 5))) && (a1249952537 == 4 && (a620105235 <=  -182 && ((a1644957382 == 32 && a709568404 == 32) && a2026977784 == 7))))) {
    	cf = 0;
    	a1916853335 = (a1249952537 - -3);
    	a1254983042 = (((((((a30494462 * a620105235) % 14999) - 6942) % 105) + 308) - -26553) - 26552);
    	a190525986 = ((a1210910088 - a1916853335) - -15);
    	a1180594800 = 34 ;
    	a4442917 = (a1521644128 + 4);
    	a1826277115 = ((((((a63333937 * a341216798) % 14999) - -3572) * 2) / 5) + 25137);
    	a404763935 = ((a2130193413 / a1478681170) - -11);
    	a2073482783 = 34 ;
    	a2026977784 = ((a1830659124 + a786258498) - 10);
    	a999024345 = (((((((a999024345 * a1018383389) % 14999) % 64) + 196) / 5) * 5) + 2);
    	a63333937 = ((((((a30494462 * a1774184757) % 14999) + 100) * 1) % 106) - -91);
    	a1985899004 = ((((((a1774184757 * a1254983042) % 14999) / 5) + -14456) % 76) + 522);
    	a983758263 = ((((((a983758263 * a1826277115) % 14999) - -26013) * 10) / 9) - -61);
    	a620105235 = (((((((a983758263 * a217799639) % 14999) % 94) - 63) + -2) - 20870) - -20871);
    	a2061425267 = ((a1478681170 * a1478681170) + 3);
    	a1211013485 = 34 ;
    	a26346326 = 34 ;
    	a1249952537 = (a404763935 - 8);
    	a217799639 = ((((((a999024345 * a63333937) % 14999) % 28) - 51) / 5) + -27);
    	a1151361287 = ((((((a1151361287 * a999024345) % 14999) % 20) + 270) + 12664) + -12664);
    	a1125477212 = 34 ;
    	a302110279 = 34 ;
    	a601495656 = 34 ;
    	a1318526106 = 34 ;
    	a1895304149 = 34 ;
    	a2087535773 = (a404763935 + -9);
    	a1675035970 = (((((((a1675035970 * a1985899004) % 14999) % 51) - -259) + 1) + 9087) + -9086);
    	a2130193413 = (a1210910088 - -8);
    	a548050643 = 35 ;
    	a2130183577 = ((((((((a813082108 * a1625516355) % 14999) + 242) % 12) - -243) * 5) % 12) + 241);
    	a778006913 = (a1241576728 - 3);
    	a1959068056 = ((a1916853335 - a4442917) + 10);
    	a1830659124 = (a2026977784 - -2);
    	a709568404 = 34 ;
    	a813082108 = ((((((a813082108 * a2130183577) % 14999) % 69) - -174) - -1) * 1);
    	a1644957382 = 34 ;
    	a30494462 = ((((((((a1625516355 * a983758263) % 14999) - -5035) % 85) + 211) * 5) % 85) + 150);
    	a1241576728 = (a1478681170 + 5);
    	a1478681170 = (a2026977784 - 4); 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a1985899004 <=  174 && (a4442917 == 5 && a1211013485 == 32)) && ((a1018383389 <=  17 && (a620105235 <=  -182 && ((input == 15) &&  cf==1 ))) && a1916853335 == 5))) {
    	a170107731 -= (a170107731 - 20) < a170107731 ? 1 : 0;
    	cf = 0;
    	a1830659124 = (a1521644128 + 8);
    	a63333937 = (((((((a63333937 * a1985899004) % 14999) * 2) % 106) + 136) - 13789) - -13788);
    	a2087535773 = a4442917;
    	a983758263 = (((((((a983758263 * a1254983042) % 14999) - -10689) % 101) - -258) * 9) / 10);
    	a1180594800 = 34 ;
    	a1895857334 = ((a1241576728 + a1916853335) - 3);
    	a1644957382 = 34 ;
    	a362219248 = (((((a341216798 * a983758263) % 14999) / 5) - -26465) + 64);
    	a217799639 = ((((((a217799639 * a1018383389) % 14999) + -9649) % 28) + -28) + -2);
    	a778006913 = (a2130193413 - 6);
    	a369798198 = 33 ;
    	a76745981 = 34 ;
    	a999024345 = (((((((a999024345 * a620105235) % 14999) % 64) - -195) * 1) + -5862) + 5862);
    	a1895304149 = 34 ;
    	a1254983042 = (((((((a1774184757 * a1151361287) % 14999) * 2) + 1) * 1) % 105) - -309);
    	a1249952537 = ((a2130193413 / a786258498) - -6);
    	a30494462 = ((((((a30494462 * a1018383389) % 14999) % 85) - -209) + 1) * 1);
    	a1916853335 = ((a1478681170 + a2026977784) + -3);
    	a1985899004 = (((((((a1985899004 * a813082108) % 14999) / 5) - 14777) / 5) % 76) - -449); 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm57(int input) {
    if(((a601495656 == 32 && a709568404 == 32) && (a1254983042 <=  -2 && (a1211013485 == 32 && ((a1675035970 <=  171 && ((input == 11) &&  cf==1 )) && a1625516355 <=  -109))))) {
    	cf = 0;
    	a1018383389 = ((((((a1018383389 * a30494462) % 14999) + -4225) % 21) - -190) - -1);
    	a1983740902 = 33 ;
    	a2073482783 = 32 ;
    	a965340096 = 32 ;
    	a1125477212 = 32 ;
    	a1830659124 = (a2087535773 + 6);
    	a1521644128 = ((a2130193413 + a786258498) - 12);
    	a1644957382 = 32 ;
    	a1478681170 = ((a4442917 + a2026977784) - 7);
    	a1916853335 = a4442917;
    	a63333937 = (((((((a217799639 * a1985899004) % 14999) % 14932) - 15066) - -21968) - -7666) - 29635);
    	a1210910088 = ((a2026977784 / a778006913) + -6);
    	a190525986 = (a2061425267 + -1); 
    	 printf("%d\n", 26); fflush(stdout); 
    } if((((a786258498 == 8 && (a26346326 == 32 && ( cf==1  && (input == 13)))) && a708839806 == 32) && ((a76745981 == 32 && a263151501 == 32) && a217799639 <=  -198))) {
    	cf = 0;
    	a721272783 = (a2061425267 - -4);
    	a1345687529 = ((((((a1254983042 * a999024345) % 14999) % 14962) + 15037) - 0) - -1);
    	a1151361287 = (((((((a1018383389 * a1345687529) % 14999) % 86) - -161) / 5) * 51) / 10);
    	a30494462 = (((((((a30494462 * a1774184757) % 14999) % 92) + -18) + -2) - 26567) - -26603);
    	a1675035970 = ((((((((a63333937 * a341216798) % 14999) - 4293) % 17) + 190) * 5) % 17) - -187);
    	a1018383389 = (((((((a1345687529 * a217799639) % 14999) - -12654) * 2) + 1417) % 74) - -93);
    	a1895304149 = 33 ;
    	a813082108 = (((((((a813082108 * a1151361287) % 14999) % 50) + 54) * 5) % 50) + 40);
    	a999024345 = (((((((a1151361287 * a1675035970) % 14999) % 41) - -88) - -2) * 9) / 10);
    	a1891437507 = 35 ;
    	a778006913 = (a1249952537 + -2);
    	a983758263 = ((((((a983758263 * a2130183577) % 14999) % 104) + 99) - 12186) + 12185);
    	a1254983042 = ((((((a1345687529 * a1774184757) % 14999) / 5) % 101) - -99) + 0);
    	a620105235 = (((((((a620105235 * a1774184757) % 14999) - 12712) / 5) + 1964) % 10) - 170);
    	a26346326 = 33 ;
    	a2130183577 = (((((((a2130183577 * a1625516355) % 14999) % 63) - -166) * 1) - -23286) + -23285);
    	a1625516355 = ((((((a1774184757 * a217799639) % 14999) % 13) + -99) - -2) + 4);
    	a302110279 = 33 ;
    	a4442917 = (a1521644128 - -3); 
    	 printf("%d\n", 20); fflush(stdout); 
    } if(((((input == 14) &&  cf==1 ) && a1018383389 <=  17) && (a1774184757 <=  -151 && (((a1983740902 == 32 && a2026977784 == 7) && a1180594800 == 32) && a2061425267 == 10)))) {
    	cf = 0;
    	a2061425267 = (a2130193413 + 3);
    	a1478681170 = (a1959068056 - 3);
    	a2073482783 = 34 ;
    	a1180594800 = 34 ;
    	a2026977784 = a2130193413;
    	a1644957382 = 32 ;
    	a1983740902 = 33 ;
    	a620105235 = ((((((a620105235 * a1254983042) % 14999) % 10) - 179) + -1) * 1);
    	a63333937 = (((((((a1018383389 * a1675035970) % 14999) / 5) * 5) + 2187) % 106) + 136);
    	a1625516355 = (((((((a1625516355 * a1985899004) % 14999) + -7365) - 834) / 5) % 37) - 41);
    	a1210910088 = (a778006913 - -2);
    	a601495656 = 34 ;
    	a1700231631 = ((a1521644128 * a1521644128) + -4);
    	a1756173294 = (((((a1774184757 * a983758263) % 14999) + -23357) / 5) * 5);
    	a341216798 = (((((((a341216798 * a1756173294) % 14999) / 5) * 5) / 5) % 31) + 266);
    	a1018383389 = (((((((a1018383389 * a2130183577) % 14999) % 21) + 190) * 1) + -29628) - -29628); 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((((a2130193413 == 9 && ( cf==1  && (input == 15))) && a30494462 <=  -62) && a4442917 == 5) && ((a1318526106 == 32 && a786258498 == 8) && a1774184757 <=  -151))) {
    	cf = 0;
    	a1983740902 = 33 ;
    	a1180594800 = 34 ;
    	a1756173294 = (((((a341216798 * a341216798) % 14999) + -19479) * 1) + -6275);
    	a1210910088 = (a1249952537 - 1);
    	a2061425267 = (a778006913 + 11);
    	a63333937 = ((((((a1774184757 * a1756173294) % 14999) - -13678) % 106) - -135) + 2);
    	a2026977784 = (a1959068056 + 1);
    	a601495656 = 34 ;
    	a620105235 = ((((((a620105235 * a217799639) % 14999) + 3063) - -10324) % 10) - 175);
    	a2073482783 = 34 ;
    	a341216798 = (((((((a341216798 * a983758263) % 14999) % 31) - -267) - -1) + 7759) - 7760);
    	a1700231631 = ((a1249952537 - a1249952537) + 5);
    	a1625516355 = ((((((a1625516355 * a813082108) % 14999) % 37) - 41) * 1) + -2);
    	a1644957382 = 32 ;
    	a1478681170 = ((a1959068056 / a1241576728) - -4);
    	a1018383389 = (((((((a1018383389 * a1151361287) % 14999) % 21) - -188) / 5) / 5) + 163); 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm59(int input) {
    if((((a76745981 == 32 && a2026977784 == 7) && a30494462 <=  -62) && (a2130193413 == 9 && (a1241576728 == 6 && (((input == 12) &&  cf==1 ) && a1675035970 <=  171))))) {
    	cf = 0;
    	a1675035970 = (((((((a1985899004 * a1254983042) % 14999) / 5) + 773) + -27298) % 51) - -303);
    	a2130193413 = ((a1249952537 / a1550739565) - -10);
    	a983758263 = (((((a983758263 * a999024345) % 14999) / 5) + 3488) + 9772);
    	a153649526 = 36 ;
    	a1125477212 = 34 ;
    	a1241576728 = ((a1916853335 - a1478681170) + 6);
    	a263151501 = 34 ;
    	a1151361287 = ((((((a1151361287 * a2130183577) % 14999) % 20) - -270) - 1) * 1);
    	a1774184757 = ((((((a1774184757 * a620105235) % 14999) % 66) - -101) * 1) + 2);
    	a4442917 = (a2026977784 / a778006913);
    	a217799639 = (((((((((a217799639 * a999024345) % 14999) % 28) - 30) * 9) / 10) * 5) % 28) + -27);
    	a2026977784 = (a786258498 - -1);
    	a813082108 = ((((((a813082108 * a63333937) % 14999) % 69) + 174) - 1) * 1);
    	a1895304149 = 34 ;
    	a1916853335 = (a1830659124 + -4);
    	a1213722969 = (a778006913 - -12);
    	a1826277115 = (((((a983758263 * a341216798) % 14999) + -26527) - 2196) * 1);
    	a1211013485 = 34 ;
    	a76745981 = 34 ;
    	a2087535773 = (a1550739565 + -1);
    	a1180594800 = 34 ;
    	a1983740902 = 34 ;
    	a778006913 = ((a1478681170 / a786258498) + 3);
    	a601495656 = 34 ;
    	a999024345 = ((((((a999024345 * a1675035970) % 14999) + -10248) / 5) % 64) + 195);
    	a302110279 = 34 ;
    	a786258498 = (a190525986 - 1);
    	a2130183577 = ((((((((a2130183577 * a30494462) % 14999) % 12) - -242) - -2) * 5) % 12) + 231);
    	a2073482783 = 34 ;
    	a1478681170 = (a2061425267 + -7);
    	a30494462 = ((((((((a30494462 * a1675035970) % 14999) % 85) + 210) + -3306) * 5) % 85) - -221); 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((a2073482783 == 32 && (a1983740902 == 32 && ((a601495656 == 32 && a786258498 == 8) && a2026977784 == 7))) && (( cf==1  && (input == 13)) && a1125477212 == 32))) {
    	cf = 0;
    	a1826277115 = ((((((a983758263 * a983758263) % 14999) - 24030) + 24368) + -12785) + 20345);
    	a263151501 = 34 ;
    	a786258498 = (a1550739565 + 4);
    	a1180594800 = 34 ;
    	a1337636546 = ((((((a999024345 * a999024345) % 14999) + -14999) - 2) + 10796) - 10796);
    	a1895304149 = 34 ;
    	a2087535773 = ((a1478681170 * a1478681170) + -4);
    	a404763935 = (a778006913 + 7);
    	a1151361287 = ((((((a1151361287 * a620105235) % 14999) % 20) + 271) - -1) * 1);
    	a999024345 = (((((((a1675035970 * a813082108) % 14999) + 6526) * 1) + 5353) % 64) - -195);
    	a302110279 = 34 ;
    	a1625516355 = ((((((a620105235 * a620105235) % 37) + -42) * 5) % 37) - 30);
    	a217799639 = (((((((a217799639 * a1675035970) % 14999) / 5) + 18988) - -6384) % 28) - 33);
    	a2130193413 = (a786258498 + 1);
    	a1478681170 = (a190525986 + -6);
    	a601495656 = 34 ;
    	a30494462 = (((((((a30494462 * a1774184757) % 14999) - -7475) / 5) + 12311) % 85) + 154);
    	a4442917 = (a1830659124 + -4);
    	a1211013485 = 34 ;
    	a709568404 = 34 ;
    	a983758263 = (((((a983758263 * a813082108) % 14999) / 5) + 15100) * 1);
    	a1983740902 = 34 ;
    	a778006913 = (a786258498 + -7);
    	a1241576728 = ((a1521644128 - a190525986) + 15);
    	a2026977784 = (a1830659124 - 2);
    	a2073482783 = 34 ;
    	a1675035970 = (((((((a2130183577 * a1826277115) % 14999) / 5) % 51) + 258) - -331) + -330);
    	a1125477212 = 34 ;
    	a813082108 = (((((((a813082108 * a2130183577) % 14999) % 69) + 174) + 16849) / 5) + -3179);
    	a2130183577 = ((((((a2130183577 * a1774184757) % 14999) + -4907) + -7623) % 12) - -243);
    	a1916853335 = ((a786258498 / a190525986) + 7); 
    	 printf("%d\n", 18); fflush(stdout); 
    } if((((a1478681170 == 3 && (a2130183577 <=  103 && a2073482783 == 32)) && a601495656 == 32) && (a786258498 == 8 && (( cf==1  && (input == 15)) && a263151501 == 32)))) {
    	cf = 0;
    	a2073482783 = 33 ;
    	a1018383389 = (((((a30494462 * a1625516355) % 14999) + 14355) / 5) + -6986);
    	a1985899004 = (((((a1675035970 * a1018383389) % 14999) - -8210) - 23109) * 1);
    	a1830659124 = (a778006913 - -8);
    	a1210910088 = (a1916853335 + -4);
    	a26346326 = 32 ;
    	a1254983042 = (((((a1625516355 * a1018383389) % 14999) + -2880) / 5) - 12334);
    	a620105235 = (((((((a30494462 * a341216798) % 14999) - 1227) % 10) - 164) + -23822) - -23818);
    	a999024345 = ((((((a999024345 * a1985899004) % 14999) % 41) - -89) - -1) + 1);
    	a1305578599 = 36 ;
    	a1318526106 = 32 ;
    	a63333937 = ((((((a1018383389 * a983758263) % 14999) % 81) + -53) / 5) * 5);
    	a2130183577 = (((((((a2130183577 * a30494462) % 14999) % 63) - -167) / 5) - -2522) - 2427);
    	a1959068056 = ((a1478681170 * a1550739565) - 10);
    	a119997292 = a1916853335;
    	a1249952537 = (a2130193413 + -5);
    	a813082108 = (((((((a813082108 * a1254983042) % 14999) % 50) + 54) + 1) + -20834) - -20832);
    	a1478681170 = a1249952537;
    	a1644957382 = 33 ;
    	a341216798 = (((((((a341216798 * a983758263) % 14999) % 18) + 216) + -21443) / 5) - -4470); 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm60(int input) {
    if((((a1983740902 == 32 && (a2130183577 <=  103 && a1675035970 <=  171)) && a1180594800 == 32) && ((a1151361287 <=  75 && ((input == 4) &&  cf==1 )) && a263151501 == 32))) {
    	a1233331030 -= (a1233331030 - 20) < a1233331030 ? 4 : 0;
    	cf = 0;
    	a813082108 = (((((((a63333937 * a63333937) % 14999) - 16901) % 69) - -215) * 10) / 9);
    	a302110279 = 34 ;
    	a786258498 = (a2087535773 - -7);
    	a983758263 = ((((((a983758263 * a999024345) % 14999) % 101) + 305) - 1) + 0);
    	a76745981 = 33 ;
    	a263151501 = 34 ;
    	a260539918 = ((((((((a260539918 * a813082108) % 14999) + 1087) % 73) - -67) * 5) % 73) + 67);
    	a999024345 = (((((((a2130183577 * a1774184757) % 14999) % 64) + 195) * 5) % 64) + 138);
    	a63333937 = ((((((((a63333937 * a1018383389) % 14999) - 12879) % 106) - -197) / 5) * 19) / 10);
    	a4442917 = ((a2087535773 / a1241576728) - -7);
    	a1211013485 = 34 ;
    	a1985899004 = (((((((a1985899004 * a1625516355) % 14999) % 76) + 448) + 1) / 5) - -353);
    	a1895857334 = (a190525986 - 1);
    	a1625516355 = ((((((a813082108 * a813082108) % 14999) % 37) + -47) + 12663) - 12660);
    	a30494462 = ((((((a30494462 * a1254983042) % 14999) % 85) - -140) - -10428) + -10362);
    	a1830659124 = a1550739565;
    	a2130193413 = (a1249952537 + 4);
    	a1241576728 = ((a1478681170 / a1521644128) - -7);
    	a1959068056 = (a2087535773 + a2026977784);
    	a369798198 = 36 ;
    	a709568404 = 34 ;
    	a1260876233 = (((((a983758263 * a983758263) % 14999) + 975) * 1) + 7060);
    	a1180594800 = 34 ;
    	a2026977784 = ((a1916853335 / a778006913) + 1);
    	a1983740902 = 34 ;
    	a2073482783 = 34 ;
    	a778006913 = a2087535773;
    	a1254983042 = ((((((((a813082108 * a1018383389) % 14999) - -9880) % 105) + 286) + -3812) * -1) / 10);
    	a1895304149 = 34 ;
    	a190525986 = (a2087535773 - -7);
    	a1774184757 = (((((((a813082108 * a1151361287) % 14999) - -6091) % 66) - -101) - -22699) - 22696);
    	a1675035970 = (((((((a1675035970 * a813082108) % 14999) % 17) + 189) - -6930) + 16853) - 23782);
    	a217799639 = (((((((a217799639 * a341216798) % 14999) % 28) - 28) - 1) * 9) / 10);
    	a2130183577 = ((((((a341216798 * a813082108) % 14999) % 63) + 123) / 5) + 103);
    	a1151361287 = (((((((a1151361287 * a620105235) % 14999) % 20) + 270) + 13543) + -9798) + -3743);
    	a2087535773 = (a2061425267 + -7); 
    	 printf("%d\n", 26); fflush(stdout); 
    } if((((input == 5) &&  cf==1 ) && ((a2087535773 == 3 && (((a63333937 <=  -135 && a260539918 <=  -44) && a2073482783 == 32) && a813082108 <=  3)) && a1895304149 == 32))) {
    	cf = 0;
    	a1210910088 = ((a2087535773 - a2087535773) + 2);
    	a2130183577 = ((((((((a2130183577 * a1774184757) % 14999) % 63) + 167) - 1) * 5) % 63) + 125);
    	a601495656 = 33 ;
    	a620105235 = ((((((a2130183577 * a2130183577) % 14999) % 10) - 177) - -7) - -1);
    	a263151501 = 33 ;
    	a76745981 = 34 ;
    	a709568404 = 33 ;
    	a190525986 = (a778006913 - -9);
    	a1983740902 = 33 ;
    	a1895304149 = 33 ;
    	a1151361287 = ((((((a620105235 * a813082108) % 14999) + -614) % 86) + 161) + 3);
    	a1254983042 = ((((((a2130183577 * a2130183577) % 14999) % 101) - 1) + -4489) - -4572);
    	a1985899004 = ((((((a1985899004 * a1151361287) % 14999) % 98) - -273) * 1) + -1);
    	a834646264 = ((a4442917 / a2130193413) - -9);
    	a999024345 = ((((((((a999024345 * a341216798) % 14999) % 41) + 90) * 5) * 5) % 41) + 55);
    	a260539918 = ((((((a260539918 * a1254983042) % 14999) % 73) + 67) - -1) / 5);
    	a1241576728 = (a1830659124 + -2);
    	a1125477212 = 33 ;
    	a1180594800 = 34 ;
    	a721272783 = (a1550739565 + 6);
    	a1018383389 = ((((51 - -59) + 10305) * 2) - 20669);
    	a217799639 = (((((((a217799639 * a30494462) % 14999) / 5) % 69) + -150) - 1080) - -1035);
    	a1211013485 = 33 ;
    	a1700231631 = (a778006913 + 6);
    	a1249952537 = (a1210910088 + 3);
    	a1830659124 = (a1210910088 + 8);
    	a30494462 = ((((((a1018383389 * a1018383389) - -1550) * 1) - 26335) % 92) - -32);
    	a1916853335 = ((a1210910088 - a1210910088) - -6);
    	a2061425267 = (a2087535773 + 8);
    	a983758263 = (((((((a983758263 * a63333937) % 14999) % 104) + 39) - -1898) - 29890) - -27990);
    	a1318526106 = 34 ;
    	a63333937 = ((((((a2130183577 * a2130183577) % 14999) + -4738) % 81) - 53) / 5);
    	a1774184757 = (((((((a1774184757 * a1625516355) % 14999) - 2446) % 92) + -58) + 13443) - 13441);
    	a2026977784 = ((a1700231631 * a1249952537) + -26);
    	a2130193413 = a190525986;
    	a1959068056 = ((a786258498 - a834646264) + 11);
    	a786258498 = ((a190525986 + a2061425267) - 12);
    	a1675035970 = ((((((a1675035970 * a1018383389) % 14999) % 17) + 188) + 0) * 1);
    	a302110279 = 34 ;
    	a1625516355 = ((((((a2130183577 * a2130183577) % 14999) % 13) - 94) - -1) + -14);
    	a26346326 = 33 ;
    	a2073482783 = 33 ;
    	a4442917 = ((a1916853335 / a2087535773) + 5);
    	a813082108 = (((((((a2130183577 * a2130183577) % 14999) / 5) + 25162) + -2909) % 50) - -11);
    	a778006913 = (a2087535773 + -1);
    	a2087535773 = (a1521644128 + 1); 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((a1959068056 == 8 && (( cf==1  && (input == 13)) && a709568404 == 32)) && ((a30494462 <=  -62 && (a1830659124 == 9 && a4442917 == 5)) && a217799639 <=  -198))) {
    	cf = 0;
    	a708839806 = 32 ;
    	a2087535773 = ((a190525986 + a1830659124) - 13);
    	a778006913 = (a2130193413 - 6);
    	a2026977784 = ((a2087535773 + a2087535773) - 1);
    	a1474668405 = (((((((a1254983042 * a1985899004) % 14999) / 5) % 76) + -82) - -26805) + -26805);
    	a1318526106 = 32 ;
    	a2061425267 = ((a1241576728 / a2087535773) - -9);
    	a2073482783 = 34 ;
    	a2130183577 = ((((((a341216798 * a1675035970) % 14999) % 12) + 243) + -1) - -1);
    	a1125477212 = 32 ;
    	a1826277115 = ((((((a1625516355 * a999024345) % 14999) - 10536) + -2081) % 14910) - -15088);
    	a999024345 = (((((((a1774184757 * a2130183577) % 14999) % 64) - -195) * 1) / 5) + 131);
    	a1254983042 = (((((((a813082108 * a813082108) % 14999) % 105) - -307) * 1) - -21281) + -21279);
    	a263151501 = 34 ;
    	a404763935 = ((a786258498 - a2130193413) - -13);
    	a983758263 = (((((a983758263 * a1826277115) % 14999) - -29538) - -150) * 1);
    	a1210910088 = (a2087535773 - 4);
    	a1644957382 = 34 ;
    	a786258498 = (a1916853335 + 3);
    	a30494462 = ((((((a30494462 * a341216798) % 14999) / 5) + -8251) % 85) - -261);
    	a26346326 = 32 ;
    	a1959068056 = (a1521644128 - -6);
    	a1985899004 = ((((((a1985899004 * a260539918) % 14999) % 76) + 448) / 5) + 396);
    	a1151361287 = ((((((a1151361287 * a63333937) % 14999) % 20) - -270) + -1) * 1);
    	a217799639 = ((((((((a217799639 * a1625516355) % 14999) % 69) - 138) * 9) / 10) * 10) / 9);
    	a1830659124 = (a1241576728 + 5);
    	a1180594800 = 34 ;
    	a260539918 = (((((((a260539918 * a1774184757) % 14999) + -4566) + -14593) - 10837) % 17) - 15);
    	a63333937 = ((((((a813082108 * a813082108) % 14999) % 106) + 135) / 5) + 39);
    	a2130193413 = (a4442917 + 6);
    	a1625516355 = ((((((((a813082108 * a813082108) % 14999) % 37) - 43) * 9) / 10) * 9) / 10);
    	a190525986 = ((a2087535773 * a1478681170) - 14);
    	a4442917 = (a2087535773 + 2);
    	a1249952537 = (a1550739565 - 7);
    	a1675035970 = (((((((a1675035970 * a813082108) % 14999) % 51) + 260) + 1) - 17300) + 17297);
    	a813082108 = (((((a813082108 % 69) - -173) + 2) + -29213) - -29211); 
    	 printf("%d\n", 19); fflush(stdout); 
    } 
}
 void calculate_outputm61(int input) {
    if(((((a2087535773 == 3 && ( cf==1  && (input == 6))) && a1249952537 == 4) && a1916853335 == 5) && ((a601495656 == 32 && a620105235 <=  -182) && a1125477212 == 32))) {
    	cf = 0;
    	a709568404 = 33 ;
    	a1254983042 = ((((((a1985899004 * a1985899004) % 14999) * 2) + 1) % 101) - -99);
    	a1644957382 = 33 ;
    	a1210910088 = (a4442917 - 3);
    	a1151361287 = ((((((a1151361287 * a620105235) % 14999) % 86) - -161) - -14964) + -14963);
    	a620105235 = ((((((a1151361287 * a999024345) % 14999) % 10) - 169) + 13387) - 13387);
    	a2130183577 = (((((((a2130183577 * a1675035970) % 14999) % 63) - -167) - -1) - 26607) + 26605);
    	a601495656 = 33 ;
    	a263151501 = 33 ;
    	a1018383389 = ((((((((a1254983042 * a1254983042) % 14999) - 6881) % 74) + 93) / 5) * 45) / 10);
    	a1895304149 = 33 ;
    	a1830659124 = (a1210910088 + 8);
    	a721272783 = ((a1916853335 + a190525986) - -3);
    	a1774184757 = (((((((a1625516355 * a1675035970) % 14999) - -7003) + -4122) / 5) % 92) - 57);
    	a1318526106 = 33 ;
    	a1700231631 = (a1249952537 - -4);
    	a1625516355 = (((((((a1254983042 * a1254983042) % 14999) % 13) - 93) * 1) + 21187) + -21187);
    	a1249952537 = ((a2087535773 - a2087535773) - -5);
    	a708839806 = 33 ;
    	a1211013485 = 33 ;
    	a1180594800 = 33 ;
    	a63333937 = (((((((a63333937 * a217799639) % 14999) % 81) - 126) + 71) + 24396) + -24397);
    	a30494462 = ((((((a30494462 * a1018383389) % 14999) % 92) - -32) / 5) - -84);
    	a1959068056 = (a4442917 - -4);
    	a2130193413 = ((a2026977784 / a190525986) - -10);
    	a2087535773 = ((a1959068056 * a1210910088) + -14);
    	a786258498 = (a4442917 + 4);
    	a2073482783 = 33 ;
    	a217799639 = (((((((a217799639 * a1774184757) % 14999) - -5132) + -16254) / 5) % 69) - 128);
    	a983758263 = ((((((((a983758263 * a341216798) % 14999) % 104) + 98) * 5) * 5) % 104) + 99);
    	a999024345 = ((((((((a1254983042 * a1985899004) % 14999) - -2117) % 41) + 89) * 5) % 41) + 55);
    	a1916853335 = (a1521644128 - -1);
    	a76745981 = 33 ;
    	a778006913 = a1210910088;
    	a26346326 = 33 ;
    	a1985899004 = (((((((a1985899004 * a1254983042) % 14999) % 98) + 273) * 5) % 98) + 226);
    	a2061425267 = (a1241576728 + 6);
    	a1895857334 = a1700231631;
    	a190525986 = ((a1959068056 - a1210910088) + 3);
    	a260539918 = ((((((a1254983042 * a1254983042) % 14999) / 5) % 17) - 24) + -2);
    	a1675035970 = (((((((a1151361287 * a1151361287) % 14999) + 2387) + -10930) - -10653) % 17) + 183);
    	a1241576728 = ((a4442917 - a4442917) - -7);
    	a4442917 = (a1210910088 + 4); 
    	 printf("%d\n", 17); fflush(stdout); 
    } if((((a2087535773 == 3 && a2130193413 == 9) && a1916853335 == 5) && (a4442917 == 5 && ((((input == 8) &&  cf==1 ) && a620105235 <=  -182) && a1211013485 == 32)))) {
    	cf = 0;
    	a1210910088 = (a1241576728 - 4);
    	a813082108 = (((((((a217799639 * a1151361287) % 14999) / 5) % 50) + 53) - 29858) + 29858);
    	a965340096 = 33 ;
    	a709568404 = 34 ;
    	a2073482783 = 33 ;
    	a601495656 = 34 ;
    	a1249952537 = (a2087535773 + 3);
    	a260539918 = (((((((a1254983042 * a217799639) % 14999) % 73) + 53) - 22) * 10) / 9);
    	a1675035970 = (((((((a1675035970 * a983758263) % 14999) - 14723) * 1) / 5) % 51) - -260);
    	a2087535773 = (a1959068056 - 3); 
    	 printf("%d\n", 20); fflush(stdout); 
    } if(((a217799639 <=  -198 && ( cf==1  && (input == 11))) && (a1675035970 <=  171 && (a999024345 <=  48 && ((a1644957382 == 32 && a263151501 == 32) && a1625516355 <=  -109))))) {
    	cf = 0;
    	a190525986 = ((a1916853335 + a4442917) + 1);
    	a1700231631 = a1916853335;
    	a2061425267 = ((a1700231631 / a786258498) + 12);
    	a1210910088 = (a2130193413 + -6);
    	a1625516355 = ((((((a1625516355 * a1254983042) % 14999) % 37) - 78) / 5) + 2);
    	a1180594800 = 34 ;
    	a1830659124 = (a2026977784 - -4);
    	a1756173294 = (((((a341216798 * a341216798) % 14999) + 6252) + -26938) - 6981);
    	a63333937 = (((((((a63333937 * a813082108) % 14999) * 2) / 5) + -4684) % 106) - -135);
    	a620105235 = (((((((a620105235 * a2130183577) % 14999) * 2) + -2) + -1) % 10) - 171);
    	a601495656 = 34 ;
    	a2073482783 = 34 ;
    	a2026977784 = ((a1241576728 + a1916853335) - 2);
    	a341216798 = ((((((a341216798 * a1756173294) % 14999) % 31) - -266) + -1) * 1);
    	a1125477212 = 34 ;
    	a1916853335 = (a1959068056 - 1); 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((((a708839806 == 32 && (a1985899004 <=  174 && (a1625516355 <=  -109 && a1180594800 == 32))) && a1916853335 == 5) && a1210910088 == 1) && ((input == 14) &&  cf==1 ))) {
    	cf = 0;
    	a1644957382 = 33 ;
    	a1318526106 = 33 ;
    	a1550739565 = ((a778006913 * a1916853335) - -6);
    	a26346326 = 34 ;
    	a1521644128 = (a2061425267 - 6);
    	a601495656 = 34 ;
    	a1916853335 = (a1521644128 - -3);
    	a1125477212 = 34 ;
    	a1210910088 = (a1550739565 + -8);
    	a708839806 = 34 ;
    	a1249952537 = ((a1959068056 / a2130193413) + 6);
    	a2061425267 = ((a1521644128 / a1521644128) + 11);
    	a1983740902 = 32 ;
    	a620105235 = (((((((a620105235 * a63333937) % 14999) - -2850) - -2763) + 527) % 94) - 83); 
    	 printf("%d\n", 20); fflush(stdout); 
    } 
}
 void calculate_outputm62(int input) {
    if((((a26346326 == 32 && a1625516355 <=  -109) && a1318526106 == 32) && (a620105235 <=  -182 && ((a217799639 <=  -198 && ( cf==1  && (input == 2))) && a1151361287 <=  75)))) {
    	cf = 0;
    	a999024345 = (((((((a217799639 * a1675035970) % 14999) % 64) + 196) / 5) / 5) - -245);
    	a1774184757 = (((((((a1774184757 * a999024345) % 14999) % 66) - -101) / 5) / 5) - -143);
    	a1254983042 = (((((((a1254983042 * a999024345) % 14999) % 105) + 307) - 0) / 5) + 322);
    	a2130193413 = (a778006913 + 10);
    	a1151361287 = ((((((((a1151361287 * a260539918) % 14999) / 5) % 20) + 270) * 5) % 20) + 254);
    	a1210910088 = ((a786258498 - a2026977784) - -2);
    	a26346326 = 33 ;
    	a1895857334 = (a1959068056 - -3);
    	a708839806 = 34 ;
    	a1211013485 = 33 ;
    	a1644957382 = 34 ;
    	a965340096 = 34 ;
    	a63333937 = (((((((a63333937 * a999024345) % 14999) + -2923) + -5681) * 1) % 106) + 215);
    	a2073482783 = 34 ;
    	a1180594800 = 34 ;
    	a2130183577 = (((((((a2130183577 * a30494462) % 14999) * 2) + 3) + 0) % 12) - -243);
    	a1985899004 = (((((((a999024345 * a1018383389) % 14999) % 76) - -429) - -1) * 9) / 10);
    	a2026977784 = ((a786258498 / a1210910088) + 7);
    	a1916853335 = (a786258498 - 1);
    	a1574467713 = ((a1830659124 + a2061425267) - 11);
    	a302110279 = 34 ;
    	a1830659124 = (a1249952537 - -5);
    	a1625516355 = ((((((((a1625516355 * a999024345) % 14999) - -15016) % 37) - 46) * 5) % 37) + -25);
    	a1125477212 = 33 ;
    	a2061425267 = ((a1959068056 / a1916853335) - -11);
    	a1241576728 = ((a1478681170 * a4442917) + -17);
    	a1318526106 = 34 ;
    	a1895304149 = 34 ;
    	a620105235 = ((((((a620105235 * a1985899004) % 14999) % 94) + -65) + 2) - 2);
    	a983758263 = ((((((a983758263 * a341216798) % 14999) % 101) + 305) - 1) + 2);
    	a263151501 = 34 ;
    	a709568404 = 33 ;
    	a30494462 = ((((((a30494462 * a1774184757) % 14999) + -1251) % 85) - -211) - 1);
    	a4442917 = (a2087535773 - -2);
    	a1959068056 = ((a1521644128 / a1521644128) + 9);
    	a190525986 = (a1249952537 - -5);
    	a76745981 = 34 ;
    	a786258498 = (a1521644128 - -4); 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((((a76745981 == 32 && (a1644957382 == 32 && a190525986 == 9)) && a1985899004 <=  174) && (a1125477212 == 32 && (((input == 11) &&  cf==1 ) && a1959068056 == 8)))) {
    	cf = 0;
    	a263638061 = (a786258498 + 2);
    	a1211013485 = 33 ;
    	a302110279 = 33 ;
    	a1826277115 = (((((a341216798 * a341216798) % 14999) - 16182) - 9365) - 1947);
    	a2130183577 = ((((((a2130183577 * a1625516355) % 14999) % 12) - -242) + 24396) + -24395);
    	a1125477212 = 34 ;
    	a1644957382 = 34 ;
    	a1916853335 = ((a1830659124 - a190525986) - -7);
    	a1625516355 = ((((((((a2130183577 * a1985899004) % 14999) + 10041) % 37) - 41) * 5) % 37) - 30);
    	a708839806 = 34 ;
    	a190525986 = (a2061425267 + 1);
    	a620105235 = ((((((a620105235 * a1254983042) % 14999) / 5) % 94) - 147) / 5);
    	a2130193413 = ((a1830659124 / a1959068056) - -10);
    	a76745981 = 34 ;
    	a778006913 = (a1521644128 + -2);
    	a30494462 = ((((((a1826277115 * a63333937) % 14999) % 85) + 154) / 5) * 5);
    	a4442917 = a2026977784;
    	a1241576728 = (a1478681170 - -2);
    	a1959068056 = a1830659124;
    	a1774184757 = (((((((a999024345 * a30494462) % 14999) % 66) - -103) - -1) + 18871) - 18871);
    	a1254983042 = ((((((a999024345 * a2130183577) % 14999) % 105) + 307) * 1) - 0);
    	a153649526 = 33 ;
    	a263151501 = 34 ;
    	a1151361287 = (((((((a1151361287 * a1774184757) % 14999) % 86) - -163) * 1) + -16228) + 16226);
    	a1895304149 = 34 ;
    	a983758263 = ((((((a983758263 * a63333937) % 14999) - 24904) - -26140) * 10) / 9);
    	a217799639 = (((((((a217799639 * a63333937) % 14999) % 28) - 52) / 5) - 3982) - -3949);
    	a786258498 = ((a263638061 - a2026977784) - -7);
    	a26346326 = 34 ;
    	a2061425267 = (a1249952537 + 6);
    	a2026977784 = (a263638061 - 2);
    	a63333937 = (((((((a63333937 * a1826277115) % 14999) % 81) + -114) + 3744) - -2091) - 5800);
    	a999024345 = (((((((a999024345 * a1675035970) % 14999) / 5) * 5) + -12483) % 64) + 195); 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((((a1241576728 == 6 && (a1254983042 <=  -2 && a2061425267 == 10)) && a1211013485 == 32) && (a190525986 == 9 && (((input == 15) &&  cf==1 ) && a1985899004 <=  174)))) {
    	cf = 0;
    	a76745981 = 34 ;
    	a1125477212 = 33 ;
    	a1895857334 = ((a1959068056 * a2026977784) - 48);
    	a1959068056 = ((a1521644128 - a1521644128) - -10);
    	a1210910088 = (a1895857334 - 5);
    	a1985899004 = ((((((a63333937 * a63333937) % 14999) + -29591) % 76) + 506) + 8);
    	a1151361287 = (((((((a1151361287 * a217799639) % 14999) % 86) + 161) * 5) % 86) + 148);
    	a2130193413 = (a190525986 + 2);
    	a2073482783 = 34 ;
    	a983758263 = ((((((a983758263 * a999024345) % 14999) % 101) + 305) / 5) * 5);
    	a708839806 = 33 ;
    	a217799639 = (((((((a1254983042 * a1985899004) % 14999) % 28) + -30) * 9) / 10) - 1);
    	a578474405 = (((((a983758263 * a983758263) % 14999) - -750) - -1298) * 1);
    	a1916853335 = ((a2026977784 / a1830659124) - -7);
    	a30494462 = ((((((a30494462 * a1625516355) % 14999) / 5) % 85) + 193) - 31);
    	a26346326 = 33 ;
    	a1774184757 = ((((((a1774184757 * a999024345) % 14999) + 518) % 66) + 101) * 1);
    	a1211013485 = 34 ;
    	a2061425267 = (a1241576728 - -6);
    	a1625516355 = (((((((a341216798 * a999024345) % 14999) % 13) - 94) + 1) - 22040) + 22037);
    	a263151501 = 33 ;
    	a1254983042 = (((((a260539918 * a260539918) / 5) % 105) - -307) - 0);
    	a1318526106 = 33 ;
    	a1180594800 = 33 ;
    	a1018383389 = ((((((a260539918 * a260539918) % 74) - -92) + -17193) + -7440) + 24633);
    	a1675035970 = (((((a260539918 * a260539918) % 17) - -189) - -6057) - 6056);
    	a1644957382 = 34 ;
    	a1241576728 = (a4442917 - -2);
    	a2026977784 = (a1959068056 + -1);
    	a2130183577 = ((((((((a2130183577 * a620105235) % 14999) % 12) + 243) + -1) * 5) % 12) + 238);
    	a4442917 = (a1478681170 - -2);
    	a1249952537 = ((a786258498 / a1210910088) - -3);
    	a190525986 = (a1895857334 + 3);
    	a999024345 = (((((a260539918 * a260539918) - 14467) % 64) + 195) - -2);
    	a1895304149 = 34 ;
    	a369798198 = 34 ;
    	a1830659124 = ((a778006913 + a778006913) + 9); 
    	 printf("%d\n", 16); fflush(stdout); 
    } 
}
 void calculate_outputm65(int input) {
    if((((a2130193413 == 9 && a2073482783 == 32) && a1625516355 <=  -109) && (a1254983042 <=  -2 && ((a1959068056 == 8 && ((input == 1) &&  cf==1 )) && a2087535773 == 3)))) {
    	cf = 0;
    	a778006913 = (a1241576728 - 3);
    	a2087535773 = (a778006913 + 2);
    	a1180594800 = 34 ;
    	a4442917 = (a190525986 - 4);
    	a404763935 = ((a1830659124 * a1959068056) - 58);
    	a1254983042 = ((((((((a1254983042 * a30494462) % 14999) % 105) + 306) * 9) / 10) * 9) / 10);
    	a263151501 = 34 ;
    	a2073482783 = 33 ;
    	a1826277115 = (((((a341216798 * a983758263) % 14999) + 21228) - -4330) * 1);
    	a1895304149 = 33 ;
    	a76745981 = 33 ;
    	a983758263 = ((((((a983758263 * a1826277115) % 14999) - -25490) * 10) / 9) + 1358);
    	a1318526106 = 33 ;
    	a1625516355 = ((((((a620105235 * a813082108) % 14999) % 37) - 42) - 12033) - -12031);
    	a1018383389 = ((((((a1018383389 * a1985899004) % 14999) / 5) - -5076) % 74) + 91);
    	a1774184757 = ((((((a1625516355 * a1985899004) % 14999) + -7938) * 1) % 66) - -114);
    	a30494462 = (((((((a30494462 * a1625516355) % 14999) % 92) - -28) * 5) % 92) + -35);
    	a548050643 = 36 ;
    	a708839806 = 34 ;
    	a2130193413 = ((a1478681170 * a1521644128) - 25);
    	a2130183577 = ((((((a2130183577 * a1774184757) % 14999) / 5) + 21952) % 12) + 231);
    	a1211013485 = 33 ;
    	a1675035970 = (((((((a1675035970 * a2130183577) % 14999) % 51) - -259) * 1) + -9534) + 9534);
    	a1830659124 = (a2087535773 - -5);
    	a63333937 = ((((((a63333937 * a999024345) % 14999) % 81) - 53) + -2454) - -2455);
    	a1241576728 = (a778006913 + 4);
    	a1151361287 = (((((((a1151361287 * a1774184757) % 14999) % 20) + 271) + -15967) + -14129) + 30094);
    	a302110279 = 34 ;
    	a1959068056 = (a1077149355 + -2); 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm66(int input) {
    if(((a1018383389 <=  17 && a1478681170 == 3) && (a1210910088 == 1 && (a1211013485 == 32 && ((((input == 5) &&  cf==1 ) && a190525986 == 9) && a999024345 <=  48))))) {
    	cf = 0;
    	a1675035970 = (((((((a1625516355 * a1625516355) % 14999) % 51) - -208) / 5) - 4998) - -5232);
    	a965340096 = 32 ;
    	a30494462 = ((((((a999024345 * a1254983042) % 14999) % 85) - -211) - 1) - -1);
    	a1895304149 = 34 ;
    	a63333937 = (((((((a63333937 * a30494462) % 14999) % 106) + 137) * 5) % 106) + 36);
    	a999024345 = ((((((a1675035970 * a1675035970) % 14999) - 1364) % 64) + 195) * 1);
    	a2061425267 = (a190525986 + 2);
    	a1826277115 = ((((((a2130183577 * a1254983042) % 14999) - -13698) % 62) - -116) + 1);
    	a1959068056 = (a190525986 - -1);
    	a1625516355 = (((((((a1625516355 * a341216798) % 14999) - 7528) % 13) + -89) - 7453) + 7452);
    	a26346326 = 34 ;
    	a2130193413 = ((a190525986 - a190525986) - -11);
    	a601495656 = 34 ;
    	a786258498 = (a190525986 - -1);
    	a1211013485 = 34 ;
    	a1478681170 = (a190525986 - 4);
    	a1151361287 = (((((((a1151361287 * a1985899004) % 14999) - -387) * 1) - 14009) % 86) - -161);
    	a1180594800 = 34 ;
    	a1521644128 = ((a1241576728 * a1241576728) - 29);
    	a983758263 = ((((((a983758263 * a1774184757) % 14999) - -14333) + -15211) - 8141) - -14652);
    	a2130183577 = ((((((a1985899004 * a1254983042) % 14999) / 5) % 12) + 242) - 0);
    	a4442917 = a1521644128;
    	a1830659124 = ((a786258498 / a1249952537) + 8);
    	a1249952537 = (a190525986 + -4);
    	a1018383389 = (((((((a1018383389 * a260339255) % 14999) - 1274) % 21) - -190) / 5) + 168);
    	a2026977784 = (a1210910088 - -8);
    	a263151501 = 34 ;
    	a76745981 = 34 ;
    	a778006913 = (a1916853335 + -2);
    	a1916853335 = (a190525986 - 2);
    	a813082108 = (((((((a260539918 * a620105235) % 14999) - 5712) * 1) + -6975) % 69) - -173);
    	a620105235 = ((((((a1675035970 * a1675035970) % 14999) + -26976) % 10) + -170) + 3);
    	a1241576728 = (a2087535773 + 5);
    	a1254983042 = ((((((a1254983042 * a813082108) % 14999) / 5) + -21396) % 101) + 143);
    	a2087535773 = ((a1959068056 * a190525986) - 86);
    	a1210910088 = (a190525986 + -6);
    	a190525986 = (a2130193413 - 1); 
    	 printf("%d\n", 19); fflush(stdout); 
    } if(((a2087535773 == 3 && (a1241576728 == 6 && ((a63333937 <=  -135 && a1675035970 <=  171) && a1625516355 <=  -109))) && (a778006913 == 1 && ((input == 14) &&  cf==1 )))) {
    	cf = 0;
    	a1644957382 = 34 ;
    	a1983740902 = 33 ;
    	a1125477212 = 34 ;
    	a708839806 = 34 ;
    	a709568404 = 34 ;
    	a1985899004 = (((((((a260339255 * a1018383389) % 14999) / 5) % 76) - -447) / 5) + 352);
    	a217799639 = ((((((a620105235 * a999024345) % 14999) / 5) % 28) + -30) + 1); 
    	 printf("%d\n", 19); fflush(stdout); 
    } if((((a1180594800 == 32 && a1675035970 <=  171) && a1959068056 == 8) && ((a1249952537 == 4 && (( cf==1  && (input == 15)) && a2087535773 == 3)) && a620105235 <=  -182))) {
    	cf = 0;
    	a708839806 = 34 ;
    	a1916853335 = ((a190525986 * a2061425267) + -101);
    	a1249952537 = (a2061425267 - 6);
    	a999024345 = (((((((a999024345 * a1254983042) % 14999) % 64) - -195) - 0) + -12063) - -12064);
    	a2087535773 = (a1478681170 - -2);
    	a1241576728 = (a778006913 + 7);
    	a263151501 = 34 ;
    	a1959068056 = ((a2061425267 * a778006913) + -2);
    	a1318526106 = 34 ;
    	a4442917 = ((a2087535773 - a1916853335) + 9);
    	a601495656 = 34 ;
    	a263638061 = ((a786258498 + a2130193413) - 6);
    	a1151361287 = ((((((((a1151361287 * a1018383389) % 14999) % 20) - -270) * 5) * 5) % 20) - -252);
    	a2130183577 = (((((((a2130183577 * a1675035970) % 14999) + -8157) - 5818) / 5) % 12) + 243);
    	a260539918 = (((((((a341216798 * a217799639) % 14999) % 73) + 65) - -1) - -9016) + -9015);
    	a1895304149 = 34 ;
    	a1895857334 = (a1521644128 - -3);
    	a1574467713 = ((a1210910088 + a778006913) + -1);
    	a1830659124 = (a2061425267 - 1);
    	a26346326 = 34 ;
    	a190525986 = (a1916853335 + 4);
    	a1675035970 = ((((((a620105235 * a1254983042) % 14999) - -6964) % 51) - -224) * 1);
    	a1210910088 = (a2026977784 + -4);
    	a2130193413 = (a1959068056 - -1);
    	a30494462 = (((((((a30494462 * a813082108) % 14999) - 9326) + 4325) - -1000) % 85) - -210);
    	a1983740902 = 34 ;
    	a786258498 = (a2061425267 + -2);
    	a620105235 = (((((((a620105235 * a63333937) % 14999) - -7525) + -21418) + 3387) % 94) - 65);
    	a1478681170 = (a1916853335 - 2);
    	a1254983042 = (((((((a1254983042 * a1774184757) % 14999) + -6174) % 105) - -307) / 5) - -240);
    	a983758263 = (((((((a983758263 * a1625516355) % 14999) - -13856) * 1) * 1) % 101) + 225);
    	a1180594800 = 34 ;
    	a63333937 = (((((((a1774184757 * a1625516355) % 14999) % 106) + 118) * 9) / 10) - -15);
    	a778006913 = ((a2026977784 * a2061425267) - 81);
    	a302110279 = 34 ;
    	a1211013485 = 34 ;
    	a1625516355 = ((((((((a1625516355 * a260339255) % 14999) % 37) - 42) * 9) / 10) * 10) / 9);
    	a709568404 = 34 ;
    	a813082108 = (((((((a1985899004 * a1985899004) % 14999) % 69) - -115) + -3) / 5) - -194);
    	a2026977784 = ((a1916853335 + a2061425267) + -10); 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((a999024345 <=  48 && a263151501 == 32) && (a1018383389 <=  17 && (a1478681170 == 3 && ((( cf==1  && (input == 4)) && a1774184757 <=  -151) && a4442917 == 5))))) {
    	cf = 0;
    	a4442917 = (a1959068056 - 1);
    	a1574467713 = (a2026977784 + -5);
    	a1959068056 = ((a1210910088 / a1249952537) - -10);
    	a1257505051 = (((((a983758263 * a260339255) % 14999) / 5) / 5) + 4245);
    	a1895857334 = ((a1916853335 / a1830659124) + 10);
    	a786258498 = (a1521644128 - -2);
    	a263151501 = 34 ;
    	a76745981 = 34 ;
    	a2026977784 = (a1241576728 + 3);
    	a1774184757 = ((((((((a1774184757 * a1018383389) % 14999) % 66) + 103) * 1) * 5) % 66) - -97);
    	a190525986 = (a2130193413 - -2);
    	a1625516355 = ((((((a1151361287 * a260539918) % 14999) + 8820) + -14699) % 37) + -43);
    	a983758263 = (((((((a983758263 * a63333937) % 14999) % 101) + 291) + -13910) * 2) - -27442);
    	a1254983042 = ((((((a1254983042 * a1625516355) % 14999) + -701) + -24715) % 105) - -338);
    	a1830659124 = (a1210910088 + 10);
    	a778006913 = (a4442917 - 4);
    	a63333937 = ((((((((a63333937 * a30494462) % 14999) / 5) % 106) + 91) * 5) % 106) - -78);
    	a302110279 = 34 ;
    	a30494462 = ((((((a30494462 * a999024345) % 14999) % 85) - -210) + -5473) + 5472);
    	a999024345 = ((((((a999024345 * a620105235) % 14999) + -12217) % 64) + 196) + 1);
    	a601495656 = 34 ;
    	a620105235 = ((((((((a620105235 * a1774184757) % 14999) / 5) % 94) + -65) * 5) % 94) + -65); 
    	 printf("%d\n", 16); fflush(stdout); 
    } 
}
 void calculate_outputm69(int input) {
    if(((a1151361287 <=  75 && (a1180594800 == 32 && (a1985899004 <=  174 && (( cf==1  && (input == 4)) && a63333937 <=  -135)))) && (a620105235 <=  -182 && a1210910088 == 1))) {
    	cf = 0;
    	a190525986 = (a778006913 - -9);
    	a2130183577 = (((((((a2130183577 * a30494462) % 14999) - 4248) % 63) + 166) - -21344) + -21343);
    	a263151501 = 33 ;
    	a1959068056 = ((a1830659124 + a4442917) - 5);
    	a1254983042 = (((((((a620105235 * a620105235) % 14999) % 101) + 68) * 9) / 10) - 39);
    	a1241576728 = ((a778006913 / a1959068056) - -7);
    	a30494462 = ((((((a1985899004 * a2130183577) % 14999) % 92) - -31) - -2) + -2);
    	a1569588614 = ((((((a1569588614 * a999024345) % 14999) + 283) * 1) % 46) + 119);
    	a26346326 = 33 ;
    	a260539918 = (((((((a813082108 * a1018383389) % 14999) % 17) - 25) + 29312) + 140) + -29451);
    	a709568404 = 33 ;
    	a217799639 = (((((((a1254983042 * a620105235) % 14999) % 69) - 128) / 5) / 5) - 180);
    	a1574467713 = (a1521644128 - 9);
    	a1644957382 = 33 ;
    	a1983740902 = 33 ;
    	a1151361287 = (((((((a1151361287 * a217799639) % 14999) + -13626) % 86) - -163) - 14897) + 14895);
    	a1895304149 = 33 ;
    	a1180594800 = 33 ;
    	a1985899004 = ((((((a1985899004 * a1625516355) % 14999) % 98) - -273) / 5) + 245);
    	a1675035970 = (((((((a1675035970 * a2130183577) % 14999) + -7339) + 16940) * 1) % 17) + 190);
    	a721272783 = (a1916853335 - -7);
    	a786258498 = (a190525986 + -1);
    	a708839806 = 33 ;
    	a1318526106 = 33 ;
    	a1249952537 = (a1830659124 + -4);
    	a999024345 = (((((((a341216798 * a1625516355) % 14999) % 41) - -89) * 5) % 41) + 50);
    	a983758263 = ((((((((a983758263 * a813082108) % 14999) % 104) + 98) * 5) * 5) % 104) - -99);
    	a1210910088 = (a1916853335 + -3);
    	a1916853335 = (a190525986 - 4); 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((((( cf==1  && (input == 6)) && a709568404 == 32) && a26346326 == 32) && a601495656 == 32) && ((a1985899004 <=  174 && a1916853335 == 5) && a778006913 == 1))) {
    	a990043066 += (a990043066 + 20) > a990043066 ? 3 : 0;
    	cf = 0;
    	a1213722969 = (a786258498 - -3);
    	a1018383389 = (((((((a1151361287 * a30494462) % 14999) % 74) - -91) * 5) % 74) + 27);
    	a834646264 = (a1249952537 - -2);
    	a1625516355 = ((((((a813082108 * a341216798) % 14999) / 5) % 13) + -95) - 1);
    	a302110279 = 33 ;
    	a1151361287 = ((((((a1151361287 * a1774184757) % 14999) % 86) + 161) + 1) + -1);
    	a341216798 = ((((((a341216798 * a983758263) % 14999) + 27646) - 35829) - -34230) + -27251); 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a4442917 == 5 && a620105235 <=  -182) && ((a217799639 <=  -198 && ((( cf==1  && (input == 9)) && a1675035970 <=  171) && a1830659124 == 9)) && a1774184757 <=  -151))) {
    	cf = 0;
    	a1254983042 = ((((((a1625516355 * a1625516355) % 101) - 1) + -3074) + -9094) - -12257);
    	a778006913 = (a1830659124 - 7);
    	a1891437507 = 35 ;
    	a1895304149 = 33 ;
    	a813082108 = ((((((a1254983042 * a1985899004) % 14999) - 7704) + -206) % 50) + 53);
    	a1478681170 = (a1916853335 + -1);
    	a4442917 = (a190525986 + -3);
    	a63333937 = ((((((a1625516355 * a1625516355) % 81) + -53) - 10) + 18771) - 18831);
    	a2130183577 = ((((((a2130183577 * a341216798) % 14999) % 63) + 166) + 1) - -1);
    	a1644957382 = 33 ;
    	a1345687529 = (((((a341216798 * a983758263) % 14999) + 25353) - 18586) + 9338);
    	a620105235 = (((((((a620105235 * a813082108) % 14999) % 10) + -169) - 3437) - 22063) - -25498);
    	a302110279 = 33 ;
    	a1151361287 = ((((((((a1151361287 * a999024345) % 14999) / 5) % 86) + 163) / 5) * 51) / 10);
    	a30494462 = ((((((a30494462 * a63333937) % 14999) % 92) + 30) - -20674) - 20673);
    	a721272783 = (a786258498 + 6);
    	a26346326 = 33 ;
    	a999024345 = ((((((((a999024345 * a1625516355) % 14999) % 41) - -90) - 13883) * 2) % 41) - -95);
    	a1210910088 = (a4442917 + -4);
    	a983758263 = ((((((a983758263 * a341216798) % 14999) + -13593) % 104) - -105) + 59);
    	a2073482783 = 33 ;
    	a1675035970 = (((((((a1675035970 * a1018383389) % 14999) - 14441) % 17) + 188) + 4056) + -4054); 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((a709568404 == 32 && (a190525986 == 9 && ((a1830659124 == 9 && (a1774184757 <=  -151 && a1180594800 == 32)) && a217799639 <=  -198))) && ( cf==1  && (input == 13)))) {
    	cf = 0;
    	a2130183577 = (((((((a2130183577 * a1675035970) % 14999) - 8355) % 63) + 167) + 14617) + -14616);
    	a1574467713 = (a786258498 - 7);
    	a1959068056 = (a1521644128 - 1);
    	a1180594800 = 33 ;
    	a30494462 = ((((((a30494462 * a1151361287) % 14999) * 2) % 92) - -32) - -1);
    	a260539918 = ((((((a1625516355 * a63333937) % 14999) / 5) / 5) % 17) + -38);
    	a1644957382 = 33 ;
    	a983758263 = ((((((a983758263 * a1675035970) % 14999) * 2) - 3) % 104) - -99);
    	a1569588614 = (((((((a1569588614 * a999024345) % 14999) % 46) + 119) + 0) + 14493) - 14490);
    	a1985899004 = (((((((a1985899004 * a260539918) % 14999) * 2) % 98) + 272) + -22753) - -22753);
    	a1983740902 = 33 ;
    	a217799639 = (((((((a217799639 * a620105235) % 14999) + 7452) % 69) + -149) + -27237) + 27197);
    	a708839806 = 33 ;
    	a1241576728 = (a1830659124 + -2);
    	a1318526106 = 33 ;
    	a999024345 = ((((((a1151361287 * a1774184757) % 14999) % 41) - -90) + 1) + -1);
    	a1151361287 = ((((((a1151361287 * a1018383389) % 14999) / 5) / 5) % 86) - -162);
    	a1895304149 = 33 ;
    	a26346326 = 33 ;
    	a1210910088 = (a778006913 - -1);
    	a263151501 = 33 ;
    	a190525986 = (a1959068056 - -1);
    	a721272783 = ((a1916853335 / a1916853335) - -11);
    	a1249952537 = a1916853335;
    	a1254983042 = (((((((a1018383389 * a341216798) % 14999) % 101) - -45) + 5) * 10) / 9);
    	a786258498 = ((a4442917 - a4442917) - -9);
    	a1675035970 = ((((((a217799639 * a217799639) % 14999) + -20067) - 5287) % 17) + 201);
    	a709568404 = 33 ;
    	a1916853335 = (a4442917 + 1); 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm4(int input) {
    if((((a2087535773 == 3 && (a709568404 == 32 && a1675035970 <=  171)) && a999024345 <=  48) && (a1774184757 <=  -151 && (a813082108 <=  3 && (a1521644128 == 3 &&  cf==1 ))))) {
    	if(((a778006913 == 1 && ((a620105235 <=  -182 && a1644957382 == 32) && a1830659124 == 9)) && (a1675035970 <=  171 && (a1774184757 <=  -151 && (a369798198 == 32 &&  cf==1 ))))) {
    		calculate_outputm55(input);
    	} 
    	if(((a2130193413 == 9 && (a709568404 == 32 && ((a1895304149 == 32 && a786258498 == 8) && a620105235 <=  -182))) && (a2130183577 <=  103 && (a369798198 == 34 &&  cf==1 )))) {
    		calculate_outputm57(input);
    	} 
    } 
    if(((a786258498 == 8 && (a2130193413 == 9 && (( cf==1  && a1521644128 == 4) && a778006913 == 1))) && ((a1151361287 <=  75 && a999024345 <=  48) && a217799639 <=  -198))) {
    	if(((a1125477212 == 32 && (a1550739565 == 6 &&  cf==1 )) && ((a4442917 == 5 && ((a2087535773 == 3 && a2073482783 == 32) && a813082108 <=  3)) && a2026977784 == 7))) {
    		calculate_outputm59(input);
    	} 
    	if(((((a260539918 <=  -44 && (a1550739565 == 11 &&  cf==1 )) && a1985899004 <=  174) && a2026977784 == 7) && (a1959068056 == 8 && (a1895304149 == 32 && a709568404 == 32)))) {
    		calculate_outputm60(input);
    	} 
    } 
    if(((((a2130193413 == 9 && a1916853335 == 5) && a26346326 == 32) && a2061425267 == 10) && ((a76745981 == 32 && ( cf==1  && a1521644128 == 5)) && a708839806 == 32))) {
    	if((((a2073482783 == 32 && a2026977784 == 7) && a63333937 <=  -135) && (a1211013485 == 32 && (a217799639 <=  -198 && (a1830659124 == 9 && ( cf==1  && a965340096 == 32)))))) {
    		calculate_outputm61(input);
    	} 
    	if(((a263151501 == 32 && a2130193413 == 9) && (((a620105235 <=  -182 && (( cf==1  && a965340096 == 33) && a1125477212 == 32)) && a76745981 == 32) && a26346326 == 32))) {
    		calculate_outputm62(input);
    	} 
    } 
    if(((a1180594800 == 32 && (a1018383389 <=  17 && (a1675035970 <=  171 && a2130183577 <=  103))) && ((a263151501 == 32 && ( cf==1  && a1521644128 == 7)) && a63333937 <=  -135))) {
    	if(((a1318526106 == 32 && (a4442917 == 5 && a1241576728 == 6)) && (a63333937 <=  -135 && (a778006913 == 1 && ((a1077149355 == 11 &&  cf==1 ) && a708839806 == 32))))) {
    		calculate_outputm65(input);
    	} 
    } 
    if((((a1830659124 == 9 && ((a1521644128 == 8 &&  cf==1 ) && a601495656 == 32)) && a1895304149 == 32) && ((a813082108 <=  3 && a263151501 == 32) && a63333937 <=  -135))) {
    	if((((a601495656 == 32 && a4442917 == 5) && a1211013485 == 32) && (((a1254983042 <=  -2 && ( cf==1  && ((14 < a260339255) && (63 >= a260339255)))) && a26346326 == 32) && a2026977784 == 7))) {
    		calculate_outputm66(input);
    	} 
    } 
    if(((a1644957382 == 32 && ((( cf==1  && a1521644128 == 10) && a1774184757 <=  -151) && a302110279 == 32)) && (a709568404 == 32 && (a1983740902 == 32 && a2130183577 <=  103)))) {
    	if(((a190525986 == 9 && a1774184757 <=  -151) && ((a1210910088 == 1 && (((a1569588614 <=  -89 &&  cf==1 ) && a1125477212 == 32) && a1241576728 == 6)) && a620105235 <=  -182))) {
    		calculate_outputm69(input);
    	} 
    } 
}
 void calculate_outputm72(int input) {
    if(((((((-62 < a30494462) && (124 >= a30494462)) && ((48 < a999024345) && (131 >= a999024345))) && ((-109 < a1625516355) && (-81 >= a1625516355))) && a1180594800 == 33) && (a778006913 == 2 && (a2087535773 == 4 && ((input == 5) &&  cf==1 ))))) {
    	cf = 0;
    	a1985899004 = ((((((a1625516355 * a803418896) % 76) + 448) + -1) + 14877) - 14876);
    	a1125477212 = 34 ;
    	a1644957382 = 34 ;
    	a601495656 = 34 ;
    	a217799639 = ((((((a803418896 * a999024345) % 28) - 30) + -1) + 8057) + -8056);
    	a2130193413 = ((a1249952537 * a1249952537) + -14); 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((((a1249952537 == 5 && a1478681170 == 4) && a1983740902 == 33) && ((75 < a1151361287) && (249 >= a1151361287))) && (a1895304149 == 33 && (a190525986 == 10 && ( cf==1  && (input == 12)))))) {
    	cf = 0;
    	a1574467713 = (a2061425267 + -10);
    	a2026977784 = (a1916853335 + 2);
    	a260539918 = (((32 + -5444) - -5434) - -21);
    	a1830659124 = (a721272783 - -1);
    	a2061425267 = (a1210910088 + 10);
    	a1675035970 = (((((((a1675035970 * a813082108) - -5707) % 51) + 245) / 5) * 45) / 10);
    	a26346326 = 34 ;
    	a1254983042 = ((((((((a1625516355 * a2130183577) % 105) - -333) * 10) / 9) * 5) % 105) + 295);
    	a1895857334 = (a1959068056 - -2);
    	a1959068056 = ((a2130193413 - a1210910088) - -1);
    	a1211013485 = 34 ;
    	a1318526106 = 34 ;
    	a30494462 = ((((((a30494462 * a1254983042) % 14999) * 2) % 85) - -211) + 1);
    	a263638061 = ((a778006913 / a1348848030) - -11);
    	a1151361287 = ((((((a1151361287 * a999024345) % 14999) % 20) - -262) / 5) + 201);
    	a983758263 = ((((((((a983758263 * a803418896) % 14999) % 101) + 304) + -11143) * 2) % 101) + 360);
    	a2087535773 = (a1574467713 + 4);
    	a302110279 = 34 ;
    	a1895304149 = 34 ;
    	a786258498 = ((a4442917 / a778006913) - -7);
    	a1625516355 = (((((((a63333937 * a1254983042) % 14999) % 37) - 41) / 5) + 16751) - 16767);
    	a190525986 = (a2061425267 + -1);
    	a263151501 = 34 ;
    	a1241576728 = (a1478681170 - -4);
    	a2130183577 = ((((((a2130183577 * a217799639) * 2) + -122) / 5) % 12) + 245);
    	a1478681170 = ((a786258498 / a1959068056) - -4);
    	a1180594800 = 34 ;
    	a708839806 = 34 ;
    	a709568404 = 34 ;
    	a63333937 = (((((((a620105235 * a1254983042) % 14999) % 106) - -136) + -1) / 5) + 119);
    	a4442917 = (a1249952537 + 2);
    	a1249952537 = (a1895857334 + -5);
    	a778006913 = (a2130193413 + -8);
    	a1983740902 = 34 ;
    	a999024345 = ((((((a999024345 * a813082108) + 9389) / 5) * 5) % 64) - -185);
    	a620105235 = (((((((a620105235 * a1985899004) % 14999) % 94) + -63) * 5) % 94) + -63);
    	a813082108 = ((((51 / 5) + 150) * 9) / 10);
    	a1210910088 = (a1916853335 - 4); 
    	 printf("%d\n", 26); fflush(stdout); 
    } if((((((-182 < a620105235) && (-160 >= a620105235)) && ((input == 15) &&  cf==1 )) && a1318526106 == 33) && (a4442917 == 6 && ((a1210910088 == 2 && ((75 < a1151361287) && (249 >= a1151361287))) && a708839806 == 33)))) {
    	cf = 0;
    	a1985899004 = ((((((a813082108 * a1625516355) % 76) + 466) + 14127) + 9621) + -23765);
    	a601495656 = 34 ;
    	a217799639 = (((((a983758263 * a813082108) * 1) % 28) - 28) - 1);
    	a1644957382 = 34 ;
    	a1125477212 = 34 ;
    	a2130193413 = ((a1959068056 - a2061425267) - -13); 
    	 printf("%d\n", 16); fflush(stdout); 
    } if(((a1983740902 == 33 && (((171 < a1675035970) && (207 >= a1675035970)) && (((-2 < a1254983042) && (202 >= a1254983042)) && ( cf==1  && (input == 13))))) && ((a1241576728 == 7 && a4442917 == 6) && ((-135 < a63333937) && (29 >= a63333937))))) {
    	cf = 0;
    	a999024345 = (((((((a999024345 * a803418896) % 64) - -196) * 5) + 15097) % 64) - -180);
    	a1675035970 = ((((((a1675035970 * a813082108) % 51) - -223) * 10) / 9) + -11);
    	a1895857334 = (a1830659124 + -4);
    	a2087535773 = (a778006913 - -3);
    	a1254983042 = (((((a1254983042 * a63333937) - -3500) % 105) - -309) + -1);
    	a620105235 = (((((((a2130183577 * a2130183577) % 14999) - -411) / 5) + 11315) % 94) + -150);
    	a1625516355 = (((((a1625516355 * a983758263) + 26324) % 37) + -43) - -1);
    	a983758263 = ((((((a983758263 * a803418896) % 14999) * 2) % 101) - -304) - -2);
    	a1323955799 = 35 ;
    	a26346326 = 34 ;
    	a1211013485 = 34 ;
    	a30494462 = (((((((a30494462 * a620105235) + 19386) % 85) + 209) * 5) % 85) + 161);
    	a263151501 = 34 ;
    	a1830659124 = (a1210910088 + 9);
    	a1151361287 = ((((((((a1151361287 * a63333937) % 14999) + 11245) % 20) - -270) * 5) % 20) - -257);
    	a1180594800 = 34 ;
    	a1249952537 = ((a1916853335 * a1959068056) + -57);
    	a1983740902 = 34 ;
    	a1352986605 = ((((((a803418896 * a983758263) % 14999) / 5) % 84) + 233) * 1);
    	a2061425267 = ((a1916853335 + a1241576728) - 2);
    	a1959068056 = (a1478681170 + 6);
    	a1241576728 = (a786258498 - 1);
    	a786258498 = a190525986; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm73(int input) {
    if((((( cf==1  && (input == 6)) && a1210910088 == 2) && ((-109 < a1625516355) && (-81 >= a1625516355))) && ((((75 < a1151361287) && (249 >= a1151361287)) && (((174 < a1985899004) && (371 >= a1985899004)) && a263151501 == 33)) && a709568404 == 33))) {
    	cf = 0;
    	a1891437507 = 35 ;
    	a1018383389 = (((((((a2130183577 * a803418896) % 14999) + 7166) + 2896) - 9909) % 74) + 91);
    	a1345687529 = ((((((a983758263 * a983758263) % 14999) % 14962) - -15037) + 1) - 0);
    	a2073482783 = 33 ;
    	a721272783 = (a1959068056 - -5);
    	a999024345 = (((((a1625516355 * a30494462) - 8535) - 3480) % 41) - -100); 
    	 printf("%d\n", 26); fflush(stdout); 
    } if(((a1644957382 == 33 && (a1241576728 == 7 && ((a302110279 == 33 && ( cf==1  && (input == 12))) && a1125477212 == 33))) && (((171 < a1675035970) && (207 >= a1675035970)) && a786258498 == 9))) {
    	cf = 0;
    	a1241576728 = ((a4442917 - a1249952537) - -7);
    	a1895857334 = ((a721272783 / a2026977784) + 10);
    	a263638061 = (a786258498 - -2);
    	a1983740902 = 34 ;
    	a983758263 = ((((((a983758263 * a803418896) % 14999) % 101) - -305) + 8893) - 8893);
    	a1574467713 = ((a263638061 + a1895857334) - 21);
    	a1625516355 = ((((((((a1625516355 * a983758263) % 14999) % 37) - 43) * 9) / 10) * 9) / 10);
    	a1675035970 = (((((((a1675035970 * a30494462) - 15219) % 51) - -259) * 5) % 51) + 231);
    	a2061425267 = (a1478681170 + 8);
    	a708839806 = 34 ;
    	a1211013485 = 34 ;
    	a2026977784 = (a1895857334 + -2);
    	a1959068056 = (a1210910088 - -8);
    	a63333937 = (((((((a63333937 * a983758263) % 14999) * 2) % 106) - -136) + 19925) + -19925);
    	a26346326 = 34 ;
    	a30494462 = (((((((a30494462 * a1985899004) % 14999) % 85) + 211) + -2) - -25535) - 25532);
    	a263151501 = 34 ;
    	a1151361287 = ((((((a1151361287 * a999024345) % 14999) + -8234) - -12109) % 20) + 255);
    	a1254983042 = ((((((a1254983042 * a2130183577) % 14999) / 5) / 5) % 105) - -309);
    	a709568404 = 34 ;
    	a2087535773 = (a190525986 - 5);
    	a1985899004 = ((((((((a999024345 * a999024345) % 14999) % 76) + 388) * 5) - -17451) % 76) + 391);
    	a2130183577 = ((((((a2130183577 * a620105235) % 14999) % 12) - -242) - -14806) + -14804);
    	a1318526106 = 34 ;
    	a302110279 = 34 ;
    	a4442917 = (a2087535773 - -2);
    	a620105235 = ((((((a620105235 * a30494462) % 14999) + 5595) % 94) + -65) - -1);
    	a1249952537 = (a2061425267 + -6);
    	a1895304149 = 34 ;
    	a813082108 = (((((((a813082108 * a983758263) % 14999) + 13910) - 19446) + 7077) % 69) - -168);
    	a1125477212 = 34 ;
    	a786258498 = ((a778006913 * a1916853335) + -2);
    	a778006913 = ((a1348848030 * a1574467713) - 7);
    	a1916853335 = ((a190525986 * a2130193413) + -103);
    	a260539918 = (((((a217799639 * a983758263) / 5) % 73) + 93) - 19);
    	a190525986 = (a1574467713 - -10);
    	a1644957382 = 34 ;
    	a1210910088 = (a1895857334 - 8);
    	a1478681170 = (a1830659124 - 6); 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((( cf==1  && (input == 13)) && a1210910088 == 2) && (a1644957382 == 33 && ((a1916853335 == 6 && (((-2 < a1254983042) && (202 >= a1254983042)) && a2061425267 == 11)) && a1241576728 == 7)))) {
    	cf = 0;
    	a1318526106 = 34 ;
    	a1151361287 = ((((((a1151361287 * a1985899004) % 14999) / 5) + 16367) % 20) - -271);
    	a1895304149 = 34 ;
    	a1916853335 = ((a2087535773 - a1241576728) - -10);
    	a778006913 = (a721272783 + -7);
    	a983758263 = ((((((a983758263 * a2130183577) % 14999) % 14796) - -15202) - 11888) + 11889);
    	a709568404 = 34 ;
    	a1644957382 = 34 ;
    	a263151501 = 34 ;
    	a2026977784 = (a1916853335 - -2);
    	a4442917 = (a1959068056 + -2);
    	a302110279 = 34 ;
    	a2130183577 = ((((((a1675035970 * a999024345) % 14999) % 12) - -231) / 5) + 195);
    	a813082108 = (((((a813082108 * a63333937) + 4084) - -12732) % 69) - -168);
    	a708839806 = 34 ;
    	a1125477212 = 34 ;
    	a2061425267 = (a1210910088 - -10);
    	a1830659124 = (a778006913 + 8);
    	a63333937 = (((((a63333937 * a30494462) % 106) + 137) + 7947) - 7946);
    	a404763935 = (a721272783 + 4);
    	a1254983042 = ((((((a1254983042 * a1675035970) % 14999) - -2369) - 1296) % 105) - -308);
    	a26346326 = 34 ;
    	a1959068056 = ((a2026977784 + a4442917) - 6);
    	a1478681170 = (a721272783 - 5);
    	a2087535773 = a1249952537;
    	a2130193413 = ((a1210910088 / a1916853335) - -11);
    	a1625516355 = (((((((a1625516355 * a983758263) % 14999) % 37) - 41) / 5) * 10) / 2);
    	a190525986 = (a786258498 - -2);
    	a30494462 = ((((((a620105235 * a803418896) % 14999) % 85) - -209) + -26155) - -26155);
    	a2073482783 = 34 ;
    	a601495656 = 34 ;
    	a1211013485 = 34 ;
    	a620105235 = (((((((a620105235 * a803418896) % 14999) - -13618) * 1) * 1) % 94) - 63);
    	a1826277115 = ((((((a983758263 * a803418896) % 14999) + 3812) - 17652) % 14910) - -15088);
    	a786258498 = ((a1249952537 / a4442917) + 10);
    	a1675035970 = ((((((((a1675035970 * a999024345) % 14999) % 51) + 258) - -1) * 5) % 51) + 259);
    	a548050643 = 35 ;
    	a1241576728 = (a190525986 + -3);
    	a1210910088 = ((a1348848030 * a1348848030) + -97);
    	a217799639 = (((((((a813082108 * a2130183577) % 14999) - -2272) % 28) + -43) - -12485) - 12471);
    	a1985899004 = (((((((a1985899004 * a1151361287) % 14999) % 76) + 434) + -33) / 5) - -336);
    	a1249952537 = (a2026977784 - 3); 
    	 printf("%d\n", 19); fflush(stdout); 
    } if(((( cf==1  && (input == 14)) && a1211013485 == 33) && (a1478681170 == 4 && (a1249952537 == 5 && (a778006913 == 2 && (a2087535773 == 4 && a708839806 == 33)))))) {
    	cf = 0;
    	a709568404 = 32 ;
    	a1916853335 = (a190525986 - 5);
    	a217799639 = ((((((a1151361287 * a1151361287) % 14999) + 3718) / 5) * 10) / -9);
    	a260539918 = (((((((a1151361287 * a1151361287) % 14999) - 21779) + 32193) + 4196) * -1) / 10);
    	a1125477212 = 34 ;
    	a999024345 = ((((((a1151361287 * a1151361287) % 14999) + -17844) * 10) / 9) * 1);
    	a1675035970 = (((((a1675035970 * a999024345) % 14999) - 14874) * 1) - 126);
    	a1249952537 = (a4442917 + -2);
    	a341216798 = (((((a803418896 * a803418896) % 31) + 265) + -622) + 624);
    	a263151501 = 32 ;
    	a1018383389 = ((((((a260539918 * a1151361287) % 14999) - -18288) - -1700) / 5) * -5);
    	a2130193413 = (a1916853335 + 4);
    	a1625516355 = (((((((a1625516355 * a217799639) % 14999) - 22183) * 10) / 9) * 10) / 9);
    	a983758263 = (((((((a983758263 * a341216798) % 14999) % 14997) + -15002) / 5) / 5) - 15779);
    	a2026977784 = (a190525986 - 3);
    	a1700231631 = (a778006913 - -4);
    	a1644957382 = 32 ;
    	a1959068056 = a190525986;
    	a2087535773 = (a721272783 + -7);
    	a786258498 = (a1249952537 - -6);
    	a1756173294 = (((((a341216798 * a983758263) % 14999) / 5) - 17695) * 1);
    	a1241576728 = ((a2061425267 - a721272783) + 5);
    	a30494462 = (((((a30494462 * a620105235) % 14969) + -15030) + 28344) - 28345);
    	a1478681170 = ((a1210910088 * a1700231631) + -9);
    	a1254983042 = ((((((a1254983042 * a999024345) % 14999) * 2) % 14999) + -15000) * 1);
    	a2061425267 = (a1916853335 - -7);
    	a2130183577 = (((((a2130183577 * a1151361287) % 14999) + -25977) - 703) + -1271);
    	a302110279 = 32 ;
    	a1985899004 = (((((a1985899004 * a63333937) % 14999) + -14872) + -4) - 49);
    	a708839806 = 34 ;
    	a1211013485 = 32 ;
    	a601495656 = 32 ;
    	a26346326 = 32 ;
    	a76745981 = 32 ;
    	a2073482783 = 33 ;
    	a1210910088 = ((a1348848030 - a1348848030) - -1);
    	a813082108 = (((((((a813082108 * a999024345) % 14999) % 69) - -173) - 0) - 25026) + 25027);
    	a1180594800 = 32 ;
    	a190525986 = ((a1916853335 / a778006913) + 7);
    	a1830659124 = (a4442917 - -3);
    	a778006913 = ((a2130193413 - a1348848030) + 2);
    	a1895304149 = 32 ;
    	a4442917 = (a2087535773 - -2); 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((((a26346326 == 33 && ((-182 < a620105235) && (-160 >= a620105235))) && a1249952537 == 5) && a76745981 == 33) && ((-62 < a30494462) && (124 >= a30494462))) && (( cf==1  && (input == 15)) && ((3 < a813082108) && (104 >= a813082108))))) {
    	cf = 0;
    	a1826277115 = ((((((a1625516355 * a2130183577) * 1) % 62) + 115) - 15906) + 15932);
    	a1644957382 = 34 ;
    	a76745981 = 34 ;
    	a1675035970 = ((((((a1675035970 * a620105235) % 14999) % 51) - -258) + 2) * 1);
    	a965340096 = 32 ;
    	a708839806 = 34 ;
    	a63333937 = (((((a1018383389 * a813082108) + 484) + 6483) % 106) - -37);
    	a1895304149 = 34 ;
    	a1521644128 = ((a4442917 + a721272783) - 11);
    	a30494462 = ((((((a30494462 * a63333937) % 14999) + -6590) - 6395) % 85) + 209);
    	a983758263 = (((((((a983758263 * a1826277115) % 14999) / 5) / 5) - 22898) * -1) / 10);
    	a1478681170 = ((a2026977784 / a2061425267) - -5);
    	a1211013485 = 34 ;
    	a263151501 = 34 ;
    	a813082108 = (((((a813082108 * a260539918) / 5) / 5) % 69) + 174);
    	a778006913 = ((a2087535773 - a1348848030) + 9);
    	a4442917 = a1241576728;
    	a786258498 = ((a721272783 + a721272783) + -10); 
    	 printf("%d\n", 19); fflush(stdout); 
    } 
}
 void calculate_outputm74(int input) {
    if(((((-62 < a30494462) && (124 >= a30494462)) && (((-44 < a260539918) && (-8 >= a260539918)) && a1318526106 == 33)) && (((-182 < a620105235) && (-160 >= a620105235)) && (a1959068056 == 9 && (((174 < a1985899004) && (371 >= a1985899004)) && ((input == 2) &&  cf==1 )))))) {
    	cf = 0;
    	a1985899004 = (((((((a1985899004 * a803418896) % 14999) * 2) - -2) + 0) % 76) - -448);
    	a1125477212 = 32 ;
    	a778006913 = a1210910088;
    	a1916853335 = (a1241576728 - 2);
    	a2073482783 = 34 ;
    	a2087535773 = (a786258498 + -6);
    	a263151501 = 34 ;
    	a217799639 = (((((a217799639 * a2130183577) % 14999) - 9475) - 3726) - 1698);
    	a1830659124 = (a778006913 - -9);
    	a190525986 = (a4442917 + 5);
    	a620105235 = (((((a620105235 * a813082108) % 94) - -15) + 4) + -3);
    	a721272783 = (a1249952537 + 10);
    	a76745981 = 32 ;
    	a2097567994 = 34 ;
    	a1644957382 = 34 ;
    	a1969216760 = 36 ;
    	a1249952537 = ((a1348848030 * a4442917) - 68);
    	a2061425267 = (a778006913 + 8);
    	a709568404 = 32 ;
    	a4442917 = ((a786258498 / a2026977784) - -4); 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a601495656 == 33 && ((a1180594800 == 33 && (((75 < a1151361287) && (249 >= a1151361287)) && (a1211013485 == 33 && (a263151501 == 33 && ( cf==1  && (input == 4)))))) && ((17 < a1018383389) && (167 >= a1018383389))))) {
    	cf = 0;
    	a63333937 = (((((((a1254983042 * a1018383389) % 14999) % 106) - -137) + -10833) - 14034) - -24866);
    	a1318526106 = 34 ;
    	a76745981 = 34 ;
    	a217799639 = (((((((a1675035970 * a63333937) % 14999) % 28) + -36) * 5) % 28) - 15);
    	a1895857334 = (a2026977784 - -5);
    	a30494462 = ((((((((a1985899004 * a63333937) % 14999) % 85) - -172) * 9) / 10) * 9) / 10);
    	a1478681170 = (a2061425267 + -7);
    	a1210910088 = (a721272783 - 7);
    	a266166646 = ((((((a999024345 * a803418896) / 5) + -17485) + -197) % 77) + 303);
    	a1254983042 = ((((((((a1254983042 * a1018383389) % 14999) % 105) - -309) * 1) * 5) % 105) + 277);
    	a1241576728 = (a4442917 + 2);
    	a263151501 = 34 ;
    	a2026977784 = (a4442917 - -3);
    	a1018383389 = ((((((a63333937 * a63333937) % 14999) % 21) + 186) - -5) + -22);
    	a2130193413 = (a721272783 - -1);
    	a1895304149 = 34 ;
    	a26346326 = 34 ;
    	a813082108 = (((((((a813082108 * a1675035970) % 69) + 165) * 5) + -11742) % 69) - -193);
    	a2073482783 = 34 ;
    	a1916853335 = ((a1478681170 / a1241576728) + 7);
    	a983758263 = ((((((((a983758263 * a266166646) % 14999) - -9863) % 101) + 305) * 5) % 101) + 243);
    	a709568404 = 34 ;
    	a999024345 = ((((((a1675035970 * a1675035970) % 14999) % 64) - -181) * 5) / 5);
    	a620105235 = (((((((a620105235 * a2130183577) % 14999) + 28164) + -15481) + 8448) % 94) + -68);
    	a1180594800 = 34 ;
    	a1985899004 = ((((((a217799639 * a1151361287) - -20196) % 76) + 412) + -12906) + 12892);
    	a302110279 = 33 ;
    	a2087632595 = 34 ;
    	a1625516355 = (((((((a1625516355 * a30494462) % 14999) + -3959) * 1) + -1467) % 37) - 22);
    	a1151361287 = (((((((a63333937 * a63333937) % 14999) + 1775) % 20) - -265) + 12541) - 12554);
    	a1959068056 = (a1249952537 + 5);
    	a786258498 = ((a1249952537 - a2130193413) - -16);
    	a1249952537 = (a778006913 - -3);
    	a260539918 = (((((a260539918 * a63333937) % 73) - -72) - -60) + -51);
    	a4442917 = ((a1830659124 - a1348848030) + 9);
    	a1830659124 = (a721272783 + 1); 
    	 printf("%d\n", 19); fflush(stdout); 
    } if(((a1241576728 == 7 && (((174 < a1985899004) && (371 >= a1985899004)) && ((a1125477212 == 33 && a1318526106 == 33) && a1644957382 == 33))) && (((-198 < a217799639) && (-59 >= a217799639)) && ( cf==1  && (input == 8))))) {
    	cf = 0;
    	a1985899004 = (((((a1985899004 * a63333937) % 14999) + -10916) + -3915) * 1);
    	a1916853335 = (a1478681170 + 3);
    	a709568404 = 34 ;
    	a1895857334 = (a1348848030 - 6);
    	a1700231631 = ((a1895857334 - a1830659124) - -12);
    	a721272783 = ((a1241576728 / a4442917) + 16);
    	a76745981 = 34 ;
    	a1180594800 = 34 ;
    	a1125477212 = 34 ;
    	a1018383389 = (((((a1018383389 * a1625516355) - 11950) + 0) % 21) + 194);
    	a4442917 = (a786258498 - 2);
    	a1478681170 = (a190525986 + -5);
    	a1211013485 = 34 ;
    	a813082108 = ((((((a813082108 * a1625516355) % 69) - -190) * 10) / 9) - -4);
    	a260539918 = (((((a260539918 * a1151361287) % 73) - -126) + 4) / 5);
    	a190525986 = ((a1959068056 * a1249952537) - 34);
    	a2130183577 = ((((((a2130183577 * a63333937) % 14999) - 12542) % 12) - -242) * 1);
    	a63333937 = ((((((a63333937 * a217799639) % 106) + 135) * 1) / 5) - -177); 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a76745981 == 33 && (( cf==1  && (input == 11)) && ((-198 < a217799639) && (-59 >= a217799639)))) && (((48 < a999024345) && (131 >= a999024345)) && ((((-2 < a1254983042) && (202 >= a1254983042)) && a601495656 == 33) && ((-109 < a1625516355) && (-81 >= a1625516355)))))) {
    	cf = 0;
    	a2130193413 = ((a190525986 * a721272783) - 91);
    	a2061425267 = (a2130193413 + 1);
    	a1830659124 = a2130193413;
    	a1625516355 = ((((a1625516355 * a1018383389) + -7339) + -1665) / 5);
    	a263151501 = 32 ;
    	a1318526106 = 32 ;
    	a983758263 = (((((((a983758263 * a803418896) % 14999) % 14997) - 15002) + -1) / 5) + -19992);
    	a620105235 = (((((((a620105235 * a1625516355) % 14999) + -18684) + 5682) * 2) % 14909) - 15090);
    	a1254983042 = ((((a1254983042 * a260539918) - 20939) + -197) * 1);
    	a1249952537 = (a1830659124 - 5);
    	a709568404 = 32 ;
    	a302110279 = 32 ;
    	a601495656 = 32 ;
    	a1774184757 = ((((a999024345 * a803418896) - -2549) * 1) - 8228);
    	a2130183577 = ((((((a2130183577 * a1675035970) % 14999) - 21805) - 754) * 10) / 9);
    	a4442917 = (a2061425267 - 5);
    	a1151361287 = ((((((a1625516355 * a1625516355) % 14999) - 3535) * 2) - -1454) + -24361);
    	a76745981 = 32 ;
    	a341216798 = ((((((a803418896 * a983758263) % 14999) % 14850) + 15148) / 5) + 6615);
    	a260539918 = ((((((a620105235 * a1151361287) % 14999) * 2) % 14978) - 15021) - 0);
    	a1210910088 = (a1959068056 + -8);
    	a1675035970 = (((((a1985899004 * a2130183577) % 14999) + -12129) / 5) - 20344);
    	a2087535773 = (a1241576728 - 4);
    	a30494462 = ((((((a30494462 * a1625516355) % 14999) % 14969) + -15030) - 2) + 0);
    	a1241576728 = ((a190525986 - a1830659124) - -5);
    	a965340096 = 32 ;
    	a63333937 = (((((((a63333937 * a2130183577) % 14999) / 5) - 694) + 24841) * -1) / 10);
    	a813082108 = (((((a813082108 * a1774184757) % 14999) + -4662) / 5) * 5);
    	a1959068056 = (a1249952537 - -4);
    	a1521644128 = (a2026977784 - 3);
    	a1478681170 = a4442917;
    	a2026977784 = (a1348848030 + -5);
    	a786258498 = ((a1348848030 / a1830659124) - -7);
    	a2073482783 = 32 ;
    	a778006913 = (a2130193413 + -8);
    	a1125477212 = 32 ;
    	a1985899004 = (((((a1625516355 * a217799639) % 14999) - 27318) - 1132) + -460);
    	a1644957382 = 32 ;
    	a1895304149 = 32 ;
    	a217799639 = (((((a999024345 * a1625516355) % 14999) / 5) / 5) + -16615);
    	a1018383389 = ((((((a999024345 * a803418896) * 1) % 21) - -189) / 5) + 158);
    	a1180594800 = 32 ;
    	a999024345 = (((((a999024345 * a1625516355) % 14999) / 5) - -3392) + -8714);
    	a1916853335 = (a2026977784 - 2);
    	a1211013485 = 32 ;
    	a708839806 = 32 ;
    	a26346326 = 32 ;
    	a190525986 = (a2087535773 + 6); 
    	 printf("%d\n", 18); fflush(stdout); 
    } 
}
 void calculate_outputm76(int input) {
    if(((a708839806 == 33 && (( cf==1  && (input == 2)) && a1959068056 == 9)) && (a1210910088 == 2 && ((a1211013485 == 33 && ((-135 < a63333937) && (29 >= a63333937))) && a2087535773 == 4)))) {
    	cf = 0;
    	a999024345 = (((((a260539918 * a260539918) + -24590) % 64) + 206) * 1);
    	a1210910088 = ((a4442917 - a2087535773) - -1);
    	a822442096 = (((((((a803418896 * a803418896) % 100) - -114) + -1) * 5) % 100) + 51);
    	a2041520547 = 36 ;
    	a1625516355 = (((((((a1625516355 * a813082108) % 37) - 7) * 10) / 9) * 9) / 10);
    	a190525986 = (a1210910088 - -8);
    	a1318526106 = 34 ;
    	a2061425267 = ((a1348848030 - a786258498) - -7);
    	a1151361287 = ((((((a1151361287 * a999024345) % 14999) % 20) - -266) + -10) * 1);
    	a2073482783 = 34 ;
    	a1675035970 = ((((((a1675035970 * a620105235) % 14999) - -1938) % 51) - -259) + -1);
    	a30494462 = ((((((a30494462 * a1985899004) % 14999) % 85) + 210) - 1) * 1);
    	a601495656 = 34 ;
    	a63333937 = ((((((a63333937 * a1675035970) % 14999) / 5) * 5) % 106) - -135);
    	a1644957382 = 34 ;
    	a1959068056 = (a4442917 - -4);
    	a1895857334 = (a1916853335 - -6);
    	a2087535773 = (a1830659124 - 6);
    	a26346326 = 34 ;
    	a1254983042 = ((((((a1254983042 * a2130183577) % 14999) / 5) % 105) - -307) - 0);
    	a1478681170 = (a1241576728 - 3);
    	a1916853335 = (a1249952537 + 1);
    	a983758263 = ((((((a983758263 * a822442096) % 14999) / 5) / 5) % 101) - -305);
    	a1774184757 = ((((((a999024345 * a999024345) % 14999) % 92) + -78) - 66) + 11);
    	a709568404 = 34 ;
    	a1211013485 = 34 ;
    	a786258498 = (a1348848030 - 4);
    	a708839806 = 34 ;
    	a1895304149 = 34 ;
    	a4442917 = (a2026977784 + -2); 
    	 printf("%d\n", 18); fflush(stdout); 
    } if(((a2061425267 == 11 && (a1210910088 == 2 && (a1478681170 == 4 && (a1318526106 == 33 && (((75 < a1151361287) && (249 >= a1151361287)) && ((3 < a813082108) && (104 >= a813082108))))))) && ( cf==1  && (input == 11)))) {
    	cf = 0;
    	a30494462 = ((((((a30494462 * a983758263) * 1) % 85) + 211) / 5) - -160);
    	a1125477212 = 32 ;
    	a260539918 = ((((a260539918 * a1774184757) * 4) * 1) - 604);
    	a1211013485 = 32 ;
    	a302110279 = 32 ;
    	a2130183577 = (((((((a2130183577 * a63333937) % 14999) - 8569) / 5) + -4524) % 12) + 248);
    	a786258498 = (a1916853335 + 4);
    	a2087535773 = (a1210910088 - -3);
    	a1985899004 = (((((a1774184757 * a30494462) % 14999) - 29454) / 5) * 5);
    	a63333937 = (((((a1151361287 * a217799639) / 5) % 106) + 153) + -6);
    	a1895304149 = 32 ;
    	a1318526106 = 32 ;
    	a266166646 = ((((a803418896 * a803418896) - 0) / 5) - 29320);
    	a999024345 = ((((((a30494462 * a217799639) % 64) + 212) - 17) + -11283) - -11330);
    	a1254983042 = (((((((a1254983042 * a983758263) % 14999) + 4040) - 13327) * 1) % 105) - -308);
    	a2087632595 = 34 ;
    	a1895857334 = (a4442917 + 7);
    	a1478681170 = (a1959068056 + -4);
    	a1625516355 = (((((a1625516355 * a217799639) * 10) / -7) + -18072) - 1865);
    	a26346326 = 34 ;
    	a1018383389 = ((((a30494462 * a217799639) + -5227) * 1) * 1);
    	a983758263 = ((((((a983758263 * a1675035970) % 14999) * 2) % 101) + 305) - 1);
    	a708839806 = 32 ;
    	a4442917 = (a1959068056 - 2);
    	a1644957382 = 34 ;
    	a813082108 = (((((((a813082108 * a1675035970) % 69) - -109) * 10) / 9) * 10) / 9);
    	a1210910088 = (a1830659124 + -8);
    	a1916853335 = (a2061425267 - 4);
    	a2061425267 = (a2087535773 + 7);
    	a190525986 = ((a721272783 * a1959068056) - 79);
    	a1675035970 = ((((((((a1675035970 * a999024345) % 14999) % 51) - -223) * 10) / 9) + -10239) + 10242);
    	a2073482783 = 34 ;
    	a709568404 = 32 ;
    	a1959068056 = a721272783; 
    	 printf("%d\n", 17); fflush(stdout); 
    } if((((((a601495656 == 33 && ((48 < a999024345) && (131 >= a999024345))) && a4442917 == 6) && ((103 < a2130183577) && (230 >= a2130183577))) && ((-62 < a30494462) && (124 >= a30494462))) && (((input == 15) &&  cf==1 ) && a786258498 == 9))) {
    	cf = 0;
    	a2087535773 = (a1830659124 + -6);
    	a1895304149 = 34 ;
    	a1916853335 = (a1959068056 - 2);
    	a1959068056 = (a2026977784 - -1);
    	a2073482783 = 34 ;
    	a786258498 = ((a1348848030 - a721272783) + 6);
    	a601495656 = 34 ;
    	a1826277115 = (((((a803418896 * a803418896) % 62) + 116) - 21056) + 21056);
    	a2061425267 = (a778006913 + 9);
    	a26346326 = 34 ;
    	a2130183577 = ((((((a1018383389 * a63333937) + 4061) % 12) + 243) - 11332) + 11331);
    	a965340096 = 32 ;
    	a983758263 = ((((((a983758263 * a1826277115) % 14999) + -9253) % 14796) + 15202) + 0);
    	a1254983042 = ((((((((a1254983042 * a2130183577) % 14999) - 3751) % 105) - -307) * 5) % 105) - -308);
    	a1521644128 = (a4442917 + 4);
    	a1478681170 = (a721272783 + -5);
    	a1210910088 = (a1916853335 + -4);
    	a30494462 = ((((((a30494462 * a620105235) % 85) - -211) * 5) % 85) - -166);
    	a999024345 = (((((a1774184757 * a63333937) / 5) % 64) - -196) + -1);
    	a1644957382 = 34 ;
    	a4442917 = ((a2026977784 - a1830659124) + 9);
    	a709568404 = 34 ;
    	a813082108 = ((((((a813082108 * a1018383389) - -2153) % 69) + 122) * 9) / 10);
    	a260539918 = (((((((a260539918 * a983758263) % 14999) % 73) - -65) - -23748) + -246) - 23499);
    	a1211013485 = 34 ;
    	a708839806 = 34 ;
    	a190525986 = ((a2087535773 - a2130193413) - -17);
    	a1625516355 = (((((((a1625516355 * a217799639) % 37) + -52) - 26) * 5) % 37) + -38);
    	a1675035970 = (((((((a1675035970 * a1151361287) % 14999) % 51) + 238) / 5) - 28003) + 28189);
    	a1318526106 = 34 ;
    	a1151361287 = ((((((a63333937 * a999024345) % 14999) + -1001) + -1185) % 20) - -270);
    	a63333937 = ((((((((a63333937 * a813082108) % 14999) % 106) - -136) * 5) * 5) % 106) - -78); 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm77(int input) {
    if(((a2026977784 == 8 && ((-44 < a260539918) && (-8 >= a260539918))) && ((((a1241576728 == 7 && ((input == 2) &&  cf==1 )) && a1830659124 == 10) && a1959068056 == 9) && ((75 < a1151361287) && (249 >= a1151361287))))) {
    	cf = 0;
    	a721272783 = ((a2087535773 - a1249952537) - -14);
    	a1916853335 = (a1210910088 - -4);
    	a76745981 = 33 ;
    	a1075307847 = 33 ;
    	a1985899004 = (((((((a983758263 * a620105235) % 14999) / 5) % 98) - -272) / 5) + 170);
    	a1826277115 = (((((((a803418896 * a983758263) % 14999) / 5) * 5) * 2) % 105) - 52); 
    	 printf("%d\n", 26); fflush(stdout); 
    } if(((((((input == 5) &&  cf==1 ) && ((-44 < a260539918) && (-8 >= a260539918))) && a1241576728 == 7) && a2130193413 == 10) && ((((-109 < a1625516355) && (-81 >= a1625516355)) && a1983740902 == 33) && ((-2 < a1254983042) && (202 >= a1254983042))))) {
    	cf = 0;
    	a1891437507 = 35 ;
    	a1345687529 = ((((((a803418896 * a983758263) % 14999) % 14962) - -15037) * 1) * 1);
    	a721272783 = (a1830659124 + 4); 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((((a1318526106 == 33 && ((-135 < a63333937) && (29 >= a63333937))) && a2026977784 == 8) && a1644957382 == 33) && ((a1180594800 == 33 && ((input == 6) &&  cf==1 )) && ((-2 < a1254983042) && (202 >= a1254983042))))) {
    	cf = 0;
    	a1826277115 = ((((a999024345 * a983758263) - -1736) - 19135) - -20319);
    	a2026977784 = a1959068056;
    	a709568404 = 34 ;
    	a190525986 = (a1348848030 + -4);
    	a260539918 = (((((((a260539918 * a1826277115) % 14999) + -7181) / 5) + 8560) % 73) + 37);
    	a404763935 = (a786258498 - -5);
    	a1644957382 = 34 ;
    	a601495656 = 34 ;
    	a1625516355 = ((((((a1625516355 * a1826277115) % 14999) / 5) - -5240) % 37) + -69);
    	a548050643 = 35 ;
    	a1959068056 = ((a721272783 * a190525986) - 100);
    	a302110279 = 34 ;
    	a1478681170 = (a2026977784 + -4);
    	a1211013485 = 34 ;
    	a786258498 = ((a1210910088 - a1241576728) - -15);
    	a1675035970 = ((((((a2130183577 * a63333937) % 14999) - 13618) * 1) % 51) - -258);
    	a1125477212 = 34 ;
    	a1210910088 = (a1348848030 - 12);
    	a1254983042 = ((((((a1254983042 * a999024345) % 105) - -309) + 15971) + 2758) - 18730);
    	a983758263 = ((((((a983758263 * a1826277115) % 14999) % 14796) + 15202) / 5) + 22367);
    	a2073482783 = 34 ;
    	a1241576728 = (a1478681170 + 3);
    	a2130183577 = ((((((a1018383389 * a1985899004) % 14999) - 14445) - 13327) % 12) + 243);
    	a4442917 = (a2026977784 - 2);
    	a2087535773 = ((a190525986 + a1830659124) - 16);
    	a1151361287 = (((((a1151361287 * a1625516355) % 20) + 276) * 1) - -10);
    	a778006913 = (a2026977784 - 6);
    	a620105235 = ((((((a620105235 * a1625516355) - 17980) % 94) + 17) - 732) + 701);
    	a1830659124 = (a786258498 + 1);
    	a1895304149 = 34 ;
    	a63333937 = ((((((a63333937 * a1675035970) % 14999) - -3805) - 1594) % 106) - -135);
    	a1180594800 = 34 ;
    	a1983740902 = 34 ;
    	a813082108 = (((((((a813082108 * a217799639) % 69) - -234) * 9) / 10) * 9) / 10);
    	a999024345 = ((((((a999024345 * a30494462) % 64) + 195) + 0) / 5) - -136);
    	a1318526106 = 34 ;
    	a26346326 = 34 ;
    	a217799639 = ((((((a1826277115 * a803418896) % 14999) / 5) * 5) % 28) - 30);
    	a2061425267 = ((a190525986 + a2130193413) + -9);
    	a2130193413 = ((a1210910088 / a1210910088) + 10);
    	a1249952537 = ((a2026977784 * a1916853335) - 57);
    	a30494462 = ((((((a30494462 * a1254983042) % 14999) + -14195) % 85) + 209) - 0); 
    	 printf("%d\n", 18); fflush(stdout); 
    } if((((a709568404 == 33 && a1895304149 == 33) && a1644957382 == 33) && ((a26346326 == 33 && (( cf==1  && (input == 15)) && ((-198 < a217799639) && (-59 >= a217799639)))) && ((-44 < a260539918) && (-8 >= a260539918))))) {
    	cf = 0;
    	a1675035970 = ((((((a1675035970 * a999024345) * 1) % 51) - -243) * 9) / 10);
    	a1151361287 = ((((((a1151361287 * a260539918) * 2) + 6604) + 15531) % 20) - -251);
    	a983758263 = ((((((a983758263 * a803418896) % 14999) % 101) - -304) / 5) + 299);
    	a302110279 = 34 ;
    	a1895857334 = (a2130193413 + 1);
    	a1125477212 = 34 ;
    	a4442917 = ((a721272783 / a2130193413) - -6);
    	a263638061 = ((a1348848030 + a1241576728) + -11);
    	a2087535773 = ((a778006913 / a1210910088) - -4);
    	a708839806 = 34 ;
    	a217799639 = ((((((((a1985899004 * a63333937) % 14999) % 28) - 28) * 5) - -4062) % 28) - 43);
    	a2130183577 = (((((((a2130183577 * a999024345) % 14999) % 12) + 232) * 1) + -7909) + 7919);
    	a1574467713 = (a1249952537 + -4);
    	a260539918 = ((((((a2130183577 * a1675035970) % 14999) % 73) - -13) + 28576) + -28554);
    	a1959068056 = (a2061425267 + -1);
    	a26346326 = 34 ;
    	a1895304149 = 34 ;
    	a786258498 = (a1249952537 + 5);
    	a30494462 = (((((((a30494462 * a620105235) + -3771) % 85) + 210) / 5) * 51) / 10);
    	a1241576728 = ((a190525986 + a2061425267) - 13);
    	a1254983042 = ((((((a1254983042 * a620105235) % 14999) % 105) + 307) - -22228) - 22227);
    	a1180594800 = 34 ;
    	a1830659124 = ((a190525986 * a190525986) - 89);
    	a63333937 = (((((((a983758263 * a2130183577) % 14999) + -19753) - 8415) / 5) % 106) - -152);
    	a999024345 = (((((((a217799639 * a217799639) * 5) % 64) - -136) * 5) % 64) - -151);
    	a709568404 = 34 ;
    	a778006913 = (a1959068056 + -7);
    	a1318526106 = 34 ;
    	a2061425267 = ((a2026977784 - a1241576728) + 12);
    	a2026977784 = (a721272783 - 1);
    	a1644957382 = 34 ;
    	a620105235 = ((((((a620105235 * a813082108) % 94) - -9) * 5) % 94) + -63);
    	a1625516355 = (((((a1625516355 * a2130183577) + 26442) % 37) + -41) * 1);
    	a2073482783 = 34 ;
    	a1210910088 = ((a1830659124 * a1830659124) - 118);
    	a1211013485 = 34 ;
    	a1249952537 = ((a2087535773 + a2087535773) - 4);
    	a813082108 = (((((((a1151361287 * a983758263) % 14999) + 3417) % 69) - -105) + 2227) - 2200);
    	a190525986 = (a4442917 + 4);
    	a1983740902 = 34 ;
    	a2130193413 = (a1478681170 - -7);
    	a1478681170 = (a1895857334 - 6); 
    	 printf("%d\n", 26); fflush(stdout); 
    } if((((((-198 < a217799639) && (-59 >= a217799639)) && ((171 < a1675035970) && (207 >= a1675035970))) && ((-182 < a620105235) && (-160 >= a620105235))) && (a1644957382 == 33 && (a1318526106 == 33 && (( cf==1  && (input == 7)) && ((-135 < a63333937) && (29 >= a63333937))))))) {
    	cf = 0;
    	a2004613952 = ((a2061425267 * a2026977784) + -78);
    	a30494462 = (((((a30494462 * a217799639) + 7588) % 85) + 210) - -2);
    	a1959068056 = (a1348848030 + -5);
    	a1675035970 = ((((((a1675035970 * a1254983042) % 14999) % 51) - -260) + -1) - 1);
    	a1249952537 = (a2004613952 - 4);
    	a1254983042 = (((((((a1151361287 * a217799639) % 14999) / 5) % 105) - -308) / 5) + 314);
    	a1625516355 = ((((((a1625516355 * a999024345) + -2248) % 37) - 23) / 5) - 25);
    	a1180594800 = 34 ;
    	a362219248 = ((((((a813082108 * a63333937) + -11254) * -1) / 10) * 10) / 9);
    	a1211013485 = 34 ;
    	a813082108 = ((((((a2130183577 * a260539918) % 69) - -230) * 5) % 69) - -163);
    	a1983740902 = 34 ;
    	a2026977784 = (a2061425267 - 2);
    	a1830659124 = (a2004613952 + 1);
    	a1895857334 = (a190525986 + -3);
    	a999024345 = ((((((a1151361287 * a620105235) % 14999) % 64) + 196) + 1) - 2);
    	a1018383389 = (((((((a1018383389 * a1774184757) % 21) + 182) * 1) * 5) % 21) + 190);
    	a983758263 = ((((((a983758263 * a362219248) % 14999) % 101) - -304) * 1) - 0);
    	a778006913 = (a1249952537 - 3);
    	a2061425267 = (a721272783 + 2);
    	a620105235 = (((((((a620105235 * a30494462) % 14999) % 94) + -65) + 17118) + 9396) - 26514);
    	a1151361287 = (((((a1151361287 * a1625516355) - -1821) % 20) - -270) * 1); 
    	 printf("%d\n", 26); fflush(stdout); 
    } 
}
 void calculate_outputm79(int input) {
    if((((((-44 < a260539918) && (-8 >= a260539918)) && ((48 < a999024345) && (131 >= a999024345))) && a1211013485 == 33) && (a1318526106 == 33 && (a708839806 == 33 && (a76745981 == 33 && ( cf==1  && (input == 7))))))) {
    	cf = 0;
    	a63333937 = (((((a1985899004 * a1985899004) % 14999) - 26878) - 881) / 5);
    	a1895304149 = 32 ;
    	a2130183577 = (((((a1254983042 * a260539918) * 3) + -2369) - -22816) + -20698);
    	a26346326 = 32 ;
    	a708839806 = 32 ;
    	a1959068056 = (a1249952537 - -3);
    	a999024345 = (((((a999024345 * a2130183577) % 14999) + -14996) - 2) + -4);
    	a1478681170 = (a778006913 - -1);
    	a1830659124 = (a190525986 - 1);
    	a1318526106 = 32 ;
    	a302110279 = 33 ;
    	a620105235 = ((((((a620105235 * a63333937) % 14999) + -21911) + -2898) * 10) / 9);
    	a341216798 = ((((a1625516355 * a1625516355) + -14585) / 5) * 5);
    	a1254983042 = ((((a1254983042 * a260539918) + -13154) - 5097) - -13623);
    	a1241576728 = ((a721272783 - a190525986) + 6);
    	a2087535773 = ((a1830659124 * a1830659124) + -78);
    	a834646264 = (a1249952537 - -1);
    	a786258498 = ((a1210910088 * a2004613952) - 16);
    	a76745981 = 32 ;
    	a1625516355 = ((((((a2130183577 * a341216798) % 14999) / 5) % 13) - 93) - 2);
    	a601495656 = 32 ;
    	a778006913 = (a190525986 + -9);
    	a983758263 = ((((((a983758263 * a341216798) % 14999) % 14997) - 15002) - 2) - 0);
    	a1018383389 = ((((((a2130183577 * a30494462) % 14999) % 74) + 91) + 0) * 1);
    	a1211013485 = 32 ;
    	a1180594800 = 32 ;
    	a1644957382 = 32 ;
    	a2073482783 = 32 ;
    	a263151501 = 32 ;
    	a30494462 = (((((a30494462 * a1675035970) % 14969) + -15030) + -1) + -1);
    	a1210910088 = (a721272783 / a190525986);
    	a1213722969 = (a4442917 + 5);
    	a260539918 = (((((a30494462 * a30494462) % 14999) - 28390) * 1) - 1026);
    	a813082108 = (((((a63333937 * a803418896) % 14999) + -3617) - 381) * 1);
    	a4442917 = (a190525986 - 5);
    	a709568404 = 32 ;
    	a1151361287 = ((((((a803418896 * a341216798) % 14999) % 86) - -163) + -16474) - -16472);
    	a1675035970 = (((((a1675035970 * a63333937) % 14999) / 5) + -24602) * 1); 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((((input == 9) &&  cf==1 ) && (a1249952537 == 5 && (a1959068056 == 9 && (a601495656 == 33 && ((a1125477212 == 33 && a2087535773 == 4) && a778006913 == 2)))))) {
    	cf = 0;
    	 
    	 printf("%d\n", 16); fflush(stdout); 
    } if((a1478681170 == 4 && (a1125477212 == 33 && (a1241576728 == 7 && (((( cf==1  && (input == 1)) && ((-109 < a1625516355) && (-81 >= a1625516355))) && ((174 < a1985899004) && (371 >= a1985899004))) && a2073482783 == 33))))) {
    	cf = 0;
    	a369798198 = 33 ;
    	a1700231631 = (a1210910088 + 4);
    	a721272783 = ((a1478681170 + a786258498) + 4); 
    	 printf("%d\n", 18); fflush(stdout); 
    } 
}
 void calculate_outputm82(int input) {
    if((((a302110279 == 33 && (a1895304149 == 33 && (((171 < a1675035970) && (207 >= a1675035970)) && ((input == 2) &&  cf==1 )))) && a1180594800 == 33) && (((-109 < a1625516355) && (-81 >= a1625516355)) && a2061425267 == 11))) {
    	cf = 0;
    	a999024345 = (((((a999024345 * a2130183577) % 14999) + -16715) / 5) - 18406);
    	a1018383389 = ((((((a1675035970 * a1254983042) % 14999) * 2) % 74) - -91) + 3);
    	a1318526106 = 32 ;
    	a983758263 = (((((((a983758263 * a803418896) % 14999) % 14997) - 15002) + -2) + 10901) - 10900);
    	a1895304149 = 32 ;
    	a834646264 = (a1830659124 - 4);
    	a1830659124 = (a786258498 - -1);
    	a1180594800 = 32 ;
    	a341216798 = ((((((a803418896 * a803418896) % 14999) + 7641) * -1) - -30317) * -1);
    	a1213722969 = ((a834646264 * a1249952537) - 19);
    	a1625516355 = (((((((a1625516355 * a620105235) % 14999) % 13) + -102) - 3) - 4968) + 4978);
    	a1675035970 = (((((a1675035970 * a2130183577) % 14999) - 20188) * 1) * 1);
    	a1211013485 = 32 ;
    	a709568404 = 32 ;
    	a2087535773 = (a2061425267 - 8);
    	a1254983042 = (((((a1254983042 * a999024345) % 14999) / 5) * 5) + -15000);
    	a63333937 = ((((a63333937 * a30494462) + -9520) - 1971) * 1);
    	a2130183577 = ((((((a2130183577 * a1774184757) % 14999) * 2) % 15051) + -14947) + -2);
    	a1151361287 = ((((((a1985899004 * a620105235) % 14999) - -1082) % 86) - -163) + 1);
    	a30494462 = ((((((a30494462 * a1985899004) % 14999) % 14969) + -15030) * 1) + -1);
    	a302110279 = 33 ;
    	a26346326 = 32 ;
    	a1210910088 = ((a1959068056 * a190525986) - 79); 
    	 printf("%d\n", 17); fflush(stdout); 
    } 
}
 void calculate_outputm5(int input) {
    if(((((((3 < a813082108) && (104 >= a813082108)) && ( cf==1  && ((-174 < a803418896) && (5 >= a803418896)))) && a786258498 == 9) && a26346326 == 33) && ((((171 < a1675035970) && (207 >= a1675035970)) && a1478681170 == 4) && ((-62 < a30494462) && (124 >= a30494462))))) {
    	if(((a1348848030 == 9 &&  cf==1 ) && (((((-135 < a63333937) && (29 >= a63333937)) && ((((-62 < a30494462) && (124 >= a30494462)) && a263151501 == 33) && a709568404 == 33)) && ((-109 < a1625516355) && (-81 >= a1625516355))) && a708839806 == 33))) {
    		calculate_outputm72(input);
    	} 
    	if(((a26346326 == 33 && a1211013485 == 33) && (a1959068056 == 9 && (((a1478681170 == 4 && ( cf==1  && a1348848030 == 10)) && a1895304149 == 33) && a1125477212 == 33)))) {
    		calculate_outputm73(input);
    	} 
    	if((((a1210910088 == 2 && ((a1348848030 == 12 &&  cf==1 ) && ((103 < a2130183577) && (230 >= a2130183577)))) && ((-109 < a1625516355) && (-81 >= a1625516355))) && (a1895304149 == 33 && (a1916853335 == 6 && ((3 < a813082108) && (104 >= a813082108)))))) {
    		calculate_outputm74(input);
    	} 
    	if((((103 < a2130183577) && (230 >= a2130183577)) && ((a1644957382 == 33 && ((((-109 < a1625516355) && (-81 >= a1625516355)) && ((a1348848030 == 14 &&  cf==1 ) && a2073482783 == 33)) && ((-44 < a260539918) && (-8 >= a260539918)))) && ((-2 < a1254983042) && (202 >= a1254983042))))) {
    		calculate_outputm76(input);
    	} 
    	if((((a2061425267 == 11 && (a1348848030 == 15 &&  cf==1 )) && ((-135 < a63333937) && (29 >= a63333937))) && ((a1125477212 == 33 && (a2026977784 == 8 && a778006913 == 2)) && ((17 < a1018383389) && (167 >= a1018383389))))) {
    		calculate_outputm77(input);
    	} 
    } 
    if((((a1210910088 == 2 && ((( cf==1  && ((5 < a803418896) && (76 >= a803418896))) && a1211013485 == 33) && ((48 < a999024345) && (131 >= a999024345)))) && a1180594800 == 33) && (((-182 < a620105235) && (-160 >= a620105235)) && a4442917 == 6))) {
    	if(((a26346326 == 33 && a786258498 == 9) && ((((a1180594800 == 33 && (a2004613952 == 12 &&  cf==1 )) && ((-109 < a1625516355) && (-81 >= a1625516355))) && a1959068056 == 9) && a2087535773 == 4))) {
    		calculate_outputm79(input);
    	} 
    } 
    if(((((((48 < a999024345) && (131 >= a999024345)) && (( cf==1  && 76 < a803418896) && a1318526106 == 33)) && ((-109 < a1625516355) && (-81 >= a1625516355))) && ((174 < a1985899004) && (371 >= a1985899004))) && (a2087535773 == 4 && ((-151 < a1774184757) && (35 >= a1774184757))))) {
    	if((((a709568404 == 33 && a1249952537 == 5) && a1916853335 == 6) && ((a1983740902 == 33 && ((a703247202 == 36 &&  cf==1 ) && a1125477212 == 33)) && a1895304149 == 33))) {
    		calculate_outputm82(input);
    	} 
    } 
}
 void calculate_outputm85(int input) {
    if((((((-109 < a1625516355) && (-81 >= a1625516355)) && ( cf==1  && (input == 13))) && a1478681170 == 4) && (((a1830659124 == 10 && a4442917 == 6) && ((-44 < a260539918) && (-8 >= a260539918))) && ((-198 < a217799639) && (-59 >= a217799639))))) {
    	cf = 0;
    	a63333937 = ((((a999024345 * a1774184757) - 8335) * 1) * 1);
    	a26346326 = 32 ;
    	a4442917 = (a1916853335 + -1);
    	a834646264 = ((a1959068056 + a778006913) - 5);
    	a1830659124 = (a2087535773 + 6);
    	a341216798 = ((((a1625516355 * a999024345) + 14411) + -27967) * 1);
    	a1895304149 = 32 ;
    	a708839806 = 32 ;
    	a260539918 = ((((((a260539918 * a63333937) % 14999) - 25235) * 10) / 9) / 5);
    	a76745981 = 32 ;
    	a1959068056 = ((a1830659124 - a1830659124) - -8);
    	a1675035970 = (((((a1675035970 * a1254983042) % 14999) + -7908) + -4638) + -749);
    	a1018383389 = ((((((a217799639 * a1151361287) % 14999) % 74) - -92) - 1) + 1);
    	a1213722969 = (a834646264 + 5);
    	a1478681170 = (a2061425267 + -8);
    	a778006913 = (a190525986 + -9);
    	a983758263 = (((((((a983758263 * a341216798) % 14999) + -67) % 14997) - 15002) / 5) + -12575);
    	a999024345 = (((((a999024345 * a260539918) % 14999) + -7921) + -1874) / 5);
    	a786258498 = ((a721272783 + a2061425267) + -14);
    	a1625516355 = (((((((a260539918 * a620105235) % 14999) + -28513) * 1) + 9583) % 13) - 81);
    	a1210910088 = (a190525986 - 9);
    	a302110279 = 33 ;
    	a1241576728 = (a2087535773 + 3);
    	a1318526106 = 32 ;
    	a1151361287 = ((((((a1151361287 * a813082108) % 14999) / 5) % 86) + 161) - 0);
    	a30494462 = ((((((a30494462 * a2130183577) % 14999) * 2) / 5) / 5) - 9461); 
    	 printf("%d\n", 26); fflush(stdout); 
    } 
}
 void calculate_outputm86(int input) {
    if(((((a1959068056 == 9 && (a1916853335 == 6 && ((input == 9) &&  cf==1 ))) && a302110279 == 33) && a1478681170 == 4) && (((75 < a1151361287) && (249 >= a1151361287)) && a1125477212 == 33))) {
    	cf = 0;
    	a786258498 = (a4442917 - -2);
    	a983758263 = ((((a983758263 * a999024345) - 28287) * 1) - 798);
    	a999024345 = (((((a2130183577 * a63333937) % 14999) / 5) - 14930) + -11651);
    	a341216798 = (((((a983758263 * a983758263) % 14999) / 5) + -18119) - 2931);
    	a1254983042 = ((((((a1254983042 * a1151361287) % 14999) * 2) % 14999) + -15000) + -2);
    	a834646264 = ((a2026977784 / a1959068056) - -6);
    	a2073482783 = 32 ;
    	a1151361287 = (((((((a983758263 * a1254983042) % 14999) / 5) % 86) + 133) - 1802) - -1749);
    	a1478681170 = (a2061425267 + -8);
    	a1959068056 = (a2087535773 + 5);
    	a1211013485 = 32 ;
    	a26346326 = 32 ;
    	a1625516355 = ((((((a1625516355 * a999024345) % 14999) % 13) - 93) / 5) + -84);
    	a1213722969 = (a778006913 + 9);
    	a4442917 = (a1210910088 - -3);
    	a30494462 = ((((((a30494462 * a260539918) % 14999) / 5) + -9868) * 10) / 9);
    	a1241576728 = (a2130193413 + -4);
    	a302110279 = 33 ;
    	a601495656 = 32 ;
    	a1018383389 = (((((((a260539918 * a260539918) % 14999) % 74) - -29) * 10) / 9) - 13);
    	a1210910088 = (a786258498 - 7);
    	a708839806 = 32 ;
    	a813082108 = ((((((a813082108 * a620105235) % 14999) / 5) + 23499) * 1) + -30421);
    	a1895304149 = 32 ;
    	a1675035970 = ((((((a1675035970 * a620105235) % 14999) + -1877) * 10) / 9) / 5);
    	a63333937 = ((((((a63333937 * a341216798) % 14999) % 14932) + -15066) - 2) * 1);
    	a778006913 = (a190525986 - 9);
    	a2130183577 = (((((a2130183577 * a1774184757) % 14999) / 5) + -26438) + -16); 
    	 printf("%d\n", 26); fflush(stdout); 
    } if(((((-198 < a217799639) && (-59 >= a217799639)) && (((171 < a1675035970) && (207 >= a1675035970)) && a2073482783 == 33)) && (a1241576728 == 7 && ((( cf==1  && (input == 12)) && a190525986 == 10) && ((75 < a1151361287) && (249 >= a1151361287)))))) {
    	cf = 0;
    	a263638061 = (a1210910088 - -8);
    	a263151501 = 34 ;
    	a30494462 = (((((a30494462 * a1018383389) % 85) - -211) - -1) + -1);
    	a778006913 = ((a1959068056 - a263638061) - -4);
    	a26346326 = 34 ;
    	a601495656 = 34 ;
    	a4442917 = (a2026977784 - 1);
    	a1625516355 = (((((a1625516355 * a63333937) % 37) - 42) + 1) - 1);
    	a620105235 = ((((((a63333937 * a1018383389) - -1528) * 1) + -1387) % 94) - 63);
    	a1125477212 = 34 ;
    	a999024345 = (((((a999024345 * a620105235) + -2528) % 64) + 195) - -2);
    	a2130193413 = (a190525986 + 1);
    	a153649526 = 33 ;
    	a708839806 = 34 ;
    	a1826277115 = ((((((a2130183577 * a983758263) % 14999) % 14921) + -15078) + -2) - 0);
    	a786258498 = ((a4442917 + a263638061) - 7);
    	a1675035970 = (((((((a1675035970 * a217799639) % 14999) + -270) % 51) + 309) + 293) - 308);
    	a1478681170 = (a2061425267 - 6);
    	a1774184757 = ((((((a1774184757 * a983758263) % 14999) + -22) % 66) - -101) + 0);
    	a983758263 = ((((a983758263 * a813082108) + 3683) - -242) * 1);
    	a217799639 = ((((((a1151361287 * a1151361287) % 14999) - -11207) + -20580) % 28) + -29);
    	a76745981 = 34 ;
    	a2130183577 = ((((((a1151361287 * a30494462) % 14999) / 5) + 8720) % 12) + 237);
    	a1644957382 = 34 ;
    	a1916853335 = (a1959068056 + -2);
    	a1895304149 = 34 ;
    	a1254983042 = (((((((a1254983042 * a1151361287) % 14999) % 105) - -309) + -1) - -22707) + -22706);
    	a190525986 = ((a778006913 - a1241576728) + 15);
    	a2061425267 = (a1249952537 - -6); 
    	 printf("%d\n", 26); fflush(stdout); 
    } if(((((input == 14) &&  cf==1 ) && a2061425267 == 11) && (((a1211013485 == 33 && (((-198 < a217799639) && (-59 >= a217799639)) && a1916853335 == 6)) && a786258498 == 9) && a708839806 == 33))) {
    	cf = 0;
    	a999024345 = (((((a999024345 * a1985899004) % 14999) - -2614) - 4662) - 12945);
    	a2130193413 = ((a721272783 - a1830659124) + 7);
    	a2087535773 = (a1916853335 + -1);
    	a30494462 = (((((((a30494462 * a1985899004) % 14999) + 4610) - 4885) + 1840) % 14969) - 15030);
    	a217799639 = ((((((((a30494462 * a30494462) % 14999) - -4898) * -1) / 10) + 2294) * -7) / 10);
    	a260539918 = ((((((a999024345 * a30494462) % 14999) % 73) + 67) + 1) + -1);
    	a1241576728 = (a1830659124 - 3);
    	a1151361287 = (((((((a1151361287 * a620105235) % 14999) - 8975) * 10) / 9) - -27073) * -1);
    	a1675035970 = ((((((a1675035970 * a813082108) - -394) + -1001) * 1) % 51) + 257);
    	a1774184757 = ((((((a1774184757 * a2130183577) % 14999) % 14924) + -15074) - 2) * 1);
    	a708839806 = 32 ;
    	a786258498 = (a1916853335 + 2);
    	a709568404 = 34 ;
    	a1625516355 = ((((((a1625516355 * a217799639) % 14999) + -24182) * 1) * 10) / 9);
    	a1254983042 = ((((a1254983042 * a813082108) + -29782) * 1) + -44);
    	a4442917 = (a1210910088 - -3);
    	a1521644128 = (a1478681170 + 1);
    	a1211013485 = 32 ;
    	a302110279 = 32 ;
    	a63333937 = (((((a63333937 * a2130183577) % 14999) / 5) - 9933) + -9047);
    	a965340096 = 33 ;
    	a341216798 = ((((((a983758263 * a983758263) % 14999) % 14850) + 15148) * 1) * 1);
    	a1959068056 = ((a190525986 * a778006913) + -12);
    	a601495656 = 34 ;
    	a2026977784 = (a1916853335 - -1);
    	a1125477212 = 32 ;
    	a2130183577 = (((((a1985899004 * a30494462) % 14999) - 14950) / 5) - 1466);
    	a778006913 = (a1959068056 + -7);
    	a1895304149 = 32 ;
    	a2061425267 = (a1916853335 - -4);
    	a983758263 = (((((((a983758263 * a341216798) % 14999) - -8182) - 6455) - 13752) % 14997) + -15002);
    	a26346326 = 32 ;
    	a1478681170 = ((a2026977784 * a190525986) - 65);
    	a190525986 = ((a1959068056 * a1959068056) - 55);
    	a1916853335 = (a1959068056 - 3); 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm6(int input) {
    if((((((((-151 < a1774184757) && (35 >= a1774184757)) && ( cf==1  && a524719993 == 34)) && a2130193413 == 10) && ((48 < a999024345) && (131 >= a999024345))) && a4442917 == 6) && (((75 < a1151361287) && (249 >= a1151361287)) && ((-135 < a63333937) && (29 >= a63333937))))) {
    	if((((((48 < a999024345) && (131 >= a999024345)) && (a190525986 == 10 && (( cf==1  && a1354435613 == 34) && a1318526106 == 33))) && a76745981 == 33) && (a1916853335 == 6 && ((-44 < a260539918) && (-8 >= a260539918))))) {
    		calculate_outputm85(input);
    	} 
    	if(((((a1354435613 == 35 &&  cf==1 ) && ((-2 < a1254983042) && (202 >= a1254983042))) && a601495656 == 33) && (((-151 < a1774184757) && (35 >= a1774184757)) && (a1241576728 == 7 && (((-109 < a1625516355) && (-81 >= a1625516355)) && a2130193413 == 10))))) {
    		calculate_outputm86(input);
    	} 
    } 
}
 void calculate_outputm90(int input) {
    if(((((input == 7) &&  cf==1 ) && a302110279 == 33) && ((((a26346326 == 33 && a1644957382 == 33) && ((75 < a1151361287) && (249 >= a1151361287))) && a1318526106 == 33) && a1830659124 == 10))) {
    	cf = 0;
    	a302110279 = 34 ;
    	a786258498 = (a1249952537 - -5);
    	a1318526106 = 34 ;
    	a1210910088 = (a786258498 + -7);
    	a2026977784 = (a1916853335 - -2);
    	a260539918 = ((((((a260539918 * a999024345) % 73) - -124) - -4) + 21439) - 21495);
    	a1241576728 = (a2026977784 - 1);
    	a1774184757 = ((((((a1774184757 * a217799639) * 3) - -1865) * 1) % 66) - -103);
    	a1895304149 = 34 ;
    	a30494462 = (((((a30494462 * a813082108) * 2) % 85) + 209) + 0);
    	a263151501 = 34 ;
    	a1675035970 = ((((((a1675035970 * a1254983042) % 14999) % 51) - -254) + -10) + 12);
    	a2130183577 = ((((((a2130183577 * a1151361287) % 14999) % 12) + 237) * 1) - 5);
    	a1213722969 = (a778006913 + 9);
    	a190525986 = ((a2061425267 * a2087535773) + -49);
    	a1249952537 = (a1241576728 + -2);
    	a983758263 = (((((a983758263 * a1569588614) + 5465) % 14796) + 15202) * 1);
    	a153649526 = 36 ;
    	a1151361287 = ((((((a1985899004 * a1018383389) % 14999) + -15855) / 5) % 20) - -289);
    	a1830659124 = (a721272783 - 1);
    	a1644957382 = 34 ;
    	a1826277115 = (((((a1625516355 * a1985899004) % 14999) + -1235) - -25155) - 31401);
    	a1180594800 = 34 ;
    	a2130193413 = (a1210910088 + 8);
    	a1959068056 = ((a721272783 - a2061425267) + 10);
    	a1625516355 = ((((((a620105235 * a63333937) % 14999) + 13089) + 1056) % 37) - 42);
    	a26346326 = 34 ;
    	a778006913 = ((a1478681170 * a721272783) + -57);
    	a813082108 = (((((((a813082108 * a1985899004) % 14999) % 69) + 114) * 10) / 9) + -17);
    	a1985899004 = (((((((a1985899004 * a1254983042) % 14999) % 76) - -394) / 5) * 10) / 2); 
    	 printf("%d\n", 18); fflush(stdout); 
    } 
}
 void calculate_outputm91(int input) {
    if((((((75 < a1151361287) && (249 >= a1151361287)) && ( cf==1  && (input == 11))) && a1180594800 == 33) && (a2130193413 == 10 && ((((17 < a1018383389) && (167 >= a1018383389)) && a1644957382 == 33) && a709568404 == 33)))) {
    	a1054543477 += (a1054543477 + 20) > a1054543477 ? 4 : 0;
    	cf = 0;
    	a1254983042 = ((((((a1254983042 * a620105235) % 14999) * 2) % 14999) + -15000) - 0);
    	a2073482783 = 32 ;
    	a30494462 = ((((((a217799639 * a217799639) % 14999) + -28312) * 1) - -35431) + -32344);
    	a26346326 = 32 ;
    	a217799639 = (((((a217799639 * a30494462) % 14999) + -16296) / 5) * 5);
    	a1983740902 = 32 ;
    	a2130183577 = ((((a2130183577 * a260539918) + 29060) - 38809) + -5988);
    	a1521644128 = a190525986;
    	a1318526106 = 32 ;
    	a1180594800 = 32 ;
    	a1985899004 = (((((a1985899004 * a1625516355) % 14999) + -11099) * 1) / 5);
    	a1625516355 = ((((((a620105235 * a620105235) % 14999) % 13) + -98) + -8) - 2);
    	a709568404 = 32 ;
    	a341216798 = ((((((a1569588614 * a983758263) % 14999) % 14850) + 15148) * 1) * 1);
    	a263151501 = 32 ;
    	a708839806 = 32 ;
    	a1210910088 = (a1830659124 - 8);
    	a1895304149 = 32 ;
    	a999024345 = (((((a999024345 * a1774184757) % 14999) - 3244) - 1841) - 461);
    	a260539918 = ((((((a1569588614 * a1569588614) * -1) / 10) * 5) * 10) / 9);
    	a1675035970 = (((((a1675035970 * a813082108) % 14999) - 14978) - 13) / 5);
    	a1241576728 = ((a1521644128 - a190525986) - -6);
    	a190525986 = ((a1210910088 - a4442917) - -13);
    	a786258498 = ((a778006913 + a1959068056) - 2);
    	a2026977784 = (a2130193413 + -3);
    	a983758263 = ((((((a983758263 * a1018383389) % 14999) % 14997) + -15002) * 1) + -2);
    	a1249952537 = (a1574467713 + 3);
    	a1151361287 = ((((((a1151361287 * a1675035970) % 14999) / 5) + -15630) * 10) / 9);
    	a1959068056 = ((a721272783 * a721272783) - 136);
    	a1916853335 = (a1521644128 - 5);
    	a2087535773 = (a1249952537 + -1);
    	a1644957382 = 32 ;
    	a1018383389 = ((((((a620105235 * a63333937) % 14999) % 74) + 92) / 5) - 0);
    	a1478681170 = (a1210910088 - -2);
    	a1569588614 = (((((a1569588614 * a341216798) % 14999) - 21679) / 5) + -5423);
    	a2130193413 = (a721272783 - 2); 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((a1249952537 == 5 && a1180594800 == 33) && ((((( cf==1  && (input == 13)) && a708839806 == 33) && a2130193413 == 10) && a1318526106 == 33) && ((75 < a1151361287) && (249 >= a1151361287))))) {
    	cf = 0;
    	a601495656 = 32 ;
    	a63333937 = ((((((a1569588614 * a1569588614) + -28317) / 5) - -12617) * -1) / 10);
    	a1018383389 = ((((((a1018383389 * a1569588614) + 621) % 74) - -55) * 9) / 10);
    	a1756173294 = ((((((a1985899004 * a2130183577) % 14999) % 53) - -163) + 3) - -3);
    	a786258498 = (a721272783 - 4);
    	a1151361287 = (((((a1569588614 * a620105235) % 14999) - -6385) + -20677) * 1);
    	a1985899004 = ((((((a1151361287 * a1625516355) % 14999) - -4656) + 5532) / 5) - 15073);
    	a983758263 = ((((((a983758263 * a1569588614) % 14999) % 14997) + -15002) * 1) - 1);
    	a999024345 = (((((a999024345 * a1756173294) - 8460) * 1) / 5) + -6867);
    	a30494462 = (((((a30494462 * a1569588614) % 14969) - 15030) / 5) + -4561);
    	a1478681170 = (a1241576728 + -4);
    	a26346326 = 32 ;
    	a2130183577 = (((((a30494462 * a1625516355) % 14999) - 23524) * 1) / 5);
    	a1249952537 = ((a1574467713 * a2087535773) + 1);
    	a341216798 = ((((((a983758263 * a1254983042) % 14999) % 31) + 266) + 17006) - 17006);
    	a1959068056 = (a2087535773 - -5);
    	a190525986 = (a2026977784 - -2);
    	a260539918 = (((((a1756173294 * a1151361287) % 14999) - 13276) / 5) - 14488);
    	a1337636546 = (((((a341216798 * a1756173294) % 14999) - -4983) - -26) + 8970);
    	a1318526106 = 32 ;
    	a1625516355 = ((((((a1625516355 * a1151361287) % 14999) % 14945) + -15053) + 11857) + -11859);
    	a813082108 = ((((((a999024345 * a1985899004) % 14999) - 14995) / 5) - -10257) + -27795);
    	a2130193413 = ((a1249952537 * a1916853335) + -15);
    	a709568404 = 32 ;
    	a1254983042 = (((((a1756173294 * a1151361287) % 14999) - 15000) * 1) - 2);
    	a1180594800 = 32 ;
    	a1916853335 = (a2130193413 - 4);
    	a217799639 = ((((((a217799639 * a260539918) % 14999) + -16098) - -22533) * 1) - 23879);
    	a1675035970 = (((((a1675035970 * a1569588614) % 14999) - 18952) + 3105) / 5);
    	a263151501 = 32 ;
    	a1241576728 = (a4442917 + 1);
    	a1644957382 = 32 ;
    	a1895304149 = 32 ;
    	a1983740902 = 32 ;
    	a708839806 = 32 ;
    	a1210910088 = ((a2026977784 + a778006913) + -7); 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm93(int input) {
    if((((((a302110279 == 33 && a1644957382 == 33) && a263151501 == 33) && a1180594800 == 33) && a1983740902 == 33) && (a601495656 == 33 && ( cf==1  && (input == 2))))) {
    	cf = 0;
    	a341216798 = ((((a1569588614 * a1569588614) / -5) + -17224) + 3845);
    	a1241576728 = (a1249952537 + 1);
    	a1895304149 = 32 ;
    	a1213722969 = ((a1830659124 + a1959068056) + -8);
    	a30494462 = (((((a30494462 * a1675035970) + -10709) - -9756) / 5) + -16964);
    	a302110279 = 33 ;
    	a1180594800 = 32 ;
    	a1830659124 = (a778006913 + 7);
    	a834646264 = ((a2087535773 * a2130193413) + -34);
    	a983758263 = (((((((a983758263 * a1254983042) % 14999) * 2) - -2) * 1) % 14997) - 15002);
    	a999024345 = ((((a999024345 * a1675035970) / 5) - 5556) - 24073);
    	a1644957382 = 32 ;
    	a601495656 = 32 ;
    	a709568404 = 32 ;
    	a1625516355 = ((((((((a1625516355 * a30494462) % 14999) % 13) + -100) * 1) / 5) * 49) / 10);
    	a76745981 = 32 ;
    	a786258498 = ((a721272783 * a1478681170) + -40);
    	a1254983042 = (((((a813082108 * a2130183577) % 14999) - 15001) - 0) + -1);
    	a1959068056 = (a1210910088 + 6);
    	a260539918 = (((((a260539918 * a217799639) * 10) / -9) - 20254) - 119);
    	a778006913 = ((a4442917 - a1213722969) - -6);
    	a26346326 = 32 ;
    	a2087535773 = ((a1574467713 - a1249952537) + 5);
    	a1318526106 = 32 ;
    	a4442917 = (a190525986 - 5);
    	a1675035970 = (((((a30494462 * a30494462) % 14999) + -2021) + -14619) / 5);
    	a63333937 = ((((((a341216798 * a341216798) % 14999) % 14932) + -15066) * 1) - 1);
    	a1478681170 = ((a1916853335 / a1241576728) - -2);
    	a1151361287 = ((((((a1151361287 * a341216798) % 14999) + -5750) * 1) % 86) - -162);
    	a1210910088 = ((a190525986 + a786258498) + -17);
    	a263151501 = 32 ;
    	a1018383389 = ((((((a1675035970 * a260539918) % 14999) % 74) - -91) + -9797) + 9798); 
    	 printf("%d\n", 17); fflush(stdout); 
    } if(((a263151501 == 33 && (a1478681170 == 4 && ((171 < a1675035970) && (207 >= a1675035970)))) && (a1830659124 == 10 && ((((75 < a1151361287) && (249 >= a1151361287)) && ((input == 9) &&  cf==1 )) && a1241576728 == 7)))) {
    	cf = 0;
    	a1345687529 = ((((((a1569588614 * a1569588614) % 73) + 1) * 5) % 73) + -2);
    	a757937656 = (a4442917 - 3);
    	a721272783 = (a1249952537 + 9); 
    	 printf("%d\n", 19); fflush(stdout); 
    } 
}
 void calculate_outputm96(int input) {
    if(((a2130193413 == 10 && (((-151 < a1774184757) && (35 >= a1774184757)) && (((75 < a1151361287) && (249 >= a1151361287)) && (( cf==1  && (input == 5)) && a1249952537 == 5)))) && (a1241576728 == 7 && a76745981 == 33))) {
    	cf = 0;
    	a1983740902 = 34 ;
    	a620105235 = ((((((a1254983042 * a30494462) % 14999) % 14909) - 15090) - 1) - 1);
    	a1211013485 = 33 ;
    	a2130193413 = (a721272783 - 1);
    	a999024345 = (((((((a999024345 * a1254983042) % 14999) / 5) - 10532) - 9883) % 64) + 200);
    	a190525986 = ((a2130193413 * a2130193413) + -110);
    	a983758263 = ((((((a983758263 * a1569588614) % 14999) * 2) + -2) % 14796) + 15202);
    	a2140773614 = 35 ;
    	a1210910088 = (a2087535773 - 2);
    	a263219509 = (a1574467713 + 1);
    	a263151501 = 34 ;
    	a2130183577 = (((((((a2130183577 * a1151361287) % 14999) / 5) - 8776) + -16516) % 12) - -254);
    	a1151361287 = (((((((a1151361287 * a1774184757) % 14999) - -6786) - -1262) * 1) % 20) - -271);
    	a4442917 = ((a263219509 * a190525986) - 92);
    	a1180594800 = 34 ;
    	a1826277115 = (((((((((a983758263 * a1569588614) % 14999) % 105) + -154) * 9) / 10) * 5) % 105) + -7);
    	a1125477212 = 34 ;
    	a26346326 = 34 ;
    	a1774184757 = ((((((((a1774184757 * a1151361287) % 14999) / 5) % 92) + -56) * 5) % 92) - 57);
    	a302110279 = 34 ;
    	a1830659124 = ((a1249952537 / a1249952537) - -10);
    	a1895304149 = 34 ;
    	a2026977784 = (a1478681170 + 5);
    	a2073482783 = 34 ;
    	a217799639 = (((((((a217799639 * a1625516355) - 11832) % 28) - 28) * 5) % 28) - 13);
    	a601495656 = 34 ;
    	a76745981 = 34 ;
    	a786258498 = ((a2087535773 * a721272783) - 38);
    	a813082108 = ((((((a813082108 * a260539918) % 69) - -238) / 5) * 31) / 10);
    	a778006913 = (a1916853335 + -4);
    	a2087535773 = (a2061425267 + -7);
    	a1675035970 = ((((((a1675035970 * a1018383389) % 14999) + 760) + 7086) % 51) + 210);
    	a1625516355 = ((((((a30494462 * a30494462) % 37) + -43) / 5) + -18882) + 18833);
    	a1241576728 = (a1249952537 + 3);
    	a1959068056 = (a1249952537 + 5);
    	a1478681170 = (a1916853335 - 2);
    	a30494462 = ((((((a30494462 * a63333937) % 14999) % 85) - -210) * 5) / 5);
    	a260539918 = ((((((a260539918 * a1254983042) / 5) * 5) / 5) % 17) + -20);
    	a1249952537 = (a786258498 + -4); 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a302110279 == 33 && ((a2130193413 == 10 && ((75 < a1151361287) && (249 >= a1151361287))) && a1959068056 == 9)) && (a1210910088 == 2 && (((103 < a2130183577) && (230 >= a2130183577)) && ((input == 7) &&  cf==1 ))))) {
    	cf = 0;
    	a2087535773 = ((a1249952537 * a1249952537) - 20);
    	a263638061 = ((a721272783 / a1478681170) + 9);
    	a1983740902 = 34 ;
    	a1241576728 = ((a2087535773 + a786258498) + -6);
    	a813082108 = (((((a813082108 * a983758263) / 5) % 69) + 174) + -1);
    	a4442917 = (a1241576728 - 1);
    	a620105235 = ((((((a260539918 * a1675035970) * 3) % 10) - 166) - 24647) - -24650);
    	a1151361287 = ((((((((a1151361287 * a1985899004) % 14999) % 20) + 266) - 10) * 5) % 20) - -259);
    	a1895304149 = 34 ;
    	a26346326 = 34 ;
    	a983758263 = ((((((a983758263 * a1569588614) % 14999) * 2) % 101) + 304) - -1);
    	a1210910088 = (a778006913 + 1);
    	a260539918 = (((((a260539918 * a2130183577) / 5) * 5) % 73) + 131);
    	a2130193413 = a1830659124;
    	a1916853335 = ((a190525986 - a1249952537) + 1);
    	a601495656 = 34 ;
    	a76745981 = 34 ;
    	a1180594800 = 34 ;
    	a786258498 = ((a263638061 / a2061425267) + 9);
    	a302110279 = 34 ;
    	a1895857334 = (a1959068056 + 2);
    	a1574467713 = (a778006913 + -1);
    	a709568404 = 33 ;
    	a63333937 = ((((((a1625516355 * a30494462) / 5) - -9627) + 12041) % 81) - 122);
    	a1318526106 = 33 ;
    	a1478681170 = (a1241576728 - 3);
    	a263151501 = 34 ;
    	a1959068056 = (a2130193413 - 1);
    	a1018383389 = ((((((a1625516355 * a999024345) / 5) - -3074) * 5) % 74) - -40);
    	a1774184757 = ((((((a1774184757 * a1985899004) % 14999) % 66) + 103) + 1) + -1);
    	a1125477212 = 34 ;
    	a1675035970 = (((((a1675035970 * a30494462) % 51) - -259) / 5) + 245);
    	a778006913 = (a2087535773 + -3);
    	a999024345 = ((((((a999024345 * a1625516355) % 64) + 225) / 5) / 5) - -128);
    	a30494462 = (((((((a30494462 * a1254983042) % 14999) % 85) - -209) + 2) / 5) - -177); 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((((a1125477212 == 33 && ((input == 12) &&  cf==1 )) && a1983740902 == 33) && (((((75 < a1151361287) && (249 >= a1151361287)) && a2026977784 == 8) && a302110279 == 33) && a1241576728 == 7))) {
    	cf = 0;
    	a1249952537 = (a1959068056 + -3);
    	a1241576728 = (a1916853335 - -1);
    	a1774184757 = ((((((a1625516355 * a1625516355) / 5) % 66) + 55) + 13249) - 13238);
    	a1830659124 = (a778006913 - -9);
    	a2026977784 = ((a1249952537 * a1916853335) + -34);
    	a983758263 = ((((((a983758263 * a1569588614) % 14999) % 14796) + 15202) + 0) - -2);
    	a217799639 = ((((((((a217799639 * a1151361287) % 14999) % 28) - 29) * 5) * 5) % 28) - 6);
    	a263219509 = (a778006913 + 6);
    	a4442917 = (a1241576728 + -1);
    	a1675035970 = (((((a1675035970 * a1151361287) % 14999) + -19161) * 1) * 1);
    	a1895304149 = 34 ;
    	a260539918 = ((((((((a260539918 * a1985899004) % 73) + 106) * 9) / 10) * 5) % 73) + -1);
    	a1211013485 = 32 ;
    	a1625516355 = (((((a1625516355 * a1151361287) / 5) / 5) % 37) - 11);
    	a190525986 = (a721272783 - 1);
    	a263151501 = 34 ;
    	a2087535773 = ((a1574467713 / a1916853335) + 4);
    	a1125477212 = 34 ;
    	a813082108 = (((((a813082108 * a1774184757) % 69) - -108) - 2) * 1);
    	a1826277115 = (((((((a1569588614 * a983758263) % 14999) % 105) - 144) + 71) + 16218) + -16258);
    	a369798198 = 35 ;
    	a1210910088 = ((a1959068056 / a778006913) - 1);
    	a1959068056 = ((a778006913 - a263219509) + 16);
    	a620105235 = ((((((a1151361287 * a1625516355) / 5) - 4543) + 31428) * -1) / 10);
    	a30494462 = (((((a30494462 * a999024345) - 16887) * 1) + 16888) - 21041);
    	a1478681170 = ((a1916853335 / a1916853335) - -4);
    	a302110279 = 34 ;
    	a1018383389 = (((((((a1774184757 * a2130183577) % 14999) % 21) - -183) - 6876) - 12413) + 19281);
    	a76745981 = 32 ;
    	a778006913 = ((a1916853335 + a1574467713) + -12);
    	a1254983042 = (((((((a999024345 * a2130183577) % 14999) % 105) + 298) * 5) % 105) + 231);
    	a1983740902 = 32 ;
    	a26346326 = 34 ;
    	a786258498 = ((a1249952537 + a2130193413) - 6);
    	a999024345 = ((((((a999024345 * a2130183577) % 14999) - -6475) * 1) % 64) + 194);
    	a2130193413 = ((a1478681170 / a2087535773) + 10);
    	a2130183577 = ((((((a1151361287 * a1151361287) % 14999) - 20487) % 12) + 248) - 5);
    	a601495656 = 34 ;
    	a2061425267 = (a1916853335 + 3);
    	a1180594800 = 34 ;
    	a1151361287 = (((((((a1151361287 * a63333937) % 14999) - 18378) * 1) / 5) % 20) + 288); 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((a26346326 == 33 && (a601495656 == 33 && (((-62 < a30494462) && (124 >= a30494462)) && ((input == 15) &&  cf==1 )))) && ((a190525986 == 10 && a1959068056 == 9) && a263151501 == 33))) {
    	cf = 0;
    	a1211013485 = 32 ;
    	a2130183577 = (((((a2130183577 * a260539918) * 10) / 9) - 10140) - 4057);
    	a63333937 = (((((((a217799639 * a2130183577) % 14999) * 2) - 2) * 1) % 14932) + -15066);
    	a1151361287 = (((((a217799639 * a63333937) % 14999) + -13744) / 5) / 5);
    	a76745981 = 32 ;
    	a778006913 = (a1249952537 / a1249952537);
    	a709568404 = 32 ;
    	a2026977784 = (a2130193413 + -3);
    	a1774184757 = ((((((a1151361287 * a1675035970) % 14999) + -455) % 14924) + -15074) - 0);
    	a1241576728 = ((a1249952537 - a778006913) - -2);
    	a260539918 = ((((a260539918 * a1675035970) - 19757) + -1035) * 1);
    	a1180594800 = 32 ;
    	a30494462 = (((((((a30494462 * a1774184757) % 14999) * 2) % 14969) + -15030) + 15020) + -15021);
    	a601495656 = 32 ;
    	a4442917 = ((a1249952537 / a2026977784) + 5);
    	a2061425267 = ((a721272783 - a721272783) + 10);
    	a263151501 = 32 ;
    	a1254983042 = ((((((a620105235 * a217799639) % 14999) - 5249) + -15714) * 10) / 9);
    	a1830659124 = (a1249952537 + 4);
    	a999024345 = (((((a999024345 * a217799639) - 937) * 10) / 9) / 5);
    	a341216798 = ((((a813082108 * a1625516355) * 2) / 5) / 5);
    	a1985899004 = ((((((a999024345 * a1625516355) % 14999) + 7855) - -1554) % 76) + 448);
    	a1644957382 = 33 ;
    	a190525986 = ((a2061425267 - a1210910088) + 1);
    	a834646264 = (a2087535773 - -6);
    	a1959068056 = ((a1478681170 * a1574467713) - 22);
    	a1125477212 = 32 ;
    	a2073482783 = 33 ;
    	a1895304149 = 32 ;
    	a1318526106 = 32 ;
    	a803418896 = (((((((a1569588614 * a983758263) % 14999) % 89) + -84) * 5) % 89) + -84);
    	a1210910088 = (a1241576728 - 5);
    	a1675035970 = (((((((a2130183577 * a620105235) % 14999) + -2028) - -9569) / 5) % 17) - -190);
    	a1018383389 = (((((((a1625516355 * a1151361287) % 14999) % 74) - -93) - 1) - -22422) + -22421);
    	a1983740902 = 34 ;
    	a813082108 = ((((((a813082108 * a341216798) % 14999) + -14997) - 1) + 4526) + -4528);
    	a26346326 = 32 ;
    	a1916853335 = (a721272783 - 7);
    	a302110279 = 34 ;
    	a2130193413 = ((a1916853335 / a2026977784) + 9);
    	a983758263 = (((((((a983758263 * a803418896) % 14999) % 14997) - 15002) + -1) / 5) + -16477);
    	a786258498 = (a1916853335 - -3);
    	a1478681170 = (a721272783 + -9);
    	a1625516355 = (((((((a1625516355 * a30494462) % 14999) / 5) % 13) + -106) + -12906) + 12908);
    	a2087535773 = (a1830659124 - 6);
    	a217799639 = ((((((((a217799639 * a620105235) % 14999) % 28) + -35) + -9808) * 3) % 28) - 17);
    	a1249952537 = (a786258498 + -2); 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm97(int input) {
    if((((((75 < a1151361287) && (249 >= a1151361287)) && a709568404 == 33) && a1180594800 == 33) && (((48 < a999024345) && (131 >= a999024345)) && (a76745981 == 33 && (a2061425267 == 11 && ((input == 12) &&  cf==1 )))))) {
    	a990043066 -= (a990043066 - 20) < a990043066 ? 4 : 0;
    	a789762657 += (a789762657 + 20) > a789762657 ? 1 : 0;
    	cf = 0;
    	a1254983042 = ((((((a1254983042 * a217799639) * 2) % 105) + 308) / 5) + 191);
    	a1675035970 = (((((((a1675035970 * a1774184757) % 14999) % 51) + 258) * 1) + -25482) - -25483);
    	a2130193413 = (a2087535773 + 6);
    	a30494462 = ((((((((a30494462 * a1569588614) % 14999) % 85) - -209) - 0) / 5) * 51) / 10);
    	a1241576728 = (a1959068056 + -1);
    	a76745981 = 34 ;
    	a983758263 = ((((((a983758263 * a999024345) % 101) + 304) - -2) - 19741) + 19740);
    	a1018383389 = (((((a1018383389 * a260539918) - -22415) % 21) - -175) * 1);
    	a1774184757 = (((((a1774184757 * a217799639) - 8884) % 66) - -133) - 4);
    	a813082108 = ((((((a813082108 * a1151361287) + 274) % 69) - -131) + -26984) + 27013);
    	a709568404 = 32 ;
    	a369798198 = 33 ;
    	a2061425267 = ((a2130193413 + a721272783) + -11);
    	a26346326 = 34 ;
    	a362219248 = ((((((((a1569588614 * a983758263) % 14999) % 34) + 213) - 1) * 5) % 34) - -232);
    	a1895304149 = 34 ;
    	a786258498 = ((a190525986 / a2130193413) + 10);
    	a260539918 = (((((a217799639 * a1625516355) % 73) - 4) + -26401) + 26472);
    	a1959068056 = (a2087535773 - -5);
    	a1625516355 = ((((((a1625516355 * a217799639) + 2346) - 15175) / 5) % 37) + -18);
    	a1478681170 = (a2130193413 - 6);
    	a1180594800 = 34 ;
    	a263151501 = 34 ;
    	a1830659124 = (a1249952537 - -6);
    	a190525986 = (a2087535773 + 6);
    	a1151361287 = ((((((a217799639 * a217799639) + 2571) - 679) * 5) % 20) - -267);
    	a1210910088 = (a4442917 - 4);
    	a1895857334 = ((a1916853335 / a1249952537) + 7);
    	a1916853335 = (a2130193413 - 4);
    	a999024345 = (((((((a999024345 * a2130183577) % 14999) / 5) % 64) - -157) - 24244) + 24228);
    	a1249952537 = ((a2026977784 / a2087535773) - -5); 
    	 printf("%d\n", 18); fflush(stdout); 
    } if(((a76745981 == 33 && ((-151 < a1774184757) && (35 >= a1774184757))) && (a190525986 == 10 && ((((-62 < a30494462) && (124 >= a30494462)) && (((input == 13) &&  cf==1 ) && a1478681170 == 4)) && a1830659124 == 10)))) {
    	cf = 0;
    	a30494462 = ((((((a30494462 * a260539918) / 5) - 3912) / 5) % 85) - -232);
    	a1352986605 = (((((a1569588614 * a1254983042) % 14999) / 5) - -24845) + 2077);
    	a1348848030 = ((a2130193413 / a1210910088) + 4);
    	a1249952537 = ((a190525986 / a190525986) + 5);
    	a1895304149 = 34 ;
    	a76745981 = 34 ;
    	a1151361287 = ((((((a1151361287 * a1675035970) % 14999) % 20) - -259) + 16184) + -16184);
    	a786258498 = (a1241576728 - -3);
    	a1830659124 = (a190525986 - -1);
    	a2061425267 = (a1241576728 - -5);
    	a260539918 = ((((((a260539918 * a813082108) % 73) - -114) + 12566) * 2) + -25222);
    	a1959068056 = ((a2026977784 - a2026977784) - -10);
    	a1895857334 = (a721272783 - 6);
    	a1254983042 = (((((((a1774184757 * a1675035970) % 14999) - 3861) % 105) + 308) - 9611) - -9610);
    	a1180594800 = 34 ;
    	a983758263 = ((((((((a983758263 * a1675035970) % 14999) % 101) - -305) + -1) * 5) % 101) + 244);
    	a999024345 = (((((a999024345 * a1774184757) * 1) % 64) - -196) - -1);
    	a1675035970 = (((((((a1675035970 * a1352986605) % 14999) % 51) + 248) - 10867) - 7002) - -17863); 
    	 printf("%d\n", 16); fflush(stdout); 
    } 
}
 void calculate_outputm99(int input) {
    if(((a601495656 == 33 && ( cf==1  && (input == 6))) && ((a1241576728 == 7 && (((174 < a1985899004) && (371 >= a1985899004)) && (((171 < a1675035970) && (207 >= a1675035970)) && ((-109 < a1625516355) && (-81 >= a1625516355))))) && a1983740902 == 33))) {
    	cf = 0;
    	a1018383389 = (((((a1625516355 * a217799639) % 21) - -183) - -3) - -1);
    	a1180594800 = 34 ;
    	a1151361287 = ((((a813082108 * a1675035970) + -29929) + -425) + -266);
    	a1985899004 = (((((((a1985899004 * a620105235) % 14999) + -11173) - -21633) + -18849) % 76) - -509);
    	a1210910088 = (a2130193413 - 7);
    	a1895857334 = (a1916853335 + 5);
    	a1895304149 = 34 ;
    	a999024345 = ((((((a999024345 * a217799639) * 1) / 5) - 12564) % 64) + 196);
    	a601495656 = 34 ;
    	a778006913 = (a2087535773 + -3);
    	a4442917 = (a2026977784 - 1);
    	a709568404 = 32 ;
    	a302110279 = 32 ;
    	a983758263 = ((((((a983758263 * a260539918) % 101) - -305) - 1) / 5) + 264);
    	a1625516355 = (((((a1018383389 * a1018383389) % 14999) - 24723) / 5) + -14496);
    	a190525986 = (a721272783 + -1);
    	a1249952537 = (a1241576728 - 1);
    	a708839806 = 32 ;
    	a1574467713 = ((a2087535773 / a1895857334) - -3);
    	a1125477212 = 32 ;
    	a2130183577 = ((((((a1018383389 * a1985899004) % 14999) / 5) % 12) - -234) - -4);
    	a1916853335 = ((a1210910088 - a2130193413) - -12);
    	a620105235 = ((((((a1018383389 * a1018383389) % 14999) - -1388) + 12383) + -18360) - 22842);
    	a2061425267 = (a1241576728 - -5);
    	a786258498 = a2130193413;
    	a2026977784 = (a2087535773 - -3);
    	a1254983042 = ((((((a217799639 * a999024345) % 14999) % 105) + 309) - -1) - 1);
    	a813082108 = (((((a1018383389 * a1018383389) % 14999) - 15431) + -3730) - 9002);
    	a1675035970 = (((((a1018383389 * a1018383389) % 14999) + -14842) - 6076) + -2154);
    	a263151501 = 34 ;
    	a76745981 = 34 ;
    	a1830659124 = ((a4442917 / a190525986) + 11);
    	a1959068056 = a2130193413;
    	a2073482783 = 32 ;
    	a1474668405 = ((((((a983758263 * a1569588614) % 14999) - 166) / 5) % 46) - -40);
    	a1318526106 = 32 ;
    	a1774184757 = (((((a1018383389 * a260539918) * 3) - -20818) + -1346) + -16839);
    	a63333937 = (((((a1018383389 * a2130183577) % 14999) / 5) - 8344) + -8790);
    	a30494462 = ((((((a30494462 * a2130183577) % 14999) / 5) * 5) % 85) - -211);
    	a217799639 = (((((a217799639 * a1018383389) % 14999) - 9922) * 1) * 1);
    	a26346326 = 32 ;
    	a2130193413 = ((a190525986 * a1574467713) - 24);
    	a260539918 = (((((a1018383389 * a1018383389) % 14999) + -17931) + -2427) / 5);
    	a2087535773 = ((a1249952537 + a1241576728) + -8);
    	a1211013485 = 32 ;
    	a1983740902 = 34 ;
    	a1241576728 = (a1478681170 + 2);
    	a1478681170 = 5; 
    	 printf("%d\n", 16); fflush(stdout); 
    } if(((a1249952537 == 5 && (a2073482783 == 33 && ((((-182 < a620105235) && (-160 >= a620105235)) && (a1916853335 == 6 && ( cf==1  && (input == 11)))) && a190525986 == 10))) && ((-198 < a217799639) && (-59 >= a217799639)))) {
    	cf = 0;
    	a2087632595 = 35 ;
    	a1254983042 = ((((((a620105235 * a620105235) % 14999) - 11106) * 2) % 105) - -308);
    	a302110279 = 34 ;
    	a1151361287 = ((((((a1985899004 * a620105235) % 14999) % 20) - -270) - -6329) + -6327);
    	a813082108 = (((((((a813082108 * a1151361287) % 14999) % 69) - -147) * 9) / 10) + 41);
    	a983758263 = ((((((a983758263 * a1675035970) % 14999) % 101) + 304) / 5) - -318);
    	a217799639 = (((((a217799639 * a999024345) % 28) + -14) - -27602) - 27607);
    	a2073482783 = 34 ;
    	a786258498 = ((a2130193413 + a1249952537) - 5);
    	a1478681170 = 5;
    	a2061425267 = ((a1959068056 - a190525986) - -13);
    	a1774184757 = ((((((a1254983042 * a1569588614) % 14999) + -13069) % 66) + 103) + -1);
    	a4442917 = 7;
    	a1180594800 = 34 ;
    	a1318526106 = 32 ;
    	a30494462 = ((((((a30494462 * a260539918) / 5) % 85) - -210) / 5) - -235);
    	a999024345 = ((((((a1985899004 * a1774184757) % 14999) + -9092) % 64) - -196) - 1);
    	a709568404 = 34 ;
    	a26346326 = 34 ;
    	a263151501 = 34 ;
    	a1830659124 = (a1478681170 + 6);
    	a2026977784 = 9;
    	a601495656 = 34 ;
    	a1895304149 = 34 ;
    	a1895857334 = (a721272783 + 1);
    	a778006913 = (a4442917 - 4);
    	a63333937 = ((((((a30494462 * a983758263) % 14999) + -14271) % 106) + 135) * 1);
    	a190525986 = ((a1241576728 / a2061425267) + 11);
    	a1875686186 = ((a1241576728 - a721272783) + 18);
    	a1916853335 = ((a2026977784 / a2087535773) - -5);
    	a1249952537 = (a2087535773 - -2);
    	a708839806 = 34 ;
    	a1125477212 = 34 ;
    	a1211013485 = 34 ;
    	a2130183577 = (((((((a217799639 * a217799639) % 12) + 243) - 9) * 5) % 12) + 241);
    	a1983740902 = 34 ;
    	a1959068056 = a2130193413;
    	a1241576728 = (a2061425267 + -4);
    	a1210910088 = a778006913;
    	a2130193413 = (a778006913 + 8);
    	a2087535773 = ((a786258498 * a2026977784) - 85);
    	a76745981 = 34 ;
    	a620105235 = ((((((((a620105235 * a2130183577) % 14999) - 1964) % 94) + 12) * 5) % 94) + -64);
    	a1675035970 = (((((((a1675035970 * a260539918) % 51) - -303) * 9) / 10) / 5) + 256);
    	a1018383389 = (((((a983758263 * a217799639) / 5) % 21) + 198) - 6);
    	a1985899004 = ((((((((a1985899004 * a1625516355) % 14999) + -1483) % 76) - -509) * 5) % 76) + 446);
    	a1625516355 = (((((((a1625516355 * a983758263) % 14999) % 37) - 41) + -19870) - 8204) - -28071);
    	a260539918 = ((((((a260539918 * a1254983042) % 73) - -78) / 5) * 9) / 10); 
    	 printf("%d\n", 18); fflush(stdout); 
    } if(((a1830659124 == 10 && (((a2130193413 == 10 && a709568404 == 33) && ((48 < a999024345) && (131 >= a999024345))) && a778006913 == 2)) && (((3 < a813082108) && (104 >= a813082108)) && ((input == 12) &&  cf==1 )))) {
    	cf = 0;
    	a2026977784 = (a190525986 - 3);
    	a1318526106 = 32 ;
    	a263151501 = 32 ;
    	a369798198 = 34 ;
    	a30494462 = ((((((a30494462 * a1018383389) % 14999) - 13720) * 1) % 14969) + -15030);
    	a709568404 = 32 ;
    	a786258498 = (a1830659124 - 2);
    	a1180594800 = 32 ;
    	a620105235 = (((((a217799639 * a1569588614) % 14999) - 14526) - -24772) + -21158);
    	a1249952537 = ((a778006913 + a2026977784) + -5);
    	a601495656 = 32 ;
    	a2061425267 = (a1249952537 + 6);
    	a217799639 = ((((((a217799639 * a1018383389) % 14999) - -7320) % 14901) - 15098) - 2);
    	a2073482783 = 33 ;
    	a302110279 = 32 ;
    	a983758263 = ((((((a983758263 * a1569588614) % 14999) + 8092) * 1) % 14997) - 15002);
    	a341216798 = (((((((a983758263 * a999024345) % 14999) - 4030) - -10683) * 3) % 14850) + 15148);
    	a1125477212 = 34 ;
    	a778006913 = ((a1210910088 - a721272783) - -11);
    	a1625516355 = ((((((a1625516355 * a1018383389) % 14999) % 14945) + -15053) - 3) + 0);
    	a1983740902 = 32 ;
    	a1895304149 = 32 ;
    	a813082108 = (((((a813082108 * a1151361287) % 14999) / 5) + -19588) - 6001);
    	a1675035970 = (((((a1675035970 * a620105235) % 14999) + -721) * 1) / 5);
    	a1644957382 = 33 ;
    	a1521644128 = ((a2087535773 * a721272783) + -45);
    	a63333937 = (((((((a1985899004 * a1018383389) % 14999) - 12699) + -1462) - -13618) % 81) + -51);
    	a1830659124 = (a778006913 - -10);
    	a2087535773 = (a1478681170 + -1);
    	a1210910088 = (a721272783 + -10);
    	a2130193413 = ((a786258498 / a786258498) + 8);
    	a999024345 = ((((((a1569588614 * a1254983042) % 14999) + -5117) / 5) * 10) / 9);
    	a1241576728 = ((a1478681170 * a1916853335) - 18);
    	a190525986 = (a1521644128 + a786258498);
    	a1959068056 = (a1249952537 - -4);
    	a1916853335 = (a778006913 * a2026977784);
    	a26346326 = 32 ;
    	a1985899004 = ((((a260539918 * a260539918) + 27794) * -1) + -293);
    	a1478681170 = (a4442917 + -1);
    	a260539918 = (((((a260539918 * a341216798) % 14999) + -7659) - 3042) + 1221); 
    	 printf("%d\n", 19); fflush(stdout); 
    } if(((a302110279 == 33 && (((a2026977784 == 8 && ((input == 14) &&  cf==1 )) && a263151501 == 33) && ((-62 < a30494462) && (124 >= a30494462)))) && (a1249952537 == 5 && a1478681170 == 4))) {
    	cf = 0;
    	a1210910088 = ((a1830659124 / a190525986) - -2);
    	a2130183577 = ((((a217799639 * a1625516355) * 1) + -26628) * 1);
    	a1018383389 = (((((((a30494462 * a63333937) % 14999) * 2) + 3) * 1) % 21) - -188);
    	a778006913 = ((a1478681170 * a1916853335) + -21);
    	a1318526106 = 34 ;
    	a1211013485 = 32 ;
    	a153649526 = 32 ;
    	a2130193413 = ((a778006913 * a1241576728) + -10);
    	a2073482783 = 34 ;
    	a786258498 = (a2087535773 - -6);
    	a1151361287 = ((((((a30494462 * a1018383389) + 3285) + -18182) + -315) % 20) + 270);
    	a1985899004 = (((((a1985899004 * a260539918) + 6232) / 5) % 76) + 448);
    	a4442917 = (a1210910088 + 4);
    	a1895304149 = 32 ;
    	a999024345 = ((((((a999024345 * a1151361287) % 14999) / 5) + 12469) % 64) - -148);
    	a2026977784 = ((a1249952537 + a190525986) - 6);
    	a1241576728 = (a721272783 + -4);
    	a1180594800 = 34 ;
    	a302110279 = 34 ;
    	a813082108 = (((((a813082108 * a30494462) * 2) / 5) / 5) + -6580);
    	a983758263 = (((((((a983758263 * a1569588614) % 14999) % 14796) - -15202) + 1) + -22410) - -22410);
    	a2061425267 = ((a1478681170 - a2130193413) + 19);
    	a1249952537 = (a1478681170 - -2);
    	a620105235 = (((((a620105235 * a1018383389) % 14999) + -1487) * 1) * 1);
    	a1254983042 = (((((a1985899004 * a1018383389) % 14999) - 26262) / 5) + -34);
    	a1625516355 = ((((((((a30494462 * a63333937) % 14999) % 13) - 94) * 5) - -13463) % 13) + -100);
    	a260539918 = (((((((a260539918 * a30494462) % 73) + 65) * 5) + -24275) % 73) + 66);
    	a76745981 = 32 ;
    	a709568404 = 32 ;
    	a708839806 = 34 ;
    	a601495656 = 34 ;
    	a1830659124 = (a2087535773 + 7);
    	a2087535773 = (a1249952537 + -3);
    	a1675035970 = (((((a1675035970 * a983758263) % 14999) - 29188) * 1) - 122);
    	a1983740902 = 34 ;
    	a1959068056 = (a4442917 + 1);
    	a1774184757 = ((((((a1569588614 * a999024345) % 14999) - 14042) - -20969) % 66) + 41);
    	a1916853335 = a4442917;
    	a1478681170 = a1210910088;
    	a190525986 = ((a1210910088 - a1210910088) + 11);
    	a263151501 = 34 ;
    	a26346326 = 32 ;
    	a30494462 = ((((((a30494462 * a63333937) % 14999) % 14969) + -15030) - 2) + 0);
    	a524719993 = 33 ;
    	a1826277115 = ((((((a983758263 * a983758263) % 14999) + 14415) * 1) / 5) + -32317); 
    	 printf("%d\n", 19); fflush(stdout); 
    } 
}
 void calculate_outputm7(int input) {
    if((((((-151 < a1774184757) && (35 >= a1774184757)) && (((((-89 < a1569588614) && (73 >= a1569588614)) &&  cf==1 ) && a2026977784 == 8) && a1241576728 == 7)) && a26346326 == 33) && (a1249952537 == 5 && a1644957382 == 33))) {
    	if((((a1180594800 == 33 && (((103 < a2130183577) && (230 >= a2130183577)) && ((-109 < a1625516355) && (-81 >= a1625516355)))) && ((3 < a813082108) && (104 >= a813082108))) && (a1959068056 == 9 && ((a1111616318 == 36 &&  cf==1 ) && a190525986 == 10)))) {
    		calculate_outputm90(input);
    	} 
    } 
    if(((((48 < a999024345) && (131 >= a999024345)) && (((-62 < a30494462) && (124 >= a30494462)) && ((-198 < a217799639) && (-59 >= a217799639)))) && ((a1959068056 == 9 && (( cf==1  && ((73 < a1569588614) && (167 >= a1569588614))) && a1249952537 == 5)) && a190525986 == 10))) {
    	if(((((((103 < a2130183577) && (230 >= a2130183577)) && a1916853335 == 6) && a1241576728 == 7) && a1959068056 == 9) && (a1983740902 == 33 && (( cf==1  && a1574467713 == 1) && a2130193413 == 10)))) {
    		calculate_outputm91(input);
    	} 
    	if((((a778006913 == 2 && ((a1318526106 == 33 && a1830659124 == 10) && a1916853335 == 6)) && a2130193413 == 10) && (a1249952537 == 5 && ( cf==1  && a1574467713 == 3)))) {
    		calculate_outputm93(input);
    	} 
    	if((((a1210910088 == 2 && (a2026977784 == 8 && a4442917 == 6)) && a1983740902 == 33) && (((3 < a813082108) && (104 >= a813082108)) && (((171 < a1675035970) && (207 >= a1675035970)) && (a1574467713 == 8 &&  cf==1 ))))) {
    		calculate_outputm96(input);
    	} 
    } 
    if(((a709568404 == 33 && ( cf==1  && 167 < a1569588614)) && ((a1241576728 == 7 && (a1830659124 == 10 && (((3 < a813082108) && (104 >= a813082108)) && a1210910088 == 2))) && a1959068056 == 9))) {
    	if((((( cf==1  && a1597554373 == 32) && ((17 < a1018383389) && (167 >= a1018383389))) && a1830659124 == 10) && (a76745981 == 33 && (((-151 < a1774184757) && (35 >= a1774184757)) && (a1180594800 == 33 && ((171 < a1675035970) && (207 >= a1675035970))))))) {
    		calculate_outputm97(input);
    	} 
    	if((((a2130193413 == 10 && (a1830659124 == 10 && ( cf==1  && a1597554373 == 36))) && a2061425267 == 11) && ((a1318526106 == 33 && a190525986 == 10) && a1895304149 == 33))) {
    		calculate_outputm99(input);
    	} 
    } 
}
 void calculate_outputm100(int input) {
    if((((( cf==1  && (input == 2)) && a708839806 == 33) && a1830659124 == 10) && ((a1211013485 == 33 && (a26346326 == 33 && ((48 < a999024345) && (131 >= a999024345)))) && ((75 < a1151361287) && (249 >= a1151361287))))) {
    	cf = 0;
    	a778006913 = (a2130193413 + -7);
    	a404763935 = ((a1830659124 - a190525986) + 14);
    	a1151361287 = ((((((a260539918 * a63333937) % 20) - -270) + -1) + -3318) + 3320);
    	a1826277115 = ((((((a1947180632 * a983758263) % 14999) - -393) % 14910) - -15088) - -2);
    	a2087535773 = ((a778006913 - a1478681170) + 6);
    	a1180594800 = 34 ;
    	a1959068056 = ((a778006913 + a721272783) + -6);
    	a2130193413 = (a2087535773 + 6);
    	a1125477212 = 34 ;
    	a2026977784 = (a778006913 - -6);
    	a1478681170 = (a404763935 + -9);
    	a1318526106 = 34 ;
    	a1985899004 = (((((((a1985899004 * a63333937) % 14999) / 5) - 10728) * 2) % 76) - -460);
    	a813082108 = ((((((((a813082108 * a1151361287) % 14999) % 69) + 149) + 8) * 5) % 69) - -164);
    	a601495656 = 34 ;
    	a2073482783 = 34 ;
    	a983758263 = ((((((a983758263 * a1826277115) % 14999) % 14796) - -15202) + 2) + 0);
    	a1241576728 = (a1249952537 + 3);
    	a999024345 = ((((((a999024345 * a620105235) % 64) + 195) - -9) + -12426) - -12435);
    	a190525986 = ((a4442917 + a1210910088) + 3);
    	a708839806 = 34 ;
    	a1830659124 = (a2087535773 + 6);
    	a1211013485 = 34 ;
    	a786258498 = (a2026977784 + 1);
    	a2130183577 = (((((a2130183577 * a1625516355) + 15129) * 3) % 12) + 243);
    	a620105235 = ((((((a983758263 * a983758263) % 14999) + 5868) / 5) % 94) - 123);
    	a1916853335 = (a2026977784 - 2);
    	a1249952537 = ((a778006913 * a721272783) - 33);
    	a1625516355 = (((((((a1625516355 * a1254983042) % 14999) + 28532) % 37) - 48) - -4921) + -4918);
    	a1210910088 = ((a404763935 / a2087535773) - -1);
    	a2061425267 = ((a4442917 - a778006913) - -9);
    	a4442917 = ((a2026977784 + a2026977784) - 11);
    	a1675035970 = ((((((a1675035970 * a30494462) / 5) * 5) * 1) % 51) + 258);
    	a26346326 = 34 ;
    	a63333937 = (((((((a63333937 * a1151361287) % 14999) % 106) + 135) - -12749) / 5) - 2496);
    	a709568404 = 34 ;
    	a302110279 = 34 ;
    	a548050643 = 35 ;
    	a30494462 = (((((a30494462 * a217799639) % 85) - -211) * 5) / 5);
    	a1895304149 = 34 ;
    	a1644957382 = 34 ;
    	a217799639 = (((((((a217799639 * a1151361287) % 14999) % 28) + -30) * 5) % 28) + -15); 
    	 printf("%d\n", 16); fflush(stdout); 
    } if(((a1125477212 == 33 && (( cf==1  && (input == 8)) && a2087535773 == 4)) && (a302110279 == 33 && ((((-135 < a63333937) && (29 >= a63333937)) && a2026977784 == 8) && a1644957382 == 33)))) {
    	cf = 0;
    	a1983740902 = 34 ;
    	a263151501 = 34 ;
    	a1254983042 = ((((((a1675035970 * a2130183577) % 14999) + -19198) % 105) - -401) - -7);
    	a260539918 = (((((((a983758263 * a1151361287) % 14999) * 2) + -3) - 0) % 73) + 66); 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((-182 < a620105235) && (-160 >= a620105235)) && (a1478681170 == 4 && (a2087535773 == 4 && ((a2130193413 == 10 && (((input == 5) &&  cf==1 ) && a1916853335 == 6)) && a601495656 == 33))))) {
    	cf = 0;
    	a1895304149 = 32 ;
    	a1180594800 = 32 ;
    	a63333937 = ((((((a1985899004 * a1774184757) % 14999) + 14235) - 23262) - -26953) - 21490);
    	a1211013485 = 32 ;
    	a341216798 = (((((a1675035970 * a1625516355) * -1) / 10) + 18033) / 5);
    	a983758263 = ((((((a983758263 * a341216798) % 14999) + -542) * 1) % 14997) - 15002);
    	a1151361287 = (((((a63333937 * a999024345) % 14999) + -9588) * 1) + -4757);
    	a4442917 = (a1210910088 + 3);
    	a620105235 = ((((((a620105235 * a30494462) % 14909) - 15090) - -1548) + 23526) + -25074);
    	a2130183577 = ((((((a2130183577 * a1151361287) % 14999) + -950) - 3853) + 5387) - 15498);
    	a2130193413 = (a2026977784 + 1);
    	a1521644128 = a1249952537;
    	a2087535773 = ((a778006913 / a721272783) + 3);
    	a1125477212 = 32 ;
    	a26346326 = 32 ;
    	a76745981 = 32 ;
    	a965340096 = 36 ;
    	a1916853335 = (a2087535773 + 2);
    	a302110279 = 32 ;
    	a708839806 = 32 ;
    	a601495656 = 32 ;
    	a30494462 = ((((((a30494462 * a1985899004) % 14999) % 14969) - 15030) / 5) + -197); 
    	 printf("%d\n", 20); fflush(stdout); 
    } 
}
 void calculate_outputm101(int input) {
    if(((((17 < a1018383389) && (167 >= a1018383389)) && (((a2073482783 == 33 && ( cf==1  && (input == 6))) && a76745981 == 33) && ((-44 < a260539918) && (-8 >= a260539918)))) && (a1318526106 == 33 && ((171 < a1675035970) && (207 >= a1675035970))))) {
    	cf = 0;
    	a721272783 = ((a190525986 - a1210910088) - -2);
    	a2073482783 = 33 ;
    	a601495656 = 34 ;
    	a4442917 = (a721272783 + -4);
    	a76745981 = 34 ;
    	a1985899004 = ((((((a1985899004 * a1254983042) % 14999) + 8556) % 76) - -447) * 1);
    	a302110279 = 33 ;
    	a1348848030 = (a1210910088 - -13);
    	a708839806 = 34 ;
    	a1916853335 = ((a778006913 * a2087535773) - 1);
    	a803418896 = (((((((a983758263 * a983758263) % 14999) + -3728) % 89) + -84) - 13535) - -13535); 
    	 printf("%d\n", 16); fflush(stdout); 
    } 
}
 void calculate_outputm102(int input) {
    if(((((-2 < a1254983042) && (202 >= a1254983042)) && (a1318526106 == 33 && (((48 < a999024345) && (131 >= a999024345)) && ((-182 < a620105235) && (-160 >= a620105235))))) && (a1895304149 == 33 && (a1959068056 == 9 && ( cf==1  && (input == 15)))))) {
    	cf = 0;
    	a76745981 = 34 ;
    	a721272783 = ((a4442917 + a2130193413) - 4);
    	a1569588614 = (((((a1625516355 * a2130183577) % 80) - -55) - 25) - -30);
    	a620105235 = (((((((a620105235 * a1675035970) % 14999) - 2551) - -13977) / 5) % 94) - 65);
    	a1111616318 = 36 ;
    	a708839806 = 34 ;
    	a1254983042 = (((((((a1254983042 * a1569588614) % 105) - -309) * 5) * 5) % 105) + 305);
    	a4442917 = ((a190525986 - a1210910088) - 1);
    	a1916853335 = ((a786258498 - a1241576728) + 5);
    	a999024345 = ((((((((a999024345 * a1151361287) % 14999) - 17772) % 64) - -254) * 5) % 64) + 196); 
    	 printf("%d\n", 17); fflush(stdout); 
    } 
}
 void calculate_outputm105(int input) {
    if(((((3 < a813082108) && (104 >= a813082108)) && ((a601495656 == 33 && a1125477212 == 33) && ((-198 < a217799639) && (-59 >= a217799639)))) && ((((input == 4) &&  cf==1 ) && a1318526106 == 33) && ((-182 < a620105235) && (-160 >= a620105235))))) {
    	cf = 0;
    	a1180594800 = 32 ;
    	a1318526106 = 32 ;
    	a983758263 = ((((a983758263 - 11158) / 5) - -29522) - 37955);
    	a63333937 = ((((((a63333937 * a983758263) % 14999) % 14932) - 15066) + 25740) + -25740);
    	a813082108 = (((((a1254983042 * a1254983042) % 14999) / 5) - 26032) - 309);
    	a1211013485 = 32 ;
    	a601495656 = 32 ;
    	a1213722969 = (a778006913 - -9);
    	a620105235 = (((((a620105235 * a260539918) % 14999) - 25580) / 5) + -10014);
    	a1675035970 = (((((a1675035970 * a813082108) % 14999) - 9056) - 5783) - 162);
    	a834646264 = ((a721272783 - a1210910088) + -5);
    	a1254983042 = ((((((a983758263 * a2130183577) % 14999) / 5) - 12281) * 10) / 9);
    	a786258498 = (a1241576728 + 2);
    	a778006913 = (a1959068056 + -7);
    	a341216798 = (((((a983758263 * a983758263) % 14999) - 28824) * 1) + -847);
    	a302110279 = 33 ;
    	a1895304149 = 32 ;
    	a30494462 = ((((a30494462 * a217799639) + -633) / 5) - 6286);
    	a1018383389 = (((((((a620105235 * a1675035970) % 14999) + -6900) * 1) * 1) % 74) + 91);
    	a26346326 = 32 ;
    	a4442917 = ((a1830659124 / a2061425267) - -5);
    	a1151361287 = ((((((a1625516355 * a999024345) % 14999) / 5) / 5) % 86) - -162);
    	a1210910088 = ((a1916853335 - a1478681170) - 1);
    	a1830659124 = ((a2061425267 / a1213722969) - -8);
    	a1478681170 = (a1213722969 - 8);
    	a2130183577 = (((((a2130183577 * a1625516355) - -2543) * 10) / 9) + -2179);
    	a1625516355 = (((((((a1625516355 * a30494462) % 14999) % 13) + -100) - 22178) * 1) - -22181); 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((a1180594800 == 33 && ((((-135 < a63333937) && (29 >= a63333937)) && a190525986 == 10) && a4442917 == 6)) && a302110279 == 33) && (( cf==1  && (input == 11)) && a2061425267 == 11))) {
    	cf = 0;
    	a1345687529 = (((((((a1254983042 * a2130183577) % 14999) % 14962) - -15037) - 26074) * 1) - -26075);
    	a999024345 = ((((((((a1345687529 * a1625516355) % 14999) % 41) + 90) + 1) / 5) * 49) / 10);
    	a1891437507 = 35 ;
    	a1644957382 = 33 ;
    	a2073482783 = 33 ;
    	a721272783 = (a1249952537 + 9); 
    	 printf("%d\n", 16); fflush(stdout); 
    } 
}
 void calculate_outputm8(int input) {
    if((((((a1075307847 == 32 &&  cf==1 ) && ((103 < a2130183577) && (230 >= a2130183577))) && ((174 < a1985899004) && (371 >= a1985899004))) && a190525986 == 10) && ((a1211013485 == 33 && ((-198 < a217799639) && (-59 >= a217799639))) && a76745981 == 33))) {
    	if(((((((a1947180632 <=  -102 &&  cf==1 ) && a1180594800 == 33) && a1318526106 == 33) && a2130193413 == 10) && a1644957382 == 33) && (((-182 < a620105235) && (-160 >= a620105235)) && a1895304149 == 33))) {
    		calculate_outputm100(input);
    	} 
    } 
    if(((((103 < a2130183577) && (230 >= a2130183577)) && ((( cf==1  && a1075307847 == 33) && a76745981 == 33) && a778006913 == 2)) && (a1895304149 == 33 && (((48 < a999024345) && (131 >= a999024345)) && a302110279 == 33)))) {
    	if(((((174 < a1985899004) && (371 >= a1985899004)) && (a1478681170 == 4 && (a1318526106 == 33 && ( cf==1  && ((-158 < a1826277115) && (53 >= a1826277115)))))) && ((((-109 < a1625516355) && (-81 >= a1625516355)) && a1241576728 == 7) && a1180594800 == 33))) {
    		calculate_outputm101(input);
    	} 
    	if(((a1959068056 == 9 && (a708839806 == 33 && a26346326 == 33)) && ((a778006913 == 2 && (( cf==1  && ((53 < a1826277115) && (178 >= a1826277115))) && a2130193413 == 10)) && a263151501 == 33))) {
    		calculate_outputm102(input);
    	} 
    } 
    if((((a1830659124 == 10 && (a1075307847 == 35 &&  cf==1 )) && a2061425267 == 11) && (a1895304149 == 33 && (a1211013485 == 33 && (a1318526106 == 33 && a1478681170 == 4))))) {
    	if((((a1478681170 == 4 && ((171 < a1675035970) && (207 >= a1675035970))) && a1125477212 == 33) && ((a1210910088 == 2 && (a1318526106 == 33 && ( cf==1  && a1597554373 == 34))) && ((-62 < a30494462) && (124 >= a30494462))))) {
    		calculate_outputm105(input);
    	} 
    } 
}
 void calculate_outputm109(int input) {
    if((( cf==1  && (input == 8)) && (((((a708839806 == 33 && a778006913 == 2) && a1895304149 == 33) && a1916853335 == 6) && a263151501 == 33) && a2130193413 == 10))) {
    	a1933720537 += (a1933720537 + 20) > a1933720537 ? 3 : 0;
    	cf = 0;
    	a1318526106 = 34 ;
    	a1211013485 = 34 ;
    	a1625516355 = ((((((a1625516355 * a217799639) % 37) - 44) / 5) - -18790) + -18813);
    	a983758263 = ((((((a983758263 * a1345687529) % 101) + 304) + -19806) - -45200) + -25393);
    	a1675035970 = (((((((a1675035970 * a63333937) * 1) % 51) - -258) * 5) % 51) + 238);
    	a1254983042 = ((((((a1254983042 * a217799639) % 105) - -308) - -2) / 5) + 217);
    	a2130193413 = (a721272783 + -3);
    	a601495656 = 34 ;
    	a263638061 = (a786258498 + 2);
    	a1574467713 = ((a1830659124 + a1916853335) + -15);
    	a1180594800 = 34 ;
    	a620105235 = (((((a1774184757 * a30494462) % 94) + -65) + -18288) - -18289);
    	a63333937 = (((((((a217799639 * a217799639) / 5) % 106) - -60) / 5) * 49) / 10);
    	a1644957382 = 34 ;
    	a813082108 = ((((((a217799639 * a217799639) / 5) % 69) - -156) * 9) / 10);
    	a786258498 = ((a2061425267 - a1478681170) + 2);
    	a999024345 = (((((((a1774184757 * a1151361287) % 14999) - -4202) * 1) - -9262) % 64) + 196);
    	a302110279 = 34 ;
    	a1830659124 = (a778006913 + 9);
    	a708839806 = 34 ;
    	a2130183577 = ((((((a2130183577 * a1774184757) % 14999) % 12) + 242) * 5) / 5);
    	a26346326 = 34 ;
    	a709568404 = 34 ;
    	a1895857334 = ((a2026977784 / a2087535773) + 9);
    	a1895304149 = 34 ;
    	a2073482783 = 34 ;
    	a778006913 = ((a190525986 - a757937656) - 5);
    	a2087535773 = (a786258498 - 5);
    	a1916853335 = (a190525986 - 3);
    	a30494462 = (((((((a30494462 * a1018383389) % 85) + 210) * 5) * 5) % 85) + 130);
    	a1249952537 = ((a1959068056 * a1210910088) - 12);
    	a1241576728 = ((a2130193413 + a2130193413) + -14);
    	a2026977784 = ((a757937656 * a190525986) + -11);
    	a4442917 = (a1241576728 + -1);
    	a1983740902 = 34 ;
    	a263151501 = 34 ;
    	a1985899004 = (((((((a1985899004 * a1151361287) % 14999) % 76) + 414) - -12) * 9) / 10);
    	a1478681170 = (a757937656 - -3);
    	a260539918 = ((((((a217799639 * a217799639) % 73) - -62) / 5) * 10) / 9);
    	a1959068056 = ((a1210910088 + a757937656) + 6);
    	a1210910088 = ((a757937656 + a757937656) - 1);
    	a190525986 = ((a757937656 + a757937656) + 7); 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((((103 < a2130183577) && (230 >= a2130183577)) && (((-135 < a63333937) && (29 >= a63333937)) && a263151501 == 33)) && ((a4442917 == 6 && (((input == 9) &&  cf==1 ) && a302110279 == 33)) && a1959068056 == 9))) {
    	cf = 0;
    	a1318526106 = 33 ;
    	a1895857334 = (a721272783 + -6);
    	a1700231631 = (a1916853335 - -2);
    	a1478681170 = (a757937656 + 3);
    	a1125477212 = 32 ;
    	a2026977784 = ((a1210910088 / a1916853335) - -7);
    	a721272783 = ((a4442917 - a1210910088) - -13);
    	a1180594800 = 33 ;
    	a601495656 = 33 ;
    	a302110279 = 32 ;
    	a1241576728 = (a757937656 + 5);
    	a620105235 = ((((((a1675035970 * a1774184757) % 14999) % 10) + -169) - 2) - -2);
    	a999024345 = (((((((a1774184757 * a63333937) % 41) - -89) + 1) * 5) % 41) + 71);
    	a217799639 = ((((((a2130183577 * a1345687529) % 69) + -128) * 5) % 69) + -128);
    	a1211013485 = 33 ;
    	a2073482783 = 33 ;
    	a260539918 = (((((((a999024345 * a30494462) % 17) + -26) * 9) / 10) + -2896) - -2893);
    	a1151361287 = (((((((a2130183577 * a1254983042) % 14999) % 86) - -161) + 1685) + 18853) - 20537); 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((a1249952537 == 5 && ((a76745981 == 33 && (a786258498 == 9 && a1644957382 == 33)) && a709568404 == 33)) && (a1210910088 == 2 && ( cf==1  && (input == 13))))) {
    	cf = 0;
    	a302110279 = 33 ;
    	a983758263 = (((((((a983758263 * a1774184757) % 14999) - -2429) + -17241) * 1) % 14997) - 15002);
    	a1644957382 = 32 ;
    	a1213722969 = (a4442917 - -5);
    	a834646264 = (a2087535773 + 2);
    	a2087535773 = (a1478681170 + -1);
    	a341216798 = (((((a63333937 * a2130183577) % 14999) - 14999) * 1) + -2);
    	a30494462 = ((((((a30494462 * a341216798) % 14999) % 14969) - 15030) + 0) * 1);
    	a1675035970 = ((((a1625516355 * a1345687529) - 10821) - 18) + -9248);
    	a1478681170 = ((a1249952537 / a834646264) - -3);
    	a708839806 = 32 ;
    	a786258498 = (a1249952537 - -3);
    	a1018383389 = ((((((a1018383389 * a341216798) % 14999) * 2) % 74) + 91) - 0);
    	a63333937 = ((((((a260539918 * a1675035970) % 14999) * 2) % 14932) + -15066) * 1);
    	a1830659124 = ((a757937656 / a2130193413) + 9);
    	a1959068056 = ((a1241576728 - a1213722969) + 13);
    	a709568404 = 32 ;
    	a26346326 = 32 ;
    	a2130183577 = (((((a813082108 * a260539918) % 14999) - 14979) + -9) - 14);
    	a1895304149 = 32 ;
    	a76745981 = 32 ;
    	a1151361287 = (((((((a341216798 * a983758263) % 14999) % 86) + 163) + -2) + -18484) - -18486);
    	a778006913 = ((a1210910088 / a1916853335) - -1);
    	a1254983042 = (((((a1254983042 * a999024345) % 14999) - 9992) - 5008) + 0);
    	a4442917 = ((a1241576728 / a1830659124) - -5);
    	a1625516355 = ((((((((a1625516355 * a999024345) % 14999) % 13) - 93) * 5) * 5) % 13) - 93);
    	a263151501 = 32 ;
    	a1210910088 = (a1959068056 - 7); 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm113(int input) {
    if(((((-135 < a63333937) && (29 >= a63333937)) && (((input == 13) &&  cf==1 ) && ((3 < a813082108) && (104 >= a813082108)))) && ((((171 < a1675035970) && (207 >= a1675035970)) && (((75 < a1151361287) && (249 >= a1151361287)) && a1644957382 == 33)) && a302110279 == 33))) {
    	cf = 0;
    	 
    	 printf("%d\n", 16); fflush(stdout); 
    } 
}
 void calculate_outputm114(int input) {
    if(((a1830659124 == 10 && (((3 < a813082108) && (104 >= a813082108)) && a601495656 == 33)) && (a1241576728 == 7 && ((((-62 < a30494462) && (124 >= a30494462)) && ( cf==1  && (input == 2))) && a1916853335 == 6)))) {
    	cf = 0;
    	a1240243570 = (a1249952537 - -5);
    	a721272783 = ((a2130193413 + a1830659124) + -4);
    	a601495656 = 32 ;
    	a63333937 = (((((a63333937 * a999024345) + 23203) / 5) * -2) / 10);
    	a1474668405 = ((((((a999024345 * a813082108) * 10) / -9) - 2367) * 10) / 9);
    	a4442917 = (a1210910088 - -3);
    	a260539918 = ((((((a1018383389 * a999024345) * 10) / -9) * 10) / 9) * 1);
    	a76745981 = 32 ;
    	a1241576728 = (a2087535773 + 2);
    	a302110279 = 33 ;
    	a620105235 = ((((((((a620105235 * a2130183577) % 14999) % 10) + -170) - 1) * 5) % 10) + -169);
    	a813082108 = ((((((a813082108 * a1018383389) % 50) + 14) * 5) % 50) - -45);
    	a1018383389 = ((((((a1018383389 * a2130183577) % 14999) % 74) - -56) + -7003) + 7010); 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((((103 < a2130183577) && (230 >= a2130183577)) && (a1478681170 == 4 && (((-151 < a1774184757) && (35 >= a1774184757)) && a1249952537 == 5))) && ((((input == 11) &&  cf==1 ) && a2061425267 == 11) && a1830659124 == 10))) {
    	cf = 0;
    	a1180594800 = 34 ;
    	a1895857334 = ((a1916853335 + a1959068056) - 4);
    	a2026977784 = (a721272783 - 5);
    	a26346326 = 34 ;
    	a1985899004 = ((((((a2130183577 * a2130183577) % 14999) % 76) - -413) + 11954) + -11964);
    	a76745981 = 34 ;
    	a778006913 = (a190525986 + -7);
    	a263151501 = 34 ;
    	a4442917 = ((a2026977784 / a1249952537) - -6);
    	a999024345 = (((((((a1985899004 * a1985899004) % 14999) + 4959) - 21716) * 1) % 64) - -203);
    	a1959068056 = (a1210910088 + 8);
    	a1254983042 = (((((a999024345 * a813082108) + -30015) * 1) % 105) + 356);
    	a983758263 = ((((((a983758263 * a1345687529) % 14999) * 2) - 0) % 101) + 305);
    	a2061425267 = ((a1895857334 + a778006913) + -2);
    	a1241576728 = (a1895857334 - 3);
    	a1574467713 = (a1478681170 - -2);
    	a190525986 = ((a2130193413 / a1210910088) + 6);
    	a30494462 = (((((a30494462 * a1774184757) % 85) + 210) / 5) + 190);
    	a620105235 = ((((((a620105235 * a1254983042) % 14999) - 8053) % 94) + -34) - -58);
    	a1774184757 = ((((((((a1985899004 * a1675035970) % 14999) % 66) - -60) * 9) / 10) - 29018) - -29073);
    	a260539918 = (((((((a63333937 * a1985899004) % 14999) % 73) - -65) - -847) / 5) - 122);
    	a601495656 = 34 ;
    	a1125477212 = 34 ;
    	a1318526106 = 34 ;
    	a1478681170 = (a1959068056 - 5);
    	a1569588614 = (((((a983758263 * a1345687529) % 14999) - -7862) + 1627) * 1);
    	a1644957382 = 34 ;
    	a1895304149 = 34 ;
    	a302110279 = 34 ;
    	a709568404 = 34 ;
    	a2087535773 = (a786258498 - 4);
    	a2130193413 = (a786258498 + 2);
    	a1151361287 = (((((((a1675035970 * a1018383389) % 14999) + -17641) % 20) + 288) - 2968) - -2970);
    	a1211013485 = 34 ;
    	a1830659124 = (a1249952537 + 6);
    	a1249952537 = (a2087535773 + 1); 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((a1318526106 == 33 && (a302110279 == 33 && a1180594800 == 33)) && (((-62 < a30494462) && (124 >= a30494462)) && (a1895304149 == 33 && (a1959068056 == 9 && ( cf==1  && (input == 15))))))) {
    	cf = 0;
    	a1569588614 = ((((((a983758263 * a983758263) % 14999) + 13365) % 46) - -119) - 0);
    	a708839806 = 32 ;
    	a813082108 = ((((a813082108 * a983758263) + -26917) - 1623) + -579);
    	a1574467713 = (a4442917 - 3);
    	a2073482783 = 32 ;
    	a721272783 = ((a190525986 + a1916853335) - 4);
    	a620105235 = (((((a620105235 * a2130183577) % 14999) + -13438) - -38157) + -39322);
    	a1211013485 = 32 ;
    	a2130183577 = (((((a2130183577 * a1675035970) % 14999) + -21948) * 1) / 5); 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm9(int input) {
    if((((a786258498 == 9 && (((174 < a1985899004) && (371 >= a1985899004)) && (((-72 < a1345687529) && (75 >= a1345687529)) &&  cf==1 ))) && a778006913 == 2) && (((-151 < a1774184757) && (35 >= a1774184757)) && (a76745981 == 33 && a1644957382 == 33)))) {
    	if(((a778006913 == 2 && ((((-62 < a30494462) && (124 >= a30494462)) && (( cf==1  && a757937656 == 2) && a2087535773 == 4)) && a1478681170 == 4)) && (a1644957382 == 33 && a190525986 == 10))) {
    		calculate_outputm109(input);
    	} 
    } 
    if(((a302110279 == 33 && a1895304149 == 33) && ((((-182 < a620105235) && (-160 >= a620105235)) && ((a2073482783 == 33 && ( cf==1  && 75 < a1345687529)) && ((103 < a2130183577) && (230 >= a2130183577)))) && a1210910088 == 2))) {
    	if(((( cf==1  && a1891437507 == 35) && a1895304149 == 33) && (a26346326 == 33 && (((48 < a999024345) && (131 >= a999024345)) && (((-135 < a63333937) && (29 >= a63333937)) && (a778006913 == 2 && a4442917 == 6)))))) {
    		calculate_outputm113(input);
    	} 
    	if((((a1830659124 == 10 && ((3 < a813082108) && (104 >= a813082108))) && a1241576728 == 7) && (a1983740902 == 33 && (a786258498 == 9 && (((171 < a1675035970) && (207 >= a1675035970)) && ( cf==1  && a1891437507 == 36)))))) {
    		calculate_outputm114(input);
    	} 
    } 
}
 void calculate_outputm115(int input) {
    if(((((-2 < a1254983042) && (202 >= a1254983042)) && ((((171 < a1675035970) && (207 >= a1675035970)) && ((75 < a1151361287) && (249 >= a1151361287))) && a709568404 == 33)) && ((a1983740902 == 33 && ( cf==1  && (input == 12))) && ((48 < a999024345) && (131 >= a999024345))))) {
    	cf = 0;
    	a1345687529 = (((((a983758263 * a999024345) + -26526) - -27675) - 23538) - -24298);
    	a1891437507 = 35 ;
    	a721272783 = (a2130193413 + 4); 
    	 printf("%d\n", 17); fflush(stdout); 
    } if(((a1830659124 == 10 && (a1318526106 == 33 && (((-109 < a1625516355) && (-81 >= a1625516355)) && ( cf==1  && (input == 15))))) && (a4442917 == 6 && (a2026977784 == 8 && ((48 < a999024345) && (131 >= a999024345)))))) {
    	cf = 0;
    	a620105235 = ((((76 - -24103) + 3692) + 563) - 30099);
    	a1211013485 = 32 ;
    	a983758263 = ((((a983758263 * a999024345) / 5) - 29559) / 5);
    	a1521644128 = ((a786258498 - a757937656) - 2);
    	a965340096 = 32 ;
    	a4442917 = (a1241576728 + -2);
    	a708839806 = 32 ;
    	a263151501 = 32 ;
    	a1318526106 = 32 ;
    	a1895304149 = 32 ;
    	a260539918 = ((((a260539918 * a1254983042) / 5) - 2320) * 5);
    	a2130183577 = (((((a620105235 * a620105235) % 14999) - 28333) * 1) * 1);
    	a2130193413 = ((a190525986 - a1521644128) + 5);
    	a2073482783 = 32 ;
    	a1254983042 = (((((a620105235 * a983758263) % 14999) + 8816) / 5) + -19328);
    	a813082108 = ((((((a620105235 * a620105235) % 14999) + -5586) / 5) * 5) + -19059);
    	a1018383389 = ((((((a1018383389 * a1151361287) % 14999) % 21) - -177) + -6040) + 6044);
    	a1210910088 = ((a1521644128 + a2087535773) + -7);
    	a778006913 = (a2061425267 - 9);
    	a26346326 = 32 ;
    	a2026977784 = (a778006913 - -6);
    	a709568404 = 32 ;
    	a601495656 = 32 ;
    	a302110279 = 32 ;
    	a30494462 = (((((a30494462 * a1675035970) % 14969) + -15030) * 1) * 1);
    	a1830659124 = ((a1241576728 + a1241576728) - 5);
    	a1180594800 = 32 ;
    	a999024345 = (((((a983758263 * a983758263) % 14999) / 5) + -9435) * 3);
    	a341216798 = ((((a1774184757 * a1774184757) + 5655) / 5) * 5);
    	a63333937 = (((((a620105235 * a620105235) % 14999) + 6906) * 1) + -35145);
    	a1478681170 = (a778006913 + 4);
    	a1151361287 = (((((a63333937 * a1985899004) % 14999) - -13517) - 28473) + -34);
    	a1644957382 = 32 ;
    	a1675035970 = (((((a2130183577 * a217799639) % 14999) / 5) / 5) + -3085);
    	a1774184757 = (((((a620105235 * a620105235) % 14999) + -17766) * 1) * 1);
    	a76745981 = 32 ;
    	a1625516355 = ((((((a1625516355 * a1985899004) % 14999) % 14945) - 15053) + -3) + 0);
    	a786258498 = ((a1521644128 - a1241576728) - -10);
    	a1249952537 = ((a1916853335 - a1241576728) - -6);
    	a1241576728 = (a2026977784 - 1); 
    	 printf("%d\n", 17); fflush(stdout); 
    } 
}
 void calculate_outputm118(int input) {
    if(((((48 < a999024345) && (131 >= a999024345)) && (a2061425267 == 11 && ((input == 4) &&  cf==1 ))) && (((a1983740902 == 33 && a2026977784 == 8) && ((174 < a1985899004) && (371 >= a1985899004))) && a1241576728 == 7))) {
    	cf = 0;
    	a1254983042 = (((((70 * 39) / 10) - -28070) + -46717) + 18588);
    	a1895304149 = 34 ;
    	a999024345 = (((((((a999024345 * a1985899004) % 14999) - 16171) + 19814) * 1) % 64) - -193);
    	a601495656 = 34 ;
    	a2004613952 = (a757937656 - 3);
    	a217799639 = (((((((a1254983042 * a1254983042) % 14999) % 28) - 46) * 5) % 28) + -25);
    	a302110279 = 34 ;
    	a1211013485 = 34 ;
    	a566060042 = ((((((a1774184757 * a983758263) % 14999) * 2) - 0) % 14) - -13);
    	a30494462 = (((((((a30494462 * a260539918) + -13817) % 85) - -272) * 5) % 85) - -154);
    	a1644957382 = 34 ;
    	a260539918 = (((((a260539918 * a1625516355) - -21624) * 10) / -9) - 550);
    	a1895857334 = ((a1830659124 * a190525986) - 93);
    	a1985899004 = ((((((a1985899004 * a217799639) * 1) * 1) / 5) % 76) + 463);
    	a1249952537 = a4442917;
    	a620105235 = (((((((((a1254983042 * a1254983042) % 14999) % 94) - 112) * 10) / 9) * 5) % 94) - -3);
    	a1125477212 = 34 ;
    	a1916853335 = ((a721272783 * a190525986) - 143);
    	a63333937 = (((((((a1254983042 * a1254983042) % 14999) % 106) + 125) + 1057) + -26089) + 24958);
    	a1151361287 = ((((((a1151361287 * a620105235) % 14999) / 5) - -17986) % 20) - -264);
    	a1675035970 = (((((((a63333937 * a63333937) % 14999) % 51) - -245) - -14) - -26223) - 26261);
    	a1983740902 = 34 ;
    	a2026977784 = ((a1478681170 - a2004613952) + 11);
    	a983758263 = (((((a983758263 * a566060042) % 101) - -305) + 1) - 2);
    	a2061425267 = (a1241576728 + 5);
    	a2073482783 = 34 ;
    	a190525986 = ((a2061425267 * a1241576728) - 73);
    	a1180594800 = 34 ;
    	a786258498 = (a757937656 + 1);
    	a708839806 = 34 ;
    	a1959068056 = ((a2026977784 * a1241576728) + -53);
    	a1625516355 = ((((((a1254983042 * a30494462) % 14999) % 37) - 79) - 1) + 0);
    	a1018383389 = ((((((a1018383389 * a1675035970) % 14999) % 21) + 186) - -3) + 2);
    	a2130183577 = ((((((a2130183577 * a813082108) - -3917) * 1) - 24969) % 12) - -242);
    	a2087535773 = ((a1249952537 - a1249952537) - -3);
    	a26346326 = 34 ;
    	a778006913 = ((a1249952537 - a4442917) - -3);
    	a813082108 = (((((((a1254983042 * a1254983042) % 14999) + 2517) % 69) + 160) * 9) / 10);
    	a1318526106 = 32 ;
    	a1478681170 = (a1210910088 + 1);
    	a1210910088 = ((a4442917 + a2130193413) + -13);
    	a1774184757 = (((((((a999024345 * a1254983042) % 14999) % 66) + 36) + 976) - 16853) - -15943);
    	a709568404 = 34 ;
    	a76745981 = 32 ;
    	a1830659124 = (a2061425267 - 1);
    	a1241576728 = ((a2130193413 / a778006913) - -5);
    	a2130193413 = (a2061425267 + -1);
    	a4442917 = (a1249952537 + 1); 
    	 printf("%d\n", 18); fflush(stdout); 
    } if((((a601495656 == 33 && (a1983740902 == 33 && ((-62 < a30494462) && (124 >= a30494462)))) && a1916853335 == 6) && ((((input == 7) &&  cf==1 ) && a2130193413 == 10) && ((103 < a2130183577) && (230 >= a2130183577))))) {
    	cf = 0;
    	a1249952537 = (a2130193413 + -4);
    	a1210910088 = (a1249952537 - 3);
    	a1180594800 = 34 ;
    	a778006913 = ((a1210910088 * a1210910088) + -6);
    	a1895857334 = (a4442917 - -2);
    	a1625516355 = (((((((a1625516355 * a620105235) % 37) + -67) * 5) * 5) % 37) + -17);
    	a601495656 = 34 ;
    	a620105235 = (((77 - -19841) - 19894) / 5);
    	a709568404 = 32 ;
    	a1959068056 = ((a757937656 * a1210910088) - 17);
    	a1983740902 = 34 ;
    	a1985899004 = ((((((a1985899004 * a1774184757) % 14999) + 4223) % 76) - -447) * 1);
    	a1895304149 = 34 ;
    	a260539918 = (((((a260539918 * a983758263) % 73) - -65) + 1) + -1);
    	a708839806 = 34 ;
    	a2026977784 = (a190525986 + -1);
    	a1774184757 = (((((a813082108 * a1151361287) + -21191) + 21753) % 66) - -73);
    	a1018383389 = (((((a1018383389 * a999024345) + -24568) % 21) + 188) + 0);
    	a362219248 = ((((((a1254983042 * a1254983042) % 14999) % 34) + 235) + 7560) - 7559);
    	a2061425267 = (a1830659124 - -2);
    	a1916853335 = (a1478681170 + 3);
    	a786258498 = (a721272783 - 5);
    	a217799639 = (((((57 * 10) / -51) * 9) / 10) - -4);
    	a63333937 = ((((33 * 5) - 38) * 10) / 9);
    	a30494462 = ((((((a30494462 * a1675035970) % 85) - -211) * 5) % 85) - -137);
    	a1675035970 = (((((((a63333937 * a813082108) % 51) + 233) / 5) / 5) * 269) / 10);
    	a999024345 = ((((((a813082108 * a217799639) + 26812) % 64) + 170) * 10) / 9);
    	a76745981 = 34 ;
    	a983758263 = ((((((a983758263 * a362219248) % 14999) % 101) + 304) - 0) + 0);
    	a1830659124 = ((a2130193413 * a190525986) - 89);
    	a2130183577 = ((((36 * 5) / 5) * 5) - -56);
    	a1254983042 = ((((41 / 5) + 2933) - 21952) + 19346);
    	a4442917 = ((a778006913 - a778006913) + 7);
    	a2087535773 = (a1210910088 - -2);
    	a1478681170 = (a190525986 + -5);
    	a1644957382 = 34 ;
    	a1211013485 = 34 ;
    	a1125477212 = 34 ;
    	a813082108 = ((((37 * 5) + -25242) + -1576) - -26867);
    	a26346326 = 34 ;
    	a1151361287 = ((((((((a1151361287 * a2130183577) % 14999) % 20) + 270) + 2) * 5) % 20) + 257);
    	a369798198 = 33 ;
    	a1241576728 = ((a2130193413 - a1895857334) - -6);
    	a1318526106 = 34 ;
    	a190525986 = (a2130193413 + 1);
    	a2073482783 = 34 ;
    	a2130193413 = ((a2087535773 / a778006913) - -10); 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((((-2 < a1254983042) && (202 >= a1254983042)) && (a26346326 == 33 && ( cf==1  && (input == 13)))) && (((a1125477212 == 33 && a1211013485 == 33) && a1830659124 == 10) && ((-62 < a30494462) && (124 >= a30494462))))) {
    	a1224489519 += (a1224489519 + 20) > a1224489519 ? 2 : 0;
    	cf = 0;
    	a26346326 = 32 ;
    	a709568404 = 32 ;
    	a999024345 = ((((((a1151361287 * a620105235) % 14999) + -7676) - -35559) + -19058) - 19764);
    	a1211013485 = 32 ;
    	a1249952537 = (a2130193413 + -6);
    	a217799639 = ((((((a999024345 * a999024345) % 14999) + 5914) % 14901) + -15098) + -1);
    	a263151501 = 32 ;
    	a2087535773 = (a2130193413 - 7);
    	a1675035970 = (((((a1675035970 * a2130183577) % 14999) - -520) + -22051) + -2127);
    	a1125477212 = 34 ;
    	a1210910088 = ((a1249952537 * a2087535773) + -11);
    	a1241576728 = (a190525986 - 4);
    	a2130183577 = ((((a813082108 * a813082108) + -20318) * 1) + -3035);
    	a1180594800 = 32 ;
    	a30494462 = (((((a30494462 * a217799639) % 14999) - -14476) / 5) + -18156);
    	a1830659124 = ((a757937656 - a1478681170) + 4);
    	a1985899004 = ((((((a620105235 * a999024345) % 14999) + -14824) - 8) - -5620) + -5613);
    	a1756173294 = (((((a1254983042 * a1774184757) % 14999) + -14975) - 21) * 1);
    	a190525986 = a757937656;
    	a260539918 = ((((((a260539918 * a999024345) % 14999) % 14978) + -15021) - 1) - 1);
    	a708839806 = 34 ;
    	a2026977784 = ((a757937656 + a2130193413) - 12);
    	a4442917 = ((a2130193413 / a2130193413) + 4);
    	a1018383389 = (((((a1018383389 * a1985899004) % 14999) - 14989) + -11) - 0);
    	a601495656 = 32 ;
    	a1254983042 = (((((((a999024345 * a999024345) % 14999) - 15001) / 5) - -29110) * -1) / 10);
    	a786258498 = (a721272783 - 5);
    	a1625516355 = ((((((a1625516355 * a260539918) % 14999) / 5) - -6918) * 3) + -36315);
    	a1774184757 = ((((((a813082108 * a999024345) % 14999) % 66) + 103) / 5) + 45);
    	a983758263 = (((((((a983758263 * a1756173294) % 14999) % 14997) + -15002) + 24199) * 1) + -24200);
    	a778006913 = (a2130193413 + -9);
    	a813082108 = ((((((a999024345 * a999024345) % 14999) % 69) + 173) + -8036) + 8037);
    	a1983740902 = 34 ;
    	a76745981 = 32 ;
    	a1916853335 = ((a2061425267 + a1241576728) + -12);
    	a1644957382 = 32 ;
    	a1318526106 = 34 ;
    	a2061425267 = (a778006913 + 11);
    	a1700231631 = (a1959068056 - 3);
    	a341216798 = ((((((a1756173294 * a1756173294) % 14999) % 31) + 265) + 18934) + -18931);
    	a1895304149 = 32 ;
    	a302110279 = 32 ;
    	a1959068056 = ((a2130193413 / a1830659124) + 9);
    	a1478681170 = (a4442917 - 2);
    	a2130193413 = 9; 
    	 printf("%d\n", 19); fflush(stdout); 
    } if(((( cf==1  && (input == 14)) && ((3 < a813082108) && (104 >= a813082108))) && ((((a2130193413 == 10 && a709568404 == 33) && ((-2 < a1254983042) && (202 >= a1254983042))) && ((17 < a1018383389) && (167 >= a1018383389))) && ((-182 < a620105235) && (-160 >= a620105235))))) {
    	cf = 0;
    	a1826277115 = ((((((a2130183577 * a813082108) / 5) % 105) + -133) * 10) / 9);
    	a1075307847 = 33 ;
    	a721272783 = ((a1478681170 * a1241576728) + -15);
    	a1774184757 = ((((((a1774184757 * a260539918) % 66) + 103) / 5) / 5) - -56); 
    	 printf("%d\n", 16); fflush(stdout); 
    } 
}
 void calculate_outputm119(int input) {
    if(((((a708839806 == 33 && a2130193413 == 10) && ((75 < a1151361287) && (249 >= a1151361287))) && a1478681170 == 4) && (((-151 < a1774184757) && (35 >= a1774184757)) && (( cf==1  && (input == 5)) && ((-2 < a1254983042) && (202 >= a1254983042)))))) {
    	cf = 0;
    	a369798198 = 32 ;
    	a2073482783 = 34 ;
    	a1774184757 = (((((a1625516355 * a1625516355) - -8731) * -1) / 10) - 44);
    	a1916853335 = ((a1959068056 * a1959068056) - 76);
    	a1180594800 = 32 ;
    	a1985899004 = ((((((a1985899004 * a1774184757) % 14999) - 2848) / 5) * 10) / 9);
    	a1895304149 = 32 ;
    	a2130183577 = (((((a1774184757 * a1774184757) % 14999) + -28880) - 707) * 1);
    	a1018383389 = ((((((a1774184757 * a1774184757) % 14999) - 18987) * 1) * 10) / 9);
    	a263151501 = 34 ;
    	a1521644128 = (a2026977784 + -5);
    	a1151361287 = (((((a1774184757 * a2130183577) % 14999) - 13087) / 5) - 22949);
    	a1125477212 = 34 ;
    	a1254983042 = (((((a1254983042 * a30494462) % 14999) - 15000) - 2) - 0);
    	a302110279 = 32 ;
    	a1318526106 = 34 ;
    	a709568404 = 32 ;
    	a30494462 = ((((((a1774184757 * a260539918) % 14999) - 24659) * 10) / 9) + -370);
    	a1983740902 = 34 ;
    	a341216798 = ((((a63333937 * a813082108) - -26717) - -227) * 1);
    	a1675035970 = (((((a2130183577 * a1018383389) % 14999) - 14880) - 43) / 5);
    	a63333937 = (((((a217799639 * a1774184757) % 14999) / 5) - 9294) * 3);
    	a708839806 = 34 ;
    	a999024345 = (((((a999024345 * a1151361287) % 14999) - -10541) + -25518) + -1);
    	a1249952537 = ((a721272783 * a1959068056) - 131);
    	a260539918 = ((((((a341216798 * a1151361287) % 14999) * 2) % 73) + 67) - 2);
    	a983758263 = ((((((a983758263 * a160322672) % 14999) - -7268) % 14997) + -15002) * 1);
    	a778006913 = (a1959068056 - 8);
    	a26346326 = 34 ;
    	a1211013485 = 32 ;
    	a813082108 = ((((((a1675035970 * a620105235) % 14999) + -13125) - -2003) * 1) - 3874);
    	a786258498 = (a1916853335 + a1916853335);
    	a76745981 = 32 ;
    	a1478681170 = ((a778006913 + a778006913) - -1);
    	a1830659124 = (a2087535773 + 5);
    	a4442917 = (a1210910088 + 3);
    	a2087535773 = ((a1521644128 + a1830659124) - 9);
    	a190525986 = (a721272783 - 6);
    	a1644957382 = 32 ;
    	a1210910088 = ((a1959068056 * a1249952537) - 33);
    	a1625516355 = (((((((a1625516355 * a341216798) % 14999) + 16530) % 37) - 57) * 10) / 9);
    	a2130193413 = a1959068056;
    	a601495656 = 34 ;
    	a2026977784 = a1241576728;
    	a1241576728 = (a190525986 + -3);
    	a1959068056 = (a721272783 + -5); 
    	 printf("%d\n", 19); fflush(stdout); 
    } if((((( cf==1  && (input == 11)) && ((174 < a1985899004) && (371 >= a1985899004))) && a1125477212 == 33) && (a76745981 == 33 && ((a708839806 == 33 && a26346326 == 33) && a1318526106 == 33)))) {
    	cf = 0;
    	a63333937 = ((((((a1254983042 * a1254983042) % 14999) + -3698) % 14932) + -15066) * 1);
    	a1241576728 = a1916853335;
    	a1774184757 = (((((a63333937 * a63333937) % 14999) - 26945) + -7) + 7450);
    	a1180594800 = 34 ;
    	a1249952537 = (a1959068056 + -5);
    	a999024345 = ((((a999024345 * a1675035970) - 32217) * 1) / 5);
    	a1644957382 = 32 ;
    	a4442917 = (a1916853335 - 1);
    	a76745981 = 32 ;
    	a2130183577 = ((((((a1254983042 * a63333937) % 14999) / 5) % 63) + 167) * 1);
    	a601495656 = 32 ;
    	a1625516355 = (((((a1625516355 * a1774184757) % 14999) - 16611) - 7215) - 3475);
    	a786258498 = (a1916853335 - -2);
    	a2061425267 = ((a1959068056 - a1959068056) + 11);
    	a190525986 = (a2130193413 + -1);
    	a263151501 = 33 ;
    	a709568404 = 32 ;
    	a1895304149 = 32 ;
    	a1478681170 = (a1916853335 - 3);
    	a2130193413 = (a721272783 + -4);
    	a1125477212 = 32 ;
    	a834646264 = (a778006913 + 6);
    	a30494462 = ((((a260539918 * a1254983042) - -13931) * 2) - 30911);
    	a1151361287 = (((((a1151361287 * a217799639) % 14999) + 24826) / 5) - 10941);
    	a1018383389 = ((((((a1254983042 * a63333937) % 14999) + -9553) - 3432) % 74) + 92);
    	a302110279 = 34 ;
    	a260539918 = ((((((a1774184757 * a217799639) % 14999) % 73) - 1) / 5) / 5);
    	a1985899004 = ((((((a1985899004 * a999024345) % 14999) + 10030) * 1) - -3251) - 28165);
    	a341216798 = (((((a983758263 * a160322672) % 14999) + -3891) - -1590) - 12655);
    	a2073482783 = 32 ;
    	a778006913 = ((a1210910088 + a1959068056) + -10);
    	a813082108 = (((((a813082108 * a30494462) % 14999) + -340) / 5) / 5);
    	a2087535773 = (a786258498 + -5);
    	a983758263 = (((((((a983758263 * a1675035970) % 14999) % 14997) - 15002) + 29736) / 5) + -29235);
    	a1830659124 = ((a2087535773 - a1249952537) - -10);
    	a1210910088 = ((a1959068056 + a1241576728) - 14);
    	a1318526106 = 32 ;
    	a1959068056 = ((a721272783 - a1916853335) - 1);
    	a1983740902 = 32 ;
    	a1211013485 = 32 ;
    	a2026977784 = (a190525986 + -2);
    	a1032084261 = 36 ;
    	a26346326 = 32 ;
    	a1254983042 = (((((a1254983042 * a620105235) % 14999) - 15001) - 0) - 1);
    	a1916853335 = (a1478681170 + 4); 
    	 printf("%d\n", 17); fflush(stdout); 
    } if(((a2130193413 == 10 && ((-151 < a1774184757) && (35 >= a1774184757))) && ((((3 < a813082108) && (104 >= a813082108)) && ((a2073482783 == 33 && ( cf==1  && (input == 12))) && ((-44 < a260539918) && (-8 >= a260539918)))) && a1959068056 == 9))) {
    	cf = 0;
    	a1826277115 = ((((a999024345 * a1625516355) + 7486) - -25739) + 406);
    	a404763935 = (a721272783 + -6);
    	a1625516355 = (((((((a160322672 * a260539918) % 14999) + -14357) + 12286) / 5) % 37) - 42);
    	a813082108 = (((((((a813082108 * a160322672) % 14999) + -10385) % 69) + 173) / 5) - -128);
    	a1254983042 = ((((((a1254983042 * a30494462) % 105) + 308) * 1) / 5) - -225);
    	a1774184757 = ((((((a1774184757 * a1625516355) * 2) % 66) - -102) / 5) - -44);
    	a2087535773 = (a4442917 - 1);
    	a1916853335 = (a190525986 - 3);
    	a1241576728 = (a1959068056 + -1);
    	a1830659124 = ((a1478681170 + a4442917) + 1);
    	a26346326 = 34 ;
    	a1895304149 = 34 ;
    	a1959068056 = ((a1916853335 - a2130193413) - -13);
    	a1478681170 = (a1241576728 - 3);
    	a1151361287 = ((((((a1151361287 * a2130183577) % 14999) - -11538) % 20) - -261) * 1);
    	a708839806 = 34 ;
    	a1675035970 = (((((((a1675035970 * a813082108) % 14999) + 4211) * 1) - -2043) % 51) - -214);
    	a1210910088 = ((a2026977784 / a2130193413) - -3);
    	a537754274 = 32 ;
    	a190525986 = ((a1916853335 + a1916853335) + -3);
    	a4442917 = (a721272783 + -8);
    	a1125477212 = 34 ;
    	a1983740902 = 34 ;
    	a1985899004 = ((((((((a1985899004 * a813082108) % 14999) / 5) % 76) + 372) * 5) % 76) - -437);
    	a601495656 = 34 ;
    	a786258498 = (a2087535773 - -5);
    	a999024345 = ((((((((a999024345 * a1826277115) % 14999) % 64) - -168) - 2535) * 5) % 64) + 232);
    	a30494462 = (((((((a30494462 * a1151361287) % 14999) % 85) + 210) + 24981) - -1426) + -26405);
    	a2073482783 = 34 ;
    	a983758263 = ((((((a983758263 * a160322672) % 14999) - 10790) % 14796) + 15202) - 0);
    	a2026977784 = ((a404763935 + a786258498) - 10);
    	a76745981 = 34 ;
    	a778006913 = (a2061425267 + -9);
    	a1180594800 = 34 ;
    	a1211013485 = 34 ;
    	a217799639 = ((((((((a983758263 * a63333937) % 14999) % 28) - 29) * 5) - 21608) % 28) - 2);
    	a2130193413 = ((a786258498 * a2087535773) + -39); 
    	 printf("%d\n", 16); fflush(stdout); 
    } if(((a1318526106 == 33 && (a1478681170 == 4 && a1180594800 == 33)) && (((( cf==1  && (input == 15)) && ((-2 < a1254983042) && (202 >= a1254983042))) && ((48 < a999024345) && (131 >= a999024345))) && a1916853335 == 6))) {
    	cf = 0;
    	a778006913 = 3;
    	a260539918 = ((((((a1151361287 * a1774184757) % 14999) % 73) - -67) - 1) - -2);
    	a30494462 = (((((a30494462 * a260539918) - 12719) % 85) + 209) + 0);
    	a786258498 = a2130193413;
    	a983758263 = ((((((a983758263 * a1625516355) * 1) + -7092) + 10269) % 101) - -304);
    	a1895857334 = ((a721272783 - a190525986) + 3);
    	a1210910088 = a778006913;
    	a1241576728 = ((a2061425267 - a1959068056) + 5);
    	a1895304149 = 34 ;
    	a1211013485 = 34 ;
    	a703247202 = 36 ;
    	a369798198 = 32 ;
    	a4442917 = (a721272783 - 8);
    	a26346326 = 34 ;
    	a1983740902 = 34 ;
    	a601495656 = 34 ;
    	a1830659124 = ((a1241576728 * a1478681170) - 21);
    	a1675035970 = (((((((a1675035970 * a1774184757) % 14999) + -10313) % 51) + 258) - -22888) - 22886);
    	a999024345 = (((((((a999024345 * a160322672) % 14999) % 64) + 195) + 0) - -21726) - 21724);
    	a1254983042 = (((((a1254983042 * a813082108) * 1) % 105) - -309) + 1);
    	a190525986 = (a778006913 + 8);
    	a1180594800 = 34 ;
    	a2026977784 = ((a2130193413 * a1210910088) + -21);
    	a1959068056 = ((a778006913 - a778006913) + 10);
    	a63333937 = (((((((a63333937 * a1151361287) % 14999) / 5) - -5946) + 4790) % 106) + 93);
    	a2087535773 = (a2130193413 + -5);
    	a2130183577 = (((((((a983758263 * a63333937) % 14999) % 12) - -242) + -21529) * 1) - -21524);
    	a2130193413 = (a778006913 + 8);
    	a1125477212 = 34 ;
    	a1478681170 = ((a1916853335 + a1916853335) - 7);
    	a1916853335 = ((a778006913 - a778006913) + 7);
    	a1774184757 = ((((((a1774184757 * a1985899004) % 14999) % 66) - -103) * 1) + -2);
    	a1985899004 = (((((((a260539918 * a999024345) % 14999) / 5) % 76) - -448) / 5) - -368);
    	a217799639 = (((((((a1151361287 * a1151361287) % 14999) % 28) - 35) / 5) + -13703) - -13678);
    	a2073482783 = 34 ;
    	a1318526106 = 34 ;
    	a1151361287 = (((((a1151361287 * a217799639) % 20) - -276) - 11485) + 11482); 
    	 printf("%d\n", 18); fflush(stdout); 
    } 
}
 void calculate_outputm121(int input) {
    if(((a1983740902 == 33 && (a1959068056 == 9 && (((-151 < a1774184757) && (35 >= a1774184757)) && ((103 < a2130183577) && (230 >= a2130183577))))) && ((a1211013485 == 33 && ( cf==1  && (input == 9))) && a1478681170 == 4))) {
    	cf = 0;
    	a1241576728 = (a2026977784 + -2);
    	a983758263 = ((((((a983758263 * a1254983042) % 14999) - -2762) + -12010) % 14997) - 15002);
    	a1959068056 = a2026977784;
    	a2130183577 = (((((a2130183577 * a1774184757) % 14999) - 14976) - 4) * 1);
    	a341216798 = ((((((a983758263 * a983758263) % 14999) / 5) + 6751) % 31) + 241);
    	a786258498 = (a1916853335 + 3);
    	a1210910088 = (a2061425267 - 9);
    	a260539918 = (((((a260539918 * a983758263) % 14999) - 26190) * 1) - 3767);
    	a999024345 = ((((a999024345 * a1774184757) + 13300) - 22394) + -621);
    	a1478681170 = (a2026977784 + -5);
    	a63333937 = ((((((a63333937 * a983758263) % 14999) + -11587) % 106) + 136) + -1);
    	a778006913 = (a2026977784 - 7);
    	a1180594800 = 32 ;
    	a2130193413 = ((a1210910088 - a1249952537) - -12);
    	a30494462 = ((((((a30494462 * a1675035970) - -3740) - 18870) + -2032) % 14969) - 15030);
    	a1354435613 = 33 ;
    	a1018383389 = ((((((((a1018383389 * a999024345) % 14999) * 2) % 21) - -189) / 5) * 51) / 10);
    	a813082108 = (((((a813082108 * a341216798) % 14999) + -27622) - 2290) - 82);
    	a1254983042 = (((((a2130183577 * a1774184757) % 14999) - 15001) / 5) + -14138);
    	a1151361287 = ((((((a1151361287 * a1675035970) % 14999) / 5) % 20) - -266) + -14);
    	a1983740902 = 34 ;
    	a1756173294 = (((((((a1774184757 * a341216798) % 14999) + 11002) + -14437) + -6471) % 18) - -95);
    	a26346326 = 34 ;
    	a1675035970 = ((((((a1675035970 * a1774184757) % 14999) * 2) * 1) % 51) - -260);
    	a601495656 = 32 ;
    	a1211013485 = 32 ;
    	a1895304149 = 32 ;
    	a1625516355 = ((((((a1625516355 * a217799639) % 14999) - 17312) + 14452) / 5) - 22206);
    	a2026977784 = ((a4442917 * a2130193413) + -38);
    	a1774184757 = ((((((a1774184757 * a2130183577) % 14999) % 14924) + -15074) / 5) + -18594); 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm122(int input) {
    if((((a2130193413 == 10 && a263151501 == 33) && a709568404 == 33) && (a302110279 == 33 && (a1249952537 == 5 && (((input == 11) &&  cf==1 ) && a1983740902 == 33))))) {
    	cf = 0;
    	a1210910088 = (a1249952537 - 2);
    	a708839806 = 34 ;
    	a983758263 = (((((((a983758263 * a1440713788) % 14999) / 5) % 101) - -304) / 5) - -243);
    	a1241576728 = ((a2130193413 + a778006913) + -5);
    	a1180594800 = 34 ;
    	a190525986 = (a1210910088 - -8);
    	a30494462 = (((((((a30494462 * a1018383389) % 85) + 210) - 1) / 5) * 51) / 10);
    	a153258473 = (((((((a1440713788 * a983758263) % 14999) % 27) - -131) + -4) / 5) - -128);
    	a1895857334 = (a721272783 - 6);
    	a2140773614 = 34 ;
    	a76745981 = 32 ;
    	a1478681170 = a1249952537;
    	a1151361287 = ((((((a1151361287 * a30494462) % 14999) + 9002) * 1) % 20) + 260);
    	a709568404 = 34 ;
    	a999024345 = ((((((a999024345 * a1254983042) % 14999) + 7086) % 64) + 149) + -6);
    	a2026977784 = (a1830659124 + -2);
    	a1774184757 = ((((((a1774184757 * a1440713788) % 14999) / 5) % 66) - -102) - 1);
    	a620105235 = (((((a153258473 * a999024345) % 14999) + 3259) - 19265) - 4457);
    	a263151501 = 34 ;
    	a1895304149 = 34 ;
    	a1249952537 = ((a1916853335 - a1210910088) - -2);
    	a2130193413 = a1830659124; 
    	 printf("%d\n", 17); fflush(stdout); 
    } 
}
 void calculate_outputm10(int input) {
    if(((((( cf==1  && a2097567994 == 32) && ((17 < a1018383389) && (167 >= a1018383389))) && a26346326 == 33) && a1211013485 == 33) && (a1180594800 == 33 && (((-44 < a260539918) && (-8 >= a260539918)) && a1895304149 == 33)))) {
    	if(((a76745981 == 33 && (((a757937656 == 2 &&  cf==1 ) && ((-44 < a260539918) && (-8 >= a260539918))) && ((-62 < a30494462) && (124 >= a30494462)))) && ((a263151501 == 33 && a708839806 == 33) && a1249952537 == 5))) {
    		calculate_outputm115(input);
    	} 
    	if(((a1959068056 == 9 && (((-62 < a30494462) && (124 >= a30494462)) && (a757937656 == 9 &&  cf==1 ))) && ((((17 < a1018383389) && (167 >= a1018383389)) && (a786258498 == 9 && a708839806 == 33)) && a1916853335 == 6))) {
    		calculate_outputm118(input);
    	} 
    } 
    if(((a1125477212 == 33 && (((-2 < a1254983042) && (202 >= a1254983042)) && ((174 < a1985899004) && (371 >= a1985899004)))) && (((48 < a999024345) && (131 >= a999024345)) && ((( cf==1  && a2097567994 == 33) && a786258498 == 9) && a2026977784 == 8)))) {
    	if((((((3 < a813082108) && (104 >= a813082108)) && ((a2087535773 == 4 && a1983740902 == 33) && a1830659124 == 10)) && a1211013485 == 33) && ((a160322672 <=  65 &&  cf==1 ) && a4442917 == 6))) {
    		calculate_outputm119(input);
    	} 
    } 
    if((((((3 < a813082108) && (104 >= a813082108)) && ((17 < a1018383389) && (167 >= a1018383389))) && ((48 < a999024345) && (131 >= a999024345))) && (a2130193413 == 10 && (((-44 < a260539918) && (-8 >= a260539918)) && ((a2097567994 == 34 &&  cf==1 ) && ((-135 < a63333937) && (29 >= a63333937))))))) {
    	if((( cf==1  && a1969216760 == 36) && (a2026977784 == 8 && (a778006913 == 2 && (a1983740902 == 33 && ((a1180594800 == 33 && a786258498 == 9) && ((-109 < a1625516355) && (-81 >= a1625516355)))))))) {
    		calculate_outputm121(input);
    	} 
    } 
    if(((((17 < a1018383389) && (167 >= a1018383389)) && ((a1478681170 == 4 && (a2097567994 == 35 &&  cf==1 )) && a1895304149 == 33)) && (a1249952537 == 5 && (a708839806 == 33 && ((48 < a999024345) && (131 >= a999024345)))))) {
    	if(((((48 < a999024345) && (131 >= a999024345)) && (a190525986 == 10 && (a1478681170 == 4 && a1180594800 == 33))) && (((312 < a1440713788 &&  cf==1 ) && ((-151 < a1774184757) && (35 >= a1774184757))) && ((-62 < a30494462) && (124 >= a30494462))))) {
    		calculate_outputm122(input);
    	} 
    } 
}
 void calculate_outputm124(int input) {
    if(((((((input == 5) &&  cf==1 ) && ((75 < a1151361287) && (249 >= a1151361287))) && a1318526106 == 33) && ((-44 < a260539918) && (-8 >= a260539918))) && ((((171 < a1675035970) && (207 >= a1675035970)) && ((-2 < a1254983042) && (202 >= a1254983042))) && a26346326 == 33))) {
    	cf = 0;
    	a217799639 = (((((((a1774184757 * a260539918) - 15090) % 28) + -10) * 5) % 28) + -26);
    	a2087535773 = (a1241576728 - 2);
    	a601495656 = 34 ;
    	a1983740902 = 34 ;
    	a1478681170 = (a778006913 - -3);
    	a1125477212 = 34 ;
    	a1075307847 = 33 ;
    	a709568404 = 34 ;
    	a1211013485 = 34 ;
    	a63333937 = ((((((a1774184757 * a1018383389) + 2340) / 5) + -17638) % 106) + 172);
    	a721272783 = (a2061425267 + 2);
    	a1826277115 = (((((((a999024345 * a983758263) % 62) - -115) - -2) * 5) % 62) - -81);
    	a2073482783 = 34 ;
    	a1018383389 = ((((((a1254983042 * a1675035970) % 14999) % 21) - -188) - 0) - -2);
    	a2061425267 = (a190525986 + 2); 
    	 printf("%d\n", 26); fflush(stdout); 
    } if(((((17 < a1018383389) && (167 >= a1018383389)) && a1895304149 == 33) && ((((((input == 9) &&  cf==1 ) && a1830659124 == 10) && a76745981 == 33) && a190525986 == 10) && a1241576728 == 7))) {
    	a789762657 -= (a789762657 - 20) < a789762657 ? 1 : 0;
    	cf = 0;
    	a63333937 = (((((a1625516355 * a999024345) + -7856) / 5) * 10) / 9);
    	a813082108 = ((((((a63333937 * a63333937) % 14999) - -8200) / 5) % 69) - -118);
    	a1077149355 = (a190525986 + 1);
    	a2130183577 = (((((a2130183577 * a1151361287) % 14999) + 2640) + -32613) * 1);
    	a341216798 = ((((((a1474668405 * a999024345) % 14999) + 17771) - 24037) - 6800) - -38637);
    	a76745981 = 32 ;
    	a2087535773 = (a721272783 + -13);
    	a1625516355 = (((((a1985899004 * a260539918) * 10) / 9) * 1) - 4667);
    	a30494462 = ((((a30494462 * a260539918) - 10988) / 5) * 5);
    	a983758263 = ((((((a983758263 * a1774184757) % 14999) % 14997) + -15002) + -1) * 1);
    	a4442917 = (a2061425267 - 6);
    	a1180594800 = 32 ;
    	a620105235 = (((((((a2130183577 * a63333937) % 14999) % 94) - 64) + -21412) / 5) + 4269);
    	a2130193413 = ((a2087535773 * a721272783) + -39);
    	a2026977784 = ((a190525986 - a190525986) + 9);
    	a1478681170 = ((a1249952537 * a2087535773) - 10);
    	a2073482783 = 32 ;
    	a1521644128 = (a1959068056 + -2);
    	a1318526106 = 32 ;
    	a2061425267 = (a190525986 + 2);
    	a786258498 = (a1240243570 - -3);
    	a1241576728 = ((a1830659124 / a1916853335) + 5);
    	a601495656 = 34 ;
    	a708839806 = 32 ;
    	a1254983042 = (((((a1254983042 * a1985899004) % 14999) - 15000) + 25107) - 25108);
    	a999024345 = (((((((a63333937 * a63333937) % 14999) + 14476) / 5) - 28539) % 64) - -254);
    	a1774184757 = (((((((a2130183577 * a2130183577) % 14999) * 2) - -1) * 1) % 14924) + -15074);
    	a1151361287 = (((((a63333937 * a260539918) % 14999) / 5) + -7135) - 15087);
    	a302110279 = 32 ;
    	a778006913 = ((a1959068056 * a4442917) + -44);
    	a263151501 = 32 ;
    	a1959068056 = ((a1210910088 * a1916853335) - 4);
    	a1211013485 = 32 ;
    	a1210910088 = ((a190525986 + a190525986) - 17);
    	a1644957382 = 34 ;
    	a1018383389 = ((((((a1018383389 * a63333937) % 14999) - 8173) - 91) + 8592) + -10201);
    	a709568404 = 34 ;
    	a1830659124 = (a2087535773 - -6);
    	a1895304149 = 32 ;
    	a1675035970 = ((((a1675035970 * a260539918) + -19917) / 5) * 5);
    	a1985899004 = (((((((a1985899004 * a63333937) % 14999) % 76) - -447) * 5) % 76) - -388);
    	a190525986 = (a2087535773 + 8); 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm125(int input) {
    if(((((-135 < a63333937) && (29 >= a63333937)) && (a709568404 == 33 && (a708839806 == 33 && ((input == 2) &&  cf==1 )))) && ((((-109 < a1625516355) && (-81 >= a1625516355)) && a263151501 == 33) && ((48 < a999024345) && (131 >= a999024345))))) {
    	cf = 0;
    	 
    	 printf("%d\n", 16); fflush(stdout); 
    } if((((-109 < a1625516355) && (-81 >= a1625516355)) && (((a1125477212 == 33 && ((((input == 13) &&  cf==1 ) && a1241576728 == 7) && a1249952537 == 5)) && a1210910088 == 2) && ((-182 < a620105235) && (-160 >= a620105235))))) {
    	a419312954 -= (a419312954 - 20) < a419312954 ? 2 : 0;
    	cf = 0;
    	 
    	 printf("%d\n", 26); fflush(stdout); 
    } 
}
 void calculate_outputm126(int input) {
    if(((((a1830659124 == 10 && a786258498 == 9) && a1895304149 == 33) && a1983740902 == 33) && ((a2073482783 == 33 && ((input == 8) &&  cf==1 )) && a190525986 == 10))) {
    	cf = 0;
    	a1891437507 = 35 ;
    	a63333937 = ((((((a983758263 * a1675035970) % 14999) - 7571) % 81) - 53) - 1);
    	a721272783 = ((a1959068056 * a778006913) - 4);
    	a1345687529 = ((((a1675035970 * a999024345) - -255) * 1) + 41);
    	a4442917 = (a2026977784 + -2); 
    	 printf("%d\n", 17); fflush(stdout); 
    } if((((a708839806 == 33 && (((75 < a1151361287) && (249 >= a1151361287)) && ((((input == 13) &&  cf==1 ) && a1318526106 == 33) && ((-2 < a1254983042) && (202 >= a1254983042))))) && a709568404 == 33) && a2130193413 == 10)) {
    	cf = 0;
    	a1345687529 = ((((((a2130183577 * a983758263) % 14999) % 14962) - -15037) + 0) - -1);
    	a1891437507 = 35 ;
    	a4442917 = (a1959068056 + -3);
    	a721272783 = (a2087535773 - -10);
    	a63333937 = (((((a1774184757 * a620105235) + 2279) + 458) % 81) - 51); 
    	 printf("%d\n", 17); fflush(stdout); 
    } if(((((input == 2) &&  cf==1 ) && a2026977784 == 8) && (((a2130193413 == 10 && (a190525986 == 10 && a786258498 == 9)) && a1478681170 == 4) && a1211013485 == 33))) {
    	cf = 0;
    	a1959068056 = (a2061425267 + -3);
    	a709568404 = 32 ;
    	a1305578599 = 34 ;
    	a708839806 = 32 ;
    	a26346326 = 32 ;
    	a341216798 = (((((((a1474668405 * a983758263) % 14999) % 18) - -215) - 17299) / 5) - -3625);
    	a1895304149 = 32 ;
    	a1644957382 = 32 ;
    	a30494462 = (((((a30494462 * a1675035970) % 14969) + -15030) - -25581) - 25581);
    	a811861560 = 36 ;
    	a1125477212 = 32 ;
    	a983758263 = ((((((a983758263 * a341216798) % 14999) % 14997) - 15002) * 1) - 2);
    	a778006913 = (a190525986 - 9);
    	a1774184757 = ((((((a1774184757 * a1625516355) + -17413) * 10) / 9) - -24500) + -24657);
    	a1625516355 = (((((a1625516355 * a1985899004) % 14999) - 3974) * 1) * 1); 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm127(int input) {
    if(((a76745981 == 33 && (((a1830659124 == 10 && ((input == 5) &&  cf==1 )) && a708839806 == 33) && ((3 < a813082108) && (104 >= a813082108)))) && (((-109 < a1625516355) && (-81 >= a1625516355)) && a1895304149 == 33))) {
    	cf = 0;
    	a1983740902 = 34 ;
    	a1985899004 = (((((a1985899004 * a217799639) / 5) * 5) % 76) - -502);
    	a709568404 = 34 ;
    	a708839806 = 34 ;
    	a2130183577 = ((((((a2130183577 * a999024345) % 14999) % 12) + 238) + 24994) + -24999);
    	a1895857334 = a2061425267;
    	a983758263 = ((((((a983758263 * a1474668405) % 14999) - -979) % 101) + 304) + 0);
    	a1916853335 = (a2026977784 - 1);
    	a263638061 = ((a2026977784 / a1240243570) - -11);
    	a26346326 = 34 ;
    	a1478681170 = ((a2087535773 + a263638061) + -11);
    	a302110279 = 34 ;
    	a1574467713 = (a778006913 - 1);
    	a2061425267 = (a190525986 + 2);
    	a778006913 = (a1916853335 + -4);
    	a190525986 = a1895857334;
    	a2130193413 = (a1241576728 + 3);
    	a1318526106 = 34 ;
    	a1895304149 = 34 ;
    	a620105235 = (((((((a1985899004 * a217799639) % 14999) % 94) - 64) + 14030) / 5) + -2785);
    	a30494462 = (((((((a30494462 * a1985899004) % 14999) % 85) + 211) - -1) + 22486) + -22487);
    	a1959068056 = (a2026977784 - -2);
    	a63333937 = (((((a813082108 * a1625516355) - -1167) % 106) + 137) - -1);
    	a999024345 = ((((((a813082108 * a813082108) - 8492) - 7149) / 5) % 64) - -203);
    	a1211013485 = 34 ;
    	a1675035970 = ((((((a1675035970 * a2130183577) % 14999) / 5) % 51) - -238) + 22);
    	a1625516355 = (((((a1625516355 * a2130183577) % 37) + -43) + -1) + 0);
    	a1830659124 = ((a1210910088 - a786258498) + 19);
    	a260539918 = (((((((a2130183577 * a1985899004) % 14999) + -15023) % 73) + 136) - 29427) + 29427);
    	a2026977784 = ((a1895857334 - a263638061) - -9);
    	a1125477212 = 34 ;
    	a1249952537 = ((a2130193413 * a2130193413) - 115);
    	a813082108 = (((((((a983758263 * a1985899004) % 14999) / 5) + 7936) - 29107) % 69) + 186);
    	a1210910088 = (a263638061 + -8); 
    	 printf("%d\n", 17); fflush(stdout); 
    } if((((a778006913 == 2 && (((input == 8) &&  cf==1 ) && a76745981 == 33)) && a2130193413 == 10) && (a709568404 == 33 && (a2026977784 == 8 && a708839806 == 33)))) {
    	cf = 0;
    	a983758263 = ((((((a983758263 * a1774184757) % 14999) - -8871) - -3907) / 5) + 16300);
    	a1625516355 = (((((((a1625516355 * a983758263) % 14999) + -2281) / 5) + 1801) % 37) - 41);
    	a1826277115 = (((((a999024345 * a1675035970) - -2572) - -79) - 26228) + 23748);
    	a813082108 = ((((((a813082108 * a260539918) % 69) + 173) - 28273) * 1) - -28273);
    	a217799639 = (((((a1625516355 * a1625516355) - -14492) % 28) + -43) - 4);
    	a1210910088 = (a1478681170 - 1);
    	a1985899004 = ((((((((a1985899004 * a1826277115) % 14999) % 76) - -420) + -9096) * 3) % 76) - -518);
    	a620105235 = ((((((a30494462 * a1826277115) % 14999) % 94) - 64) + 1) - 1);
    	a1675035970 = (((((a63333937 * a1625516355) / 5) % 51) - -299) - 4);
    	a30494462 = ((((((a30494462 * a260539918) % 85) - -211) - -1) - 19492) + 19490);
    	a2073482783 = 34 ;
    	a190525986 = (a2087535773 + 6);
    	a2026977784 = (a2087535773 + 4);
    	a404763935 = (a2061425267 + 3);
    	a708839806 = 34 ;
    	a26346326 = 34 ;
    	a1916853335 = (a778006913 - -5);
    	a548050643 = 35 ;
    	a2130183577 = (((((((a2130183577 * a1474668405) % 14999) % 12) + 243) / 5) * 51) / 10);
    	a1895304149 = 34 ;
    	a601495656 = 34 ;
    	a999024345 = ((((((a260539918 * a1151361287) % 14999) * 2) % 64) + 195) * 1);
    	a1241576728 = (a1830659124 + -2);
    	a1830659124 = a1240243570;
    	a2130193413 = ((a1249952537 + a1249952537) - -1);
    	a1125477212 = 34 ;
    	a1478681170 = ((a4442917 + a786258498) + -12);
    	a709568404 = 34 ;
    	a778006913 = (a1249952537 + -2);
    	a1211013485 = 34 ;
    	a1959068056 = ((a1210910088 - a721272783) - -23);
    	a2061425267 = (a4442917 + 5);
    	a1318526106 = 34 ;
    	a302110279 = 34 ;
    	a1249952537 = (a1210910088 + 3); 
    	 printf("%d\n", 17); fflush(stdout); 
    } 
}
 void calculate_outputm11(int input) {
    if(((a1211013485 == 33 && (((a1210910088 == 2 && a1249952537 == 5) && a2061425267 == 11) && a1125477212 == 33)) && (( cf==1  && a1474668405 <=  -160) && ((174 < a1985899004) && (371 >= a1985899004))))) {
    	if((((a190525986 == 10 && (((-2 < a1254983042) && (202 >= a1254983042)) && ( cf==1  && a1240243570 == 7))) && a1959068056 == 9) && (((-109 < a1625516355) && (-81 >= a1625516355)) && (a2061425267 == 11 && ((17 < a1018383389) && (167 >= a1018383389)))))) {
    		calculate_outputm124(input);
    	} 
    	if((((a1249952537 == 5 && (a1240243570 == 9 &&  cf==1 )) && ((-135 < a63333937) && (29 >= a63333937))) && (((-62 < a30494462) && (124 >= a30494462)) && (a1125477212 == 33 && (a1644957382 == 33 && a1318526106 == 33))))) {
    		calculate_outputm125(input);
    	} 
    	if((((((171 < a1675035970) && (207 >= a1675035970)) && (a1644957382 == 33 && ( cf==1  && a1240243570 == 10))) && a1318526106 == 33) && (a1211013485 == 33 && (((-62 < a30494462) && (124 >= a30494462)) && ((75 < a1151361287) && (249 >= a1151361287)))))) {
    		calculate_outputm126(input);
    	} 
    	if(((a1478681170 == 4 && a2130193413 == 10) && (((a190525986 == 10 && ((a1240243570 == 11 &&  cf==1 ) && a302110279 == 33)) && a26346326 == 33) && a2026977784 == 8))) {
    		calculate_outputm127(input);
    	} 
    } 
}
 void calculate_outputm132(int input) {
    if(((( cf==1  && (input == 13)) && ((3 < a813082108) && (104 >= a813082108))) && ((((a1249952537 == 5 && a1211013485 == 33) && ((103 < a2130183577) && (230 >= a2130183577))) && a1210910088 == 2) && a786258498 == 9))) {
    	cf = 0;
    	a1180594800 = 32 ;
    	a620105235 = (((((a620105235 * a30494462) - 4448) % 14909) - 15090) * 1);
    	a1211013485 = 32 ;
    	a263151501 = 32 ;
    	a26346326 = 32 ;
    	a778006913 = (a2061425267 + -10);
    	a601495656 = 32 ;
    	a1478681170 = a1700231631;
    	a1151361287 = (((((((a1151361287 * a1018383389) % 14999) - -3171) / 5) * 5) % 86) - -156);
    	a983758263 = ((((((a983758263 * a999024345) - 28736) / 5) + 20307) * -1) / 10);
    	a1213722969 = (a1700231631 - -8);
    	a2130183577 = ((((((a2130183577 * a1774184757) % 14999) - 14966) * 1) - -1259) - 1287);
    	a834646264 = a4442917;
    	a302110279 = 33 ;
    	a999024345 = (((((a1018383389 * a1985899004) % 14999) + -27702) + -2269) * 1);
    	a341216798 = ((((((a983758263 * a983758263) % 14999) / 5) - 9255) + 6845) - 14923);
    	a813082108 = ((((a813082108 * a1675035970) * -1) + -5801) + -363);
    	a30494462 = (((((((a2130183577 * a1625516355) % 14999) % 14969) + -15030) - -29887) * 1) + -29887);
    	a1959068056 = (a4442917 - -2);
    	a1018383389 = ((((((a1018383389 * a2130183577) % 14999) % 74) - -91) + 1) + 1);
    	a1210910088 = a778006913;
    	a786258498 = (a1241576728 - -2);
    	a1895304149 = 32 ;
    	a260539918 = ((((a217799639 * a1625516355) - -1549) - 29354) - 2569);
    	a1830659124 = (a778006913 - -8);
    	a1644957382 = 32 ;
    	a2087535773 = (a778006913 + 2);
    	a4442917 = (a721272783 + -12);
    	a1254983042 = ((((a1254983042 * a1625516355) + 14977) * 1) + -20371);
    	a2073482783 = 32 ;
    	a1675035970 = (((((a1675035970 * a260539918) % 14999) - 11266) - 3590) + 4065);
    	a1625516355 = (((((((a1625516355 * a1985899004) % 14999) - 9055) % 13) - 93) * 9) / 10); 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((((((17 < a1018383389) && (167 >= a1018383389)) && (( cf==1  && (input == 14)) && ((-2 < a1254983042) && (202 >= a1254983042)))) && ((-182 < a620105235) && (-160 >= a620105235))) && ((a786258498 == 9 && a2061425267 == 11) && ((103 < a2130183577) && (230 >= a2130183577))))) {
    	cf = 0;
    	a778006913 = (a190525986 + -7);
    	a190525986 = (a1249952537 + 6);
    	a1644957382 = 34 ;
    	a786258498 = (a778006913 + 7);
    	a1895304149 = 34 ;
    	a1895857334 = (a721272783 + -4);
    	a63333937 = ((((((a1985899004 * a1985899004) % 14999) - -697) % 106) - -135) + -54);
    	a217799639 = (((((a217799639 * a30494462) % 28) + -29) + -1) + 2);
    	a983758263 = ((((((a983758263 * a1774184757) % 14999) - -8651) * 1) % 101) - -304);
    	a1983740902 = 33 ;
    	a813082108 = (((((a260539918 * a999024345) % 69) + 174) / 5) - -163);
    	a2087632595 = 32 ;
    	a30494462 = ((((((a63333937 * a1774184757) % 14999) % 85) + 209) * 1) + 0);
    	a1916853335 = (a2061425267 + -4);
    	a2061425267 = ((a1249952537 + a1700231631) - -4);
    	a999024345 = ((((((a260539918 * a1985899004) % 14999) % 64) - -195) - 9041) + 9041);
    	a620105235 = ((((((a620105235 * a1254983042) % 14999) % 94) - 64) - -1) - 1);
    	a2073482783 = 34 ;
    	a709568404 = 33 ;
    	a263151501 = 34 ;
    	a1959068056 = ((a2026977784 * a786258498) + -80);
    	a1151361287 = ((((((((a1151361287 * a813082108) % 14999) % 20) + 261) * 5) - 23138) % 20) + 275);
    	a80157050 = (a2087535773 + 3);
    	a1241576728 = (a2130193413 + -3);
    	a1210910088 = (a786258498 + -7);
    	a2087535773 = (a778006913 - -2);
    	a2130183577 = (((((((a2130183577 * a1675035970) % 14999) + 4599) + -30016) / 5) % 12) + 252);
    	a4442917 = ((a1241576728 + a1249952537) + -6);
    	a1625516355 = (((((a1625516355 * a1774184757) % 37) + -42) + 16834) - 16833);
    	a1254983042 = (((((a260539918 * a260539918) * 1) + -26018) % 105) + 386);
    	a76745981 = 34 ;
    	a1675035970 = (((((a1018383389 * a260539918) % 51) - -259) - 1) + 1);
    	a1211013485 = 34 ;
    	a1180594800 = 34 ;
    	a708839806 = 33 ;
    	a1018383389 = ((((((a1774184757 * a260539918) - 8161) % 21) + 188) / 5) - -172);
    	a1830659124 = (a4442917 + 4);
    	a26346326 = 34 ;
    	a1318526106 = 34 ;
    	a1249952537 = (a778006913 + 3);
    	a1774184757 = (((((((a1774184757 * a1985899004) % 14999) - 2928) % 66) + 101) / 5) - -92);
    	a1985899004 = (((a1985899004 / 5) / 5) + 485); 
    	 printf("%d\n", 26); fflush(stdout); 
    } if(((((-151 < a1774184757) && (35 >= a1774184757)) && ((((75 < a1151361287) && (249 >= a1151361287)) && (a778006913 == 2 && a1830659124 == 10)) && a1210910088 == 2)) && (a190525986 == 10 && ((input == 10) &&  cf==1 )))) {
    	cf = 0;
    	a983758263 = ((((a983758263 - -8742) * 10) / 9) - 4479);
    	a1826277115 = (((((a983758263 * a983758263) % 14999) - -5635) * 1) - -1495);
    	a1474668405 = (((((((a1675035970 * a1985899004) % 14999) % 46) - -25) - 4) * 10) / 9);
    	a1625516355 = (((((a1625516355 * a1774184757) / 5) % 37) - 42) + 1);
    	a1644957382 = 34 ;
    	a1985899004 = (((((a620105235 * a1474668405) % 76) - -447) / 5) + 347);
    	a190525986 = a2061425267;
    	a4442917 = (a1210910088 + 5);
    	a1249952537 = (a786258498 + -3);
    	a404763935 = (a1830659124 - -2);
    	a999024345 = ((((((a999024345 * a30494462) % 64) + 195) / 5) * 51) / 10);
    	a778006913 = ((a2087535773 * a190525986) + -41);
    	a1151361287 = ((((((a1151361287 * a1254983042) % 14999) % 20) - -270) / 5) * 5);
    	a2087535773 = (a190525986 + -6);
    	a1830659124 = ((a2026977784 - a2130193413) - -13);
    	a786258498 = ((a2026977784 - a1700231631) - -4);
    	a263151501 = 34 ;
    	a1254983042 = (((((a1254983042 * a1625516355) % 105) - -307) - 12847) - -12849); 
    	 printf("%d\n", 20); fflush(stdout); 
    } 
}
 void calculate_outputm133(int input) {
    if(((((174 < a1985899004) && (371 >= a1985899004)) && (((-62 < a30494462) && (124 >= a30494462)) && (a2026977784 == 8 && a2130193413 == 10))) && (a778006913 == 2 && (((103 < a2130183577) && (230 >= a2130183577)) && ( cf==1  && (input == 6)))))) {
    	cf = 0;
    	a709568404 = 32 ;
    	a813082108 = (((((((a217799639 * a1151361287) % 14999) + -2736) * 10) / 9) + 18482) + -21922);
    	a1211013485 = 34 ;
    	a1018383389 = (((((((a1985899004 * a1625516355) % 14999) % 21) - -190) / 5) - -7878) - 7729);
    	a302110279 = 32 ;
    	a1916853335 = ((a190525986 + a1959068056) + -12);
    	a263151501 = 34 ;
    	a260539918 = (((((a999024345 * a1625516355) - 2483) - 8848) * 10) / 9);
    	a2087535773 = ((a4442917 - a1959068056) - -8);
    	a786258498 = (a778006913 + 8);
    	a1241576728 = a2026977784; 
    	 printf("%d\n", 20); fflush(stdout); 
    } if(((((((-182 < a620105235) && (-160 >= a620105235)) && (a76745981 == 33 && a1125477212 == 33)) && ((-135 < a63333937) && (29 >= a63333937))) && a4442917 == 6) && (a2026977784 == 8 && ((input == 12) &&  cf==1 )))) {
    	cf = 0;
    	a302110279 = 34 ;
    	a1125477212 = 34 ;
    	a1151361287 = ((((((a1151361287 * a1254983042) % 14999) * 2) % 20) + 270) + -1);
    	a260539918 = ((((((a1151361287 * a1151361287) % 14999) + 1350) % 73) + -4) - 2);
    	a1895857334 = (a778006913 + 9);
    	a63333937 = ((((((a63333937 * a1151361287) % 14999) % 106) - -137) - -1) - 3);
    	a4442917 = (a1241576728 + -1);
    	a1644957382 = 34 ;
    	a217799639 = (((((((a217799639 * a1151361287) % 14999) % 28) + -29) - 2) / 5) - 34);
    	a1985899004 = ((((((((a1985899004 * a1774184757) % 14999) % 76) + 448) * 5) + -16099) % 76) - -514);
    	a1254983042 = (((((((a620105235 * a2130183577) % 14999) / 5) + -22831) - -41318) % 105) + 299);
    	a601495656 = 34 ;
    	a2061425267 = (a4442917 - -5);
    	a1574467713 = (a1895857334 + -10);
    	a2130193413 = ((a1210910088 - a4442917) - -16);
    	a1210910088 = ((a1916853335 * a1895857334) - 74);
    	a983758263 = ((((a983758263 - 14066) % 101) + 405) - 36);
    	a1983740902 = 34 ;
    	a263638061 = a1895857334;
    	a1180594800 = 34 ;
    	a813082108 = (((((((a1151361287 * a1151361287) % 14999) % 69) + 119) * 9) / 10) * 1);
    	a2130183577 = ((((((a2130183577 * a1675035970) % 14999) / 5) - 6935) % 12) - -248);
    	a26346326 = 34 ;
    	a1830659124 = (a190525986 + 1);
    	a708839806 = 34 ;
    	a620105235 = ((((((((a620105235 * a983758263) % 14999) % 94) - 65) - -2) * 5) % 94) + -65);
    	a1959068056 = ((a1249952537 - a778006913) + 7);
    	a1249952537 = (a190525986 - 4);
    	a1675035970 = (((((((a1675035970 * a999024345) / 5) % 51) + 208) * 5) % 51) - -230);
    	a1318526106 = 34 ;
    	a778006913 = (a786258498 - 7);
    	a999024345 = ((((((a1151361287 * a1625516355) % 14999) + 2719) % 64) + 196) - 1);
    	a30494462 = ((((((a30494462 * a1151361287) % 14999) % 85) - -210) / 5) + 174);
    	a1478681170 = (a2026977784 + -3);
    	a2073482783 = 34 ;
    	a709568404 = 34 ;
    	a1625516355 = ((((((a1625516355 * a1151361287) % 14999) % 37) + -43) - -27310) - 27309);
    	a1895304149 = 34 ;
    	a190525986 = (a2061425267 - 1);
    	a2026977784 = (a1895857334 + -2); 
    	 printf("%d\n", 16); fflush(stdout); 
    } if(((a1125477212 == 33 && (((48 < a999024345) && (131 >= a999024345)) && (((input == 13) &&  cf==1 ) && a190525986 == 10))) && (a1318526106 == 33 && (((-109 < a1625516355) && (-81 >= a1625516355)) && a1180594800 == 33)))) {
    	a456906074 += (a456906074 + 20) > a456906074 ? 3 : 0;
    	cf = 0;
    	a778006913 = (a721272783 + -16);
    	a1959068056 = (a190525986 - 2);
    	a63333937 = (((((a1774184757 * a30494462) * 1) - -4377) - -1495) + -16033);
    	a2073482783 = 32 ;
    	a1644957382 = 32 ;
    	a1895304149 = 32 ;
    	a1125477212 = 32 ;
    	a341216798 = ((((a1774184757 * a1774184757) - -6580) + -2723) + 2217);
    	a1318526106 = 32 ;
    	a217799639 = (((((a217799639 * a620105235) % 14999) + -27275) + -284) - 1455);
    	a999024345 = ((((((a620105235 * a620105235) % 14999) + -23476) - 351) * 10) / 9);
    	a601495656 = 32 ;
    	a965340096 = 32 ;
    	a1985899004 = ((((((a1774184757 * a620105235) % 15087) + -14912) - 2) - -6360) - 6359);
    	a1675035970 = (((((a1675035970 * a620105235) % 14999) + -3475) / 5) * 5);
    	a1180594800 = 32 ;
    	a1241576728 = ((a2026977784 / a2026977784) + 5);
    	a983758263 = (((((((a983758263 * a341216798) % 14999) % 14997) - 15002) - -19774) - 12417) + -7357);
    	a1151361287 = ((((((a1151361287 * a999024345) % 14999) / 5) - 5813) + 24906) * -1);
    	a1625516355 = ((((((a1985899004 * a217799639) % 14999) * 2) + 3) / 5) + -18777);
    	a2026977784 = (a721272783 - 10);
    	a1521644128 = (a1210910088 + 3);
    	a2087535773 = (a1478681170 - 1);
    	a1916853335 = (a778006913 - -4);
    	a1210910088 = ((a721272783 - a778006913) + -15);
    	a26346326 = 32 ;
    	a1254983042 = ((((((a1254983042 * a63333937) % 14999) - 15000) - 0) + 12684) - 12685);
    	a708839806 = 32 ;
    	a2061425267 = (a1700231631 + 7);
    	a76745981 = 32 ;
    	a786258498 = (a778006913 + 7);
    	a1211013485 = 32 ;
    	a1830659124 = ((a721272783 + a721272783) + -25);
    	a4442917 = (a721272783 + -12);
    	a2130193413 = ((a1249952537 - a1249952537) + 9);
    	a30494462 = ((((((a30494462 * a1675035970) % 14999) % 14969) + -15030) * 1) * 1);
    	a2130183577 = (((((a2130183577 * a1625516355) % 14999) / 5) + -25212) + -1318);
    	a1478681170 = (a778006913 + 4);
    	a190525986 = (a4442917 + 4);
    	a1249952537 = (a778006913 - -3);
    	a263151501 = 32 ;
    	a1774184757 = ((((((a1774184757 * a620105235) % 14924) + -15074) + -1) / 5) + -11518);
    	a620105235 = ((((((a620105235 * 12) / 10) + -22680) + 28330) * -1) / 10); 
    	 printf("%d\n", 18); fflush(stdout); 
    } if(((a708839806 == 33 && a601495656 == 33) && ((((75 < a1151361287) && (249 >= a1151361287)) && (((-2 < a1254983042) && (202 >= a1254983042)) && (((input == 15) &&  cf==1 ) && a1983740902 == 33))) && a778006913 == 2))) {
    	cf = 0;
    	a1241576728 = 6;
    	a217799639 = ((((((a217799639 * a813082108) % 14999) % 14901) - 15098) + -2) - 0);
    	a601495656 = 34 ;
    	a1210910088 = (a721272783 - 14);
    	a1125477212 = 34 ;
    	a2073482783 = 32 ;
    	a2087535773 = (a1241576728 + -3);
    	a1895304149 = 32 ;
    	a1180594800 = 32 ;
    	a620105235 = ((((((a620105235 * a217799639) % 14999) + -23303) * 1) % 94) + -48);
    	a1959068056 = ((a4442917 / a2087535773) - -6);
    	a1625516355 = ((((a1625516355 * a999024345) * 2) / 5) * 5);
    	a1211013485 = 32 ;
    	a263151501 = 32 ;
    	a1983740902 = 32 ;
    	a2130183577 = ((((((a1985899004 * a1151361287) % 14999) + 10428) + 216) * 1) + -28438);
    	a786258498 = (a1241576728 + 2);
    	a2061425267 = (a4442917 - -6);
    	a190525986 = (a2026977784 + 1);
    	a778006913 = (a786258498 + -7);
    	a983758263 = (((a983758263 - 10591) + -795) * 2);
    	a2026977784 = ((a1700231631 - a1700231631) - -7);
    	a1521644128 = (a1249952537 + -1);
    	a1254983042 = (((((a1254983042 * a2130183577) % 14999) - 15000) - 0) * 1);
    	a76745981 = 32 ;
    	a341216798 = (((((a1675035970 * a1985899004) % 14999) - -6408) + 8336) - -102);
    	a30494462 = (((((a30494462 * a999024345) + 7158) - 25884) * 10) / 9);
    	a63333937 = ((((((a63333937 * a1985899004) % 14999) + 13495) * 1) % 14932) + -15066);
    	a999024345 = ((((((a217799639 * a217799639) % 14999) - 20285) * 10) / 9) * 1);
    	a26346326 = 34 ;
    	a2130193413 = (a1830659124 - 1);
    	a1830659124 = ((a778006913 + a1241576728) + 2);
    	a1550739565 = (a1478681170 - -7);
    	a1478681170 = (a1241576728 - 1);
    	a1151361287 = (((((a1151361287 * a1774184757) % 14999) + -14991) + -4) / 5);
    	a1774184757 = ((((((a1774184757 * a260539918) % 14999) % 14924) + -15074) + 0) - 0);
    	a708839806 = 34 ;
    	a1249952537 = a1241576728;
    	a4442917 = (a786258498 + -3);
    	a1675035970 = ((((((a1675035970 * a1985899004) % 14999) + -20277) * 1) * 10) / 9);
    	a1985899004 = (((((a1985899004 * a217799639) % 14999) + -9751) / 5) * 5); 
    	 printf("%d\n", 18); fflush(stdout); 
    } 
}
 void calculate_outputm134(int input) {
    if(((((174 < a1985899004) && (371 >= a1985899004)) && (((48 < a999024345) && (131 >= a999024345)) && ((75 < a1151361287) && (249 >= a1151361287)))) && (a1210910088 == 2 && (((-151 < a1774184757) && (35 >= a1774184757)) && (((input == 6) &&  cf==1 ) && a1180594800 == 33))))) {
    	cf = 0;
    	a2061425267 = ((a1241576728 * a1210910088) + -2);
    	a983758263 = (((a983758263 + 22091) * 1) * 1);
    	a1644957382 = 34 ;
    	a1675035970 = ((((((a1675035970 * a983758263) % 14999) - 9362) % 51) - -260) + -2);
    	a1478681170 = (a1210910088 + 3);
    	a999024345 = ((((((a217799639 * a217799639) % 14999) % 64) + 174) * 5) / 5);
    	a190525986 = ((a1241576728 - a2026977784) - -13);
    	a1318526106 = 34 ;
    	a2130183577 = ((((((a2130183577 * a1151361287) % 14999) - -5105) % 12) - -239) + 4);
    	a708839806 = 34 ;
    	a2087535773 = (a2026977784 + -4);
    	a1983740902 = 34 ;
    	a1826277115 = ((((a813082108 * a260539918) + 13350) / 5) - -6575);
    	a1959068056 = a2130193413;
    	a4442917 = ((a721272783 + a1249952537) - 15);
    	a404763935 = (a1210910088 - -12);
    	a26346326 = 34 ;
    	a2073482783 = 34 ;
    	a601495656 = 34 ;
    	a260539918 = (((((((a30494462 * a1151361287) % 14999) % 73) - -65) - 0) - 17209) - -17211);
    	a548050643 = 35 ;
    	a1180594800 = 34 ;
    	a786258498 = (a1700231631 + a1478681170);
    	a709568404 = 34 ;
    	a1125477212 = 34 ;
    	a1985899004 = (((((((a30494462 * a1151361287) % 14999) % 76) + 448) * 5) % 76) - -392);
    	a1211013485 = 34 ;
    	a1895304149 = 34 ;
    	a813082108 = (((((((a217799639 * a1018383389) % 14999) + 26659) - 6633) * 1) % 69) + 112);
    	a63333937 = (((((((a1826277115 * a1625516355) % 14999) % 106) + 135) + -13695) + 35824) - 22128);
    	a778006913 = (a786258498 - 7);
    	a620105235 = ((((((a1151361287 * a1151361287) % 14999) + -24752) % 94) - -15) + 15);
    	a1830659124 = (a1210910088 - -9);
    	a263151501 = 34 ;
    	a1249952537 = ((a1210910088 / a2130193413) + 6);
    	a2130193413 = (a1210910088 - -9);
    	a1625516355 = ((((((a1985899004 * a30494462) % 14999) % 37) + -42) / 5) * 5);
    	a1254983042 = ((((((((a1675035970 * a983758263) % 14999) % 105) - -248) * 9) / 10) + -411) - -424);
    	a1241576728 = (a4442917 + 1);
    	a30494462 = (((((a30494462 * a1774184757) - 8990) - -21197) % 85) - -209);
    	a1151361287 = ((((((a1151361287 * a999024345) % 14999) % 20) - -253) + -2) - -19);
    	a217799639 = (((((a217799639 * a1774184757) - -412) - -21) % 28) - 30);
    	a1210910088 = (a1916853335 + -4); 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((((((input == 8) &&  cf==1 ) && ((103 < a2130183577) && (230 >= a2130183577))) && ((75 < a1151361287) && (249 >= a1151361287))) && a2073482783 == 33) && (a1895304149 == 33 && (a1830659124 == 10 && ((17 < a1018383389) && (167 >= a1018383389)))))) {
    	a295012665 += (a295012665 + 20) > a295012665 ? 3 : 0;
    	cf = 0;
    	a2087535773 = (a2061425267 + -8);
    	a983758263 = (((a983758263 - 8726) + -3781) * 2);
    	a1895304149 = 32 ;
    	a2073482783 = 32 ;
    	a302110279 = 33 ;
    	a1018383389 = ((((((a1018383389 * a260539918) % 74) - -117) + -3) - 124) + 162);
    	a2130183577 = (((((a2130183577 * a217799639) % 14999) - 1147) * 1) / 5);
    	a341216798 = ((((a1675035970 * a1625516355) - 5905) + -609) / 5);
    	a834646264 = ((a2130193413 + a2130193413) - 14);
    	a1241576728 = (a190525986 + -4);
    	a1213722969 = (a1478681170 - -7);
    	a601495656 = 32 ;
    	a1478681170 = ((a1959068056 * a1959068056) + -61);
    	a999024345 = ((((((a999024345 * a63333937) % 14999) + -6488) - -35339) - -1028) * -1);
    	a708839806 = 32 ;
    	a1318526106 = 32 ;
    	a1830659124 = (a2087535773 + 6);
    	a1675035970 = ((((((a1985899004 * a813082108) % 14999) - 14382) - -18129) / 5) - 13038);
    	a813082108 = ((((a813082108 * a1151361287) + -26285) - 171) - 430);
    	a1644957382 = 32 ;
    	a263151501 = 32 ;
    	a76745981 = 32 ;
    	a1210910088 = (a1249952537 - 4);
    	a1625516355 = (((((((a1151361287 * a983758263) % 14999) % 13) + -94) + -9433) / 5) - -1804);
    	a30494462 = ((((((a30494462 * a620105235) % 14999) % 14969) + -15030) * 1) - 1);
    	a1180594800 = 32 ;
    	a26346326 = 32 ;
    	a260539918 = ((((((a260539918 * a341216798) % 14999) % 14978) + -15021) - 1) * 1);
    	a1151361287 = ((((((((a1151361287 * a1774184757) % 14999) % 86) - -161) + -6416) + 8411) * 1) / 10); 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((((((input == 15) &&  cf==1 ) && a2061425267 == 11) && a1318526106 == 33) && ((-198 < a217799639) && (-59 >= a217799639))) && (a26346326 == 33 && (((3 < a813082108) && (104 >= a813082108)) && a2087535773 == 4)))) {
    	cf = 0;
    	a2130183577 = ((((a1018383389 * a1018383389) + -1235) - 6730) - 21359);
    	a2026977784 = (a1700231631 + 2);
    	a1644957382 = 32 ;
    	a26346326 = 32 ;
    	a2087535773 = (a2130193413 - 7);
    	a2073482783 = 32 ;
    	a1916853335 = ((a2130193413 + a1700231631) - 10);
    	a1241576728 = (a1916853335 - -1);
    	a1625516355 = (((((a1625516355 * a260539918) + -8905) * 10) / 9) * 3);
    	a1180594800 = 32 ;
    	a30494462 = ((((a30494462 * a813082108) + -19614) * 1) - 455);
    	a190525986 = ((a778006913 - a2087535773) + 11);
    	a999024345 = (((((a63333937 * a620105235) % 14999) - 19183) * 1) * 1);
    	a1985899004 = (((((a1985899004 * a2130183577) % 14999) + -14863) - 20) + -86);
    	a341216798 = ((((((a983758263 * a983758263) % 14999) % 14850) - -15148) - 0) - -1);
    	a983758263 = ((((((a983758263 * a341216798) % 14999) % 14997) + -15002) * 1) * 1);
    	a708839806 = 32 ;
    	a1318526106 = 32 ;
    	a263151501 = 32 ;
    	a1774184757 = ((((((a1774184757 * a999024345) % 14999) * 2) % 14924) + -15074) + -2);
    	a1895304149 = 32 ;
    	a1151361287 = (((((a1151361287 * a620105235) % 14999) - 705) - -11869) + -22946);
    	a601495656 = 32 ;
    	a302110279 = 32 ;
    	a1018383389 = ((((((a1018383389 * a260539918) % 21) + 206) + -18588) - 6235) + 24819);
    	a76745981 = 32 ;
    	a1210910088 = ((a1478681170 + a4442917) - 8);
    	a1521644128 = (a1830659124 + -5);
    	a2061425267 = ((a1700231631 / a2130193413) - -10);
    	a1478681170 = a1700231631;
    	a217799639 = (((((a217799639 * a1675035970) % 14999) + -7173) / 5) * 5);
    	a813082108 = (((((a63333937 * a260539918) % 14999) + -29997) / 5) / 5);
    	a1675035970 = ((((((a1151361287 * a260539918) % 14999) + -6493) * 1) + -1264) + -7080);
    	a2130193413 = ((a2061425267 - a2061425267) - -9);
    	a1125477212 = 32 ;
    	a965340096 = 32 ;
    	a1249952537 = (a2026977784 + -3);
    	a1830659124 = (a721272783 + -8);
    	a260539918 = (((((((a260539918 * a620105235) % 14999) - 22101) - -24072) / 5) * -2) / 10); 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm136(int input) {
    if((((((a709568404 == 33 && a76745981 == 33) && ((3 < a813082108) && (104 >= a813082108))) && a190525986 == 10) && ((-151 < a1774184757) && (35 >= a1774184757))) && (a302110279 == 33 && ( cf==1  && (input == 1))))) {
    	cf = 0;
    	a2073482783 = 34 ;
    	a983758263 = (((((((a983758263 * a1675035970) % 14999) - 2788) / 5) * 5) % 14796) - -15202);
    	a2087535773 = (a1210910088 + 3);
    	a709568404 = 34 ;
    	a620105235 = ((((((a983758263 * a63333937) % 14999) * 2) - 3) % 94) - 63);
    	a1211013485 = 34 ;
    	a2130183577 = ((((((((a983758263 * a63333937) % 14999) + -7191) % 12) + 242) * 5) % 12) - -235);
    	a404763935 = ((a786258498 * a1249952537) - 32);
    	a76745981 = 34 ;
    	a1830659124 = ((a778006913 / a1241576728) + 11);
    	a190525986 = a2130193413;
    	a2026977784 = (a2130193413 - 2);
    	a786258498 = a1959068056;
    	a1916853335 = (a2130193413 + -4);
    	a1254983042 = (((((((a1254983042 * a620105235) % 14999) % 105) - -309) - 2) - 9844) + 9846);
    	a1644957382 = 34 ;
    	a601495656 = 34 ;
    	a26346326 = 34 ;
    	a1249952537 = (a4442917 + -1);
    	a813082108 = (((((a813082108 * a1625516355) + -7365) / 5) % 69) - -186);
    	a302110279 = 34 ;
    	a217799639 = ((((((a217799639 * a983758263) % 14999) - 889) % 28) - 27) + 1);
    	a1151361287 = ((((((a983758263 * a1774184757) % 14999) - -11648) + -13796) % 20) - -269);
    	a1125477212 = 34 ;
    	a1895304149 = 34 ;
    	a30494462 = (((((((a30494462 * a983758263) % 14999) * 2) / 5) + 22937) % 85) + 200);
    	a1826277115 = ((((((a983758263 * a983758263) % 14999) + 5822) * 10) / 9) - -5454);
    	a1625516355 = (((((((a2130183577 * a620105235) % 14999) + 10188) % 37) - 42) - -20108) + -20109);
    	a999024345 = (((((((a999024345 * a983758263) % 14999) - 19919) - 8528) + -1531) % 64) - -254);
    	a1983740902 = 34 ;
    	a1210910088 = (a2087535773 + -2);
    	a1774184757 = (((((((a1774184757 * a1151361287) % 14999) * 2) - 1) + -1) % 66) + 103);
    	a34679179 = ((((((a1826277115 * a983758263) % 14999) + 6561) + -35791) % 46) + 2);
    	a1675035970 = (((((((a1675035970 * a983758263) % 14999) % 51) - -224) * 5) % 51) - -245);
    	a63333937 = (((((((a63333937 * a983758263) % 14999) % 106) + 137) - 22179) / 5) + 4534); 
    	 printf("%d\n", 17); fflush(stdout); 
    } if((((((input == 14) &&  cf==1 ) && a1210910088 == 2) && a302110279 == 33) && (((a1916853335 == 6 && a2087535773 == 4) && ((-109 < a1625516355) && (-81 >= a1625516355))) && a1211013485 == 33))) {
    	cf = 0;
    	a1959068056 = 8;
    	a708839806 = 32 ;
    	a778006913 = (a1959068056 + -7);
    	a76745981 = 32 ;
    	a30494462 = ((((a999024345 * a63333937) + -11398) + -327) + -602);
    	a1151361287 = (((((a1151361287 * a30494462) % 14999) - -16229) * 1) + -27631);
    	a1478681170 = ((a778006913 * a778006913) + 2);
    	a1318526106 = 32 ;
    	a4442917 = (a778006913 + 4);
    	a104481388 = ((a1249952537 + a1249952537) - -6);
    	a601495656 = 32 ;
    	a217799639 = ((((((a217799639 * a620105235) % 14999) - 19133) * 1) * 10) / 9);
    	a1210910088 = ((a778006913 / a786258498) - -3);
    	a983758263 = (((a983758263 * 5) + -29400) + -11);
    	a341216798 = (((((a1774184757 * a999024345) % 18) - -215) - -2) * 1);
    	a1625516355 = ((((((a1675035970 * a620105235) % 14999) + -5028) * 10) / 9) + -2262);
    	a26346326 = 32 ;
    	a1675035970 = (((((((a1675035970 * a2130183577) % 14999) - -1837) % 51) - -238) * 9) / 10);
    	a1254983042 = (((((a1254983042 * a63333937) % 14999) + -15000) + 26140) - 26141);
    	a2061425267 = (a1959068056 - -2);
    	a1916853335 = ((a721272783 / a2026977784) + 3);
    	a1895304149 = 32 ;
    	a2130183577 = ((((((a30494462 * a999024345) % 14999) - 9665) * 10) / 9) * 1);
    	a1830659124 = ((a2061425267 + a2026977784) - 9);
    	a1249952537 = (a1478681170 - -3);
    	a1211013485 = 32 ;
    	a1774184757 = ((((((a1774184757 * a1625516355) % 14999) / 5) % 66) + 101) * 1);
    	a2073482783 = 32 ;
    	a1305578599 = 33 ;
    	a813082108 = ((((((a813082108 * a63333937) / 5) + -5902) / 5) % 69) + 203);
    	a63333937 = (((((a999024345 * a999024345) * 10) / -9) - 8239) - 2556);
    	a786258498 = (a1700231631 - -4);
    	a1241576728 = (a1478681170 + 3);
    	a190525986 = (a2026977784 + 1);
    	a2026977784 = (a1916853335 + 4);
    	a1125477212 = 32 ;
    	a2087535773 = (a1241576728 + -3);
    	a1983740902 = 34 ;
    	a709568404 = 32 ;
    	a999024345 = ((((((a999024345 * a30494462) % 14999) - 7911) % 64) - -239) + 10); 
    	 printf("%d\n", 20); fflush(stdout); 
    } if(((((((-182 < a620105235) && (-160 >= a620105235)) && (((-151 < a1774184757) && (35 >= a1774184757)) && ((-135 < a63333937) && (29 >= a63333937)))) && a1211013485 == 33) && a1895304149 == 33) && (a786258498 == 9 && ((input == 15) &&  cf==1 )))) {
    	cf = 0;
    	a2073482783 = 34 ;
    	a1830659124 = (a4442917 - -4);
    	a708839806 = 33 ;
    	a76745981 = 34 ;
    	a260339255 = (((((a2130183577 * a999024345) % 14999) + 11600) + -22693) - -24725);
    	a1254983042 = ((((((a1254983042 * a1018383389) % 14999) * 2) % 105) - -309) + -2);
    	a26346326 = 34 ;
    	a2087535773 = (a4442917 - 2);
    	a813082108 = ((((((a813082108 * a1151361287) - -1698) + -4035) * 1) % 69) + 173);
    	a1774184757 = (((((a1774184757 * a63333937) - -9876) - 12118) % 66) - -103);
    	a2041520547 = 33 ;
    	a1478681170 = ((a721272783 + a2087535773) + -18);
    	a778006913 = (a1916853335 + -4);
    	a1249952537 = ((a1959068056 + a1830659124) - 15);
    	a190525986 = (a2061425267 + -1);
    	a1895304149 = 34 ;
    	a983758263 = (((((((a983758263 * a260339255) % 14999) % 101) + 304) - -1) + -24464) - -24463);
    	a2026977784 = a786258498;
    	a1895857334 = (a1700231631 - -6);
    	a1210910088 = ((a2087535773 + a1830659124) + -13);
    	a217799639 = ((((((a217799639 * a260539918) % 28) - 30) * 9) / 10) + -5);
    	a30494462 = (((((((a30494462 * a1985899004) % 14999) - 5217) / 5) / 5) % 85) - -211);
    	a999024345 = ((((((a1675035970 * a620105235) % 14999) % 64) - -195) + 0) + 2);
    	a786258498 = (a2061425267 - 2); 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm137(int input) {
    if(((( cf==1  && (input == 4)) && a778006913 == 2) && (a76745981 == 33 && ((((75 < a1151361287) && (249 >= a1151361287)) && (a2130193413 == 10 && ((-109 < a1625516355) && (-81 >= a1625516355)))) && a190525986 == 10)))) {
    	cf = 0;
    	a247580515 = 34 ;
    	a1625516355 = ((((((a1018383389 * a999024345) % 14999) % 37) - 75) + -4) - 1);
    	a76745981 = 32 ;
    	a620105235 = (((((a620105235 * a30494462) % 94) - 65) + -23534) + 23535);
    	a1644957382 = 34 ;
    	a263151501 = 34 ;
    	a217799639 = ((((((a217799639 * a1625516355) / 5) * 5) - -12295) % 28) + -47);
    	a1675035970 = (((((((a1675035970 * a2130183577) % 14999) / 5) % 51) - -224) * 10) / 9);
    	a1125477212 = 34 ;
    	a2087535773 = (a2061425267 - 7);
    	a404763935 = (a721272783 - 10);
    	a1983740902 = 34 ;
    	a1895304149 = 34 ;
    	a1826277115 = ((((((a983758263 * a983758263) % 14999) % 14910) - -15088) + 0) * 1);
    	a2073482783 = 34 ;
    	a1151361287 = ((((((a1151361287 * a813082108) % 14999) / 5) + 18720) % 20) - -271);
    	a778006913 = ((a834646264 / a1700231631) + 2);
    	a1830659124 = ((a190525986 + a2061425267) - 11);
    	a26346326 = 32 ;
    	a30494462 = ((((((a1625516355 * a1625516355) * 4) - 22974) - 6626) % 85) + 244);
    	a1210910088 = (a786258498 - 7);
    	a983758263 = ((((a983758263 * a260539918) * 3) - -28839) / 5);
    	a1180594800 = 34 ;
    	a709568404 = 34 ;
    	a260539918 = ((((((a1625516355 * a1774184757) / 5) * 5) + 6850) % 73) - -66);
    	a190525986 = ((a786258498 + a1249952537) - 5);
    	a4442917 = (a778006913 + 4);
    	a2130183577 = ((((((a2130183577 * a1985899004) % 14999) - -12649) % 12) - -238) * 1); 
    	 printf("%d\n", 19); fflush(stdout); 
    } 
}
 void calculate_outputm138(int input) {
    if(((((-2 < a1254983042) && (202 >= a1254983042)) && ((a26346326 == 33 && ((17 < a1018383389) && (167 >= a1018383389))) && a1249952537 == 5)) && (a1125477212 == 33 && (a2130193413 == 10 && ( cf==1  && (input == 6)))))) {
    	a295012665 += (a295012665 + 20) > a295012665 ? 1 : 0;
    	cf = 0;
    	a1574467713 = ((a778006913 - a786258498) - -11);
    	a263151501 = 33 ;
    	a1830659124 = (a1916853335 - -5);
    	a2026977784 = (a1830659124 - 2);
    	a709568404 = 33 ;
    	a786258498 = ((a2130193413 - a190525986) + 9);
    	a1964635488 = 36 ;
    	a1895857334 = ((a190525986 - a1210910088) - -3);
    	a76745981 = 34 ;
    	a302110279 = 34 ;
    	a2073482783 = 33 ;
    	a1895304149 = 34 ;
    	a1644957382 = 34 ;
    	a1254983042 = (((((a1254983042 * a1625516355) - 5460) / 5) % 105) - -410);
    	a1211013485 = 34 ;
    	a1774184757 = (((((((a1774184757 * a260539918) % 66) + 101) * 5) - 792) % 66) - -103);
    	a983758263 = ((((((a983758263 * a1985899004) % 14999) * 2) % 101) + 304) + 1);
    	a1151361287 = ((((((a1151361287 * a2130183577) % 14999) - -2446) - 22415) % 20) + 276);
    	a217799639 = (((((a217799639 * a1625516355) % 69) - 166) - -11772) + -11756);
    	a1125477212 = 33 ;
    	a1983740902 = 33 ;
    	a601495656 = 34 ;
    	a30494462 = (((((a30494462 * a620105235) / 5) * 5) % 85) - -209);
    	a1210910088 = (a1241576728 - 4);
    	a620105235 = (((((((a620105235 * a983758263) % 14999) + 23158) - -920) * 1) % 10) - 170);
    	a63333937 = (((((((a63333937 * a1625516355) % 81) - 52) + -1) * 5) % 81) - 51);
    	a1241576728 = ((a1830659124 / a2130193413) - -6);
    	a1478681170 = (a1574467713 - -1);
    	a1675035970 = ((((((((a1675035970 * a2130183577) % 14999) % 17) + 184) - 5) * 5) % 17) - -176);
    	a1985899004 = (((((((a1985899004 * a2130183577) % 14999) - -12719) % 98) + 177) - -24703) + -24687);
    	a1916853335 = (a2061425267 - 5);
    	a999024345 = (((((((a1254983042 * a813082108) % 14999) + -24590) % 64) + 217) + 16187) + -16208);
    	a778006913 = ((a4442917 * a2087535773) - 32);
    	a1018383389 = ((((((((a1018383389 * a1151361287) % 14999) % 74) - -65) * 9) / 10) + 15967) + -15959);
    	a2130183577 = (((((a2130183577 * a1625516355) - -37988) % 12) + 240) - -3);
    	a1249952537 = (a190525986 + -4);
    	a26346326 = 33 ;
    	a813082108 = ((((((a813082108 * a999024345) / 5) + 12338) / 5) % 69) - -115);
    	a2130193413 = ((a1830659124 + a1830659124) - 11);
    	a2061425267 = (a4442917 + 5);
    	a1625516355 = (((((((a1625516355 * a1151361287) % 14999) + 7413) % 37) + -42) + 14499) + -14498);
    	a190525986 = ((a1959068056 + a1959068056) - 9); 
    	 printf("%d\n", 20); fflush(stdout); 
    } if(((((-182 < a620105235) && (-160 >= a620105235)) && (((103 < a2130183577) && (230 >= a2130183577)) && ((-198 < a217799639) && (-59 >= a217799639)))) && (((a190525986 == 10 && ( cf==1  && (input == 9))) && a2073482783 == 33) && a1249952537 == 5))) {
    	cf = 0;
    	a358386401 = (a2061425267 - 9);
    	a1826277115 = (((((((a983758263 * a983758263) % 14999) % 62) + 116) + 18539) - 27263) - -8724);
    	a1774184757 = ((((((a1774184757 * a1254983042) % 14999) + -10680) * 1) % 66) + 101);
    	a302110279 = 32 ;
    	a2061425267 = (a358386401 + 10);
    	a999024345 = (((((((a1018383389 * a620105235) % 14999) - 10881) % 64) + 230) * 10) / 9);
    	a708839806 = 34 ;
    	a1241576728 = (a2130193413 - 2);
    	a1211013485 = 32 ;
    	a63333937 = (((((((a63333937 * a999024345) % 14999) / 5) + -13962) / 5) % 106) - -172);
    	a263151501 = 34 ;
    	a2130193413 = (a1830659124 - 1);
    	a778006913 = ((a1700231631 + a2061425267) + -16);
    	a26346326 = 34 ;
    	a2073482783 = 34 ;
    	a217799639 = ((((((((a217799639 * a1675035970) % 14999) % 28) - 28) * 5) * 5) % 28) - 29);
    	a709568404 = 32 ;
    	a1125477212 = 34 ;
    	a30494462 = ((((((a30494462 * a1826277115) % 85) - -211) - -6362) - -20482) + -26845);
    	a601495656 = 34 ;
    	a1644957382 = 34 ;
    	a1210910088 = ((a4442917 - a1959068056) + 6);
    	a1895304149 = 34 ;
    	a1625516355 = (((((((a1625516355 * a260539918) % 37) + -41) * 5) + -26361) % 37) - 9);
    	a2130183577 = ((((((a2130183577 * a1985899004) % 14999) + -6318) * 3) % 12) + 242);
    	a1916853335 = (a190525986 + -3);
    	a983758263 = (((((((a983758263 * a1826277115) % 14999) % 14796) + 15202) + 0) - 27556) - -27559);
    	a620105235 = (((((((a260539918 * a217799639) % 94) - 64) + -1) * 5) % 94) - 64);
    	a813082108 = (((((a813082108 * a1151361287) * 1) * 1) % 69) + 122);
    	a1151361287 = ((((((a30494462 * a2130183577) % 14999) - 21705) / 5) + 2730) + -13426);
    	a786258498 = ((a1916853335 - a834646264) - -12);
    	a2087535773 = ((a2061425267 * a721272783) + -201);
    	a1985899004 = (((((a2130183577 * a1826277115) % 14999) + -7218) - 20600) / 5);
    	a190525986 = ((a721272783 * a1210910088) + -42);
    	a965340096 = 36 ;
    	a1830659124 = (a1249952537 - -4);
    	a1983740902 = 32 ;
    	a1249952537 = ((a2061425267 + a1478681170) - 11);
    	a1675035970 = ((((((((a1675035970 * a1018383389) % 14999) / 5) % 51) - -245) / 5) * 45) / 10);
    	a1018383389 = ((((((a1018383389 * a260539918) * 1) + -14914) - 13742) % 21) - -200);
    	a2026977784 = (a1241576728 - 1);
    	a1254983042 = ((((a1254983042 * a260539918) * 1) - 28505) + -2); 
    	 printf("%d\n", 16); fflush(stdout); 
    } if(((a1249952537 == 5 && (((171 < a1675035970) && (207 >= a1675035970)) && (a786258498 == 9 && ((-151 < a1774184757) && (35 >= a1774184757))))) && ((((input == 12) &&  cf==1 ) && a1210910088 == 2) && a601495656 == 33))) {
    	cf = 0;
    	a63333937 = (((((a260539918 * a1774184757) % 106) - -136) * 1) - -1);
    	a999024345 = ((((((a260539918 * a260539918) % 64) + 196) + 1) / 5) - -115);
    	a1675035970 = (((((a63333937 * a1625516355) % 51) + 282) - -6) + 1);
    	a2061425267 = (a2026977784 + 3);
    	a1774184757 = ((((((((a1774184757 * a1675035970) % 14999) % 66) - -103) + 1) * 5) % 66) - -62);
    	a1985899004 = ((((((a1985899004 * a1254983042) % 14999) * 2) - 2) % 76) + 447);
    	a1625516355 = ((((((((a1151361287 * a260539918) % 14999) / 5) % 13) - 95) * 5) % 13) + -95);
    	a778006913 = (a1478681170 + -3);
    	a1783229935 = ((a721272783 / a1916853335) + 13);
    	a1241576728 = (a2087535773 - -3);
    	a26346326 = 34 ;
    	a1895304149 = 34 ;
    	a1210910088 = (a786258498 + -6);
    	a2041520547 = 35 ;
    	a4442917 = (a190525986 + -4);
    	a1254983042 = (((((a813082108 * a999024345) / 5) + 20523) % 105) - -217);
    	a1983740902 = 33 ;
    	a620105235 = ((((((((a620105235 * a999024345) % 14999) % 94) + -65) + 1) * 5) % 94) + -63);
    	a1830659124 = ((a1210910088 - a834646264) + 17);
    	a1895857334 = ((a2130193413 + a190525986) - 8);
    	a1644957382 = 33 ;
    	a709568404 = 34 ;
    	a1211013485 = 32 ;
    	a786258498 = ((a2061425267 + a1249952537) + -7);
    	a2130193413 = ((a1478681170 + a2026977784) - 5);
    	a2073482783 = 33 ;
    	a1018383389 = ((((((a1018383389 * a63333937) % 14999) % 21) - -184) - 14) + -1);
    	a1318526106 = 32 ;
    	a983758263 = ((((a983758263 % 101) + 305) - 18684) - -18683);
    	a601495656 = 34 ;
    	a263151501 = 34 ;
    	a30494462 = (((((a30494462 * a217799639) - 4757) % 85) - -209) + 0);
    	a217799639 = ((((((a1675035970 * a999024345) % 14999) + 12088) * -1) / 10) / 5);
    	a1125477212 = 34 ;
    	a813082108 = ((((((a1151361287 * a1151361287) % 14999) - -13128) % 69) - -165) - -5);
    	a1249952537 = ((a1700231631 - a1959068056) - -7);
    	a1916853335 = (a1700231631 - 2);
    	a2130183577 = (((((((a2130183577 * a1675035970) % 14999) + -20118) + -9464) * 1) % 12) - -254);
    	a1151361287 = (((((((a1151361287 * a1018383389) % 14999) % 86) - -96) + 13303) + 10629) + -23911);
    	a190525986 = (a2061425267 + -1); 
    	 printf("%d\n", 16); fflush(stdout); 
    } if(((((((input == 14) &&  cf==1 ) && ((-198 < a217799639) && (-59 >= a217799639))) && ((3 < a813082108) && (104 >= a813082108))) && a1983740902 == 33) && ((a190525986 == 10 && a1125477212 == 33) && ((-135 < a63333937) && (29 >= a63333937))))) {
    	cf = 0;
    	a601495656 = 34 ;
    	a620105235 = (((((((a620105235 * a1675035970) % 14999) - 971) - -16655) + -24287) % 94) + 15);
    	a778006913 = (a4442917 + -4);
    	a1916853335 = (a190525986 - 3);
    	a26346326 = 34 ;
    	a263151501 = 34 ;
    	a2073482783 = 32 ;
    	a2061425267 = (a2087535773 + 7);
    	a1675035970 = ((((a1675035970 * a999024345) + 102) * 1) + -36013);
    	a1895304149 = 32 ;
    	a1826277115 = ((((((a983758263 * a983758263) % 14999) % 105) + -52) - 1) - 0);
    	a263219509 = ((a721272783 + a1241576728) + -12);
    	a2026977784 = (a1959068056 + -1);
    	a1774184757 = ((((((a260539918 * a620105235) / 5) % 66) + 103) - -7300) + -7301);
    	a1249952537 = ((a4442917 * a1916853335) + -43);
    	a1983740902 = 34 ;
    	a1210910088 = a778006913;
    	a1241576728 = (a4442917 - -1);
    	a1985899004 = ((((((((a1985899004 * a217799639) % 14999) % 76) - -448) + 3169) / 5) * 6) / 10);
    	a217799639 = (((((a1018383389 * a1018383389) + -4650) % 28) - 28) - 2);
    	a1644957382 = 34 ;
    	a822442096 = (((((a999024345 * a999024345) - 2076) % 100) - -82) / 5);
    	a983758263 = ((((a983758263 * a813082108) + 7555) * 1) * 1);
    	a2130183577 = (((((a2130183577 * a813082108) - -2955) % 12) - -242) * 1);
    	a2130193413 = ((a786258498 + a2061425267) - 10);
    	a999024345 = (((((a63333937 * a63333937) * 1) * 1) % 64) - -196);
    	a786258498 = a190525986;
    	a76745981 = 32 ;
    	a1830659124 = (a1916853335 - -4);
    	a709568404 = 34 ;
    	a1151361287 = ((((((a1151361287 * a620105235) % 14999) % 20) + 271) - 1) + -1);
    	a813082108 = ((((((a30494462 * a63333937) % 69) + 174) / 5) - 6336) + 6490);
    	a1180594800 = 32 ;
    	a30494462 = ((((a63333937 * a1625516355) + -23072) * 1) * 1);
    	a1254983042 = (((((a1254983042 * a1018383389) % 14999) - 3669) + 8295) - 19627);
    	a1018383389 = (((((a1018383389 * a1774184757) % 21) - -185) * 1) - -2);
    	a1125477212 = 34 ;
    	a190525986 = (a1700231631 - -4);
    	a1211013485 = 32 ;
    	a63333937 = ((((((a63333937 * a1625516355) * 2) + -12953) * 1) % 14932) - 15066);
    	a1625516355 = (((((a1625516355 * a260539918) * 1) / 5) % 13) - 95); 
    	 printf("%d\n", 20); fflush(stdout); 
    } 
}
 void calculate_outputm139(int input) {
    if(((a786258498 == 9 && (a26346326 == 33 && (a2026977784 == 8 && ( cf==1  && (input == 5))))) && (a1959068056 == 9 && (a1249952537 == 5 && a263151501 == 33)))) {
    	cf = 0;
    	a786258498 = (a2026977784 + 2);
    	a2130193413 = a190525986;
    	a1830659124 = (a786258498 + 1);
    	a965340096 = 32 ;
    	a217799639 = (((((((a217799639 * a813082108) % 14999) / 5) - -13199) + 6399) % 28) - 42);
    	a1625516355 = ((((((a620105235 * a813082108) % 14999) % 37) - 41) * 1) - 3);
    	a601495656 = 32 ;
    	a1826277115 = ((((((((a983758263 * a983758263) % 14999) % 62) - -115) * 5) * 5) % 62) + 114);
    	a1895304149 = 34 ;
    	a26346326 = 34 ;
    	a999024345 = (((((((a999024345 * a1826277115) % 64) + 147) * 10) / 9) * 10) / 9);
    	a263151501 = 34 ;
    	a2073482783 = 34 ;
    	a1644957382 = 34 ;
    	a30494462 = (((((a30494462 * a620105235) - 5525) % 85) - -210) * 1);
    	a1521644128 = (a2087535773 - -4);
    	a1675035970 = ((((((a1675035970 * a1625516355) / 5) / 5) - -4379) % 51) - -249);
    	a1959068056 = (a721272783 + -7);
    	a1210910088 = (a1700231631 + -5);
    	a1774184757 = ((((((((a1774184757 * a1254983042) % 14999) % 66) - -102) - 1) * 5) % 66) + 97);
    	a1318526106 = 34 ;
    	a2087535773 = (a190525986 - 6);
    	a1151361287 = (((((((a1151361287 * a260539918) % 14999) - 11563) * 1) - 2027) % 20) - -269);
    	a1983740902 = 34 ;
    	a2026977784 = (a1700231631 + 1);
    	a1241576728 = a1700231631;
    	a1249952537 = (a190525986 + -5);
    	a620105235 = (((((((a620105235 * a1018383389) % 14999) - -11501) * 2) * 1) % 94) + -65);
    	a1254983042 = (((((((a1254983042 * a983758263) % 14999) % 105) - -309) / 5) - -26373) - 26059);
    	a983758263 = ((((((a983758263 * a1826277115) % 14999) % 14796) - -15202) * 1) * 1); 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((((171 < a1675035970) && (207 >= a1675035970)) && (( cf==1  && (input == 8)) && a2026977784 == 8)) && (a26346326 == 33 && (((-151 < a1774184757) && (35 >= a1774184757)) && (((-2 < a1254983042) && (202 >= a1254983042)) && ((-198 < a217799639) && (-59 >= a217799639))))))) {
    	cf = 0;
    	a260539918 = ((((((a1254983042 * a620105235) % 14999) - 2506) % 17) - 24) * 1);
    	a1700231631 = ((a1249952537 + a1241576728) - 5);
    	a1959068056 = ((a1210910088 / a1895857334) + 10);
    	a4442917 = (a1830659124 + -4);
    	a778006913 = a1210910088;
    	a834646264 = (a2130193413 - 2);
    	a1985899004 = (((((a260539918 * a1151361287) % 76) + 470) / 5) + 322);
    	a709568404 = 33 ;
    	a1249952537 = (a778006913 - -4);
    	a76745981 = 33 ;
    	a2026977784 = ((a1210910088 - a786258498) - -16);
    	a1180594800 = 33 ;
    	a1774184757 = (((((((a1774184757 * a1254983042) % 14999) / 5) % 66) - -102) / 5) + 31);
    	a2130183577 = (((((a1625516355 * a260539918) - -21667) % 63) - -104) - -17);
    	a999024345 = (((((((a999024345 * a2130183577) % 14999) % 64) + 141) + 25389) / 5) + -4934);
    	a786258498 = (a2087535773 + 6);
    	a1125477212 = 33 ;
    	a190525986 = ((a1210910088 - a4442917) - -14);
    	a1241576728 = ((a1210910088 / a2087535773) - -8);
    	a1254983042 = (((((((a1254983042 * a217799639) % 14999) % 105) + 307) - -2) + 166) + -167); 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm140(int input) {
    if((((a190525986 == 10 && (((-198 < a217799639) && (-59 >= a217799639)) && ( cf==1  && (input == 6)))) && ((-151 < a1774184757) && (35 >= a1774184757))) && (((-109 < a1625516355) && (-81 >= a1625516355)) && (a2087535773 == 4 && ((48 < a999024345) && (131 >= a999024345)))))) {
    	cf = 0;
    	a708839806 = 34 ;
    	a190525986 = (a721272783 + -6);
    	a786258498 = (a721272783 + -7);
    	a1180594800 = 34 ;
    	a999024345 = ((((((a30494462 * a30494462) - 9646) - 12301) * 1) % 64) - -201);
    	a2026977784 = (a786258498 + -1);
    	a260539918 = ((((((a30494462 * a30494462) - 8299) % 73) + 67) - 13095) + 13094);
    	a1625516355 = (((((((a999024345 * a999024345) % 14999) + -7536) % 37) - 43) - 3309) + 3310);
    	a709568404 = 34 ;
    	a2130183577 = ((((((((a2130183577 * a620105235) % 14999) % 12) + 243) * 5) - -2740) % 12) - -235);
    	a983758263 = ((((((a983758263 * a1774184757) % 14999) % 101) + 304) - -1097) - 1096);
    	a1574467713 = ((a1700231631 * a1700231631) + -57);
    	a1125477212 = 34 ;
    	a1211013485 = 34 ;
    	a1830659124 = ((a2061425267 - a4442917) - -5);
    	a1916853335 = (a1959068056 - 2);
    	a1895304149 = 34 ;
    	a1151361287 = ((((((a1151361287 * a1018383389) % 14999) % 20) - -253) - 10086) - -10102);
    	a2087535773 = ((a778006913 + a778006913) + 1);
    	a1983740902 = 34 ;
    	a1895857334 = ((a1249952537 + a1959068056) - 3);
    	a4442917 = ((a786258498 * a786258498) + -93);
    	a1254983042 = (((((((a1254983042 * a217799639) % 14999) % 105) + 309) + -21171) * 1) + 21169);
    	a1644957382 = 34 ;
    	a1959068056 = ((a721272783 - a1210910088) + -5);
    	a76745981 = 34 ;
    	a263151501 = 34 ;
    	a1018383389 = (((((a30494462 * a30494462) % 21) - -189) * 1) * 1);
    	a601495656 = 34 ;
    	a1249952537 = ((a721272783 / a2130193413) - -5);
    	a620105235 = ((((((a1625516355 * a30494462) + 22923) % 94) - 156) + -23352) + 23416);
    	a1675035970 = ((((((a1675035970 * a63333937) % 51) - -258) - 28363) + 42089) - 13724);
    	a620988906 = 32 ;
    	a1318526106 = 34 ;
    	a63333937 = ((((((a30494462 * a30494462) - -439) % 106) - -136) + -3623) + 3622);
    	a217799639 = (((((((a217799639 * a1254983042) % 14999) - 8166) % 28) - 18) - -7239) - 7233);
    	a813082108 = (((((a30494462 * a30494462) / 5) - 8778) % 69) - -200);
    	a26346326 = 34 ;
    	a30494462 = (((((a30494462 * a1625516355) * 3) / 5) % 85) - -210); 
    	 printf("%d\n", 19); fflush(stdout); 
    } if((((a76745981 == 33 && a1211013485 == 33) && a2073482783 == 33) && ((((171 < a1675035970) && (207 >= a1675035970)) && (((75 < a1151361287) && (249 >= a1151361287)) && ( cf==1  && (input == 13)))) && a4442917 == 6))) {
    	cf = 0;
    	a1241576728 = (a1916853335 + 2);
    	a4442917 = (a1241576728 + -1);
    	a1830659124 = ((a4442917 / a1895857334) + 11);
    	a1983740902 = 34 ;
    	a2087535773 = (a778006913 - -3);
    	a1644957382 = 34 ;
    	a1249952537 = (a1959068056 - 3);
    	a2004613952 = (a190525986 + -4);
    	a2130183577 = ((((((((a2130183577 * a217799639) % 14999) - -6557) % 12) - -242) * 5) % 12) - -243);
    	a708839806 = 34 ;
    	a63333937 = ((((((a1675035970 * a1774184757) % 14999) % 106) - -136) - -27871) + -27870);
    	a1211013485 = 34 ;
    	a566060042 = ((((a999024345 * a983758263) - -1723) * 1) + 950);
    	a302110279 = 33 ;
    	a1254983042 = (((((((a1254983042 * a217799639) % 14999) % 105) - -307) * 5) % 105) - -240);
    	a2026977784 = ((a1916853335 + a2061425267) + -9);
    	a2130193413 = (a1700231631 + 3);
    	a999024345 = (((((a30494462 * a983758263) % 64) + 195) - -2) + -2);
    	a1210910088 = (a1478681170 - 2);
    	a263151501 = 34 ;
    	a1018383389 = (((((a1774184757 * a1625516355) % 21) - -190) * 1) + 1);
    	a190525986 = (a1959068056 + 2);
    	a620105235 = ((((((a620105235 * a1151361287) % 14999) - -3419) % 94) + -64) - -1);
    	a778006913 = (a1241576728 + -5);
    	a1959068056 = (a2026977784 - -1);
    	a30494462 = (((((((a30494462 * a63333937) % 14999) + 5065) % 85) - -210) / 5) - -203);
    	a1895304149 = 34 ;
    	a1895857334 = ((a721272783 / a721272783) + 6);
    	a983758263 = (((((((a983758263 * a1774184757) % 14999) + 7021) % 101) - -305) / 5) - -230);
    	a709568404 = 34 ;
    	a1774184757 = (((((((a1774184757 * a1018383389) % 14999) % 66) + 102) - -1) - -8531) + -8532); 
    	 printf("%d\n", 19); fflush(stdout); 
    } if(((((((17 < a1018383389) && (167 >= a1018383389)) && a1644957382 == 33) && a190525986 == 10) && ((-151 < a1774184757) && (35 >= a1774184757))) && (a778006913 == 2 && (((-135 < a63333937) && (29 >= a63333937)) && ( cf==1  && (input == 14)))))) {
    	cf = 0;
    	a1211013485 = 32 ;
    	a601495656 = 32 ;
    	a1569588614 = (((((((a2130183577 * a2130183577) % 14999) - -12797) * 1) * 1) % 46) - -106);
    	a1774184757 = (((((a1774184757 * a63333937) - 19544) - -1861) / 5) - 14536);
    	a76745981 = 32 ;
    	a1574467713 = ((a778006913 / a1895857334) - -1);
    	a721272783 = (a1249952537 + 7);
    	a1830659124 = ((a1916853335 / a2087535773) - -8);
    	a2087535773 = (a190525986 - 7);
    	a63333937 = ((((a1985899004 * a260539918) * 1) * 1) * 1);
    	a778006913 = (a1249952537 + -4);
    	a4442917 = (a1959068056 + -4);
    	a2073482783 = 32 ;
    	a620105235 = (((((a620105235 * a1625516355) / 5) - 7786) + 32198) + -49737); 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm142(int input) {
    if((((a709568404 == 33 && (a1180594800 == 33 && ( cf==1  && (input == 2)))) && ((3 < a813082108) && (104 >= a813082108))) && ((a1644957382 == 33 && ((-2 < a1254983042) && (202 >= a1254983042))) && ((171 < a1675035970) && (207 >= a1675035970))))) {
    	cf = 0;
    	a1249952537 = ((a2061425267 * a2087535773) - 38);
    	a1241576728 = (a2130193413 + -2);
    	a302110279 = 34 ;
    	a1959068056 = (a1210910088 + 8);
    	a778006913 = (a1478681170 - 1);
    	a1983740902 = 34 ;
    	a708839806 = 33 ;
    	a1318526106 = 33 ;
    	a1125477212 = 34 ;
    	a76745981 = 34 ;
    	a2130183577 = (((((a1675035970 * a813082108) % 12) + 231) + 5312) + -5307);
    	a620105235 = (((((((a260539918 * a30494462) % 94) + -63) - 2) * 5) % 94) - 63);
    	a1985899004 = (((((a260539918 * a260539918) * 5) / 5) % 76) + 375);
    	a1211013485 = 34 ;
    	a2026977784 = a786258498; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((((171 < a1675035970) && (207 >= a1675035970)) && ((input == 12) &&  cf==1 )) && ((((a1644957382 == 33 && ((48 < a999024345) && (131 >= a999024345))) && ((-44 < a260539918) && (-8 >= a260539918))) && ((17 < a1018383389) && (167 >= a1018383389))) && a1916853335 == 6))) {
    	cf = 0;
    	a1180594800 = 34 ;
    	a2130183577 = (((((a63333937 * a1774184757) * 1) - -5041) % 63) + 143);
    	a263151501 = 34 ;
    	a1211013485 = 33 ;
    	a721272783 = ((a4442917 * a1357285245) + -44);
    	a1018383389 = (((((((a1018383389 * a1675035970) % 14999) - 15649) % 21) + 205) + 3626) - 3628);
    	a1830659124 = (a721272783 - -1);
    	a1959068056 = (a721272783 + -1);
    	a217799639 = ((((((a217799639 * a1254983042) % 14999) + -8242) % 28) - 28) + -2);
    	a803418896 = (((((((a983758263 * a983758263) % 14999) - -12249) - -471) - -854) % 89) - 83);
    	a2130193413 = (a786258498 + 2);
    	a1348848030 = (a2061425267 - -3);
    	a1774184757 = ((((((((a1774184757 * a1254983042) % 14999) % 66) + 102) * 1) * 5) % 66) - -74); 
    	 printf("%d\n", 16); fflush(stdout); 
    } if(((((a2087535773 == 4 && a1916853335 == 6) && ((-151 < a1774184757) && (35 >= a1774184757))) && ((75 < a1151361287) && (249 >= a1151361287))) && ((((input == 14) &&  cf==1 ) && a709568404 == 33) && ((-198 < a217799639) && (-59 >= a217799639))))) {
    	cf = 0;
    	a217799639 = ((((((a217799639 * a2130183577) % 14999) % 28) + -28) + 17300) + -17301);
    	a1574467713 = ((a1210910088 - a1916853335) + 5);
    	a263151501 = 34 ;
    	a1644957382 = 34 ;
    	a1895857334 = (a4442917 + 5);
    	a1254983042 = ((((((a1254983042 * a999024345) % 105) + 308) + 2) - 21094) - -21091);
    	a4442917 = (a190525986 - 3);
    	a2087535773 = (a2061425267 - 6);
    	a1625516355 = ((((((a1625516355 * a1254983042) % 14999) % 37) - 42) * 5) / 5);
    	a2026977784 = (a4442917 + 2);
    	a1983740902 = 34 ;
    	a709568404 = 34 ;
    	a30494462 = (((((a30494462 * a217799639) / 5) - -8370) % 85) + 174);
    	a302110279 = 34 ;
    	a1249952537 = a1916853335;
    	a1180594800 = 34 ;
    	a2061425267 = ((a1357285245 * a1478681170) + -24);
    	a1478681170 = ((a190525986 + a786258498) - 14);
    	a778006913 = (a1959068056 - 7);
    	a2073482783 = 34 ;
    	a601495656 = 34 ;
    	a708839806 = 34 ;
    	a263638061 = (a1574467713 + 10);
    	a620105235 = ((((((a30494462 * a1985899004) % 14999) + 10955) % 94) - 148) - -37);
    	a26346326 = 34 ;
    	a1916853335 = (a721272783 - 10);
    	a983758263 = ((((a983758263 % 101) + 305) / 5) + 299);
    	a63333937 = ((((((a63333937 * a217799639) % 106) - -135) * 5) % 106) - -33);
    	a999024345 = ((((((a999024345 * a813082108) / 5) % 64) + 169) * 9) / 10);
    	a260539918 = (((((a260539918 * a2130183577) % 73) + 99) - -11583) + -11616);
    	a1895304149 = 34 ;
    	a1830659124 = ((a786258498 / a1241576728) - -10);
    	a1318526106 = 34 ;
    	a1675035970 = ((((((a1675035970 * a813082108) - -8461) / 5) / 5) % 51) + 244);
    	a1151361287 = (((((((a1151361287 * a1774184757) % 14999) + 14224) * 1) / 5) % 20) + 271);
    	a2130193413 = (a190525986 + 1);
    	a190525986 = (a2087535773 - -6);
    	a786258498 = (a1830659124 - 1);
    	a1210910088 = (a2087535773 - 2);
    	a813082108 = ((((((a813082108 * a1018383389) + -26020) % 69) + 225) * 9) / 10); 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm143(int input) {
    if((((((-151 < a1774184757) && (35 >= a1774184757)) && a1959068056 == 9) && a1211013485 == 33) && (a1125477212 == 33 && (a1916853335 == 6 && (((input == 5) &&  cf==1 ) && a2130193413 == 10))))) {
    	cf = 0;
    	a601495656 = 34 ;
    	a2130193413 = ((a1249952537 - a1700231631) + 15);
    	a1675035970 = (((((a1774184757 * a217799639) % 51) - -259) + -1) * 1);
    	a2073482783 = 34 ;
    	a999024345 = ((((((a999024345 * a1675035970) % 14999) % 64) - -166) + 10269) + -10269);
    	a263151501 = 34 ;
    	a813082108 = ((((((a813082108 * a999024345) % 69) + 118) / 5) + 5201) - 5018);
    	a708839806 = 34 ;
    	a404763935 = ((a1916853335 * a1357285245) - 46);
    	a1151361287 = ((((((a1151361287 * a1675035970) % 14999) - 19334) % 20) - -278) * 1);
    	a1125477212 = 34 ;
    	a983758263 = ((((a983758263 - -11829) + 8218) * 10) / 9);
    	a1318526106 = 34 ;
    	a4442917 = ((a1916853335 / a1249952537) + 6);
    	a190525986 = (a721272783 + -6);
    	a1983740902 = 34 ;
    	a1478681170 = (a778006913 + 3);
    	a1644957382 = 34 ;
    	a1210910088 = ((a786258498 * a786258498) - 78);
    	a1895304149 = 34 ;
    	a302110279 = 34 ;
    	a30494462 = ((((((a30494462 * a999024345) % 14999) % 85) - -211) * 1) * 1);
    	a1826277115 = (((((a983758263 * a983758263) % 14999) + 14155) * 1) / 5);
    	a2087535773 = a1249952537;
    	a1625516355 = (((((a1625516355 * a217799639) % 37) + -69) - -10437) + -10436);
    	a217799639 = (((((a1018383389 * a1018383389) / 5) + -10080) % 28) - 12);
    	a548050643 = 35 ;
    	a260539918 = ((((((a260539918 * a1675035970) - -1584) + -13243) - -42145) % 73) - -29);
    	a63333937 = ((((((a63333937 * a1675035970) % 14999) - -5360) - 16642) % 106) + 137);
    	a1916853335 = (a1249952537 - -2);
    	a778006913 = ((a1830659124 + a1249952537) + -12);
    	a620105235 = ((((((((a1151361287 * a983758263) % 14999) % 94) + -104) * 10) / 9) * 9) / 10);
    	a26346326 = 34 ;
    	a786258498 = (a1249952537 + 5);
    	a1830659124 = ((a1249952537 + a1249952537) - -1);
    	a2026977784 = ((a2061425267 * a1241576728) + -68);
    	a2130183577 = ((((((a2130183577 * a1254983042) % 14999) % 12) - -243) + 1) + -1);
    	a1211013485 = 34 ;
    	a2061425267 = ((a2087535773 + a2087535773) + 2);
    	a1241576728 = ((a778006913 - a1210910088) + 8);
    	a1180594800 = 34 ;
    	a709568404 = 34 ;
    	a1254983042 = ((((((a1254983042 * a1985899004) % 14999) % 105) - -308) - 1) - -3);
    	a1249952537 = ((a1959068056 - a1959068056) + 6);
    	a1959068056 = 10; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((( cf==1  && (input == 6)) && a4442917 == 6) && ((a1318526106 == 33 && (a302110279 == 33 && (a1983740902 == 33 && ((-44 < a260539918) && (-8 >= a260539918))))) && a1241576728 == 7))) {
    	cf = 0;
    	a1211013485 = 32 ;
    	a63333937 = (((((((a63333937 * a2130183577) % 14999) - 13497) * 1) + 16078) % 14932) - 15066);
    	a1318526106 = 32 ;
    	a1959068056 = ((a4442917 * a778006913) - 4);
    	a1151361287 = ((((((a1151361287 * a1625516355) % 86) - -185) - 21) - 5637) + 5649);
    	a1478681170 = (a1357285245 + -7);
    	a778006913 = (a721272783 + -16);
    	a2073482783 = 32 ;
    	a1895304149 = 32 ;
    	a834646264 = ((a1249952537 * a190525986) - 44);
    	a1210910088 = (a2026977784 + -7);
    	a813082108 = (((((a813082108 * a63333937) % 14999) / 5) + -12815) + -954);
    	a786258498 = (a1357285245 + -2);
    	a1180594800 = 32 ;
    	a30494462 = (((((a30494462 * a217799639) - 1066) * 1) % 14969) + -15030);
    	a1241576728 = (a2087535773 - -3);
    	a302110279 = 33 ;
    	a260539918 = ((((((a620105235 * a1254983042) % 14999) - 9518) % 14978) + -15021) - 1);
    	a1213722969 = (a1357285245 - -1);
    	a983758263 = (((((a983758263 - -4078) * 10) / -9) + 7079) - 20241);
    	a601495656 = 32 ;
    	a1830659124 = (a1249952537 - -4);
    	a1644957382 = 32 ;
    	a999024345 = ((((a999024345 * a1675035970) - 36871) / 5) / 5);
    	a1254983042 = ((((((a217799639 * a813082108) % 14999) + -15000) / 5) - -6242) + -8177);
    	a341216798 = (((((a983758263 * a983758263) % 14999) + 2909) / 5) / -5);
    	a26346326 = 32 ;
    	a4442917 = (a786258498 + -3);
    	a1675035970 = (((((a1675035970 * a260539918) % 14999) / 5) - -28838) * -1);
    	a2130183577 = (((((a2130183577 * a1018383389) % 14999) - -14163) - -482) / -5);
    	a1018383389 = ((((((a1018383389 * a1625516355) + 17733) + 1355) / 5) % 74) + 43);
    	a1625516355 = (((((((a1625516355 * a63333937) % 14999) % 13) - 97) / 5) * 10) / 2); 
    	 printf("%d\n", 19); fflush(stdout); 
    } if(((a778006913 == 2 && ( cf==1  && (input == 11))) && ((((a1959068056 == 9 && a1983740902 == 33) && a1210910088 == 2) && a1180594800 == 33) && a2026977784 == 8))) {
    	cf = 0;
    	a1959068056 = ((a1478681170 + a1357285245) - 4);
    	a1254983042 = (((((a260539918 * a260539918) - 26506) % 105) + 382) + 17);
    	a2026977784 = a786258498;
    	a2004613952 = ((a1357285245 + a1478681170) - 8);
    	a1983740902 = 34 ;
    	a1151361287 = ((((((a1151361287 * a1018383389) % 14999) / 5) % 20) - -251) - 1);
    	a1644957382 = 34 ;
    	a63333937 = (((((((a63333937 * a1254983042) % 14999) / 5) / 5) - 22906) % 106) + 179);
    	a1830659124 = ((a2026977784 - a1959068056) - -12);
    	a778006913 = (a1357285245 + -7);
    	a1895304149 = 34 ;
    	a2073482783 = 34 ;
    	a566060042 = ((((((a999024345 * a983758263) * 1) * 1) / 5) % 14) + 11);
    	a620105235 = (((((a260539918 * a260539918) / 5) + -10729) % 94) + 17);
    	a1180594800 = 34 ;
    	a709568404 = 34 ;
    	a1318526106 = 32 ;
    	a30494462 = ((((((a30494462 * a2130183577) - -550) - -184) * 1) % 85) + 210);
    	a190525986 = (a1700231631 - -2);
    	a1241576728 = ((a778006913 - a4442917) + 11);
    	a2061425267 = (a1210910088 - -10);
    	a1210910088 = (a1357285245 - 7);
    	a1774184757 = ((((((a620105235 * a260539918) / 5) / 5) * 5) % 66) - -103);
    	a1895857334 = ((a1249952537 + a721272783) - 15);
    	a26346326 = 34 ;
    	a1916853335 = (a2004613952 + 1);
    	a302110279 = 34 ;
    	a1211013485 = 34 ;
    	a1125477212 = 34 ;
    	a217799639 = (((((((a217799639 * a1774184757) % 14999) % 28) + -29) + 1) / 5) - 42);
    	a983758263 = (((((a983758263 * a566060042) / 5) / 5) / 5) + 209);
    	a813082108 = (((((((a260539918 * a260539918) % 69) - -170) * 5) * 5) % 69) - -170);
    	a263151501 = 34 ;
    	a999024345 = (((((a260539918 * a260539918) * 5) / 5) % 64) - -170);
    	a1249952537 = ((a1357285245 + a1959068056) - 14);
    	a4442917 = (a1357285245 + -3);
    	a2130193413 = a190525986;
    	a1018383389 = (((((((a1018383389 * a1675035970) % 14999) % 21) + 182) + 1) / 5) + 140);
    	a2130183577 = (((((a260539918 * a260539918) % 12) + 239) + 2) + 3);
    	a601495656 = 34 ;
    	a1675035970 = (((((a260539918 * a1151361287) % 51) + 307) + 4) + -30);
    	a786258498 = a1959068056;
    	a1625516355 = ((((((a1625516355 * a813082108) % 37) + -37) + 26368) * 1) + -26372);
    	a1478681170 = (a2004613952 - 3);
    	a708839806 = 34 ;
    	a260539918 = ((((a260539918 * 10) / 1) - 11215) + -2060); 
    	 printf("%d\n", 26); fflush(stdout); 
    } if(((((3 < a813082108) && (104 >= a813082108)) && a778006913 == 2) && (a1210910088 == 2 && (a190525986 == 10 && (a786258498 == 9 && (a1241576728 == 7 && ( cf==1  && (input == 13)))))))) {
    	cf = 0;
    	a1959068056 = a2026977784;
    	a983758263 = ((((((a983758263 * a1254983042) % 14999) - 11020) % 14997) + -15002) + -1);
    	a1254983042 = (((((a217799639 * a1625516355) / 5) * 5) + 5358) + -31681);
    	a1211013485 = 32 ;
    	a813082108 = ((((((a1774184757 * a1018383389) + -1917) * 1) * 1) % 15001) + -14997);
    	a1213722969 = (a1478681170 + 7);
    	a341216798 = (((((a983758263 * a983758263) % 14999) - 26207) + -663) + 523);
    	a302110279 = 33 ;
    	a63333937 = ((((((a63333937 * a341216798) % 14999) * 2) % 14932) + -15066) * 1);
    	a1241576728 = (a1478681170 + 2);
    	a30494462 = ((((a30494462 * a260539918) - 3305) * 3) / 5);
    	a1675035970 = ((((a1675035970 * a999024345) / 5) - -17614) + -40965);
    	a834646264 = (a1700231631 - 3);
    	a1644957382 = 32 ;
    	a1830659124 = ((a2087535773 / a1916853335) - -9);
    	a1318526106 = 32 ;
    	a1180594800 = 32 ;
    	a1625516355 = (((((((a1151361287 * a1151361287) % 14999) % 13) - 95) * 1) * 10) / 9);
    	a601495656 = 32 ;
    	a778006913 = (a190525986 - 9);
    	a786258498 = (a1357285245 + -2);
    	a2130183577 = (((((a2130183577 * a1018383389) % 14999) - 21358) + -649) * 1);
    	a1151361287 = (((((((a1151361287 * a983758263) % 14999) % 86) - -162) - 8386) / 5) + 1843);
    	a999024345 = (((((a1018383389 * a620105235) % 14999) - 13315) / 5) * 5);
    	a1018383389 = ((((((a1018383389 * a63333937) % 14999) - -29199) - 23) % 74) + 78);
    	a26346326 = 32 ;
    	a1210910088 = (a1357285245 - 9);
    	a2073482783 = 32 ;
    	a260539918 = ((((((a260539918 * a813082108) % 14999) % 14978) + -15021) * 1) + -2);
    	a1895304149 = 32 ;
    	a4442917 = ((a786258498 + a2130193413) + -13);
    	a1478681170 = (a1213722969 - 8); 
    	 printf("%d\n", 26); fflush(stdout); 
    } if((((a2130193413 == 10 && a2026977784 == 8) && a1959068056 == 9) && ((a1210910088 == 2 && (((103 < a2130183577) && (230 >= a2130183577)) && ( cf==1  && (input == 2)))) && ((-109 < a1625516355) && (-81 >= a1625516355))))) {
    	cf = 0;
    	a341216798 = ((((((a983758263 * a983758263) % 14999) * 2) + 3) % 18) + 216);
    	a1675035970 = (((((a1675035970 * a1018383389) % 14999) - 29909) * 1) - 58);
    	a1125477212 = 32 ;
    	a1895304149 = 32 ;
    	a26346326 = 32 ;
    	a1305578599 = 35 ;
    	a30494462 = ((((a30494462 * a813082108) - 21519) * 1) / 5);
    	a661990791 = ((a1241576728 * a778006913) - 6);
    	a1241576728 = (a1478681170 - -2);
    	a1916853335 = (a2061425267 + -6);
    	a983758263 = ((((((a983758263 * a341216798) % 14999) % 14997) - 15002) * 1) - 2);
    	a1249952537 = ((a2026977784 / a786258498) - -4);
    	a217799639 = (((((a217799639 * a1151361287) % 14999) - 13643) + -398) + -426);
    	a190525986 = ((a2061425267 - a721272783) + 15);
    	a2130193413 = (a1478681170 + 5);
    	a1830659124 = a1959068056;
    	a1625516355 = (((((a1625516355 * a999024345) * 10) / 9) - 10831) - 1767);
    	a4442917 = (a1210910088 - -3);
    	a778006913 = ((a1916853335 - a1357285245) - -6); 
    	 printf("%d\n", 16); fflush(stdout); 
    } 
}
 void calculate_outputm12(int input) {
    if(((a1959068056 == 9 && (((-151 < a1774184757) && (35 >= a1774184757)) && (a1700231631 == 3 &&  cf==1 ))) && (a26346326 == 33 && ((((75 < a1151361287) && (249 >= a1151361287)) && ((103 < a2130183577) && (230 >= a2130183577))) && a1180594800 == 33)))) {
    	if((((a1012466188 == 34 &&  cf==1 ) && ((75 < a1151361287) && (249 >= a1151361287))) && (((-182 < a620105235) && (-160 >= a620105235)) && (((a1644957382 == 33 && a1211013485 == 33) && a1916853335 == 6) && a263151501 == 33)))) {
    		calculate_outputm132(input);
    	} 
    	if(((a190525986 == 10 && (a2130193413 == 10 && ((-2 < a1254983042) && (202 >= a1254983042)))) && (((a2061425267 == 11 && (a1012466188 == 35 &&  cf==1 )) && a1180594800 == 33) && ((75 < a1151361287) && (249 >= a1151361287))))) {
    		calculate_outputm133(input);
    	} 
    } 
    if(((a1249952537 == 5 && a190525986 == 10) && (((a1983740902 == 33 && (( cf==1  && a1700231631 == 5) && ((-151 < a1774184757) && (35 >= a1774184757)))) && a1180594800 == 33) && a1125477212 == 33))) {
    	if((((a76745981 == 33 && (a1241576728 == 7 && (a524719993 == 36 &&  cf==1 ))) && a263151501 == 33) && ((a708839806 == 33 && ((-62 < a30494462) && (124 >= a30494462))) && a1210910088 == 2))) {
    		calculate_outputm134(input);
    	} 
    } 
    if(((a1916853335 == 6 && ((-151 < a1774184757) && (35 >= a1774184757))) && (a2026977784 == 8 && ((a709568404 == 33 && (((-2 < a1254983042) && (202 >= a1254983042)) && ( cf==1  && a1700231631 == 6))) && ((3 < a813082108) && (104 >= a813082108)))))) {
    	if(((a2073482783 == 33 && (((-151 < a1774184757) && (35 >= a1774184757)) && a26346326 == 33)) && ((a1983740902 == 33 && (a1125477212 == 33 && ( cf==1  && a369798198 == 34))) && a76745981 == 33))) {
    		calculate_outputm136(input);
    	} 
    } 
    if((((a1983740902 == 33 && (((103 < a2130183577) && (230 >= a2130183577)) && a263151501 == 33)) && a1125477212 == 33) && (a1830659124 == 10 && (a709568404 == 33 && (a1700231631 == 7 &&  cf==1 ))))) {
    	if(((a778006913 == 2 && (a4442917 == 6 && (a834646264 == 8 &&  cf==1 ))) && ((a1180594800 == 33 && (((-182 < a620105235) && (-160 >= a620105235)) && a1830659124 == 10)) && a2087535773 == 4))) {
    		calculate_outputm137(input);
    	} 
    	if(((((174 < a1985899004) && (371 >= a1985899004)) && (((-62 < a30494462) && (124 >= a30494462)) && a1211013485 == 33)) && (a1895304149 == 33 && (((-182 < a620105235) && (-160 >= a620105235)) && (a1644957382 == 33 && ( cf==1  && a834646264 == 9)))))) {
    		calculate_outputm138(input);
    	} 
    } 
    if(((a2130193413 == 10 && (((-198 < a217799639) && (-59 >= a217799639)) && (a1318526106 == 33 && (a1700231631 == 8 &&  cf==1 )))) && ((a1983740902 == 33 && ((171 < a1675035970) && (207 >= a1675035970))) && ((-182 < a620105235) && (-160 >= a620105235))))) {
    	if((((a1983740902 == 33 && ((48 < a999024345) && (131 >= a999024345))) && ((-62 < a30494462) && (124 >= a30494462))) && (a1959068056 == 9 && (a1644957382 == 33 && (a1895304149 == 33 && (a1895857334 == 6 &&  cf==1 )))))) {
    		calculate_outputm139(input);
    	} 
    	if((((((171 < a1675035970) && (207 >= a1675035970)) && ((-2 < a1254983042) && (202 >= a1254983042))) && a1916853335 == 6) && ((((103 < a2130183577) && (230 >= a2130183577)) && (( cf==1  && a1895857334 == 8) && a601495656 == 33)) && a2130193413 == 10))) {
    		calculate_outputm140(input);
    	} 
    } 
    if((((a2130193413 == 10 && ((a1700231631 == 9 &&  cf==1 ) && ((-135 < a63333937) && (29 >= a63333937)))) && ((-198 < a217799639) && (-59 >= a217799639))) && ((a2061425267 == 11 && a190525986 == 10) && a1478681170 == 4))) {
    	if(((a2087535773 == 4 && (a1895304149 == 33 && a786258498 == 9)) && (((a1916853335 == 6 && ( cf==1  && a1357285245 == 9)) && a263151501 == 33) && ((75 < a1151361287) && (249 >= a1151361287))))) {
    		calculate_outputm142(input);
    	} 
    	if((((((17 < a1018383389) && (167 >= a1018383389)) && ( cf==1  && a1357285245 == 10)) && a26346326 == 33) && (((a2061425267 == 11 && a1210910088 == 2) && a1241576728 == 7) && ((75 < a1151361287) && (249 >= a1151361287))))) {
    		calculate_outputm143(input);
    	} 
    } 
}
 void calculate_outputm145(int input) {
    if(((((-8 < a260539918) && (140 >= a260539918)) && ((167 < a1018383389) && (211 >= a1018383389))) && (((35 < a1774184757) && (169 >= a1774184757)) && (a1478681170 == 5 && (a1318526106 == 34 && (((input == 5) &&  cf==1 ) && a2073482783 == 34)))))) {
    	cf = 0;
    	a1826277115 = ((((((a983758263 * a260339255) % 14999) % 105) - 52) - 1) + 1);
    	a302110279 = 32 ;
    	a1675035970 = (((((((a1675035970 * a1018383389) % 14999) + -11443) % 51) + 260) + -24626) - -24624);
    	a2130183577 = ((((((a63333937 * a1254983042) % 14999) - 23601) * 10) / 9) - 3337);
    	a263219509 = (a4442917 - -4);
    	a260539918 = ((((((((a260539918 * a1254983042) % 14999) % 73) - -66) - -2) * 5) % 73) + 65);
    	a1983740902 = 33 ;
    	a1830659124 = (a1895857334 + 5);
    	a708839806 = 32 ;
    	a983758263 = ((((((a983758263 * a999024345) % 14999) / 5) - 29905) - 52) - -49058);
    	a190525986 = ((a2026977784 + a778006913) + -1);
    	a76745981 = 34 ;
    	a661990791 = ((a778006913 - a1916853335) - -10);
    	a2087535773 = (a2026977784 + -6);
    	a1895304149 = 32 ;
    	a2073482783 = 34 ;
    	a620105235 = ((((((a1985899004 * a1625516355) % 14999) % 10) + -170) * 1) + -1);
    	a1774184757 = ((((((a1774184757 * a1826277115) + 13474) - -2193) + -10931) % 66) - -102);
    	a601495656 = 34 ;
    	a1211013485 = 34 ;
    	a1959068056 = ((a1249952537 - a2130193413) + 15); 
    	 printf("%d\n", 26); fflush(stdout); 
    } 
}
 void calculate_outputm146(int input) {
    if((((a601495656 == 34 && (( cf==1  && (input == 2)) && ((207 < a1675035970) && (311 >= a1675035970)))) && ((35 < a1774184757) && (169 >= a1774184757))) && ((((167 < a1018383389) && (211 >= a1018383389)) && a1210910088 == 3) && a1644957382 == 34))) {
    	cf = 0;
    	a1830659124 = (a1241576728 - -3);
    	a341216798 = (((((a983758263 * a260339255) * 1) / 5) * 10) / 9);
    	a1211013485 = 32 ;
    	a965340096 = 32 ;
    	a1180594800 = 32 ;
    	a1151361287 = (((((a1151361287 * a260339255) + -20485) * 10) / 9) / 5);
    	a2061425267 = (a778006913 - -9);
    	a1125477212 = 32 ;
    	a76745981 = 32 ;
    	a1521644128 = (a1895857334 + -1);
    	a1774184757 = (((((a1774184757 * a1675035970) % 14999) + -20838) + -2183) + -6497);
    	a30494462 = (((((a30494462 * a1625516355) % 14999) - 8438) + -885) / 5);
    	a1644957382 = 32 ;
    	a1249952537 = (a778006913 - -3);
    	a1210910088 = ((a190525986 / a2087535773) + -2);
    	a1959068056 = (a1830659124 + -1);
    	a601495656 = 32 ;
    	a999024345 = (((((a1675035970 * a1985899004) % 14999) - 14955) + -23) / 5);
    	a983758263 = ((((((a983758263 * a1352986605) % 14999) + 1797) + -10812) % 14997) + -15002);
    	a1254983042 = ((((((a1254983042 * a620105235) % 14999) - 5173) * 10) / 9) / 5);
    	a2130193413 = ((a4442917 + a786258498) - 6);
    	a786258498 = (a1916853335 - -3);
    	a260539918 = ((((((a260539918 * a999024345) % 14999) % 14978) + -15021) - 2) + 0);
    	a2026977784 = (a190525986 + -2);
    	a1675035970 = (((((a1675035970 * a1151361287) % 14999) - 14961) + -1) - 10); 
    	 printf("%d\n", 17); fflush(stdout); 
    } 
}
 void calculate_outputm148(int input) {
    if(((a302110279 == 34 && ((230 < a2130183577) && (255 >= a2130183577))) && ((a2026977784 == 9 && (((131 < a999024345) && (260 >= a999024345)) && (((-59 < a217799639) && (-1 >= a217799639)) && ( cf==1  && (input == 8))))) && a4442917 == 7))) {
    	cf = 0;
    	a1318526106 = 34 ;
    	a26346326 = 34 ;
    	a2073482783 = 34 ;
    	a601495656 = 34 ;
    	a709568404 = 34 ;
    	a2130193413 = a1830659124;
    	a983758263 = (((((a983758263 * a707417839) % 14999) - -2006) * 1) * 1);
    	a1211013485 = 34 ;
    	a1959068056 = (a2061425267 + -2);
    	a1895304149 = 34 ;
    	a1249952537 = ((a1210910088 / a2087535773) + 6);
    	a217799639 = ((((((a217799639 * a999024345) % 28) + -28) + -3832) + 33705) + -29857);
    	a404763935 = (a2061425267 + 2);
    	a1241576728 = (a4442917 + 1);
    	a548050643 = 35 ;
    	a1125477212 = 34 ;
    	a30494462 = ((((((a30494462 * a1254983042) % 14999) / 5) - 23220) % 85) - -281);
    	a1826277115 = ((((((a707417839 * a707417839) % 14999) / 5) - -12513) + -15231) - -6989);
    	a1830659124 = ((a1916853335 * a2026977784) - 52);
    	a620105235 = (((((((((a1151361287 * a1151361287) % 14999) % 94) - 119) * 10) / 9) * 5) % 94) + -27);
    	a2061425267 = (a778006913 + 9); 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm152(int input) {
    if(((((a190525986 == 11 && a2026977784 == 9) && a1180594800 == 34) && ((-8 < a260539918) && (140 >= a260539918))) && ((((-160 < a620105235) && (30 >= a620105235)) && ( cf==1  && (input == 7))) && a1916853335 == 7))) {
    	cf = 0;
    	a1644957382 = 34 ;
    	a2087535773 = ((a4442917 - a778006913) + 1);
    	a1211013485 = 33 ;
    	a601495656 = 33 ;
    	a1241576728 = (a2087535773 - -3);
    	a1959068056 = (a1830659124 - 2);
    	a1210910088 = (a1241576728 + -5);
    	a1826277115 = (((((((a983758263 * a983758263) % 14999) % 105) + -111) * 10) / 9) + -33);
    	a1942901885 = 33 ;
    	a709568404 = 32 ;
    	a263219509 = (a2026977784 + -2);
    	a1983740902 = 33 ;
    	a813082108 = (((((((a1151361287 * a1254983042) % 14999) - 8819) % 69) - -174) + -27212) - -27212);
    	a1180594800 = 33 ;
    	a1318526106 = 32 ;
    	a26346326 = 34 ;
    	a983758263 = ((((((a983758263 * a1254983042) % 14999) - -9801) * 1) * 10) / 9);
    	a30494462 = (((((((a30494462 * a2130183577) % 14999) % 92) + -35) + 48) * 10) / 9); 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a2130193413 == 11 && ((input == 8) &&  cf==1 )) && ((a263151501 == 34 && ((a1478681170 == 5 && ((124 < a30494462) && (296 >= a30494462))) && a76745981 == 34)) && a1959068056 == 10))) {
    	cf = 0;
    	a1644957382 = 34 ;
    	a1942901885 = 33 ;
    	a983758263 = (((((a983758263 * a1352986605) % 14999) / 5) / 5) + 22000);
    	a2087535773 = (a2061425267 + -7);
    	a1210910088 = (a1916853335 + -4);
    	a26346326 = 34 ;
    	a709568404 = 32 ;
    	a1983740902 = 33 ;
    	a1211013485 = 33 ;
    	a30494462 = ((((((a30494462 * a260539918) % 14999) % 92) - -30) + 1) + 2);
    	a813082108 = (((((a620105235 * a1625516355) % 69) + 174) - -13090) - 13089);
    	a601495656 = 33 ;
    	a1826277115 = (((((a1774184757 * a1774184757) % 105) + -110) - -28063) + -28084);
    	a1959068056 = (a1348848030 + -4);
    	a1180594800 = 33 ;
    	a263219509 = (a1249952537 + 1);
    	a1318526106 = 32 ;
    	a1241576728 = (a4442917 + 1); 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((( cf==1  && (input == 12)) && a1180594800 == 34) && a1959068056 == 10) && (((a1983740902 == 34 && ((202 < a1254983042) && (414 >= a1254983042))) && a1895304149 == 34) && a1211013485 == 34))) {
    	cf = 0;
    	a76745981 = 32 ;
    	a983758263 = (((((a983758263 * a1254983042) % 14999) + -15755) * 1) - 772);
    	a1211013485 = 32 ;
    	a341216798 = (((((a1352986605 * a1352986605) % 14999) + 6594) + -35027) * 1);
    	a778006913 = ((a2087535773 / a1895857334) + 1);
    	a834646264 = ((a2026977784 - a1916853335) + 4);
    	a2073482783 = 32 ;
    	a1018383389 = ((((((a1352986605 * a260539918) % 14999) % 74) - -93) - 2) + 3);
    	a260539918 = (((((a983758263 * a1985899004) % 14999) + -3849) + -9225) + -1393);
    	a63333937 = (((((((a63333937 * a620105235) % 14999) % 14932) + -15066) - 2) / 5) + -23210);
    	a1478681170 = (a4442917 - 4);
    	a709568404 = 32 ;
    	a302110279 = 33 ;
    	a620105235 = (((((((a341216798 * a260539918) % 14999) % 14909) + -15090) / 5) - -29774) - 46923);
    	a30494462 = (((((((a30494462 * a813082108) % 14999) % 14969) - 15030) + -2) / 5) - 15079);
    	a1625516355 = (((((((a341216798 * a1151361287) % 14999) % 13) + -94) + -25463) - 427) - -25889);
    	a1213722969 = (a4442917 + 4);
    	a1318526106 = 32 ;
    	a4442917 = (a2061425267 + -7);
    	a1895304149 = 32 ;
    	a1959068056 = ((a1210910088 + a1241576728) - -1);
    	a1675035970 = ((((((a1675035970 * a983758263) % 14999) - 6109) + -4573) * 10) / 9);
    	a263151501 = 32 ;
    	a708839806 = 32 ;
    	a786258498 = (a1830659124 - 3);
    	a2130183577 = (((((a1151361287 * a341216798) % 14999) + -14928) + -68) + -6);
    	a1254983042 = (((((a813082108 * a30494462) % 14999) + -15000) * 1) + -1);
    	a1180594800 = 32 ;
    	a1830659124 = (a1916853335 + 2);
    	a999024345 = (((((a999024345 * a1151361287) % 14999) - 22812) - 2411) / 5);
    	a1151361287 = (((((((a1151361287 * a1774184757) % 14999) / 5) - -222) * 5) % 86) - -137); 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((( cf==1  && (input == 14)) && a2061425267 == 12) && (((a708839806 == 34 && (a778006913 == 3 && ((202 < a1254983042) && (414 >= a1254983042)))) && ((-8 < a260539918) && (140 >= a260539918))) && ((131 < a999024345) && (260 >= a999024345))))) {
    	cf = 0;
    	a2087535773 = ((a1959068056 - a778006913) + -2);
    	a1210910088 = (a2087535773 + -2);
    	a1826277115 = ((((((a1352986605 * a1352986605) % 14999) - -4225) * 1) % 105) + -123);
    	a263219509 = a4442917;
    	a983758263 = (((((((a983758263 * a260539918) % 14999) % 14796) - -15202) / 5) + -28076) - -42936);
    	a1942901885 = 33 ;
    	a26346326 = 34 ;
    	a1318526106 = 32 ;
    	a1983740902 = 33 ;
    	a709568404 = 32 ;
    	a30494462 = ((((((a30494462 * a1675035970) % 14999) / 5) + 21046) % 92) + 28);
    	a1644957382 = 34 ;
    	a601495656 = 33 ;
    	a1959068056 = (a1348848030 - 4);
    	a1241576728 = (a2087535773 + 3);
    	a1180594800 = 33 ;
    	a1211013485 = 33 ;
    	a813082108 = ((((((a2130183577 * a2130183577) % 14999) + -1180) % 69) - -173) * 1); 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a1895304149 == 34 && ((371 < a1985899004) && (524 >= a1985899004))) && ((a1959068056 == 10 && (a1249952537 == 6 && (((input == 10) &&  cf==1 ) && a709568404 == 34))) && ((131 < a999024345) && (260 >= a999024345))))) {
    	cf = 0;
    	a961167689 = (a1830659124 - 4);
    	a1895857334 = a786258498;
    	a1257505051 = (((((((a1352986605 * a1352986605) % 14999) - 21100) % 14) - 14) * 9) / 10); 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm153(int input) {
    if(((a1916853335 == 7 && ((a4442917 == 7 && ((input == 5) &&  cf==1 )) && a2061425267 == 12)) && (a26346326 == 34 && (((124 < a30494462) && (296 >= a30494462)) && ((167 < a1018383389) && (211 >= a1018383389)))))) {
    	cf = 0;
    	a786258498 = (a1348848030 - 6);
    	a1625516355 = (((((((a2130183577 * a2130183577) % 14999) / 5) + 7002) / 5) % 13) + -94);
    	a1478681170 = (a786258498 - 5);
    	a260539918 = (((((a2130183577 * a1625516355) % 17) - 14) / 5) - 33);
    	a1675035970 = (((((((a63333937 * a813082108) % 14999) + -17732) / 5) / 5) % 17) - -199);
    	a2130193413 = (a1830659124 + -1);
    	a2026977784 = (a1249952537 - -2);
    	a26346326 = 33 ;
    	a1211013485 = 33 ;
    	a1018383389 = (((((((a1625516355 * a2130183577) % 74) + 97) * 10) / 9) / 5) + 26);
    	a1151361287 = (((((((a1151361287 * a1675035970) % 14999) % 86) - -144) - 18159) - -36127) - 17969);
    	a1983740902 = 33 ;
    	a1254983042 = ((((((a2130183577 * a1774184757) % 14999) * 2) % 101) - -99) / 5);
    	a30494462 = ((((((((a30494462 * a1352986605) % 14999) % 92) - -22) * 9) / 10) * 10) / 9);
    	a1895304149 = 33 ;
    	a1180594800 = 33 ;
    	a76745981 = 32 ;
    	a601495656 = 33 ;
    	a217799639 = (((((a1985899004 * a2130183577) % 14999) - -8622) + -24305) - 1974);
    	a1959068056 = (a190525986 - 2);
    	a63333937 = (((((((a63333937 * a813082108) % 14999) % 81) + -104) * 9) / 10) / 5);
    	a999024345 = (((((((a999024345 * a1254983042) % 14999) - -8420) % 41) - -90) + -18309) - -18309);
    	a2097567994 = 34 ;
    	a620105235 = (((((a260539918 * a1625516355) - -22860) % 94) - 100) - -3);
    	a1210910088 = (a786258498 + -7);
    	a709568404 = 32 ;
    	a721272783 = ((a1249952537 + a1916853335) - -2);
    	a983758263 = ((((((a983758263 * a2130183577) % 14999) % 104) - -14) * 5) / 5);
    	a778006913 = ((a1830659124 / a2130193413) + 1);
    	a1241576728 = (a2130193413 - 3);
    	a2061425267 = ((a1895857334 + a1916853335) + -3);
    	a813082108 = (((((((a813082108 * a1018383389) % 14999) + 9354) / 5) - 29190) % 50) - -54);
    	a1125477212 = 32 ;
    	a2087535773 = ((a1830659124 * a786258498) + -96);
    	a1916853335 = ((a4442917 / a1241576728) - -4);
    	a1249952537 = (a1241576728 + -3);
    	a4442917 = (a786258498 - 4);
    	a1969216760 = 36 ;
    	a1318526106 = 33 ;
    	a2130183577 = ((((((a2130183577 * a1625516355) - -44069) % 63) + 130) * 9) / 10); 
    	 printf("%d\n", 16); fflush(stdout); 
    } if(((a1983740902 == 34 && (a1830659124 == 11 && a601495656 == 34)) && (((207 < a1675035970) && (311 >= a1675035970)) && ((a1125477212 == 34 && ((input == 6) &&  cf==1 )) && a263151501 == 34)))) {
    	cf = 0;
    	a721272783 = ((a1249952537 * a786258498) + -45);
    	a1983740902 = 33 ;
    	a2061425267 = ((a1916853335 * a1348848030) - 95);
    	a1180594800 = 33 ;
    	a620105235 = (((((((a1774184757 * a1985899004) % 14999) * 2) / 5) / 5) % 94) + -65);
    	a1241576728 = (a1830659124 - 4);
    	a1211013485 = 33 ;
    	a2097567994 = 34 ;
    	a983758263 = ((((((a983758263 * a1352986605) % 14999) % 104) - -25) + -17791) + 17771);
    	a601495656 = 33 ;
    	a1895304149 = 33 ;
    	a1249952537 = (a1241576728 - 3);
    	a260539918 = ((((((a1774184757 * a1985899004) % 14999) % 17) - 24) + 3593) - 3595);
    	a709568404 = 32 ;
    	a217799639 = ((((((a1774184757 * a1985899004) % 14999) * 2) % 14901) - 15098) - 2);
    	a1254983042 = (((((((a2130183577 * a1018383389) % 14999) % 101) - 1) - 0) + 29696) - 29655);
    	a813082108 = (((((((a813082108 * a30494462) % 14999) % 50) + 22) / 5) - 24023) - -24064);
    	a1959068056 = (a4442917 + 2);
    	a1969216760 = 36 ;
    	a999024345 = ((((((a999024345 * a1151361287) % 14999) - 18517) % 41) - -122) - -9);
    	a778006913 = ((a2130193413 - a1895857334) - 3);
    	a1318526106 = 33 ;
    	a1675035970 = (((((((a1675035970 * a1254983042) % 14999) % 17) - -189) - 1) - -22300) - 22299);
    	a1125477212 = 32 ;
    	a786258498 = (a190525986 + -2);
    	a1478681170 = (a721272783 - 11);
    	a2130183577 = (((((((a1985899004 * a1985899004) % 14999) % 63) - -128) - -1418) + -8677) - -7279);
    	a1210910088 = (a1348848030 / a1895857334);
    	a2026977784 = (a778006913 + 6);
    	a1625516355 = (((((((a1985899004 * a1985899004) % 14999) % 13) - 99) - 5) + -29776) - -29776);
    	a4442917 = (a1478681170 - -1);
    	a30494462 = ((((((a1625516355 * a1018383389) % 92) - -94) / 5) + -19957) + 19959);
    	a1151361287 = (((((((a1151361287 * a1254983042) % 14999) - -5388) * 1) * 1) % 86) - -163);
    	a63333937 = (((((((a63333937 * a1018383389) % 14999) % 81) - 84) * 9) / 10) / 5);
    	a1018383389 = (((((a1018383389 * a260539918) % 74) + 164) - -1) + -10);
    	a2130193413 = (a1241576728 + 3);
    	a2087535773 = ((a1916853335 + a721272783) - 19);
    	a26346326 = 33 ;
    	a76745981 = 32 ;
    	a1916853335 = (a1895857334 + -1); 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a778006913 == 3 && ((input == 7) &&  cf==1 )) && ((((104 < a813082108) && (243 >= a813082108)) && (a1211013485 == 34 && (a709568404 == 34 && a76745981 == 34))) && a4442917 == 7))) {
    	cf = 0;
    	a1180594800 = 32 ;
    	a983758263 = (((((a983758263 * a1985899004) % 14999) - 3730) + -22365) * 1);
    	a709568404 = 32 ;
    	a2087535773 = ((a2061425267 / a2061425267) - -2);
    	a63333937 = ((((((a63333937 * a999024345) % 14999) - 16008) * 1) * 10) / 9);
    	a786258498 = (a1249952537 + 2);
    	a1675035970 = (((((a1675035970 * a30494462) % 14999) + -27980) * 1) - 1608);
    	a1478681170 = a2087535773;
    	a263151501 = 32 ;
    	a1895304149 = 32 ;
    	a1241576728 = (a1916853335 - 1);
    	a302110279 = 33 ;
    	a1213722969 = ((a1830659124 * a2130193413) - 110);
    	a1644957382 = 32 ;
    	a813082108 = (((((a813082108 * a30494462) % 14999) - 4189) + -5568) + -9755);
    	a708839806 = 32 ;
    	a1018383389 = (((((((a1018383389 * a260539918) % 14999) + 20281) % 74) - -70) - 16560) - -16579);
    	a1959068056 = (a1478681170 - -5);
    	a1151361287 = ((((((((a1151361287 * a63333937) % 14999) + 4966) % 86) - -162) * 5) % 86) - -139);
    	a76745981 = 32 ;
    	a834646264 = (a2026977784 - 3);
    	a4442917 = (a1478681170 - -2);
    	a1211013485 = 32 ;
    	a1625516355 = ((((((a2130183577 * a1254983042) % 14999) % 13) - 95) * 1) * 1);
    	a2130183577 = (((((a2130183577 * a620105235) % 14999) + -8590) - 3526) + -1706);
    	a26346326 = 32 ;
    	a1830659124 = (a778006913 - -6);
    	a778006913 = ((a786258498 - a190525986) - -4);
    	a341216798 = (((((a1254983042 * a999024345) % 14999) - 22932) - 2631) / 5);
    	a1210910088 = ((a2026977784 * a1241576728) - 53);
    	a2073482783 = 32 ;
    	a999024345 = ((((((a983758263 * a620105235) % 14999) + -22969) + 27099) / 5) - 4438);
    	a1254983042 = (((((((a63333937 * a620105235) % 14999) - -4755) * 10) / -9) + 8464) - 6242);
    	a601495656 = 32 ;
    	a30494462 = ((((((a30494462 * a983758263) % 14999) - 1373) * 10) / 9) - 7763); 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((a1959068056 == 10 && a302110279 == 34) && ((a708839806 == 34 && ((a26346326 == 34 && ( cf==1  && (input == 14))) && ((131 < a999024345) && (260 >= a999024345)))) && a1830659124 == 11))) {
    	cf = 0;
    	a1241576728 = ((a1249952537 * a1478681170) - 22);
    	a548050643 = 35 ;
    	a620105235 = ((((((a30494462 * a1985899004) % 14999) % 94) + -137) + -9) / 5);
    	a26346326 = 34 ;
    	a260539918 = ((((((a1254983042 * a2130183577) % 14999) % 73) - -48) * 5) / 5);
    	a1318526106 = 34 ;
    	a601495656 = 34 ;
    	a30494462 = (((((((a30494462 * a63333937) % 14999) % 85) + 190) * 9) / 10) + -41);
    	a983758263 = (((((a983758263 * a1352986605) % 14999) / 5) - -16326) * 1);
    	a1895304149 = 34 ;
    	a1826277115 = (((((a1352986605 * a983758263) % 14999) - -12568) + -31066) - -26954);
    	a1211013485 = 34 ;
    	a1959068056 = ((a1478681170 * a1830659124) - 45);
    	a2061425267 = (a1249952537 - -6);
    	a217799639 = (((((((a1151361287 * a1675035970) % 14999) % 28) + -44) + 11) * 9) / 10);
    	a1125477212 = 34 ;
    	a1249952537 = ((a1210910088 - a1895857334) - -9);
    	a404763935 = (a1895857334 + 8);
    	a2130193413 = a1830659124;
    	a2073482783 = 34 ;
    	a709568404 = 34 ;
    	a1830659124 = (a4442917 + 4); 
    	 printf("%d\n", 16); fflush(stdout); 
    } if(((((29 < a63333937) && (243 >= a63333937)) && (a708839806 == 34 && (((207 < a1675035970) && (311 >= a1675035970)) && a263151501 == 34))) && (a1211013485 == 34 && (a1916853335 == 7 && ( cf==1  && (input == 2)))))) {
    	cf = 0;
    	a965340096 = 36 ;
    	a1895857334 = a190525986;
    	a1574467713 = ((a1249952537 - a1241576728) + 10); 
    	 printf("%d\n", 19); fflush(stdout); 
    } 
}
 void calculate_outputm13(int input) {
    if((((( cf==1  && a1352986605 <=  85) && a1210910088 == 3) && a1125477212 == 34) && (a2026977784 == 9 && ((a2130193413 == 11 && ((131 < a999024345) && (260 >= a999024345))) && a1959068056 == 10)))) {
    	if(((a601495656 == 34 && ((a260339255 <=  14 &&  cf==1 ) && a1478681170 == 5)) && ((a1241576728 == 8 && (((249 < a1151361287) && (291 >= a1151361287)) && a1959068056 == 10)) && a778006913 == 3))) {
    		calculate_outputm145(input);
    	} 
    	if((((a1249952537 == 6 && a2026977784 == 9) && ((-8 < a260539918) && (140 >= a260539918))) && (((249 < a1151361287) && (291 >= a1151361287)) && ((( cf==1  && ((14 < a260339255) && (63 >= a260339255))) && ((207 < a1675035970) && (311 >= a1675035970))) && a1180594800 == 34)))) {
    		calculate_outputm146(input);
    	} 
    } 
    if((a1830659124 == 11 && (((((( cf==1  && ((85 < a1352986605) && (148 >= a1352986605))) && a190525986 == 11) && a786258498 == 10) && ((-59 < a217799639) && (-1 >= a217799639))) && a1318526106 == 34) && a708839806 == 34))) {
    	if(((a190525986 == 11 && (268 < a707417839 &&  cf==1 )) && ((((((167 < a1018383389) && (211 >= a1018383389)) && a263151501 == 34) && ((-8 < a260539918) && (140 >= a260539918))) && a1478681170 == 5) && a1983740902 == 34))) {
    		calculate_outputm148(input);
    	} 
    } 
    if((((((317 < a1352986605 &&  cf==1 ) && ((249 < a1151361287) && (291 >= a1151361287))) && ((29 < a63333937) && (243 >= a63333937))) && ((371 < a1985899004) && (524 >= a1985899004))) && ((a2026977784 == 9 && a1895304149 == 34) && a2073482783 == 34))) {
    	if((((a2130193413 == 11 && (a1348848030 == 13 &&  cf==1 )) && a709568404 == 34) && ((a263151501 == 34 && (a4442917 == 7 && a1895304149 == 34)) && a1478681170 == 5))) {
    		calculate_outputm152(input);
    	} 
    	if(((a1983740902 == 34 && ((a1210910088 == 3 && a1125477212 == 34) && a1830659124 == 11)) && (((104 < a813082108) && (243 >= a813082108)) && (( cf==1  && a1348848030 == 15) && a76745981 == 34)))) {
    		calculate_outputm153(input);
    	} 
    } 
}
 void calculate_outputm154(int input) {
    if((((a1916853335 == 7 && ((a2026977784 == 9 && ( cf==1  && (input == 5))) && ((104 < a813082108) && (243 >= a813082108)))) && a1241576728 == 8) && (((131 < a999024345) && (260 >= a999024345)) && a1210910088 == 3))) {
    	cf = 0;
    	a1895304149 = 32 ;
    	a620105235 = (((((a620105235 * a566060042) % 14999) / 5) - 10670) / 5);
    	a1667689532 = 32 ;
    	a1478681170 = (a786258498 + -7);
    	a2073482783 = 32 ;
    	a1210910088 = (a1249952537 + -5);
    	a2130183577 = ((((a2130183577 * a1625516355) * 1) * 1) - 4146);
    	a1018383389 = (((((a1018383389 * a566060042) % 14999) + -5572) * 1) - 846);
    	a1644957382 = 32 ;
    	a1675035970 = ((((((a1774184757 * a813082108) % 14999) + 7116) / 5) / 5) * -5);
    	a2004613952 = (a778006913 - -8);
    	a260539918 = ((((((a260539918 * a1254983042) % 14999) % 14978) + -15021) - 1) - 1);
    	a1241576728 = (a2087535773 - -1); 
    	 printf("%d\n", 20); fflush(stdout); 
    } if(((((((input == 9) &&  cf==1 ) && a1983740902 == 34) && a2073482783 == 34) && a709568404 == 34) && ((((249 < a1151361287) && (291 >= a1151361287)) && a1895304149 == 34) && a1644957382 == 34))) {
    	cf = 0;
    	a1983740902 = 34 ;
    	a1318526106 = 33 ;
    	a302110279 = 34 ;
    	a26346326 = 33 ;
    	a1985899004 = ((((((a30494462 * a1675035970) % 14999) % 76) - -391) + 21601) - 21589);
    	a1625516355 = (((((((a983758263 * a217799639) % 13) + -84) / 5) * 5) * 11) / 10);
    	a1644957382 = 34 ;
    	a2140773614 = 35 ;
    	a153258473 = ((((((a566060042 * a983758263) % 14999) + -2851) * 1) % 27) - -153);
    	a2130183577 = (((((((a2130183577 * a153258473) % 14999) % 63) + 144) * 10) / 9) + -1);
    	a76745981 = 34 ;
    	a778006913 = (a2130193413 - 8);
    	a263151501 = 34 ;
    	a63333937 = (((((((a1018383389 * a983758263) % 14999) + 11087) % 106) - -67) / 5) - -176);
    	a601495656 = 32 ;
    	a1895857334 = (a1249952537 + 3);
    	a2026977784 = (a2004613952 - -3);
    	a1241576728 = ((a786258498 * a2061425267) + -112); 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a26346326 == 34 && ((-8 < a260539918) && (140 >= a260539918))) && (a1210910088 == 3 && ((((230 < a2130183577) && (255 >= a2130183577)) && (a302110279 == 34 && ( cf==1  && (input == 11)))) && a778006913 == 3)))) {
    	cf = 0;
    	a1318526106 = 33 ;
    	a1151361287 = (((((((a1151361287 * a813082108) % 14999) - 5914) + -8882) + 13869) % 86) - -161);
    	a369798198 = 35 ;
    	a63333937 = (((((a1254983042 * a217799639) % 106) - -140) - -74) + -29);
    	a263151501 = 33 ;
    	a4442917 = (a1916853335 + -1);
    	a2073482783 = 33 ;
    	a76745981 = 34 ;
    	a778006913 = (a1830659124 - 9);
    	a1891437507 = 32 ;
    	a620105235 = ((((((a620105235 * a1675035970) % 14999) + -12356) - -16379) % 10) + -171);
    	a601495656 = 33 ;
    	a1180594800 = 33 ;
    	a1895857334 = (a1830659124 + -3);
    	a1985899004 = ((((((a1675035970 * a260539918) % 14999) + 2482) * 1) % 76) + 447);
    	a2130183577 = (((((((a2130183577 * a813082108) % 14999) + -15787) * 1) * 1) % 63) - -201);
    	a813082108 = ((((((((a813082108 * a63333937) % 14999) % 50) + 26) * 9) / 10) + 25198) + -25173); 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm155(int input) {
    if((((a263151501 == 34 && ((a708839806 == 34 && a1959068056 == 10) && a709568404 == 34)) && a2130193413 == 11) && (a1180594800 == 34 && ((input == 9) &&  cf==1 )))) {
    	cf = 0;
    	a1318526106 = 34 ;
    	a217799639 = (((((a217799639 * a1675035970) - -4460) + 11118) % 28) + -30);
    	a1352986605 = (((((a983758263 * a2130183577) % 14999) + 8172) + -18859) + 25393);
    	a813082108 = ((((((a813082108 * a1018383389) % 14999) + -20370) - 872) * 10) / 9);
    	a2087535773 = (a1830659124 - 8);
    	a76745981 = 34 ;
    	a26346326 = 32 ;
    	a302110279 = 34 ;
    	a1348848030 = (a1959068056 + 3);
    	a1895857334 = (a1241576728 - 2);
    	a1625516355 = ((((((a1625516355 * a566060042) % 37) + -43) + -7735) - -15947) - 8212);
    	a1478681170 = ((a778006913 - a1249952537) + 8);
    	a1644957382 = 32 ;
    	a260539918 = (((((((a999024345 * a63333937) % 14999) % 73) + 61) * 9) / 10) + -46);
    	a601495656 = 32 ;
    	a1125477212 = 34 ;
    	a1210910088 = (a1348848030 + -12);
    	a1241576728 = ((a2130193413 + a2004613952) + -11);
    	a1018383389 = (((((((((a1018383389 * a1774184757) % 14999) % 21) - -168) * 10) / 9) / 5) * 46) / 10); 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((((input == 13) &&  cf==1 ) && ((-59 < a217799639) && (-1 >= a217799639))) && ((a1959068056 == 10 && ((a1125477212 == 34 && ((207 < a1675035970) && (311 >= a1675035970))) && a1895304149 == 34)) && ((104 < a813082108) && (243 >= a813082108))))) {
    	cf = 0;
    	a1830659124 = ((a1241576728 - a778006913) + 5);
    	a260539918 = ((((((((a620105235 * a620105235) % 17) - 25) * 9) / 10) * 5) % 17) + -19);
    	a63333937 = ((((((a620105235 * a620105235) % 81) - 51) - 3) + 15887) + -15885);
    	a217799639 = (((((a620105235 * a620105235) + 3178) * 1) % 69) - 128);
    	a2026977784 = (a1830659124 - 2);
    	a1983740902 = 33 ;
    	a2130193413 = a1830659124;
    	a786258498 = (a2130193413 - 1);
    	a1774184757 = ((((((a217799639 * a260539918) * 3) / 5) / 5) % 92) - 116);
    	a2130183577 = (((((((a2130183577 * a1675035970) % 14999) % 63) - -119) * 9) / 10) + 52);
    	a1959068056 = (a1916853335 - -2);
    	a1151361287 = ((((((a1151361287 * a813082108) % 14999) / 5) - -6074) % 86) + 97);
    	a4442917 = (a1830659124 + -4);
    	a1249952537 = (a2061425267 + -7);
    	a1357285245 = (a1895857334 - -3);
    	a1180594800 = 33 ;
    	a1211013485 = 33 ;
    	a601495656 = 33 ;
    	a1644957382 = 33 ;
    	a1018383389 = ((((((a1018383389 * a1774184757) % 14999) - -12517) % 74) + 93) - 2);
    	a1916853335 = ((a1830659124 / a1241576728) - -5);
    	a1318526106 = 33 ;
    	a1254983042 = (((((((a1254983042 * a813082108) % 14999) % 101) - -87) + -70) * 10) / 9);
    	a1625516355 = (((((a1625516355 * a217799639) + -13588) * 2) % 13) - 93);
    	a263151501 = 32 ;
    	a709568404 = 32 ;
    	a1985899004 = ((((((((a1018383389 * a2130183577) % 14999) % 76) + 398) - -48) * 5) % 76) - -424);
    	a999024345 = ((((((a999024345 * a1774184757) % 14999) % 41) + 90) / 5) + 62);
    	a1700231631 = (a2061425267 + -3);
    	a708839806 = 32 ;
    	a1478681170 = (a1830659124 - 6);
    	a721272783 = (a190525986 + 6);
    	a983758263 = ((((((a983758263 * a566060042) * 2) * 1) / 5) % 104) + 99);
    	a26346326 = 33 ;
    	a302110279 = 33 ;
    	a1210910088 = (a2004613952 + -4);
    	a30494462 = ((((((((a30494462 * a63333937) % 14999) % 92) + 30) - -1) * 5) % 92) + 32);
    	a1895304149 = 33 ;
    	a190525986 = ((a1830659124 / a1830659124) - -9);
    	a2073482783 = 33 ;
    	a1675035970 = ((((((a2130183577 * a2130183577) % 14999) / 5) - -4453) % 17) + 182);
    	a1125477212 = 33 ;
    	a813082108 = ((((((a620105235 * a620105235) % 50) + 54) / 5) * 45) / 10);
    	a2061425267 = (a1241576728 + 3);
    	a778006913 = (a1478681170 - 2);
    	a620105235 = (((((a620105235 * a1018383389) % 14909) + -15090) + -1) * 1);
    	a1241576728 = ((a1210910088 + a4442917) - 1); 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((a601495656 == 34 && (((a1983740902 == 34 && a1959068056 == 10) && ((-160 < a620105235) && (30 >= a620105235))) && a4442917 == 7)) && a709568404 == 34) && ( cf==1  && (input == 14)))) {
    	cf = 0;
    	a778006913 = ((a1249952537 + a1916853335) + -11);
    	a302110279 = 33 ;
    	a1895857334 = ((a1210910088 + a190525986) + -3);
    	a2087535773 = (a2004613952 + -1);
    	a1318526106 = 34 ;
    	a1625516355 = (((((a1625516355 * a1774184757) % 13) + -88) * 1) + 5);
    	a1151361287 = (((((((a1151361287 * a30494462) % 14999) - -24) % 86) - -94) / 5) + 191);
    	a2073482783 = 33 ;
    	a1574467713 = ((a1916853335 * a1210910088) - 14);
    	a26346326 = 33 ;
    	a620988906 = 34 ;
    	a4442917 = (a1574467713 + -1);
    	a1241576728 = (a786258498 - 3);
    	a1478681170 = (a1830659124 + -7);
    	a1675035970 = (((((((a1675035970 * a999024345) % 14999) % 17) - -176) * 5) % 17) + 187); 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((a1644957382 == 34 && ((202 < a1254983042) && (414 >= a1254983042))) && (a302110279 == 34 && (a190525986 == 11 && ((((249 < a1151361287) && (291 >= a1151361287)) && ((input == 15) &&  cf==1 )) && a1830659124 == 11))))) {
    	cf = 0;
    	a1211013485 = 32 ;
    	a2073482783 = 32 ;
    	a1830659124 = (a2087535773 + 7);
    	a834646264 = ((a1241576728 / a1895857334) - -10);
    	a1018383389 = ((((((a1018383389 * a999024345) % 14999) + -17377) - 2975) * 10) / 9);
    	a1644957382 = 32 ;
    	a190525986 = (a2087535773 - -6);
    	a1916853335 = (a2087535773 - -2);
    	a26346326 = 32 ;
    	a341216798 = ((((a983758263 * a566060042) + -28168) * 1) + -960);
    	a1985899004 = (((((((a1151361287 * a341216798) % 14999) * 2) + 2) * 1) % 76) - -448);
    	a263151501 = 32 ;
    	a2061425267 = ((a2130193413 / a1478681170) - -7);
    	a217799639 = ((((((a1675035970 * a1151361287) % 14999) + 2041) * -1) / 10) + -16620);
    	a1625516355 = ((((((a1625516355 * a1774184757) % 13) - 89) / 5) + 15830) - 15906);
    	a824591188 = ((((((a63333937 * a1774184757) % 14999) - -6310) + 1892) * 1) * -1);
    	a1241576728 = (a2087535773 - -3);
    	a999024345 = ((((((a2130183577 * a2130183577) % 14999) + -27734) + 37402) * 1) * -1);
    	a1249952537 = (a834646264 + -7);
    	a2130193413 = (a2004613952 + a1210910088);
    	a302110279 = 32 ;
    	a601495656 = 32 ;
    	a786258498 = (a190525986 - 1);
    	a63333937 = (((((a1151361287 * a1675035970) % 14999) - 23930) + -4031) / 5);
    	a983758263 = ((((((a983758263 * a824591188) % 14999) - -11339) * 1) % 14997) - 15002);
    	a1895304149 = 32 ;
    	a1210910088 = (a1916853335 - 3);
    	a1180594800 = 32 ;
    	a1125477212 = 33 ;
    	a1254983042 = ((((((a1254983042 * a620105235) % 14999) % 101) - -100) / 5) - 1);
    	a4442917 = ((a2087535773 + a1916853335) - 3);
    	a709568404 = 32 ;
    	a778006913 = (a2026977784 + -8);
    	a30494462 = (((((((a30494462 * a217799639) % 14999) + -4795) * 10) / 9) + 35231) + -39979);
    	a1774184757 = ((((((a1774184757 * a260539918) % 14999) % 92) - 56) / 5) + 14);
    	a620105235 = (((((((a620105235 * a813082108) % 14999) % 14909) - 15090) - 0) - -3599) - 3600);
    	a1983740902 = 32 ;
    	a2130183577 = ((((((a2130183577 * a813082108) % 14999) - 26914) * 1) + 30020) + -25896);
    	a1959068056 = ((a2087535773 / a778006913) - -5);
    	a708839806 = 32 ;
    	a2026977784 = (a834646264 + -2);
    	a813082108 = (((((((a813082108 * a1675035970) % 14999) + 3052) % 50) + 20) + 12935) + -12902);
    	a1675035970 = (((((a1675035970 * a1151361287) % 14999) / 5) / 5) - 28568);
    	a1151361287 = (((((((a1151361287 * a217799639) % 14999) % 20) - -269) * 5) % 20) + 269); 
    	 printf("%d\n", 16); fflush(stdout); 
    } 
}
 void calculate_outputm156(int input) {
    if((((a4442917 == 7 && a708839806 == 34) && a1210910088 == 3) && (((202 < a1254983042) && (414 >= a1254983042)) && (a1983740902 == 34 && (((input == 9) &&  cf==1 ) && a2026977784 == 9))))) {
    	cf = 0;
    	a217799639 = (((((((a566060042 * a566060042) % 14999) % 28) + -31) + 12692) * 2) + -25379);
    	a1959068056 = (a1916853335 - -3);
    	a2026977784 = (a786258498 + -1);
    	a1895304149 = 33 ;
    	a190525986 = ((a2087535773 * a2061425267) - 50);
    	a1254983042 = (((((((a1985899004 * a1675035970) % 14999) % 101) + -1) * 5) % 101) + 100);
    	a1345687529 = ((((((a63333937 * a1018383389) % 14999) + 9324) % 73) - 28) - 18);
    	a778006913 = (a1959068056 + -7);
    	a2061425267 = ((a778006913 + a1895857334) - -3);
    	a721272783 = ((a2087535773 / a1478681170) - -13);
    	a4442917 = ((a1916853335 * a786258498) - 48);
    	a1830659124 = (a2087535773 + 5);
    	a1644957382 = 33 ;
    	a1210910088 = (a2026977784 - 6);
    	a1478681170 = (a1241576728 + -4);
    	a1151361287 = ((((((a1625516355 * a1345687529) % 20) + 271) - -1) / 5) - -232);
    	a30494462 = ((((((a620105235 * a1254983042) % 14999) - 3146) % 92) - -31) + -1);
    	a983758263 = (((((((a983758263 * a2130183577) % 14999) + 13043) % 104) + 51) + -19743) - -19694);
    	a1180594800 = 32 ;
    	a1983740902 = 33 ;
    	a63333937 = (((((a1625516355 * a999024345) + 16185) - -17741) % 81) + -107);
    	a601495656 = 32 ;
    	a709568404 = 33 ;
    	a757937656 = (a721272783 + -12);
    	a1018383389 = (((((((a1018383389 * a1774184757) % 14999) - -14272) / 5) - 32195) % 74) + 121);
    	a2130193413 = ((a2004613952 + a2004613952) - 2);
    	a1774184757 = ((((((a1985899004 * a30494462) % 14999) % 92) + -58) - -2) - 3);
    	a1211013485 = 32 ;
    	a260539918 = ((((((a30494462 * a1675035970) * 1) % 14978) - 15021) / 5) - 20029);
    	a2130183577 = (((((((a1985899004 * a1254983042) % 14999) / 5) % 63) - -166) + -8460) + 8461);
    	a1249952537 = (a786258498 - 4);
    	a2073482783 = 32 ;
    	a708839806 = 33 ;
    	a1318526106 = 32 ;
    	a1125477212 = 34 ;
    	a263151501 = 33 ;
    	a2087535773 = (a2004613952 + -2);
    	a1241576728 = ((a2130193413 + a2004613952) - 10);
    	a999024345 = (((((a1254983042 * a983758263) % 14999) + -14951) / 5) + -16262);
    	a620105235 = ((((((a620105235 * a1774184757) - -6121) / 5) - -15600) * -1) / 10);
    	a813082108 = ((((a1625516355 * a1774184757) + 87) / 5) + -10074); 
    	 printf("%d\n", 26); fflush(stdout); 
    } 
}
 void calculate_outputm157(int input) {
    if(((a1125477212 == 34 && (a1644957382 == 34 && (((371 < a1985899004) && (524 >= a1985899004)) && ( cf==1  && (input == 4))))) && ((((207 < a1675035970) && (311 >= a1675035970)) && a2087535773 == 5) && a1830659124 == 11))) {
    	cf = 0;
    	a1644957382 = 33 ;
    	a2073482783 = 33 ;
    	a1891437507 = 35 ;
    	a1345687529 = ((((a1625516355 * a1774184757) * 2) - -28801) + 1528);
    	a983758263 = (((((((a983758263 * a1345687529) % 14999) - 19415) - -10748) / 5) % 104) - -99);
    	a302110279 = 33 ;
    	a620105235 = ((((((a620105235 * a2130183577) % 14999) + -14393) % 10) + -169) + -3);
    	a721272783 = (a190525986 - -3);
    	a1478681170 = (a2026977784 + -5);
    	a999024345 = (((((((a999024345 * a1345687529) % 14999) % 41) - -79) - -11) * 9) / 10);
    	a778006913 = (a1895857334 + -5);
    	a30494462 = ((((((a30494462 * a1254983042) % 14999) % 92) - 3) + -25495) - -25515);
    	a1625516355 = (((((((a1675035970 * a2130183577) % 14999) - -5802) + -32649) / 5) % 13) + -87);
    	a1675035970 = (((((a1675035970 * a217799639) % 17) - -198) - 118) - -108);
    	a1254983042 = ((((((a1254983042 * a999024345) % 14999) + -25737) % 101) + 102) + -1); 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm158(int input) {
    if(((a1211013485 == 34 && (((124 < a30494462) && (296 >= a30494462)) && a2087535773 == 5)) && (((a2026977784 == 9 && ((input == 12) &&  cf==1 )) && a1249952537 == 6) && ((230 < a2130183577) && (255 >= a2130183577))))) {
    	a854924571 += (a854924571 + 20) > a854924571 ? 2 : 0;
    	cf = 0;
    	a965340096 = 33 ;
    	a983758263 = (((a983758263 - -13698) * 2) * 1);
    	a1826277115 = (((((((a983758263 * a999024345) % 14999) % 62) + 65) * 5) % 62) - -71);
    	a1240243570 = (a1249952537 + 1); 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a601495656 == 34 && ( cf==1  && (input == 10))) && ((a26346326 == 34 && ((((371 < a1985899004) && (524 >= a1985899004)) && a2061425267 == 12) && a709568404 == 34)) && a1478681170 == 5))) {
    	cf = 0;
    	a1683451995 = ((a1357285245 / a1241576728) + 3);
    	a2004613952 = ((a4442917 - a1249952537) + 11); 
    	 printf("%d\n", 19); fflush(stdout); 
    } 
}
 void calculate_outputm160(int input) {
    if(((((((371 < a1985899004) && (524 >= a1985899004)) && ( cf==1  && (input == 15))) && a1180594800 == 34) && a1210910088 == 3) && (a2087535773 == 5 && (a786258498 == 10 && ((-160 < a620105235) && (30 >= a620105235)))))) {
    	cf = 0;
    	a26346326 = 33 ;
    	a30494462 = ((((((a30494462 * a1625516355) % 92) - -102) * 5) % 92) - 31);
    	a2130183577 = ((((((a2130183577 * a1985899004) % 14999) + -7357) - -17879) % 63) - -159);
    	a1478681170 = (a2061425267 + -8);
    	a778006913 = ((a1478681170 * a2087535773) - 18);
    	a1210910088 = ((a1249952537 - a2130193413) - -7);
    	a983758263 = ((((((a983758263 * a1625516355) % 14999) + 24537) % 104) + -5) / 5);
    	a1895304149 = 33 ;
    	a721272783 = (a4442917 - -7);
    	a1675035970 = ((((((a217799639 * a1625516355) / 5) % 17) - -183) - -29602) - 29601);
    	a1018383389 = ((((((a1018383389 * a1254983042) % 14999) % 74) + 23) / 5) * 5);
    	a1891437507 = 35 ;
    	a999024345 = ((((((a999024345 * a1675035970) % 14999) % 41) + 53) + -22987) - -23002);
    	a1345687529 = (((((a983758263 * a983758263) % 14999) / 5) + 21487) - -3610);
    	a4442917 = (a786258498 + -4);
    	a620105235 = (((((a620105235 * a999024345) % 10) - 170) - -1) - 3);
    	a1151361287 = ((((((a217799639 * a1625516355) - -2181) % 86) - -157) * 9) / 10);
    	a1254983042 = (((((((a1254983042 * a30494462) % 14999) + -9291) % 101) - -100) + -4657) + 4657);
    	a302110279 = 33 ;
    	a63333937 = ((((((a2130183577 * a813082108) - 6056) / 5) * 5) % 81) - 52);
    	a1644957382 = 33 ;
    	a1625516355 = (((((a1625516355 * a30494462) % 13) + -94) - 2) * 1); 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((((((230 < a2130183577) && (255 >= a2130183577)) && (((35 < a1774184757) && (169 >= a1774184757)) && ( cf==1  && (input == 10)))) && a786258498 == 10) && a263151501 == 34) && (a76745981 == 34 && a2130193413 == 11))) {
    	cf = 0;
    	a263638061 = (a1895857334 + 1);
    	a1826277115 = ((((((a983758263 * a983758263) % 14999) + -26471) * 10) / 9) + -263);
    	a153649526 = 33 ;
    	a983758263 = (((((a983758263 * a1826277115) % 14999) + 16643) * 1) * 1); 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm162(int input) {
    if((((((input == 5) &&  cf==1 ) && a76745981 == 34) && a778006913 == 3) && (((-81 < a1625516355) && (-5 >= a1625516355)) && ((a786258498 == 10 && a1830659124 == 11) && a4442917 == 7)))) {
    	cf = 0;
    	a1826277115 = (((((((a983758263 * a999024345) % 14999) - -854) - 27946) * 1) * -1) / 10);
    	a620105235 = ((((((a1675035970 * a1826277115) % 14999) % 94) - 146) - -76) + 4);
    	a1241576728 = (a1830659124 - 3);
    	a1211013485 = 34 ;
    	a404763935 = ((a786258498 - a1478681170) - -9);
    	a1249952537 = (a778006913 + 3);
    	a548050643 = 35 ;
    	a1895304149 = 34 ;
    	a601495656 = 34 ;
    	a217799639 = (((((a217799639 * a813082108) % 28) - 11) / 5) + 1);
    	a1959068056 = (a778006913 + 7);
    	a1318526106 = 34 ;
    	a983758263 = (((((a983758263 * a999024345) % 14999) + -17370) - -6877) - -16856);
    	a2061425267 = (a2004613952 + a778006913);
    	a1125477212 = 34 ;
    	a709568404 = 34 ;
    	a2130193413 = ((a4442917 - a1830659124) - -15);
    	a2073482783 = 34 ;
    	a26346326 = 34 ;
    	a30494462 = ((((((a30494462 * a1151361287) % 14999) % 85) + 137) / 5) - -137);
    	a1830659124 = ((a1895857334 - a778006913) + 7); 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a4442917 == 7 && (a786258498 == 10 && a1241576728 == 8)) && (a1983740902 == 34 && ((((29 < a63333937) && (243 >= a63333937)) && ((input == 6) &&  cf==1 )) && a1478681170 == 5)))) {
    	cf = 0;
    	a983758263 = (((((a983758263 * a1774184757) % 14999) - 16863) - -29365) * 1);
    	a601495656 = 34 ;
    	a404763935 = (a1916853335 - -7);
    	a620105235 = ((((((a1985899004 * a1254983042) % 14999) + 2135) % 94) + -78) + -59);
    	a30494462 = (((((((a30494462 * a2130183577) % 14999) + -6050) % 85) - -209) + 27793) + -27791);
    	a1318526106 = 34 ;
    	a2061425267 = (a2087535773 - -7);
    	a26346326 = 34 ;
    	a1895304149 = 34 ;
    	a1826277115 = ((((((a1337636546 * a983758263) % 14999) - -4371) / 5) + -23632) - -45591);
    	a709568404 = 34 ;
    	a1959068056 = (a1830659124 + -1);
    	a2130193413 = ((a1249952537 / a1210910088) + 9);
    	a1125477212 = 34 ;
    	a2073482783 = 34 ;
    	a1211013485 = 34 ;
    	a548050643 = 35 ;
    	a1241576728 = (a2026977784 + -1);
    	a217799639 = ((((((((a217799639 * a1151361287) % 28) - 2) * 9) / 10) * 5) % 28) + -29);
    	a1249952537 = (a1830659124 + -5);
    	a1830659124 = (a404763935 + -3); 
    	 printf("%d\n", 16); fflush(stdout); 
    } 
}
 void calculate_outputm164(int input) {
    if(((a709568404 == 34 && (a2130193413 == 11 && (a1211013485 == 34 && ( cf==1  && (input == 4))))) && ((((104 < a813082108) && (243 >= a813082108)) && a1959068056 == 10) && a1180594800 == 34))) {
    	a990043066 += (a990043066 + 20) > a990043066 ? 1 : 0;
    	cf = 0;
    	a983758263 = ((((((a983758263 * a1774184757) % 14999) + -21710) * 10) / 9) + -1672);
    	a1211013485 = 32 ;
    	a30494462 = (((((a30494462 * a63333937) % 14999) / 5) - 20587) - 2144);
    	a1180594800 = 32 ;
    	a834646264 = (a786258498 + -4);
    	a4442917 = a2087535773;
    	a999024345 = (((((a999024345 * a63333937) % 14999) + -11960) - 976) + -1500);
    	a341216798 = (((((a983758263 * a983758263) % 14999) + -25779) / 5) / 5);
    	a786258498 = (a1916853335 - -1);
    	a26346326 = 32 ;
    	a778006913 = ((a4442917 - a834646264) + 2);
    	a1254983042 = (((((a1254983042 * a63333937) % 14999) + -13993) + 37835) - 37857);
    	a263151501 = 32 ;
    	a1959068056 = (a4442917 + 3);
    	a302110279 = 33 ;
    	a1213722969 = ((a1830659124 + a2087535773) + -5);
    	a813082108 = ((((a813082108 * a1625516355) + -8728) + -647) * 1);
    	a1830659124 = (a2061425267 - 3);
    	a708839806 = 32 ;
    	a1018383389 = ((((((a260539918 * a260539918) % 14999) / 5) - 29873) % 74) - -93);
    	a2087535773 = (a1916853335 + -4);
    	a709568404 = 32 ;
    	a1318526106 = 32 ;
    	a1151361287 = ((((((((a2130183577 * a1254983042) % 14999) / 5) % 86) + 162) * 5) % 86) + 138);
    	a1625516355 = ((((((a1625516355 * a341216798) % 14999) % 13) - 94) + 22705) - 22706); 
    	 printf("%d\n", 19); fflush(stdout); 
    } if(((((202 < a1254983042) && (414 >= a1254983042)) && (((124 < a30494462) && (296 >= a30494462)) && ((input == 7) &&  cf==1 ))) && (a1180594800 == 34 && (a26346326 == 34 && (a1211013485 == 34 && a1830659124 == 11))))) {
    	cf = 0;
    	a1254983042 = (((((a1254983042 * a63333937) % 14999) - 11333) + -1813) + -54);
    	a1318526106 = 32 ;
    	a834646264 = (a1916853335 - 1);
    	a1830659124 = (a2004613952 + -2);
    	a26346326 = 32 ;
    	a1180594800 = 32 ;
    	a778006913 = ((a1241576728 + a1249952537) - 11);
    	a813082108 = ((((((a813082108 * a1018383389) % 14999) + 12500) * 1) / 5) + -24332);
    	a709568404 = 32 ;
    	a4442917 = (a834646264 + -1);
    	a1213722969 = ((a2130193413 * a1959068056) - 100);
    	a30494462 = (((((a30494462 * a1774184757) % 14999) - 19926) / 5) - 1613);
    	a2130193413 = (a834646264 - -3);
    	a341216798 = ((((((a983758263 * a983758263) % 14999) + -17271) * 10) / 9) / 5);
    	a983758263 = ((((((a983758263 * a341216798) % 14999) + -6612) + 16608) % 14997) + -15002); 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm167(int input) {
    if(((((-59 < a217799639) && (-1 >= a217799639)) && ((((input == 7) &&  cf==1 ) && ((-8 < a260539918) && (140 >= a260539918))) && ((35 < a1774184757) && (169 >= a1774184757)))) && ((a2061425267 == 12 && a1180594800 == 34) && a26346326 == 34))) {
    	cf = 0;
    	a2130193413 = (a1895857334 + 3);
    	a1241576728 = (a1210910088 - -4);
    	a26346326 = 33 ;
    	a76745981 = 33 ;
    	a548050643 = 36 ;
    	a1211013485 = 33 ;
    	a1318526106 = 33 ;
    	a983758263 = ((((((a983758263 * a1254983042) % 14999) - -7411) - -5976) - 28122) - -16594);
    	a1983740902 = 33 ;
    	a1125477212 = 33 ;
    	a1895304149 = 33 ;
    	a2073482783 = 33 ;
    	a1830659124 = (a1683451995 - -5);
    	a30494462 = (((((a30494462 * a1625516355) % 92) - -100) - 47) / 5);
    	a260539918 = (((((((a260539918 * a1151361287) % 14999) * 2) % 17) + -24) / 5) + -15);
    	a1959068056 = (a1683451995 + 4);
    	a601495656 = 34 ;
    	a217799639 = (((((a217799639 * a813082108) * 2) % 69) - 61) * 1);
    	a1826277115 = (((((a983758263 * a983758263) % 14999) + 13688) - -294) * 1);
    	a404763935 = (a1249952537 + 8);
    	a1916853335 = (a778006913 - -3);
    	a1249952537 = (a1895857334 - 2);
    	a63333937 = ((((((((a1018383389 * a1985899004) % 14999) % 81) - 116) * 5) + 6484) % 81) + -91);
    	a1018383389 = (((((a1018383389 * a1625516355) % 74) - -128) - -24327) + -24320); 
    	 printf("%d\n", 18); fflush(stdout); 
    } if(((a4442917 == 7 && ((input == 8) &&  cf==1 )) && ((((-81 < a1625516355) && (-5 >= a1625516355)) && (a2073482783 == 34 && (a1210910088 == 3 && ((167 < a1018383389) && (211 >= a1018383389))))) && ((249 < a1151361287) && (291 >= a1151361287))))) {
    	cf = 0;
    	a26346326 = 34 ;
    	a1895304149 = 34 ;
    	a709568404 = 34 ;
    	a2061425267 = (a1830659124 - -1);
    	a601495656 = 34 ;
    	a404763935 = ((a2026977784 / a1959068056) + 14);
    	a983758263 = (((((a983758263 * a999024345) % 14999) + 2240) + 11478) - -33);
    	a1318526106 = 34 ;
    	a1959068056 = (a778006913 + 7);
    	a1826277115 = (((((((a1774184757 * a2130183577) % 14999) - -654) * 10) / 9) * 10) / 9);
    	a620105235 = ((((((a260539918 * a1018383389) * 1) + -6729) - 4768) % 94) - 63);
    	a1830659124 = ((a1478681170 - a786258498) - -16);
    	a1125477212 = 34 ;
    	a548050643 = 35 ;
    	a2073482783 = 34 ;
    	a30494462 = ((((((a30494462 * a1985899004) % 14999) - -432) + -6178) % 85) + 209);
    	a217799639 = (((((a217799639 * a1675035970) - 11458) % 28) + -6) / 5);
    	a1241576728 = (a2087535773 + 3);
    	a2130193413 = ((a1478681170 / a1683451995) + 10);
    	a1211013485 = 34 ;
    	a1249952537 = ((a786258498 + a190525986) - 15); 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((((131 < a999024345) && (260 >= a999024345)) && ((a1959068056 == 10 && a76745981 == 34) && a1983740902 == 34)) && ((( cf==1  && (input == 11)) && a709568404 == 34) && a263151501 == 34))) {
    	cf = 0;
    	a1895857334 = (a1683451995 - -8);
    	a1125477212 = 33 ;
    	a266166646 = (((((((a2130183577 * a1675035970) % 14999) - 10551) % 77) + 235) + -17501) - -17501);
    	a1774184757 = (((((((a1774184757 * a1254983042) % 14999) - -11559) - -2157) - 24918) % 92) - 56);
    	a302110279 = 33 ;
    	a1983740902 = 33 ;
    	a1644957382 = 33 ;
    	a2087632595 = 34 ;
    	a1211013485 = 33 ;
    	a2087535773 = (a786258498 - 6);
    	a2130183577 = ((((((a2130183577 * a983758263) % 14999) - 25767) - 242) % 63) - -209);
    	a190525986 = (a2026977784 - -1);
    	a1675035970 = ((((((a1675035970 * a266166646) % 14999) / 5) % 17) + 183) - -4); 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((((((-8 < a260539918) && (140 >= a260539918)) && ((a1210910088 == 3 && ( cf==1  && (input == 14))) && ((249 < a1151361287) && (291 >= a1151361287)))) && a778006913 == 3) && ((202 < a1254983042) && (414 >= a1254983042))) && a1180594800 == 34)) {
    	cf = 0;
    	a803418896 = (((((a1774184757 * a1774184757) % 89) + -169) + -4) - -42);
    	a721272783 = (a1830659124 - 1);
    	a2026977784 = (a1830659124 + -3);
    	a1211013485 = 33 ;
    	a1348848030 = (a786258498 + 2);
    	a1985899004 = ((((((a803418896 * a260539918) + -3016) + -1670) * 1) % 98) + 328);
    	a2073482783 = 33 ;
    	a26346326 = 33 ;
    	a190525986 = (a1683451995 - -5);
    	a2087535773 = (a1830659124 - 7);
    	a1478681170 = (a2026977784 - 4);
    	a1774184757 = (((((((a1254983042 * a2130183577) % 14999) + -25517) / 5) - 20717) % 92) + -50);
    	a999024345 = (((((((a999024345 * a217799639) % 41) + 93) * 5) + 14592) % 41) + 90);
    	a1018383389 = ((((((a1018383389 * a813082108) % 14999) % 74) + 28) / 5) - -90);
    	a1895304149 = 33 ;
    	a2130193413 = (a2004613952 + -2);
    	a1318526106 = 33 ;
    	a1241576728 = (a1249952537 - -1);
    	a76745981 = 33 ;
    	a1625516355 = (((((((a1625516355 * a813082108) % 13) - 90) * 5) * 5) % 13) - 90);
    	a1180594800 = 33 ;
    	a786258498 = (a778006913 + 6);
    	a2130183577 = (((((((a803418896 * a999024345) % 63) - -167) * 5) * 5) % 63) + 129);
    	a983758263 = ((((((((a983758263 * a803418896) % 14999) * 2) % 104) - -98) * 5) % 104) - -99);
    	a620105235 = ((((((a260539918 * a260539918) % 10) + -171) * 5) % 10) - 163);
    	a1644957382 = 33 ;
    	a4442917 = ((a190525986 + a2061425267) - 16);
    	a1983740902 = 33 ;
    	a217799639 = ((((((a260539918 * a1675035970) % 14999) % 69) + -128) + 1) - 1);
    	a1210910088 = (a2026977784 + -6);
    	a1916853335 = (a1830659124 + -5);
    	a1249952537 = ((a778006913 * a1478681170) + -7);
    	a263151501 = 33 ;
    	a1125477212 = 33 ;
    	a63333937 = ((((((((a620105235 * a1985899004) % 14999) + 25017) % 81) + -114) + -343) * 1) / 10);
    	a30494462 = ((((((((a30494462 * a1151361287) % 14999) - 22524) % 92) - -118) * 5) % 92) + -27);
    	a813082108 = ((((((a813082108 * a1254983042) % 14999) - -1303) - 29843) % 50) - -103);
    	a1959068056 = (a721272783 - 1);
    	a1151361287 = (((((a803418896 * a260539918) / 5) - -28620) % 86) - -104);
    	a1254983042 = ((((((a1675035970 * a260539918) % 14999) - 10914) % 101) - -100) + 1);
    	a709568404 = 33 ;
    	a1675035970 = ((((((a803418896 * a803418896) - 10634) / 5) * 5) % 17) - -188);
    	a260539918 = ((((((a260539918 * a999024345) % 17) - 25) - -1) - 6615) - -6614);
    	a1830659124 = ((a1683451995 - a778006913) + 8); 
    	 printf("%d\n", 26); fflush(stdout); 
    } 
}
 void calculate_outputm169(int input) {
    if(((a2061425267 == 12 && a786258498 == 10) && (((-59 < a217799639) && (-1 >= a217799639)) && ((a190525986 == 11 && (( cf==1  && (input == 6)) && a778006913 == 3)) && a26346326 == 34)))) {
    	a170107731 -= (a170107731 - 20) < a170107731 ? 1 : 0;
    	cf = 0;
    	a709568404 = 34 ;
    	a1959068056 = (a1830659124 - 1);
    	a1895304149 = 34 ;
    	a548050643 = 35 ;
    	a983758263 = (((((a983758263 * a1774184757) % 14999) / 5) + 10325) + 6979);
    	a404763935 = (a1210910088 + 11);
    	a1318526106 = 34 ;
    	a1211013485 = 34 ;
    	a2087535773 = ((a1249952537 / a1683451995) + 5);
    	a620105235 = (((((((a1151361287 * a1774184757) % 14999) + 13968) / 5) - -15146) % 94) - 149);
    	a217799639 = ((((((a217799639 * a63333937) + 27921) / 5) * 5) % 28) + -30);
    	a1830659124 = ((a2026977784 * a778006913) + -16);
    	a1826277115 = (((((a813082108 * a999024345) % 14999) - 29173) + -430) - -41403);
    	a1675035970 = ((((((a1018383389 * a1254983042) % 14999) + 13564) % 51) - -209) + -1);
    	a708839806 = 34 ;
    	a1241576728 = (a2004613952 - 4);
    	a1478681170 = (a190525986 - 6);
    	a2073482783 = 34 ;
    	a1125477212 = 34 ;
    	a1180594800 = 34 ;
    	a260539918 = ((((((((a1675035970 * a1985899004) % 14999) % 73) - 6) * 5) * 5) % 73) - -66);
    	a1644957382 = 34 ;
    	a2061425267 = (a2130193413 + 1);
    	a26346326 = 34 ;
    	a1249952537 = (a404763935 - 8);
    	a601495656 = 34 ;
    	a2130193413 = (a786258498 + 1);
    	a30494462 = ((((((a30494462 * a1625516355) / 5) * 5) + 14500) % 85) - -210); 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a1211013485 == 34 && (((124 < a30494462) && (296 >= a30494462)) && ((a1916853335 == 7 && ((( cf==1  && (input == 14)) && a2130193413 == 11) && a1895304149 == 34)) && a2073482783 == 34)))) {
    	cf = 0;
    	a341216798 = (((((a2130183577 * a1985899004) % 14999) / 5) - 11600) / 5);
    	a786258498 = (a1830659124 + -3);
    	a4442917 = ((a1249952537 - a2004613952) - -11);
    	a263151501 = 32 ;
    	a601495656 = 32 ;
    	a709568404 = 32 ;
    	a1959068056 = (a2026977784 + -1);
    	a834646264 = ((a1210910088 - a1683451995) + 11);
    	a30494462 = ((((((a30494462 * a1151361287) % 14999) + -28224) / 5) + 12553) + -25966);
    	a26346326 = 32 ;
    	a1254983042 = ((((((a1254983042 * a1675035970) % 14999) + -15000) / 5) / 5) - 21316);
    	a1625516355 = ((((((a341216798 * a30494462) % 14999) % 13) - 95) + 4697) + -4695);
    	a983758263 = (((((a983758263 * a1774184757) % 14999) + -16855) - 3144) + -2114);
    	a1213722969 = (a1895857334 - -4);
    	a1211013485 = 32 ;
    	a1210910088 = ((a1916853335 * a4442917) + -34);
    	a302110279 = 33 ;
    	a778006913 = (a1959068056 - 7);
    	a2130183577 = (((((a341216798 * a63333937) % 14999) + -14966) + -14) - 1);
    	a2073482783 = 32 ;
    	a1895304149 = 32 ;
    	a999024345 = (((((a999024345 * a620105235) % 14999) - 10975) - 571) + -530);
    	a1151361287 = (((((((((a983758263 * a217799639) % 14999) % 86) + 117) * 10) / 9) / 5) * 31) / 10);
    	a813082108 = ((((((a813082108 * a1018383389) % 14999) - -14393) * 1) * 1) * -1);
    	a1830659124 = ((a2087535773 / a2061425267) - -9);
    	a63333937 = ((((((a63333937 * a341216798) % 14999) % 14932) + -15066) - 0) * 1);
    	a1018383389 = ((((((((a1018383389 * a813082108) % 14999) % 74) + 92) - -1) / 5) * 45) / 10); 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((((167 < a1018383389) && (211 >= a1018383389)) && a601495656 == 34) && (a709568404 == 34 && (a1959068056 == 10 && ((( cf==1  && (input == 15)) && ((249 < a1151361287) && (291 >= a1151361287))) && a2130193413 == 11))))) {
    	cf = 0;
    	a30494462 = (((((((a30494462 * a813082108) % 14999) % 85) + 125) + 0) - 2391) + 2466);
    	a26346326 = 34 ;
    	a601495656 = 34 ;
    	a1241576728 = ((a1916853335 * a1895857334) + -41);
    	a620105235 = ((((((a2130183577 * a1625516355) + 12290) + -17698) / 5) % 94) + -12);
    	a1211013485 = 34 ;
    	a1249952537 = (a2130193413 - 5);
    	a1830659124 = ((a2061425267 * a2130193413) + -121);
    	a548050643 = 35 ;
    	a983758263 = (((((a983758263 * a999024345) % 14999) / 5) - -16539) - -1307);
    	a404763935 = ((a190525986 / a1683451995) + 13);
    	a1826277115 = (((((a983758263 * a983758263) % 14999) + 14239) * 1) + 507);
    	a2087535773 = (a1959068056 + -5);
    	a260539918 = ((((((a1151361287 * a1018383389) % 14999) - -7831) % 73) + 4) / 5);
    	a217799639 = (((((a217799639 * a1625516355) % 28) + -50) - -1) - -20);
    	a709568404 = 34 ;
    	a2073482783 = 34 ;
    	a1318526106 = 34 ;
    	a708839806 = 34 ;
    	a1675035970 = ((((((a1151361287 * a1774184757) % 14999) % 51) + 253) + -624) + 583);
    	a1959068056 = ((a1683451995 - a1916853335) - -9);
    	a1895304149 = 34 ;
    	a2130193413 = (a1210910088 - -8);
    	a1180594800 = 34 ;
    	a1644957382 = 34 ;
    	a1478681170 = (a786258498 - 5);
    	a1125477212 = 34 ;
    	a2061425267 = ((a2004613952 / a1683451995) - -11); 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm170(int input) {
    if(((a2061425267 == 12 && ((a1180594800 == 34 && (((input == 8) &&  cf==1 ) && ((-59 < a217799639) && (-1 >= a217799639)))) && a2130193413 == 11)) && (a709568404 == 34 && a2087535773 == 5))) {
    	cf = 0;
    	a708839806 = 34 ;
    	a1895857334 = (a2026977784 + 2);
    	a1574467713 = (a2087535773 + 2);
    	a620988906 = 33 ;
    	a2026977784 = (a1959068056 - 1);
    	a1125477212 = 34 ;
    	a2130193413 = (a1249952537 - -5);
    	a26346326 = 33 ;
    	a778006913 = ((a190525986 + a190525986) + -19);
    	a63333937 = ((((((a30494462 * a999024345) % 14999) % 81) - 107) + -23061) - -23057);
    	a1318526106 = 33 ;
    	a1478681170 = ((a1574467713 * a190525986) - 73);
    	a1985899004 = (((((((a1254983042 * a1675035970) % 14999) + 1476) + 12531) - 3549) % 76) - -424); 
    	 printf("%d\n", 19); fflush(stdout); 
    } 
}
 void calculate_outputm172(int input) {
    if((((((104 < a813082108) && (243 >= a813082108)) && ( cf==1  && (input == 8))) && ((-160 < a620105235) && (30 >= a620105235))) && (((a2026977784 == 9 && ((202 < a1254983042) && (414 >= a1254983042))) && a2073482783 == 34) && a601495656 == 34))) {
    	cf = 0;
    	a302110279 = 34 ;
    	a620105235 = ((((((a620105235 * a813082108) % 14999) / 5) % 94) - 63) + -3);
    	a1249952537 = (a1241576728 - 2);
    	a778006913 = (a2061425267 + -9);
    	a1574467713 = (a190525986 + -10);
    	a263638061 = (a1478681170 - -6);
    	a813082108 = ((((((((a1675035970 * a999024345) % 14999) % 69) + 122) * 9) / 10) * 10) / 9);
    	a1318526106 = 34 ;
    	a1210910088 = (a4442917 - 4);
    	a1983740902 = 34 ;
    	a190525986 = (a2004613952 - 2);
    	a260539918 = (((((a217799639 * a30494462) * 1) - 6436) % 73) + 84);
    	a708839806 = 34 ;
    	a709568404 = 34 ;
    	a1625516355 = ((((((a1625516355 * a1675035970) * 1) % 37) - 22) / 5) - 61);
    	a63333937 = ((((((a1985899004 * a1774184757) % 14999) / 5) % 106) + 124) + -30);
    	a1895857334 = (a2087535773 - -6);
    	a2026977784 = (a786258498 - 1);
    	a1478681170 = (a1830659124 + -6); 
    	 printf("%d\n", 20); fflush(stdout); 
    } if(((((a1249952537 == 6 && a1318526106 == 34) && ((-160 < a620105235) && (30 >= a620105235))) && a601495656 == 34) && ((( cf==1  && (input == 15)) && a1478681170 == 5) && a778006913 == 3))) {
    	cf = 0;
    	a983758263 = ((((((a983758263 * a1254983042) % 14999) + 14981) - -3) - 35571) + 30808);
    	a1826277115 = ((((((a2130183577 * a1625516355) % 62) + 120) - -16) * 9) / 10);
    	a965340096 = 35 ;
    	a834646264 = ((a190525986 * a190525986) - 110); 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm14(int input) {
    if(((a1644957382 == 34 && ( cf==1  && a2004613952 == 6)) && ((((a709568404 == 34 && a2130193413 == 11) && ((-160 < a620105235) && (30 >= a620105235))) && a2061425267 == 12) && ((167 < a1018383389) && (211 >= a1018383389))))) {
    	if(((((202 < a1254983042) && (414 >= a1254983042)) && ((((a566060042 <=  -3 &&  cf==1 ) && a1180594800 == 34) && a1241576728 == 8) && a1210910088 == 3)) && (((-8 < a260539918) && (140 >= a260539918)) && a1249952537 == 6))) {
    		calculate_outputm154(input);
    	} 
    	if(((((-81 < a1625516355) && (-5 >= a1625516355)) && ((((131 < a999024345) && (260 >= a999024345)) && ((((-3 < a566060042) && (27 >= a566060042)) &&  cf==1 ) && ((249 < a1151361287) && (291 >= a1151361287)))) && ((202 < a1254983042) && (414 >= a1254983042)))) && (a26346326 == 34 && a786258498 == 10))) {
    		calculate_outputm155(input);
    	} 
    	if(((a708839806 == 34 && (a1241576728 == 8 && (a1895304149 == 34 && a190525986 == 11))) && (((77 < a566060042 &&  cf==1 ) && a1210910088 == 3) && a263151501 == 34))) {
    		calculate_outputm156(input);
    	} 
    } 
    if(((a2130193413 == 11 && ( cf==1  && a2004613952 == 7)) && (a2073482783 == 34 && (a302110279 == 34 && (((-160 < a620105235) && (30 >= a620105235)) && (a1125477212 == 34 && a1478681170 == 5)))))) {
    	if(((a1318526106 == 34 && ((a1357285245 == 8 &&  cf==1 ) && a2087535773 == 5)) && (((-59 < a217799639) && (-1 >= a217799639)) && ((a709568404 == 34 && a1241576728 == 8) && ((124 < a30494462) && (296 >= a30494462)))))) {
    		calculate_outputm157(input);
    	} 
    	if(((a601495656 == 34 && (((35 < a1774184757) && (169 >= a1774184757)) && (a4442917 == 7 && (a2026977784 == 9 && a190525986 == 11)))) && (a1318526106 == 34 && (a1357285245 == 12 &&  cf==1 )))) {
    		calculate_outputm158(input);
    	} 
    } 
    if((((((-59 < a217799639) && (-1 >= a217799639)) && a302110279 == 34) && a1895304149 == 34) && ((a601495656 == 34 && (a1249952537 == 6 && ( cf==1  && a2004613952 == 8))) && a778006913 == 3))) {
    	if(((a709568404 == 34 && ((167 < a1018383389) && (211 >= a1018383389))) && (((((a1969216760 == 36 &&  cf==1 ) && a786258498 == 10) && a1830659124 == 11) && a26346326 == 34) && a2061425267 == 12))) {
    		calculate_outputm160(input);
    	} 
    } 
    if(((((((-8 < a260539918) && (140 >= a260539918)) && a302110279 == 34) && a2087535773 == 5) && ((29 < a63333937) && (243 >= a63333937))) && (a190525986 == 11 && (a1249952537 == 6 && ( cf==1  && a2004613952 == 9))))) {
    	if(((((-59 < a217799639) && (-1 >= a217799639)) && ((236 < a1337636546 &&  cf==1 ) && a190525986 == 11)) && (a2026977784 == 9 && ((((-81 < a1625516355) && (-5 >= a1625516355)) && ((131 < a999024345) && (260 >= a999024345))) && a1241576728 == 8)))) {
    		calculate_outputm162(input);
    	} 
    } 
    if(((((((a2004613952 == 11 &&  cf==1 ) && ((-81 < a1625516355) && (-5 >= a1625516355))) && a1180594800 == 34) && a708839806 == 34) && a709568404 == 34) && (a2087535773 == 5 && a4442917 == 7))) {
    	if(((a2130193413 == 11 && ((a1318526106 == 34 && (a1667689532 == 32 &&  cf==1 )) && a1125477212 == 34)) && ((a2061425267 == 12 && a1959068056 == 10) && a1983740902 == 34))) {
    		calculate_outputm164(input);
    	} 
    } 
    if(((((a2073482783 == 34 && (a2004613952 == 12 &&  cf==1 )) && ((167 < a1018383389) && (211 >= a1018383389))) && a786258498 == 10) && ((a1983740902 == 34 && a4442917 == 7) && a778006913 == 3))) {
    	if((a1211013485 == 34 && ((a1249952537 == 6 && (((-81 < a1625516355) && (-5 >= a1625516355)) && (((a1683451995 == 5 &&  cf==1 ) && a1125477212 == 34) && ((104 < a813082108) && (243 >= a813082108))))) && a2130193413 == 11))) {
    		calculate_outputm167(input);
    	} 
    	if(((((104 < a813082108) && (243 >= a813082108)) && (((29 < a63333937) && (243 >= a63333937)) && (( cf==1  && a1683451995 == 8) && a709568404 == 34))) && (a190525986 == 11 && (a1210910088 == 3 && ((35 < a1774184757) && (169 >= a1774184757)))))) {
    		calculate_outputm169(input);
    	} 
    } 
    if(((((a2130193413 == 11 && a1249952537 == 6) && a1959068056 == 10) && a778006913 == 3) && ((( cf==1  && a2004613952 == 13) && a1241576728 == 8) && a1125477212 == 34))) {
    	if(((a1249952537 == 6 && (( cf==1  && ((-95 < a1260876233) && (13 >= a1260876233))) && ((230 < a2130183577) && (255 >= a2130183577)))) && (((((35 < a1774184757) && (169 >= a1774184757)) && a1180594800 == 34) && a4442917 == 7) && a1125477212 == 34))) {
    		calculate_outputm170(input);
    	} 
    	if(((a1241576728 == 8 && (a1830659124 == 11 && (198 < a1260876233 &&  cf==1 ))) && (a2087535773 == 5 && ((((230 < a2130183577) && (255 >= a2130183577)) && ((124 < a30494462) && (296 >= a30494462))) && ((-81 < a1625516355) && (-5 >= a1625516355)))))) {
    		calculate_outputm172(input);
    	} 
    } 
}
 void calculate_outputm173(int input) {
    if(((a1125477212 == 34 && ( cf==1  && (input == 4))) && ((((35 < a1774184757) && (169 >= a1774184757)) && (a1211013485 == 34 && (a1830659124 == 11 && ((-8 < a260539918) && (140 >= a260539918))))) && a1318526106 == 34))) {
    	cf = 0;
    	a1895857334 = a190525986;
    	a302110279 = 34 ;
    	a1478681170 = (a786258498 - 5);
    	a1625516355 = ((((((a217799639 * a30494462) / 5) + 19252) * 1) % 37) + -77);
    	a1983740902 = 34 ;
    	a813082108 = (((((a217799639 * a2130183577) + 8976) % 69) - -173) * 1);
    	a1318526106 = 34 ;
    	a778006913 = (a4442917 + -4);
    	a263638061 = a2130193413;
    	a1574467713 = (a2026977784 - 8);
    	a620105235 = ((((((a1254983042 * a63333937) % 14999) - -12738) - -1663) % 94) + -75);
    	a2026977784 = (a1210910088 - -6);
    	a1210910088 = (a190525986 - 8);
    	a708839806 = 34 ;
    	a1249952537 = (a2087535773 - -1);
    	a63333937 = ((((((a217799639 * a260539918) * 3) % 106) - -137) + -5862) + 5860);
    	a190525986 = a1895857334;
    	a709568404 = 34 ;
    	a260539918 = ((((((a260539918 * a1774184757) * 1) % 73) - -65) + 15289) - 15288); 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((((input == 15) &&  cf==1 ) && a1180594800 == 34) && ((a1983740902 == 34 && (a2073482783 == 34 && (((35 < a1774184757) && (169 >= a1774184757)) && a1895304149 == 34))) && ((124 < a30494462) && (296 >= a30494462))))) {
    	cf = 0;
    	a834646264 = (a1895857334 + 4);
    	a965340096 = 35 ;
    	a1826277115 = ((((((a983758263 * a983758263) % 14999) % 62) - -110) * 5) / 5);
    	a983758263 = (((((((a983758263 * a1826277115) % 14999) + -14196) * 2) + 18401) % 14796) + 15202); 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm174(int input) {
    if((((input == 5) &&  cf==1 ) && (((((a1241576728 == 8 && a2026977784 == 9) && ((124 < a30494462) && (296 >= a30494462))) && a1916853335 == 7) && a1210910088 == 3) && ((167 < a1018383389) && (211 >= a1018383389))))) {
    	a707706067 += (a707706067 + 20) > a707706067 ? 6 : 0;
    	cf = 0;
    	a1151361287 = ((((((((a1018383389 * a1018383389) % 14999) % 86) + 77) * 10) / 9) + 2939) - 2915);
    	a1318526106 = 34 ;
    	a190525986 = ((a1895857334 + a2026977784) + -7);
    	a26346326 = 33 ;
    	a1774184757 = ((((((((a1151361287 * a63333937) % 14999) % 92) + -95) * 10) / 9) * 10) / 9);
    	a983758263 = (((((((a983758263 * a1254983042) % 14999) / 5) % 104) - -25) + -24194) - -24243);
    	a786258498 = (a778006913 + 6);
    	a601495656 = 34 ;
    	a2130193413 = (a1895857334 - -2);
    	a260539918 = (((((((a1774184757 * a983758263) % 14999) * 2) + -3) + 5) % 17) - 26);
    	a2061425267 = a1830659124;
    	a813082108 = ((((((a1774184757 * a1151361287) % 14999) - -6738) / 5) % 50) + 54);
    	a1597554373 = 32 ;
    	a1675035970 = (((((((a2130183577 * a2130183577) % 14999) + 8340) * 1) * 1) % 17) - -180);
    	a1241576728 = (a1249952537 - -1);
    	a1644957382 = 34 ;
    	a709568404 = 33 ;
    	a1478681170 = ((a4442917 - a190525986) + 7);
    	a999024345 = (((((((a63333937 * a362219248) % 14999) - -10389) % 41) + 79) + -19256) + 19237);
    	a1210910088 = (a2130193413 - 8);
    	a721272783 = ((a1916853335 - a1916853335) - -12);
    	a76745981 = 33 ;
    	a778006913 = ((a1249952537 / a721272783) - -3);
    	a1569588614 = ((((a63333937 * a217799639) * 2) + 14655) + 14001);
    	a1895304149 = 33 ;
    	a263151501 = 33 ;
    	a1625516355 = ((((((a63333937 * a1018383389) % 14999) % 13) + -104) / 5) - 67);
    	a2130183577 = ((((((a1018383389 * a999024345) % 12) + 242) + -17723) + 22505) - 4783);
    	a1254983042 = (((((a813082108 * a1774184757) / 5) * 5) % 101) - -99);
    	a620105235 = (((((((a1675035970 * a1774184757) % 14999) * 2) * 1) * 1) % 94) + -64);
    	a217799639 = (((((a217799639 * a260539918) * 5) - -10162) % 28) - 46);
    	a1180594800 = 33 ;
    	a1916853335 = (a1895857334 + -2);
    	a4442917 = ((a1249952537 * a1241576728) - 35);
    	a30494462 = ((((((a30494462 * a999024345) % 14999) / 5) + 1486) % 92) + 23);
    	a1959068056 = (a1249952537 - -3);
    	a1983740902 = 34 ;
    	a1830659124 = ((a2087535773 - a2087535773) - -10);
    	a2087535773 = (a2026977784 - 4);
    	a1018383389 = ((((((a1018383389 * a260539918) + 4471) % 74) + 93) * 9) / 10);
    	a1249952537 = (a2061425267 - 6); 
    	 printf("%d\n", 26); fflush(stdout); 
    } if((((a2073482783 == 34 && ((input == 6) &&  cf==1 )) && a4442917 == 7) && (((a1180594800 == 34 && ((202 < a1254983042) && (414 >= a1254983042))) && a786258498 == 10) && ((-59 < a217799639) && (-1 >= a217799639))))) {
    	cf = 0;
    	a1260876233 = ((((((a63333937 * a260539918) % 14999) % 14900) + 15098) - 0) * 1);
    	a1180594800 = 34 ;
    	a2004613952 = (a1830659124 - -2);
    	a1895304149 = 34 ;
    	a1895857334 = ((a1241576728 - a2061425267) + 11);
    	a217799639 = ((((((a217799639 * a999024345) + -7526) % 28) - 9) + 19012) + -19021);
    	a1151361287 = ((((((((a1254983042 * a999024345) % 14999) % 20) + 250) * 1) / 5) * 51) / 10); 
    	 printf("%d\n", 20); fflush(stdout); 
    } if(((((131 < a999024345) && (260 >= a999024345)) && ((a4442917 == 7 && a2130193413 == 11) && a1478681170 == 5)) && (((230 < a2130183577) && (255 >= a2130183577)) && (( cf==1  && (input == 8)) && a786258498 == 10)))) {
    	cf = 0;
    	a1478681170 = (a1241576728 + -3);
    	a1774184757 = ((((((a30494462 * a1018383389) % 14999) % 66) + 75) + 23) + -2);
    	a1912617323 = ((a1959068056 * a1830659124) - 101);
    	a302110279 = 34 ;
    	a2026977784 = (a1895857334 - -1);
    	a1180594800 = 34 ;
    	a983758263 = ((((((a983758263 * a260539918) % 14999) + -13464) % 14796) + 15202) * 1);
    	a263219509 = ((a2087535773 + a2130193413) - 11);
    	a1318526106 = 34 ;
    	a2073482783 = 34 ;
    	a620105235 = (((((((a1675035970 * a1018383389) % 14999) % 94) + -64) - -8565) / 5) - 1838);
    	a63333937 = (((((a63333937 * a813082108) % 14999) - 26620) * 1) * 1);
    	a1826277115 = ((((((a983758263 * a362219248) % 14999) + -5214) % 105) - 51) / 5);
    	a1018383389 = ((((((((a1018383389 * a30494462) % 14999) % 21) + 190) * 5) + 1684) % 21) + 186); 
    	 printf("%d\n", 19); fflush(stdout); 
    } 
}
 void calculate_outputm176(int input) {
    if((((((371 < a1985899004) && (524 >= a1985899004)) && (( cf==1  && (input == 2)) && a2130193413 == 11)) && ((-8 < a260539918) && (140 >= a260539918))) && (a1478681170 == 5 && (a1644957382 == 34 && a76745981 == 34)))) {
    	cf = 0;
    	a1478681170 = (a2061425267 - 8);
    	a786258498 = (a1241576728 - -1);
    	a778006913 = ((a1478681170 + a1478681170) - 7);
    	a190525986 = (a1916853335 + 3);
    	a601495656 = 33 ;
    	a2073482783 = 33 ;
    	a30494462 = ((((((a30494462 * a813082108) % 14999) + 6204) % 92) - -33) + -84);
    	a1211013485 = 32 ;
    	a721272783 = (a2130193413 + 6);
    	a983758263 = (((((((a983758263 * a1774184757) % 14999) % 104) - 5) + 0) - -29575) + -29550);
    	a999024345 = ((((((a999024345 * a578474405) % 14999) + 10893) % 41) + 69) - -1);
    	a1644957382 = 33 ;
    	a2130183577 = ((((((((a2130183577 * a1675035970) % 14999) % 63) - -115) * 5) - -27155) % 63) - -155);
    	a620105235 = ((((((a1675035970 * a813082108) * 10) / -9) / 5) * 10) / 8);
    	a1830659124 = (a2026977784 + 1);
    	a1254983042 = (((((a1254983042 * a999024345) % 14999) - 10971) - 14757) * 1);
    	a2087535773 = (a2026977784 + -5);
    	a1210910088 = (a4442917 + -5);
    	a217799639 = (((((a217799639 * a1018383389) % 69) + -107) - 22) + 0);
    	a260539918 = ((((((a260539918 * a1151361287) % 14999) % 17) - 24) + 3198) + -3199);
    	a524719993 = 36 ;
    	a2061425267 = (a1959068056 + 1);
    	a76745981 = 33 ;
    	a1774184757 = ((((((a1985899004 * a1151361287) % 14999) + -14884) % 92) + -57) / 5);
    	a709568404 = 32 ;
    	a1895304149 = 33 ;
    	a1700231631 = (a2026977784 - 4);
    	a4442917 = (a1478681170 - -1);
    	a1916853335 = a1241576728;
    	a2130193413 = ((a1249952537 - a1959068056) + 15);
    	a63333937 = ((((a1018383389 * a1625516355) - -19280) + -24295) + -5912);
    	a302110279 = 34 ;
    	a1985899004 = ((((((a1985899004 * a1151361287) % 14999) + 3073) - -6297) % 98) + 252);
    	a2026977784 = (a1241576728 + 2);
    	a1959068056 = (a1478681170 + 4); 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm177(int input) {
    if(((((167 < a1018383389) && (211 >= a1018383389)) && (((207 < a1675035970) && (311 >= a1675035970)) && ((29 < a63333937) && (243 >= a63333937)))) && ((((-8 < a260539918) && (140 >= a260539918)) && (((input == 11) &&  cf==1 ) && ((371 < a1985899004) && (524 >= a1985899004)))) && a2130193413 == 11))) {
    	cf = 0;
    	a1625516355 = (((((a1625516355 * a813082108) - 1907) % 13) + -90) + 2);
    	a26346326 = 33 ;
    	a721272783 = (a2087535773 - -9);
    	a1895304149 = 33 ;
    	a30494462 = ((((((a30494462 * a217799639) % 92) - -86) + 5) - -10971) + -11013);
    	a1644957382 = 33 ;
    	a63333937 = (((((((a63333937 * a983758263) % 14999) + 8682) / 5) / 5) % 81) - 102);
    	a1018383389 = ((((((((a1018383389 * a1675035970) % 14999) % 74) + 93) * 5) + 1125) % 74) + 31);
    	a1891437507 = 35 ;
    	a302110279 = 33 ;
    	a1675035970 = ((((((a1675035970 * a260539918) % 14999) % 17) + 190) - 1) * 1);
    	a1254983042 = (((((((a1254983042 * a1625516355) % 14999) % 101) - -101) + -18247) / 5) - -3705);
    	a999024345 = (((((a999024345 * a813082108) % 41) - -78) + 28067) + -28093);
    	a1210910088 = (a2130193413 - 9);
    	a1478681170 = ((a2130193413 - a1959068056) + 3);
    	a983758263 = (((((a983758263 * 1) / 10) * 5) * 9) / 10);
    	a1345687529 = (((((a983758263 * a983758263) % 14999) / 5) / 5) + 1889); 
    	 printf("%d\n", 19); fflush(stdout); 
    } if(((((a1241576728 == 8 && ( cf==1  && (input == 6))) && a1644957382 == 34) && a1125477212 == 34) && (((202 < a1254983042) && (414 >= a1254983042)) && (((371 < a1985899004) && (524 >= a1985899004)) && a302110279 == 34)))) {
    	a1933720537 += (a1933720537 + 20) > a1933720537 ? 4 : 0;
    	cf = 0;
    	a1474668405 = (((((a999024345 * a983758263) % 14999) + -29790) + -157) * 1);
    	a1675035970 = (((((((a1675035970 * a1985899004) % 14999) + -25399) * 1) - -11784) % 17) + 188);
    	a1210910088 = ((a2061425267 - a1895857334) + -2);
    	a1895304149 = 33 ;
    	a1018383389 = (((((((a1018383389 * a620105235) % 14999) % 74) - -93) - 22470) / 5) + 4590);
    	a1345687529 = (((((((a1474668405 * a983758263) % 14999) - 9403) % 56) - 126) + -15717) + 15747);
    	a721272783 = ((a190525986 - a2061425267) + 15);
    	a1916853335 = ((a1241576728 - a2130193413) + 9);
    	a1625516355 = ((((((a1625516355 * a260539918) % 13) + -94) / 5) * 51) / 10);
    	a1478681170 = (a1916853335 - 2);
    	a983758263 = ((((((a983758263 * a1985899004) % 14999) % 104) + -3) + 23993) + -23943);
    	a1254983042 = ((((((a1254983042 * a30494462) % 14999) % 101) - -75) - -14) - 13);
    	a26346326 = 33 ;
    	a30494462 = ((((((a30494462 * a1254983042) % 14999) + -8355) % 92) - -30) + 2);
    	a63333937 = (((((((a63333937 * a260539918) % 14999) % 81) - 53) / 5) + -9301) - -9202);
    	a2130193413 = (a1830659124 + -1); 
    	 printf("%d\n", 17); fflush(stdout); 
    } 
}
 void calculate_outputm178(int input) {
    if(((((167 < a1018383389) && (211 >= a1018383389)) && (((249 < a1151361287) && (291 >= a1151361287)) && (a1916853335 == 7 && a1644957382 == 34))) && ((a2073482783 == 34 && ( cf==1  && (input == 2))) && ((131 < a999024345) && (260 >= a999024345))))) {
    	cf = 0;
    	a1241576728 = (a2026977784 + -3);
    	a1211013485 = 32 ;
    	a999024345 = (((((a999024345 * a260539918) % 14999) + 7849) / 5) + -21871);
    	a1830659124 = (a1241576728 - -3);
    	a1959068056 = ((a1895857334 * a1895857334) + -56);
    	a1644957382 = 32 ;
    	a263151501 = 32 ;
    	a4442917 = (a2026977784 - 4);
    	a2087535773 = ((a1916853335 / a1959068056) + 3);
    	a983758263 = ((((((a983758263 * a1254983042) % 14999) - 19715) * 10) / 9) + -3423);
    	a786258498 = (a4442917 + 3);
    	a834646264 = (a2061425267 + -6);
    	a1210910088 = (a1478681170 - 4);
    	a1180594800 = 32 ;
    	a302110279 = 33 ;
    	a620105235 = ((((a620105235 * a217799639) - 4406) + -22732) * 1);
    	a1213722969 = (a778006913 + 8);
    	a1478681170 = (a1241576728 - 3);
    	a341216798 = ((((((a1774184757 * a2130183577) % 14999) + -20444) * 1) - -9002) - 7962);
    	a1254983042 = ((((((a813082108 * a30494462) % 14999) - -12392) - 27392) - -16800) - 16800);
    	a778006913 = (a786258498 - 7);
    	a2073482783 = 32 ;
    	a708839806 = 32 ;
    	a30494462 = (((((((a30494462 * a1675035970) % 14999) - -7641) % 14969) + -15030) / 5) - 18436);
    	a1151361287 = ((((((a1151361287 * a1254983042) % 14999) / 5) + -20121) % 86) - -192);
    	a63333937 = (((((a63333937 * a1254983042) % 14999) + -1110) * 1) * 1);
    	a1895304149 = 32 ;
    	a2130183577 = ((((a2130183577 * a1625516355) + -6685) * 1) / 5);
    	a709568404 = 32 ;
    	a1625516355 = ((((((a999024345 * a30494462) % 14999) * 2) / 5) % 13) - 93);
    	a260539918 = (((((a260539918 * a1018383389) + 277) % 14978) + -15021) + -1);
    	a1018383389 = ((((((a1018383389 * a999024345) % 14999) % 74) - -92) + -1) * 1); 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((a1830659124 == 11 && ( cf==1  && (input == 6))) && (a2061425267 == 12 && (((124 < a30494462) && (296 >= a30494462)) && (a1211013485 == 34 && (((167 < a1018383389) && (211 >= a1018383389)) && a1241576728 == 8)))))) {
    	cf = 0;
    	a26346326 = 33 ;
    	a601495656 = 33 ;
    	a260539918 = ((((((a1985899004 * a1018383389) % 14999) / 5) - 19025) % 17) + -8);
    	a1180594800 = 33 ;
    	a263151501 = 33 ;
    	a1700231631 = (a2026977784 + -2);
    	a1625516355 = ((((((a260539918 * a1985899004) % 13) - 93) * 9) / 10) - 1);
    	a1675035970 = (((((((a1774184757 * a30494462) % 14999) / 5) - -9381) * 2) % 17) - -188);
    	a834646264 = ((a4442917 * a4442917) + -41);
    	a1125477212 = 33 ;
    	a620105235 = ((((((a620105235 * a1625516355) % 10) - 171) + 25308) + 2855) + -28162);
    	a1210910088 = (a778006913 - 1);
    	a721272783 = ((a1895857334 / a1478681170) + 16);
    	a778006913 = (a2026977784 + -7);
    	a2087535773 = (a786258498 - 6);
    	a1644957382 = 33 ;
    	a1830659124 = (a1916853335 + 3);
    	a709568404 = 33 ;
    	a76745981 = 33 ;
    	a2073482783 = 33 ;
    	a2130183577 = (((((((a2130183577 * a1675035970) % 14999) % 63) + 105) + -1) + -28894) - -28939);
    	a983758263 = (((((((a983758263 * a1260876233) % 14999) % 104) + 98) + 20579) - 44764) - -24186);
    	a1983740902 = 33 ;
    	a4442917 = ((a190525986 + a834646264) + -12);
    	a217799639 = (((((a217799639 * a999024345) % 69) + -64) + 17718) + -17749);
    	a813082108 = ((((((a30494462 * a1774184757) % 14999) / 5) + -11318) % 69) - -214);
    	a1895304149 = 33 ;
    	a1151361287 = ((((((a1151361287 * a1254983042) % 14999) % 86) - -98) / 5) * 5);
    	a30494462 = (((((((a30494462 * a620105235) % 14999) % 92) + 32) - -4041) - 28338) - -24296); 
    	 printf("%d\n", 16); fflush(stdout); 
    } if(((((input == 11) &&  cf==1 ) && ((-160 < a620105235) && (30 >= a620105235))) && (((((131 < a999024345) && (260 >= a999024345)) && (a1125477212 == 34 && a2061425267 == 12)) && ((124 < a30494462) && (296 >= a30494462))) && a1210910088 == 3))) {
    	cf = 0;
    	a302110279 = 33 ;
    	a786258498 = ((a1210910088 - a1210910088) + 8);
    	a1254983042 = (((((a1675035970 * a2130183577) % 14999) + -15000) - 1) + -1);
    	a1478681170 = ((a1895857334 - a1916853335) + 2);
    	a1211013485 = 32 ;
    	a778006913 = (a1210910088 - 2);
    	a1213722969 = ((a1241576728 * a1210910088) - 13);
    	a620105235 = ((((((a620105235 * a1985899004) % 14999) % 14909) - 15090) + -1) + 0);
    	a263151501 = 32 ;
    	a2087535773 = ((a2026977784 / a2026977784) + 2);
    	a63333937 = ((((((a63333937 * a1254983042) % 14999) + -6941) - 4974) * 10) / 9);
    	a1018383389 = (((((((a1018383389 * a30494462) % 14999) / 5) % 74) + 48) + 13505) + -13502);
    	a1959068056 = a786258498;
    	a834646264 = ((a1830659124 - a4442917) + 2);
    	a260539918 = (((((a1254983042 * a217799639) % 14999) - 6071) - 10715) * 1);
    	a2073482783 = 32 ;
    	a30494462 = (((((((a30494462 * a1254983042) % 14999) - -26672) - -1660) * 1) * -1) / 10);
    	a1830659124 = (a786258498 - -1);
    	a1241576728 = (a778006913 - -5);
    	a4442917 = (a1210910088 - -2);
    	a983758263 = ((((((a983758263 * a999024345) % 14999) + -21227) * 10) / 9) + -4376);
    	a1180594800 = 32 ;
    	a341216798 = ((((a1625516355 * a1774184757) / 5) * 5) / 5);
    	a999024345 = ((((((a1260876233 * a260539918) % 14999) + -15043) * 10) / 9) - 575);
    	a709568404 = 32 ;
    	a1895304149 = 32 ;
    	a1151361287 = ((((((a1151361287 * a1625516355) % 86) - -161) - 0) * 10) / 9);
    	a2130183577 = (((((a2130183577 * a1254983042) % 14999) / 5) - -5711) * -5);
    	a1625516355 = (((((((a1625516355 * a620105235) % 14999) + -19538) + -5373) + 27912) % 13) + -101);
    	a1644957382 = 32 ;
    	a708839806 = 32 ;
    	a1210910088 = (a1895857334 + -7); 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((((a786258498 == 10 && ( cf==1  && (input == 12))) && ((-59 < a217799639) && (-1 >= a217799639))) && a1241576728 == 8) && ((((-8 < a260539918) && (140 >= a260539918)) && a2026977784 == 9) && a709568404 == 34))) {
    	a419312954 -= (a419312954 - 20) < a419312954 ? 3 : 0;
    	cf = 0;
    	a1895304149 = 33 ;
    	a217799639 = ((((((a63333937 * a1018383389) % 14999) % 69) - 185) - -18529) + -18489);
    	a76745981 = 34 ;
    	a2087535773 = (a1210910088 + 1);
    	a1983740902 = 33 ;
    	a263151501 = 33 ;
    	a2073482783 = 33 ;
    	a1675035970 = (((((((a2130183577 * a260539918) % 14999) / 5) + 4455) * 4) % 17) - -178);
    	a983758263 = ((((((a983758263 * a1260876233) % 14999) % 104) - -98) * 5) / 5);
    	a1774184757 = ((((((((a1774184757 * a1675035970) % 14999) % 92) - 98) * 10) / 9) - -18754) - 18767);
    	a1700231631 = ((a1478681170 * a1830659124) - 47);
    	a1644957382 = 33 ;
    	a1985899004 = (((((a1985899004 * a217799639) % 14999) + -2020) * 1) * 1);
    	a620105235 = ((((((a620105235 * a999024345) % 14999) % 10) + -171) / 5) * 5);
    	a601495656 = 33 ;
    	a26346326 = 33 ;
    	a721272783 = (a1210910088 - -14);
    	a786258498 = ((a4442917 / a2061425267) - -9);
    	a1830659124 = (a786258498 - -1);
    	a1151361287 = ((((((a1151361287 * a30494462) % 14999) / 5) / 5) % 86) - -129);
    	a190525986 = (a2026977784 - -2);
    	a1895857334 = (a1959068056 - 4);
    	a1318526106 = 33 ;
    	a1249952537 = (a2130193413 - 5);
    	a1254983042 = (((((((a1254983042 * a1018383389) % 14999) % 101) + -1) + 43) * 9) / 10);
    	a999024345 = (((((((a1675035970 * a1675035970) % 14999) - -3441) - 28064) / 5) % 41) + 118);
    	a1241576728 = a1916853335;
    	a813082108 = (((((a1675035970 * a260539918) % 69) - -173) / 5) * 5);
    	a1959068056 = a786258498;
    	a30494462 = ((((((a1625516355 * a217799639) + 9638) - 6791) - 31233) % 92) + 103);
    	a1210910088 = ((a2061425267 + a778006913) - 13);
    	a1625516355 = (((((((((a1675035970 * a1675035970) % 14999) % 13) + -98) * 10) / 9) * 5) % 13) - 95);
    	a2026977784 = ((a4442917 - a2061425267) + 13); 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((a302110279 == 34 && a1125477212 == 34) && (((249 < a1151361287) && (291 >= a1151361287)) && (a263151501 == 34 && ((( cf==1  && (input == 1)) && a1478681170 == 5) && a2073482783 == 34))))) {
    	cf = 0;
    	a778006913 = ((a4442917 - a2061425267) - -6);
    	a983758263 = ((((((a983758263 * a999024345) % 14999) - 15972) * 10) / 9) - 10929);
    	a1985899004 = (((((a1985899004 * a1151361287) % 14999) - 11824) + -5863) - 8143);
    	a119997292 = (a2061425267 + -6);
    	a30494462 = ((((((a30494462 * a1260876233) % 14999) + -8187) * 10) / 9) * 1);
    	a1916853335 = a2087535773;
    	a217799639 = ((((a217799639 * a260539918) - 2623) - -16926) - 31465);
    	a1644957382 = 32 ;
    	a302110279 = 32 ;
    	a1210910088 = (a786258498 - 9);
    	a1125477212 = 32 ;
    	a2026977784 = (a1478681170 + 2);
    	a1895304149 = 32 ;
    	a1254983042 = ((((((a1254983042 * a620105235) % 14999) * 2) % 14999) + -15000) + -1);
    	a1830659124 = (a1895857334 - -1);
    	a1305578599 = 36 ;
    	a1625516355 = ((((a1625516355 * a999024345) + -4076) * 1) + -455);
    	a1983740902 = 32 ;
    	a709568404 = 32 ;
    	a341216798 = (((((((a983758263 * a983758263) % 14999) - 20631) % 18) + 228) - -9961) - 9964);
    	a4442917 = (a1959068056 - 5);
    	a1241576728 = (a1478681170 - -1); 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm179(int input) {
    if((((a1830659124 == 11 && (((input == 4) &&  cf==1 ) && a786258498 == 10)) && ((104 < a813082108) && (243 >= a813082108))) && (a1211013485 == 34 && (((-81 < a1625516355) && (-5 >= a1625516355)) && a4442917 == 7)))) {
    	cf = 0;
    	a1211013485 = 33 ;
    	a620105235 = (((((((a620105235 * a1675035970) % 14999) * 2) % 10) + -171) / 5) + -138);
    	a1125477212 = 33 ;
    	a1151361287 = ((((((a1151361287 * a1260876233) % 14999) % 86) + 107) - -12102) - 12051);
    	a786258498 = ((a2061425267 - a1241576728) - -5);
    	a708839806 = 32 ;
    	a1075307847 = 35 ;
    	a30494462 = ((((((a217799639 * a1774184757) % 92) + 86) + 5) - -1706) - 1715);
    	a778006913 = (a1959068056 - 8);
    	a1180594800 = 33 ;
    	a721272783 = (a2061425267 - -1);
    	a1254983042 = (((((((a1254983042 * a30494462) % 14999) % 101) - -99) + 14058) + 13361) - 27416);
    	a4442917 = (a786258498 + -3);
    	a302110279 = 33 ;
    	a1625516355 = (((((a1625516355 * a1774184757) - -18417) + -34463) % 13) + -92);
    	a1916853335 = ((a778006913 / a2087535773) - -6);
    	a813082108 = (((((((a813082108 * a1985899004) % 14999) / 5) % 50) - -49) * 9) / 10);
    	a709568404 = 32 ;
    	a1644957382 = 32 ;
    	a263151501 = 32 ;
    	a76745981 = 32 ;
    	a1895304149 = 33 ;
    	a1478681170 = (a1241576728 - 4);
    	a260539918 = (((((a30494462 * a1018383389) % 14978) - 15021) / 5) + -18843);
    	a26346326 = 33 ;
    	a983758263 = ((((((a983758263 * a1774184757) % 14999) - 2608) / 5) % 104) - -99);
    	a1597554373 = 34 ;
    	a1249952537 = (a786258498 + -4);
    	a1830659124 = ((a1478681170 * a1959068056) - 30);
    	a63333937 = ((((((a63333937 * a1774184757) % 14999) % 81) + -65) - -24851) - 24842);
    	a217799639 = ((((((a217799639 * a1675035970) * 2) % 69) - 121) - -18907) - 18895);
    	a1210910088 = ((a190525986 / a4442917) - -1);
    	a2087535773 = (a721272783 + -10);
    	a2061425267 = (a1895857334 - -3);
    	a2073482783 = 32 ;
    	a1959068056 = (a1210910088 + 6);
    	a1018383389 = (((((((a30494462 * a2130183577) % 74) - -93) - -1) * 5) % 74) + 40);
    	a999024345 = (((((a999024345 * a1260876233) % 14999) + -24984) / 5) - 10574);
    	a601495656 = 33 ;
    	a1241576728 = (a1830659124 - 4); 
    	 printf("%d\n", 17); fflush(stdout); 
    } if((((((371 < a1985899004) && (524 >= a1985899004)) && ((((input == 8) &&  cf==1 ) && a778006913 == 3) && a1180594800 == 34)) && a26346326 == 34) && (((-81 < a1625516355) && (-5 >= a1625516355)) && a1478681170 == 5))) {
    	cf = 0;
    	a1478681170 = ((a778006913 - a1895857334) + 9);
    	a4442917 = (a1478681170 + 2);
    	a217799639 = ((((((a217799639 * a2130183577) % 69) + -63) - -4) * 10) / 9);
    	a1700231631 = (a1249952537 + -3);
    	a2073482783 = 33 ;
    	a983758263 = (((((((a983758263 * a1260876233) % 14999) % 104) - -82) + -28043) - 1452) + 29458);
    	a709568404 = 32 ;
    	a1895304149 = 33 ;
    	a2061425267 = (a2026977784 - -3);
    	a1774184757 = ((((((a1774184757 * a1985899004) % 14999) + -4511) % 92) - 56) + -3);
    	a1210910088 = ((a1895857334 / a1916853335) - -1);
    	a30494462 = (((((((a813082108 * a813082108) % 14999) % 92) + -23) - -11062) / 5) + -2171);
    	a63333937 = ((((((((a63333937 * a620105235) % 14999) % 81) - 53) - 1) * 5) % 81) - 52);
    	a1180594800 = 33 ;
    	a708839806 = 33 ;
    	a1983740902 = 33 ;
    	a26346326 = 33 ;
    	a999024345 = (((((((a999024345 * a2130183577) % 14999) % 41) - -58) + -8) - -5225) - 5192);
    	a1959068056 = (a2061425267 + -2);
    	a721272783 = (a1241576728 - -9);
    	a1625516355 = (((((a1625516355 * a620105235) % 13) - 93) + 7019) + -7019);
    	a778006913 = (a1916853335 - a2087535773);
    	a1241576728 = (a1478681170 + 4);
    	a1125477212 = 33 ;
    	a1830659124 = a190525986;
    	a260539918 = (((((a1774184757 * a1625516355) - 6200) * 3) % 14978) - 15021);
    	a1254983042 = ((((((a1254983042 * a30494462) % 14999) / 5) * 5) % 101) - -100);
    	a601495656 = 33 ;
    	a1151361287 = ((((((a1151361287 * a620105235) % 14999) * 2) % 86) + 162) - 1);
    	a1018383389 = ((((((a1018383389 * a983758263) % 14999) / 5) % 21) + 188) - 0);
    	a1012466188 = 35 ;
    	a1249952537 = (a786258498 + -5);
    	a263151501 = 34 ;
    	a302110279 = 32 ;
    	a1985899004 = (((((((a1985899004 * a620105235) % 14999) * 2) % 98) + 272) / 5) - -226);
    	a813082108 = (((((a1774184757 * a983758263) % 14999) + -15001) * 1) + -1);
    	a2087535773 = ((a2026977784 * a190525986) - 75);
    	a1916853335 = (a4442917 - -1);
    	a786258498 = (a1700231631 - -7);
    	a1211013485 = 34 ;
    	a620105235 = ((((((((a620105235 * a1675035970) % 14999) * 2) % 10) + -170) / 5) * 51) / 10); 
    	 printf("%d\n", 18); fflush(stdout); 
    } if(((a1125477212 == 34 && (( cf==1  && (input == 11)) && a601495656 == 34)) && (((a1180594800 == 34 && ((131 < a999024345) && (260 >= a999024345))) && ((167 < a1018383389) && (211 >= a1018383389))) && a1210910088 == 3))) {
    	cf = 0;
    	a1318526106 = 34 ;
    	a1826277115 = (((((((a1260876233 * a1985899004) % 14999) - -14527) % 105) - 86) - -15581) - 15615);
    	a620105235 = ((((((a620105235 * a1260876233) % 14999) / 5) / 5) % 94) + -65);
    	a160322672 = (((((((a999024345 * a1260876233) % 14999) % 50) + 164) * 9) / 10) + -22);
    	a1959068056 = (a778006913 - -5);
    	a263219509 = (a1916853335 + 3);
    	a190525986 = ((a1895857334 * a1895857334) + -55);
    	a1644957382 = 34 ;
    	a2026977784 = ((a1210910088 - a1478681170) - -9);
    	a1210910088 = (a1916853335 - 4);
    	a2130193413 = (a2087535773 - -6);
    	a708839806 = 34 ;
    	a983758263 = ((((((a983758263 * a63333937) % 14999) - -2784) * 1) * 10) / 9);
    	a601495656 = 34 ;
    	a76745981 = 32 ;
    	a2061425267 = (a1241576728 + 4);
    	a1675035970 = (((((((a1254983042 * a1260876233) % 14999) / 5) % 51) + 230) / 5) - -179);
    	a1983740902 = 32 ;
    	a1180594800 = 32 ;
    	a2130183577 = (((((((a1675035970 * a1625516355) % 12) + 250) * 5) - -11863) % 12) - -243); 
    	 printf("%d\n", 26); fflush(stdout); 
    } 
}
 void calculate_outputm15(int input) {
    if((((a786258498 == 10 && ((29 < a63333937) && (243 >= a63333937))) && a1241576728 == 8) && ((a778006913 == 3 && (a1211013485 == 34 && ( cf==1  && a369798198 == 32))) && ((-8 < a260539918) && (140 >= a260539918))))) {
    	if(((((a1210910088 == 3 && (a703247202 == 36 &&  cf==1 )) && a1241576728 == 8) && a1895304149 == 34) && ((a709568404 == 34 && ((202 < a1254983042) && (414 >= a1254983042))) && ((124 < a30494462) && (296 >= a30494462))))) {
    		calculate_outputm173(input);
    	} 
    } 
    if((((((a369798198 == 33 &&  cf==1 ) && a1180594800 == 34) && a76745981 == 34) && a778006913 == 3) && ((a786258498 == 10 && a1249952537 == 6) && ((124 < a30494462) && (296 >= a30494462))))) {
    	if((((a26346326 == 34 && (a1983740902 == 34 && a1249952537 == 6)) && a1478681170 == 5) && (a2026977784 == 9 && (a1211013485 == 34 && ( cf==1  && ((201 < a362219248) && (270 >= a362219248))))))) {
    		calculate_outputm174(input);
    	} 
    } 
    if((((a709568404 == 34 && (a601495656 == 34 && a2130193413 == 11)) && a1916853335 == 7) && ((a4442917 == 7 && ( cf==1  && a369798198 == 34)) && a190525986 == 11))) {
    	if(((((-59 < a217799639) && (-1 >= a217799639)) && (a2073482783 == 34 && (((180 < a578474405 &&  cf==1 ) && a1210910088 == 3) && a1959068056 == 10))) && (a1211013485 == 34 && ((230 < a2130183577) && (255 >= a2130183577))))) {
    		calculate_outputm176(input);
    	} 
    } 
    if(((a369798198 == 35 &&  cf==1 ) && ((((-59 < a217799639) && (-1 >= a217799639)) && ((a1916853335 == 7 && (a76745981 == 34 && a26346326 == 34)) && a1478681170 == 5)) && a302110279 == 34))) {
    	if((((a1895304149 == 34 && (((29 < a63333937) && (243 >= a63333937)) && (a190525986 == 11 && ((-81 < a1625516355) && (-5 >= a1625516355))))) && a1249952537 == 6) && ((a1891437507 == 32 &&  cf==1 ) && a1210910088 == 3))) {
    		calculate_outputm177(input);
    	} 
    } 
    if(((a708839806 == 34 && ((a2073482783 == 34 && ((-160 < a620105235) && (30 >= a620105235))) && ((249 < a1151361287) && (291 >= a1151361287)))) && (a1983740902 == 34 && (a2087535773 == 5 && (a369798198 == 36 &&  cf==1 ))))) {
    	if(((((371 < a1985899004) && (524 >= a1985899004)) && ( cf==1  && a1260876233 <=  -95)) && ((((a2073482783 == 34 && a1180594800 == 34) && a302110279 == 34) && a2061425267 == 12) && ((29 < a63333937) && (243 >= a63333937))))) {
    		calculate_outputm178(input);
    	} 
    	if((((a709568404 == 34 && (a2073482783 == 34 && ((202 < a1254983042) && (414 >= a1254983042)))) && a1830659124 == 11) && (a1241576728 == 8 && ((198 < a1260876233 &&  cf==1 ) && a1983740902 == 34)))) {
    		calculate_outputm179(input);
    	} 
    } 
}
 void calculate_outputm180(int input) {
    if(((a778006913 == 3 && ((230 < a2130183577) && (255 >= a2130183577))) && (((a786258498 == 10 && (((input == 4) &&  cf==1 ) && a263151501 == 34)) && a709568404 == 34) && a4442917 == 7))) {
    	a1054543477 += (a1054543477 + 20) > a1054543477 ? 2 : 0;
    	cf = 0;
    	a803418896 = ((((((a999024345 * a160322672) % 14999) % 14961) + 15037) / 5) + 11741);
    	a1644957382 = 32 ;
    	a263151501 = 32 ;
    	a834646264 = (a2061425267 - 2);
    	a190525986 = a1895857334;
    	a778006913 = (a1916853335 - 4);
    	a1018383389 = (((((a1018383389 * a30494462) % 14999) - -3135) / -5) - 6967);
    	a983758263 = (((((a983758263 * a803418896) % 14999) - 17320) / 5) - 20552);
    	a2073482783 = 32 ;
    	a709568404 = 32 ;
    	a1985899004 = (((((a1018383389 * a217799639) % 14999) - 14975) + -14) - 4);
    	a260539918 = (((((a2130183577 * a2130183577) % 14999) + -16659) * 1) * 1);
    	a1151361287 = (((((a1151361287 * a803418896) % 14999) + 1465) * -1) * 1);
    	a341216798 = ((((((a803418896 * a153258473) % 14999) + -14807) + 27562) + 2189) + -29816);
    	a2061425267 = a786258498;
    	a620105235 = (((((a30494462 * a30494462) % 14999) - 15376) + -6776) - 5225);
    	a30494462 = (((((a1254983042 * a1254983042) % 14999) + -22927) + -5415) + -1536);
    	a1983740902 = 33 ;
    	a1211013485 = 32 ;
    	a1210910088 = ((a1241576728 * a1959068056) - 59);
    	a1478681170 = (a1916853335 - 2);
    	a26346326 = 32 ;
    	a1774184757 = (((((a1774184757 * a260539918) % 14999) - 11192) + -1107) * 1);
    	a1959068056 = ((a778006913 / a190525986) - -8);
    	a1625516355 = ((((((((a217799639 * a983758263) % 14999) % 37) + -46) * 10) / 9) + 1304) - 1303);
    	a1895304149 = 32 ;
    	a2026977784 = (a1830659124 - 4);
    	a999024345 = ((((((a803418896 * a803418896) % 14999) - -1074) * 1) / 5) * -5);
    	a786258498 = (a1241576728 + 2);
    	a1675035970 = (((((a1675035970 * a2130183577) % 14999) / 5) - 18063) / 5);
    	a708839806 = 32 ;
    	a302110279 = 32 ;
    	a1830659124 = (a778006913 - -8);
    	a601495656 = 32 ;
    	a1254983042 = ((((a1254983042 * a217799639) - 4315) - 871) * 1);
    	a4442917 = ((a1249952537 / a778006913) - -1);
    	a2130193413 = ((a190525986 * a834646264) + -81);
    	a217799639 = ((((((a217799639 * a63333937) % 14999) / 5) + -15852) * 10) / 9);
    	a2130183577 = (((((a2130183577 * a803418896) % 14999) / 5) - 11723) - 2634); 
    	 printf("%d\n", 19); fflush(stdout); 
    } 
}
 void calculate_outputm181(int input) {
    if(((a1211013485 == 34 && (a1644957382 == 34 && (a708839806 == 34 && a1249952537 == 6))) && (a778006913 == 3 && (a1895304149 == 34 && ( cf==1  && (input == 6)))))) {
    	cf = 0;
    	a1625516355 = (((((((a260539918 * a999024345) % 14999) % 37) + -42) - 1) + -2348) - -2347);
    	a601495656 = 34 ;
    	a1478681170 = (a778006913 - -2);
    	a708839806 = 34 ;
    	a26346326 = 34 ;
    	a1574467713 = ((a2087535773 / a1249952537) + 1);
    	a1895857334 = ((a1574467713 - a1830659124) + 21);
    	a1318526106 = 34 ;
    	a2130183577 = (((((a260539918 * a217799639) / 5) % 12) + 243) - 1);
    	a813082108 = (((((a153258473 * a260539918) % 69) + 173) + -10685) + 10685);
    	a620105235 = (((((((a30494462 * a30494462) % 14999) - -2538) + 5938) * 1) % 94) - 77);
    	a190525986 = (a1241576728 + 3);
    	a2026977784 = ((a1210910088 / a2061425267) + 9);
    	a1249952537 = (a786258498 - 4);
    	a302110279 = 34 ;
    	a1983740902 = 34 ;
    	a63333937 = (((((((a1151361287 * a1254983042) % 14999) % 106) - -33) - -66) * 9) / 10);
    	a1675035970 = (((((((a30494462 * a2130183577) % 14999) - 21037) % 51) - -277) + 18437) - 18435);
    	a709568404 = 34 ;
    	a263638061 = (a778006913 - -8);
    	a778006913 = (a2061425267 - 9);
    	a1210910088 = (a1959068056 - 7);
    	a260539918 = ((((((a260539918 * a1985899004) % 14999) % 73) + 67) / 5) + -1); 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a778006913 == 3 && (((input == 13) &&  cf==1 ) && a2087535773 == 5)) && (a1180594800 == 34 && ((a263151501 == 34 && a2026977784 == 9) && a1241576728 == 8)))) {
    	cf = 0;
    	a1211013485 = 32 ;
    	a1675035970 = ((((a217799639 * a217799639) - 11858) + -9334) / 5);
    	a1318526106 = 32 ;
    	a2130183577 = ((((((a1675035970 * a217799639) % 14999) - -7477) * 1) * 1) + -22432);
    	a2073482783 = 32 ;
    	a63333937 = ((((((a1675035970 * a217799639) % 14999) + 6863) % 14932) + -15066) * 1);
    	a1180594800 = 32 ;
    	a1151361287 = ((((((a153258473 * a153258473) % 86) + 136) - 11962) * 2) + 23730);
    	a813082108 = (((((a2130183577 * a63333937) % 14999) - 14995) + -4) + -3);
    	a1644957382 = 32 ;
    	a30494462 = ((((((a30494462 * a620105235) % 14999) + -3885) * 10) / 9) + -5424);
    	a1213722969 = (a786258498 - -1);
    	a709568404 = 32 ;
    	a302110279 = 33 ;
    	a1254983042 = ((((((a63333937 * a813082108) % 14999) * 2) - 0) % 14999) - 15000);
    	a263151501 = 32 ;
    	a778006913 = ((a1210910088 - a2087535773) - -3);
    	a708839806 = 32 ;
    	a1241576728 = (a1210910088 + 3);
    	a1895304149 = 32 ;
    	a834646264 = ((a4442917 * a1916853335) - 43);
    	a1478681170 = ((a778006913 - a2026977784) + 11);
    	a1018383389 = ((((((a2130183577 * a1985899004) % 14999) * 2) % 74) + 91) * 1);
    	a999024345 = ((((((a999024345 * a1254983042) % 14999) + -5927) * 1) - -14057) - 22578);
    	a4442917 = (a2061425267 - 7);
    	a341216798 = (((((a153258473 * a983758263) % 14999) - 18394) - 6108) - -6062);
    	a26346326 = 32 ;
    	a1959068056 = (a190525986 + -3);
    	a601495656 = 32 ;
    	a260539918 = ((((a260539918 * a1774184757) + -25712) / 5) * 5);
    	a786258498 = a1959068056;
    	a983758263 = (((((((a983758263 * a1985899004) % 14999) + 7412) - 15468) + 21686) * -1) / 10);
    	a1625516355 = (((((((a63333937 * a1675035970) % 14999) % 13) - 95) / 5) * 51) / 10);
    	a1830659124 = (a2087535773 + 4);
    	a1210910088 = (a1249952537 + -5);
    	a2087535773 = (a1895857334 - 6); 
    	 printf("%d\n", 26); fflush(stdout); 
    } if(((a2026977784 == 9 && (((-8 < a260539918) && (140 >= a260539918)) && (a1830659124 == 11 && (a708839806 == 34 && ((input == 14) &&  cf==1 ))))) && (a4442917 == 7 && a1125477212 == 34))) {
    	cf = 0;
    	a1318526106 = 34 ;
    	a1249952537 = (a2026977784 + -3);
    	a708839806 = 34 ;
    	a778006913 = ((a2130193413 + a190525986) + -19);
    	a813082108 = ((((((a153258473 * a217799639) % 69) + 216) - 24604) / 5) + 5076);
    	a601495656 = 34 ;
    	a1675035970 = (((((((a1151361287 * a1254983042) % 14999) % 51) - -248) + 273) - -13182) + -13474);
    	a620105235 = ((((((a30494462 * a260539918) % 14999) % 94) - 64) - 11016) + 11014);
    	a1574467713 = ((a2087535773 * a1895857334) - 44);
    	a2026977784 = (a2061425267 - 3);
    	a63333937 = ((((((a30494462 * a217799639) % 106) - -192) - -31) - 12336) + 12282);
    	a1625516355 = ((((((a217799639 * a983758263) + -1316) * 1) / 5) % 37) + -23);
    	a1210910088 = (a1895857334 + -6);
    	a26346326 = 34 ;
    	a1983740902 = 34 ;
    	a190525986 = (a4442917 + 4);
    	a263638061 = (a2087535773 - -6);
    	a260539918 = (((((a1774184757 * a217799639) - -11699) % 73) - 4) - 3);
    	a709568404 = 34 ;
    	a2130183577 = ((((((a217799639 * a999024345) - -15054) % 12) - -243) - 22208) + 22208);
    	a302110279 = 34 ;
    	a1478681170 = (a1241576728 + -3);
    	a1895857334 = (a2087535773 - -6); 
    	 printf("%d\n", 18); fflush(stdout); 
    } if(((a263151501 == 34 && a190525986 == 11) && ((a786258498 == 10 && (((35 < a1774184757) && (169 >= a1774184757)) && (a1644957382 == 34 && ((input == 2) &&  cf==1 )))) && ((-8 < a260539918) && (140 >= a260539918))))) {
    	cf = 0;
    	a1210910088 = (a1241576728 - 6);
    	a721272783 = (a1895857334 + 1);
    	a803418896 = (((((a983758263 * a153258473) % 14999) / 5) - -12147) / 5);
    	a217799639 = ((((((a217799639 * a153258473) % 69) - 59) * 1) * 10) / 9);
    	a1249952537 = (a1830659124 - 6);
    	a983758263 = ((((((a983758263 * a999024345) % 14999) - -11897) - 2477) % 104) - -77);
    	a1211013485 = 33 ;
    	a999024345 = ((((((((a999024345 * a1254983042) % 14999) % 41) - -81) * 9) / 10) * 10) / 9);
    	a1774184757 = ((((((a1774184757 * a1625516355) % 92) + 16) * 5) % 92) + -57);
    	a709568404 = 33 ;
    	a703247202 = 32 ;
    	a1895304149 = 33 ;
    	a2087535773 = ((a2061425267 - a1249952537) + -3);
    	a190525986 = (a778006913 - -7);
    	a2073482783 = 33 ;
    	a30494462 = ((((((a30494462 * a260539918) % 14999) / 5) % 92) - -31) - -1);
    	a1318526106 = 33 ;
    	a1254983042 = ((((((a1254983042 * a63333937) % 14999) + 2063) + -7564) % 101) + 101);
    	a1985899004 = (((((((a1985899004 * a1675035970) % 14999) - 27347) - -36597) + 2487) % 98) + 176); 
    	 printf("%d\n", 19); fflush(stdout); 
    } 
}
 void calculate_outputm182(int input) {
    if(((a1180594800 == 34 && (((249 < a1151361287) && (291 >= a1151361287)) && ((124 < a30494462) && (296 >= a30494462)))) && ((a1916853335 == 7 && (((input == 5) &&  cf==1 ) && a2087535773 == 5)) && ((371 < a1985899004) && (524 >= a1985899004))))) {
    	cf = 0;
    	a1521644128 = ((a2130193413 + a1895857334) - 12);
    	a1985899004 = (((((a1985899004 * a260539918) % 14999) + 13734) / 5) + -9900);
    	a983758263 = (((((a983758263 * a1774184757) % 14999) - -10766) + 1562) - 10931);
    	a965340096 = 32 ;
    	a26346326 = 34 ;
    	a1625516355 = (((((((a1151361287 * a260539918) % 14999) / 5) / 5) / 5) % 37) + -42);
    	a1318526106 = 34 ;
    	a2130183577 = ((((((a260539918 * a1625516355) - 4552) % 12) + 249) / 5) - -185);
    	a1826277115 = ((((((((a63333937 * a153258473) % 14999) / 5) % 62) + 77) - -1616) * 1) / 10); 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((((a1125477212 == 34 && (((input == 6) &&  cf==1 ) && ((167 < a1018383389) && (211 >= a1018383389)))) && a2073482783 == 34) && (((249 < a1151361287) && (291 >= a1151361287)) && (a1478681170 == 5 && ((207 < a1675035970) && (311 >= a1675035970)))))) {
    	a170107731 -= (a170107731 - 20) < a170107731 ? 3 : 0;
    	cf = 0;
    	a709568404 = 34 ;
    	a1826277115 = ((((((a983758263 * a153258473) % 14999) - -7624) * 10) / 9) / 5);
    	a1895304149 = 34 ;
    	a217799639 = (((((((a217799639 * a813082108) % 28) - 25) * 5) * 5) % 28) + -19);
    	a2130183577 = ((((((((a813082108 * a1985899004) % 14999) % 12) + 235) * 1) * 5) % 12) - -233);
    	a1125477212 = 34 ;
    	a404763935 = (a4442917 + 7);
    	a983758263 = (((((a983758263 * a1826277115) % 14999) + 11225) * 1) + 3641);
    	a1318526106 = 34 ;
    	a601495656 = 34 ;
    	a620105235 = ((((((a620105235 * a1151361287) % 14999) + 13354) % 94) - 64) / 5);
    	a1249952537 = ((a2087535773 - a1478681170) + 6);
    	a2073482783 = 34 ;
    	a548050643 = 35 ;
    	a30494462 = (((((((a30494462 * a63333937) % 14999) / 5) + -27995) + 22988) % 85) - -211);
    	a1625516355 = ((((((a1018383389 * a1985899004) % 14999) - 29496) - -6341) % 37) - 40);
    	a1241576728 = (a2061425267 - 4);
    	a2061425267 = ((a404763935 - a2130193413) + 9);
    	a2130193413 = ((a1959068056 / a2026977784) + 10);
    	a1211013485 = 34 ;
    	a26346326 = 34 ;
    	a1830659124 = (a786258498 + 1);
    	a1959068056 = ((a1916853335 * a1895857334) - 53); 
    	 printf("%d\n", 16); fflush(stdout); 
    } if(((a1211013485 == 34 && ( cf==1  && (input == 12))) && ((a1249952537 == 6 && (((207 < a1675035970) && (311 >= a1675035970)) && (a1180594800 == 34 && a1210910088 == 3))) && a708839806 == 34))) {
    	cf = 0;
    	a263151501 = 34 ;
    	a1644957382 = 34 ;
    	a601495656 = 32 ;
    	a1241576728 = ((a2087535773 / a1916853335) + 8);
    	a2026977784 = ((a190525986 + a1249952537) - 8);
    	a1983740902 = 34 ;
    	a302110279 = 34 ;
    	a778006913 = (a2130193413 + -8); 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((a2087535773 == 5 && (a786258498 == 10 && ((124 < a30494462) && (296 >= a30494462)))) && (a1916853335 == 7 && (((35 < a1774184757) && (169 >= a1774184757)) && (( cf==1  && (input == 13)) && ((29 < a63333937) && (243 >= a63333937))))))) {
    	cf = 0;
    	a803418896 = (((((a1774184757 * a813082108) % 14999) + 6398) / 5) + 8458);
    	a1675035970 = (((((a1018383389 * a1625516355) * 1) % 17) + 203) + 1);
    	a703247202 = 33 ;
    	a999024345 = (((((((a999024345 * a620105235) % 14999) % 41) - -90) / 5) + -1788) - -1857);
    	a1211013485 = 33 ;
    	a721272783 = ((a1210910088 / a190525986) - -10);
    	a2061425267 = a2130193413;
    	a1985899004 = ((((((((a1675035970 * a153258473) % 14999) % 98) - -221) * 10) / 9) / 5) - -175);
    	a1180594800 = 33 ;
    	a983758263 = (((((((a983758263 * a803418896) % 14999) % 104) + 80) + -11) * 10) / 9);
    	a30494462 = (((((((a30494462 * a1985899004) % 14999) % 92) + 7) + -28777) + -696) + 29470);
    	a709568404 = 33 ;
    	a190525986 = (a1895857334 - -1);
    	a76745981 = 33 ;
    	a1210910088 = (a190525986 - 8);
    	a1895304149 = 33 ;
    	a1774184757 = ((((((a2130183577 * a1151361287) % 14999) + -25872) - 3800) % 92) - 55);
    	a63333937 = ((((((a803418896 * a1018383389) % 14999) + -11754) * 2) % 81) + -53);
    	a1254983042 = ((((((a1254983042 * a63333937) % 14999) + -11057) % 101) + 101) + -1);
    	a2087535773 = (a2061425267 + -7); 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm16(int input) {
    if(((a1895304149 == 34 && ((a263151501 == 34 && ((207 < a1675035970) && (311 >= a1675035970))) && a190525986 == 11)) && (a2026977784 == 9 && (((249 < a1151361287) && (291 >= a1151361287)) && ( cf==1  && a153258473 <=  35))))) {
    	if((((((202 < a1254983042) && (414 >= a1254983042)) && (a601495656 == 34 && (a160322672 <=  65 &&  cf==1 ))) && a1210910088 == 3) && (((167 < a1018383389) && (211 >= a1018383389)) && (((-59 < a217799639) && (-1 >= a217799639)) && ((35 < a1774184757) && (169 >= a1774184757)))))) {
    		calculate_outputm180(input);
    	} 
    } 
    if(((((131 < a999024345) && (260 >= a999024345)) && ((-59 < a217799639) && (-1 >= a217799639))) && (a1478681170 == 5 && (a1125477212 == 34 && ((( cf==1  && ((114 < a153258473) && (169 >= a153258473))) && a1895304149 == 34) && a1210910088 == 3))))) {
    	if(((((-59 < a217799639) && (-1 >= a217799639)) && (a1318526106 == 34 && a1241576728 == 8)) && (((( cf==1  && a2140773614 == 34) && a2061425267 == 12) && a1211013485 == 34) && a709568404 == 34))) {
    		calculate_outputm181(input);
    	} 
    	if(((a76745981 == 34 && (((-160 < a620105235) && (30 >= a620105235)) && ((a2140773614 == 35 &&  cf==1 ) && a1180594800 == 34))) && ((a708839806 == 34 && a709568404 == 34) && ((249 < a1151361287) && (291 >= a1151361287))))) {
    		calculate_outputm182(input);
    	} 
    } 
}
 void calculate_outputm188(int input) {
    if(((((249 < a1151361287) && (291 >= a1151361287)) && (a26346326 == 34 && a2073482783 == 34)) && ((((207 < a1675035970) && (311 >= a1675035970)) && (((35 < a1774184757) && (169 >= a1774184757)) && ((input == 8) &&  cf==1 ))) && a1241576728 == 8))) {
    	cf = 0;
    	a217799639 = (((88 - 148) - -1) * 1);
    	a63333937 = ((((((a217799639 * a217799639) % 14999) % 81) + -130) - -50) - -23);
    	a708839806 = 33 ;
    	a1151361287 = ((((((a1151361287 * a63333937) % 14999) / 5) % 86) + 161) - 0);
    	a4442917 = ((a1574467713 / a263638061) + 6);
    	a1018383389 = ((((a63333937 * a63333937) - 20450) * 1) + -4731);
    	a1249952537 = (a1210910088 - -2);
    	a620105235 = ((((((a1675035970 * a1625516355) % 10) + -168) + 26397) + 3107) - 29500);
    	a1180594800 = 33 ;
    	a601495656 = 33 ;
    	a1625516355 = (((((((a1625516355 * a813082108) % 13) - 85) * 1) * 5) % 13) + -84);
    	a2087535773 = (a1249952537 - 1);
    	a1895304149 = 33 ;
    	a1947180632 = (((((a983758263 * a983758263) % 14999) / 5) - 7496) - 5472);
    	a786258498 = ((a1210910088 + a778006913) - -3);
    	a1916853335 = (a1210910088 + 3);
    	a2130193413 = (a786258498 + 1);
    	a721272783 = ((a2026977784 / a190525986) + 13);
    	a26346326 = 33 ;
    	a1241576728 = a1916853335;
    	a1478681170 = (a1830659124 - 7);
    	a1075307847 = 32 ;
    	a2026977784 = ((a2087535773 + a2061425267) + -8);
    	a778006913 = a1574467713;
    	a1830659124 = (a721272783 - 3);
    	a813082108 = (((((((a813082108 * a1151361287) % 14999) / 5) % 50) - -47) + -19639) - -19630);
    	a30494462 = ((((((((a30494462 * a1675035970) % 14999) % 92) - 10) - -26) * 5) % 92) + 23);
    	a2130183577 = ((((((a217799639 * a63333937) + 2926) * 1) / 5) % 63) - -167);
    	a1774184757 = (((((a1774184757 * a1254983042) % 14999) + -26116) * 1) * 1);
    	a983758263 = (((((((a983758263 * a1947180632) % 14999) + -5558) * 1) + 6042) % 104) + 98);
    	a1985899004 = ((((((a1985899004 * a260539918) % 14999) % 98) + 272) - -2) - 1);
    	a1125477212 = 33 ;
    	a76745981 = 33 ;
    	a1254983042 = ((((((a1254983042 * a1985899004) % 14999) - 9485) % 105) - -308) * 1);
    	a260539918 = ((((((a260539918 * a620105235) + -2751) % 73) - -126) - -6427) - 6425);
    	a1644957382 = 33 ;
    	a999024345 = ((((((a999024345 * a2130183577) % 14999) % 41) + 50) - -5492) - 5455);
    	a1983740902 = 34 ;
    	a2061425267 = (a190525986 - 1);
    	a302110279 = 33 ;
    	a1211013485 = 33 ;
    	a263151501 = 34 ;
    	a190525986 = ((a1210910088 + a1959068056) + -3);
    	a1675035970 = ((((((a1675035970 * a620105235) % 14999) + 18510) % 17) - -172) - -2);
    	a1210910088 = (a263638061 - 4); 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((((-160 < a620105235) && (30 >= a620105235)) && (((-81 < a1625516355) && (-5 >= a1625516355)) && a1210910088 == 3)) && ((((104 < a813082108) && (243 >= a813082108)) && (a2130193413 == 11 && ((input == 9) &&  cf==1 ))) && a1478681170 == 5))) {
    	cf = 0;
    	a1352986605 = ((((((a983758263 * a983758263) % 14999) + 633) * 10) / 9) * 1);
    	a1348848030 = ((a1241576728 + a263638061) + 1);
    	a1625516355 = (((((a1625516355 * a1675035970) - 4601) * 1) % 37) + -6);
    	a1895857334 = ((a778006913 / a1830659124) - -6);
    	a260539918 = (((((a260539918 * a983758263) % 14999) / 5) - 25775) * 1);
    	a620105235 = ((((a620105235 * a1774184757) / 5) - 17415) / 5);
    	a1318526106 = 32 ;
    	a1774184757 = (((((((a1774184757 * a2130183577) % 14999) % 92) - 66) - -9653) + -34868) - -25195); 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((( cf==1  && (input == 11)) && ((124 < a30494462) && (296 >= a30494462))) && ((((249 < a1151361287) && (291 >= a1151361287)) && ((a1211013485 == 34 && ((-8 < a260539918) && (140 >= a260539918))) && ((104 < a813082108) && (243 >= a813082108)))) && a302110279 == 34))) {
    	cf = 0;
    	a302110279 = 33 ;
    	a1318526106 = 34 ;
    	a1151361287 = ((((((a1151361287 * a999024345) % 14999) % 20) + 261) * 1) + 5);
    	a1574467713 = ((a1959068056 * a2061425267) + -113);
    	a1625516355 = (((((((a1625516355 * a999024345) - 4673) % 13) - 83) * 5) % 13) - 83);
    	a26346326 = 33 ;
    	a620988906 = 35 ;
    	a1125477212 = 34 ;
    	a1210910088 = (a263638061 - 4);
    	a2026977784 = ((a1830659124 - a263638061) - -3);
    	a2073482783 = 34 ;
    	a2130193413 = ((a4442917 / a1916853335) - -10); 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm190(int input) {
    if((((((131 < a999024345) && (260 >= a999024345)) && (a1916853335 == 7 && a1125477212 == 34)) && ((371 < a1985899004) && (524 >= a1985899004))) && ((((207 < a1675035970) && (311 >= a1675035970)) && ((input == 4) &&  cf==1 )) && ((230 < a2130183577) && (255 >= a2130183577))))) {
    	cf = 0;
    	a1210910088 = (a1959068056 - 7);
    	a2026977784 = ((a1241576728 / a2130193413) + 9);
    	a778006913 = (a2087535773 + -2);
    	a1625516355 = ((((((a2130183577 * a1985899004) % 14999) % 37) - 52) - -24748) + -24746);
    	a1249952537 = (a4442917 + -1);
    	a260539918 = ((((((a1675035970 * a217799639) - 5484) % 73) + 134) + 15054) - 15068);
    	a813082108 = ((((((a217799639 * a1675035970) % 69) - -183) * 1) / 5) - -95);
    	a63333937 = ((((((a2130183577 * a1985899004) % 14999) + 13094) + -36480) % 106) + 169);
    	a1983740902 = 34 ;
    	a620105235 = ((((((((a1151361287 * a30494462) % 14999) % 94) - 156) + -1) * 5) % 94) + 3);
    	a302110279 = 34 ;
    	a1318526106 = 34 ;
    	a708839806 = 34 ;
    	a709568404 = 34 ;
    	a190525986 = (a786258498 + 1);
    	a1478681170 = (a1916853335 + -2); 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((((a786258498 == 10 && (a2087535773 == 5 && (( cf==1  && (input == 6)) && a2073482783 == 34))) && ((249 < a1151361287) && (291 >= a1151361287))) && (a1241576728 == 8 && a2130193413 == 11))) {
    	cf = 0;
    	a260539918 = ((((((a1675035970 * a1675035970) % 14999) % 73) - -7) - -27) - -22);
    	a2026977784 = ((a1916853335 / a263638061) - -9);
    	a620105235 = ((((((a999024345 * a999024345) % 14999) + 11457) % 94) + -82) + 8);
    	a63333937 = (((((((a1675035970 * a1151361287) % 14999) % 106) + 30) / 5) + 1360) + -1276);
    	a190525986 = (a1574467713 - -10);
    	a1249952537 = (a2087535773 + 1);
    	a709568404 = 34 ;
    	a1210910088 = (a1241576728 - 5);
    	a1318526106 = 34 ;
    	a708839806 = 34 ;
    	a1625516355 = ((((((a999024345 * a1985899004) % 14999) + 2563) - 4322) % 37) + -41);
    	a1983740902 = 34 ;
    	a778006913 = ((a2130193413 * a4442917) + -74);
    	a1478681170 = ((a2061425267 + a263638061) - 18);
    	a302110279 = 34 ;
    	a813082108 = ((((((a217799639 * a1254983042) * 1) % 69) + 188) - 22457) + 22471); 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((a1125477212 == 34 && (a1211013485 == 34 && (a4442917 == 7 && a2087535773 == 5))) && ((((-59 < a217799639) && (-1 >= a217799639)) && ((input == 12) &&  cf==1 )) && a1241576728 == 8))) {
    	cf = 0;
    	a1826277115 = (((((a1675035970 * a217799639) + 25136) + -5942) * 10) / 9);
    	a983758263 = (((((a983758263 * a1826277115) % 14999) + -3158) + 10047) * 1);
    	a1337636546 = ((((((a1826277115 * a2130183577) % 14999) / 5) - 15716) * 10) / 9);
    	a404763935 = (a1916853335 + 1); 
    	 printf("%d\n", 18); fflush(stdout); 
    } 
}
 void calculate_outputm191(int input) {
    if(((a786258498 == 10 && a2087535773 == 5) && ((((249 < a1151361287) && (291 >= a1151361287)) && (((371 < a1985899004) && (524 >= a1985899004)) && (( cf==1  && (input == 13)) && ((131 < a999024345) && (260 >= a999024345))))) && a1210910088 == 3))) {
    	cf = 0;
    	a302110279 = 33 ;
    	a1895304149 = 33 ;
    	a2073482783 = 33 ;
    	a983758263 = ((((a983758263 + -206) + -2) - 15281) - -15283);
    	a1478681170 = (a778006913 + 2);
    	a999024345 = ((((((((a1625516355 * a1675035970) % 14999) % 41) - -90) + 1) * 5) % 41) + 68);
    	a26346326 = 33 ;
    	a721272783 = (a1959068056 - -4);
    	a1345687529 = ((((((a983758263 * a983758263) % 14999) % 14962) + 15037) + -23955) - -23957);
    	a813082108 = (((((((a813082108 * a1151361287) % 14999) % 50) + 41) / 5) + 10366) + -10333);
    	a1891437507 = 35 ;
    	a1151361287 = (((((((a30494462 * a620105235) % 14999) % 86) + 162) + -1) + 27578) - 27576);
    	a1644957382 = 33 ;
    	a4442917 = (a1241576728 + -2);
    	a1254983042 = (((((((a1254983042 * a1985899004) % 14999) % 101) - 1) - 0) - 1937) + 2038);
    	a1210910088 = (a1478681170 + -2);
    	a30494462 = (((((((a30494462 * a999024345) % 14999) % 92) + 25) + 4) + -16295) - -16225);
    	a1675035970 = ((((((a1675035970 * a1625516355) % 14999) % 17) - -190) + -2) + 2); 
    	 printf("%d\n", 17); fflush(stdout); 
    } if((((a2073482783 == 34 && a1895304149 == 34) && a76745981 == 34) && ((a1983740902 == 34 && (( cf==1  && (input == 5)) && a302110279 == 34)) && ((249 < a1151361287) && (291 >= a1151361287))))) {
    	cf = 0;
    	a1125477212 = 33 ;
    	a721272783 = ((a786258498 - a1478681170) - -5);
    	a803418896 = (((((((a1675035970 * a1254983042) % 14999) / 5) % 89) - 154) - -26565) - 26526);
    	a813082108 = ((((((a813082108 * a999024345) % 14999) % 50) + 13) + -28029) - -28069);
    	a1348848030 = ((a2061425267 - a1574467713) - -2);
    	a1151361287 = ((((((a1151361287 * a2130183577) % 14999) % 86) - -152) + -38) - -42);
    	a1478681170 = (a4442917 + -3);
    	a30494462 = (((((((a30494462 * a1774184757) % 14999) + -571) - -13790) - -229) % 92) + -24);
    	a1254983042 = ((((((a1625516355 * a1985899004) % 14999) + 15272) / 5) % 101) + 78);
    	a1675035970 = (((((((a1151361287 * a1151361287) % 14999) % 17) + 172) - -24579) / 5) - 4764);
    	a260539918 = (((((a260539918 * a63333937) % 17) - 24) - 1) + 1);
    	a1895304149 = 33 ;
    	a26346326 = 33 ;
    	a983758263 = (((((((a983758263 * a803418896) % 14999) % 104) + 98) + -24422) + 46640) - 22216);
    	a1210910088 = (a1895857334 + -9);
    	a786258498 = (a1241576728 + 1); 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm192(int input) {
    if(((((a26346326 == 34 && a1916853335 == 7) && a2026977784 == 9) && ((-8 < a260539918) && (140 >= a260539918))) && (((29 < a63333937) && (243 >= a63333937)) && (((249 < a1151361287) && (291 >= a1151361287)) && ( cf==1  && (input == 4)))))) {
    	cf = 0;
    	a721272783 = (a1478681170 + 9);
    	a778006913 = ((a1249952537 / a2087535773) + 1);
    	a1675035970 = ((((((a260539918 * a1151361287) % 14999) % 17) - -190) + 29706) + -29706);
    	a1345687529 = (((((a983758263 * a1474668405) % 14999) + 14261) - -4960) * 1);
    	a1478681170 = (a778006913 + 2);
    	a30494462 = ((((((a30494462 * a1675035970) % 14999) % 92) + -9) + 27678) - 27689);
    	a983758263 = ((((((((a983758263 * a63333937) % 14999) % 104) + 25) * 10) / 9) - 4489) - -4494);
    	a2130183577 = (((((((a2130183577 * a999024345) % 14999) % 63) + 154) + -9532) - 12119) + 21647);
    	a4442917 = ((a1916853335 / a786258498) + 6);
    	a813082108 = (((((((a813082108 * a983758263) % 14999) % 50) - -54) / 5) / 5) - -19);
    	a1254983042 = ((((((a1254983042 * a1625516355) % 14999) % 101) + 100) + -1) + 1);
    	a63333937 = ((((((a1345687529 * a1675035970) % 14999) % 81) + -85) - 19164) + 19180);
    	a1895304149 = 33 ;
    	a26346326 = 33 ;
    	a1018383389 = (((((((a1018383389 * a1151361287) % 14999) % 74) + 52) - -6380) + -20237) + 13854);
    	a1210910088 = (a1895857334 - 9);
    	a999024345 = ((((((((a999024345 * a1151361287) % 14999) - 11194) % 41) - -90) * 5) % 41) - -64);
    	a1644957382 = 33 ;
    	a1891437507 = 35 ;
    	a620105235 = (((((((a1151361287 * a1345687529) % 14999) - -8469) + 6154) * 1) % 10) - 179);
    	a2073482783 = 33 ;
    	a1151361287 = ((((((a1151361287 * a620105235) % 14999) / 5) + -10829) % 86) - -216); 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((( cf==1  && (input == 6)) && a2026977784 == 9) && (a26346326 == 34 && (a2087535773 == 5 && ((a708839806 == 34 && ((104 < a813082108) && (243 >= a813082108))) && a1895304149 == 34))))) {
    	cf = 0;
    	a4442917 = (a1249952537 - 1);
    	a1180594800 = 32 ;
    	a2130183577 = ((((((a2130183577 * a999024345) % 14999) + -22911) - 3938) * 10) / 9);
    	a834646264 = (a1916853335 + -1);
    	a786258498 = (a2061425267 - 4);
    	a1644957382 = 32 ;
    	a1895304149 = 32 ;
    	a1213722969 = a1895857334;
    	a813082108 = ((((((a813082108 * a620105235) % 14999) / 5) / 5) - -12588) * -2);
    	a1830659124 = ((a778006913 + a2087535773) - -3);
    	a1478681170 = (a4442917 - 2);
    	a601495656 = 32 ;
    	a1318526106 = 32 ;
    	a63333937 = ((((((a63333937 * a1675035970) % 14999) % 14932) + -15066) + -2) + 0);
    	a1959068056 = (a1574467713 - -5);
    	a302110279 = 33 ;
    	a708839806 = 32 ;
    	a341216798 = (((((a983758263 * a1474668405) % 14999) + -6369) + -4873) / 5);
    	a1018383389 = ((((((a1018383389 * a2130183577) % 14999) + -11080) * 1) % 74) - -93);
    	a999024345 = ((((((a1675035970 * a2130183577) % 14999) + 12988) / 5) * 5) - 27967);
    	a983758263 = ((((((a983758263 * a341216798) % 14999) % 14997) + -15002) * 1) + -2);
    	a1254983042 = (((((((a1254983042 * a1151361287) % 14999) - 21104) + -2747) + 34835) * -1) / 10);
    	a30494462 = (((((a30494462 * a1474668405) % 14999) - 12900) - 117) - 1794);
    	a26346326 = 32 ;
    	a1151361287 = ((((((a1151361287 * a620105235) % 14999) % 86) + 162) * 1) - 1);
    	a76745981 = 32 ;
    	a1625516355 = ((((((a620105235 * a341216798) % 14999) * 2) * 1) % 13) - 94);
    	a1211013485 = 32 ;
    	a260539918 = ((((((a260539918 * a63333937) % 14999) / 5) - 5273) * 10) / 9);
    	a263151501 = 32 ;
    	a2087535773 = (a1210910088 - -2); 
    	 printf("%d\n", 18); fflush(stdout); 
    } if((((a190525986 == 11 && ((((124 < a30494462) && (296 >= a30494462)) && ((131 < a999024345) && (260 >= a999024345))) && a263151501 == 34)) && a1211013485 == 34) && (( cf==1  && (input == 12)) && ((-8 < a260539918) && (140 >= a260539918))))) {
    	cf = 0;
    	a620988906 = 32 ;
    	a620105235 = (((((((a2130183577 * a30494462) % 14999) - -11432) % 94) - 109) - 14342) + 14307);
    	a709568404 = 34 ;
    	a1675035970 = (((((((a1254983042 * a1254983042) % 14999) + -22504) % 51) + 287) + 25287) - 25298);
    	a1625516355 = (((((((a1151361287 * a1018383389) % 14999) + 9100) % 37) - 54) * 10) / 9);
    	a1574467713 = (a2087535773 + 2); 
    	 printf("%d\n", 19); fflush(stdout); 
    } 
}
 void calculate_outputm194(int input) {
    if(((a76745981 == 34 && a1983740902 == 34) && ((a190525986 == 11 && ((( cf==1  && (input == 7)) && ((124 < a30494462) && (296 >= a30494462))) && a786258498 == 10)) && a263151501 == 34))) {
    	cf = 0;
    	a2061425267 = a786258498;
    	a1249952537 = ((a190525986 + a2026977784) - 14);
    	a1830659124 = (a1574467713 + 6);
    	a1521644128 = (a4442917 + -2);
    	a601495656 = 32 ;
    	a2087535773 = (a1249952537 - 1);
    	a1985899004 = ((((((a1985899004 * a1625516355) % 14999) / 5) - -21862) / 5) - 29600);
    	a1210910088 = (a1916853335 + -4);
    	a1254983042 = ((((((a1254983042 * a1151361287) % 14999) - -220) * 1) / 5) + -26832);
    	a190525986 = (a1916853335 + 4);
    	a263151501 = 32 ;
    	a2130183577 = (((((a2130183577 * a620105235) % 14999) + 18997) - 33710) * 1);
    	a983758263 = ((((((a983758263 * a1474668405) % 14999) % 14997) - 15002) * 1) + -2);
    	a76745981 = 32 ;
    	a999024345 = (((((a999024345 * a63333937) % 14999) - -2111) + -17018) * 1);
    	a786258498 = (a778006913 + 7);
    	a1644957382 = 32 ;
    	a341216798 = ((((a1474668405 * a1474668405) + 6213) + 3903) * 1);
    	a30494462 = (((((a30494462 * a620105235) % 14999) / 5) - 21931) + -2374);
    	a965340096 = 32 ;
    	a1180594800 = 32 ;
    	a1959068056 = ((a1241576728 / a2130193413) - -8);
    	a1983740902 = 33 ;
    	a1895304149 = 32 ;
    	a4442917 = ((a1830659124 / a2026977784) - -4); 
    	 printf("%d\n", 20); fflush(stdout); 
    } 
}
 void calculate_outputm195(int input) {
    if(((((-81 < a1625516355) && (-5 >= a1625516355)) && (((-8 < a260539918) && (140 >= a260539918)) && (a1959068056 == 10 && ( cf==1  && (input == 7))))) && ((((35 < a1774184757) && (169 >= a1774184757)) && ((230 < a2130183577) && (255 >= a2130183577))) && ((104 < a813082108) && (243 >= a813082108))))) {
    	cf = 0;
    	a1249952537 = ((a786258498 + a786258498) - 13);
    	a30494462 = (((((((a1985899004 * a63333937) % 14999) - 4978) % 92) - -32) + 23765) + -23765);
    	a1625516355 = ((((((a1625516355 * a260539918) - -13398) % 13) - 97) * 10) / 9);
    	a601495656 = 33 ;
    	a1151361287 = (((((((a1151361287 * a30494462) % 14999) / 5) % 86) - -162) + -1126) - -1127);
    	a1644957382 = 33 ;
    	a1774184757 = ((((((a2130183577 * a1254983042) % 14999) % 92) - 74) / 5) / 5);
    	a813082108 = (((((((a813082108 * a2130183577) % 14999) - 999) + -5956) / 5) % 50) - -54);
    	a1700231631 = (a2061425267 - 5);
    	a999024345 = ((((((a999024345 * a1774184757) % 14999) % 41) - -90) - 28743) + 28743);
    	a1895304149 = 33 ;
    	a721272783 = (a778006913 - -14);
    	a834646264 = (a4442917 - -2);
    	a1211013485 = 33 ;
    	a778006913 = (a1959068056 - 8);
    	a2130183577 = (((((((a2130183577 * a217799639) % 14999) + -2513) % 63) - -169) * 10) / 9);
    	a1210910088 = (a2087535773 + -3);
    	a983758263 = ((((a983758263 / 5) - -115) + -13417) + 13421);
    	a1830659124 = (a1895857334 - 1);
    	a1254983042 = ((((((a1254983042 * a1018383389) % 14999) % 101) - 1) - -24100) + -24015);
    	a2130193413 = ((a190525986 * a1700231631) - 67);
    	a190525986 = a1830659124;
    	a2061425267 = ((a1574467713 - a834646264) + 16); 
    	 printf("%d\n", 17); fflush(stdout); 
    } 
}
 void calculate_outputm196(int input) {
    if(((a778006913 == 3 && (a1318526106 == 34 && ( cf==1  && (input == 4)))) && (((35 < a1774184757) && (169 >= a1774184757)) && ((a2130193413 == 11 && ((249 < a1151361287) && (291 >= a1151361287))) && ((-8 < a260539918) && (140 >= a260539918)))))) {
    	cf = 0;
    	a1018383389 = (((((((a1018383389 * a999024345) % 14999) / 5) % 74) - -32) - 2622) - -2663);
    	a834646264 = a1574467713;
    	a778006913 = (a190525986 - 10);
    	a1213722969 = (a1241576728 + 3);
    	a1830659124 = ((a2061425267 / a786258498) + 8);
    	a1959068056 = (a1895857334 - 3);
    	a341216798 = (((((a983758263 * a983758263) % 14999) + 7990) + -32938) + -2496);
    	a2087535773 = ((a1916853335 - a1959068056) - -4);
    	a1211013485 = 32 ;
    	a813082108 = (((((a1675035970 * a1774184757) % 14999) - 15001) * 1) * 1);
    	a620105235 = (((((((a620105235 * a1985899004) % 14999) + 1344) * 1) * 1) % 14909) + -15090);
    	a1254983042 = ((((((a1254983042 * a63333937) % 14999) - 7683) * 1) * 10) / 9);
    	a30494462 = (((((a30494462 * a1625516355) * 10) / 9) - -18266) + -19134);
    	a1318526106 = 32 ;
    	a263151501 = 32 ;
    	a260539918 = ((((((a260539918 * a2130183577) % 14999) % 14978) + -15021) * 1) - 2);
    	a1151361287 = (((((((a1151361287 * a2130183577) % 14999) - -10169) - 20536) * 2) % 86) + 161);
    	a26346326 = 32 ;
    	a302110279 = 33 ;
    	a1210910088 = ((a1241576728 + a1478681170) + -10);
    	a708839806 = 32 ;
    	a1241576728 = ((a786258498 - a4442917) + 3);
    	a1644957382 = 32 ;
    	a983758263 = (((((a983758263 * a2130183577) % 14999) + -26696) + -2766) - 178);
    	a1625516355 = ((((((a1625516355 * a2130183577) * 1) + 2910) / 5) % 13) + -95);
    	a1895304149 = 32 ;
    	a999024345 = (((((a999024345 * a813082108) % 14999) + -14967) / 5) / 5);
    	a601495656 = 32 ;
    	a1180594800 = 32 ;
    	a2130183577 = ((((((a2130183577 * a1569588614) * 1) - -4796) + 2675) % 15051) - 14947); 
    	 printf("%d\n", 17); fflush(stdout); 
    } if(((((-81 < a1625516355) && (-5 >= a1625516355)) && ( cf==1  && (input == 5))) && ((((((371 < a1985899004) && (524 >= a1985899004)) && ((230 < a2130183577) && (255 >= a2130183577))) && a1644957382 == 34) && ((-8 < a260539918) && (140 >= a260539918))) && a1830659124 == 11))) {
    	cf = 0;
    	a786258498 = (a1895857334 - 1);
    	a983758263 = (((((a983758263 * a999024345) % 14999) - -13320) - -363) - -654);
    	a2073482783 = 34 ;
    	a1826277115 = (((((((a983758263 * a1569588614) % 14999) + 7331) * 1) + -146) % 62) - -115);
    	a965340096 = 32 ;
    	a709568404 = 34 ;
    	a4442917 = (a1210910088 + 4);
    	a76745981 = 34 ;
    	a63333937 = (((((((a30494462 * a2130183577) % 14999) + -15483) % 106) - -190) * 10) / 9);
    	a1521644128 = (a2087535773 - -5);
    	a1478681170 = ((a1959068056 - a1241576728) + 3);
    	a1675035970 = (((((a1774184757 * a620105235) * 1) % 51) + 260) - 1); 
    	 printf("%d\n", 26); fflush(stdout); 
    } if(((((-160 < a620105235) && (30 >= a620105235)) && (a1211013485 == 34 && ((input == 6) &&  cf==1 ))) && (((a190525986 == 11 && a1830659124 == 11) && ((104 < a813082108) && (243 >= a813082108))) && ((167 < a1018383389) && (211 >= a1018383389))))) {
    	cf = 0;
    	a709568404 = 32 ;
    	a1983740902 = 34 ;
    	a63333937 = ((((((a620105235 * a1985899004) % 14999) % 14932) - 15066) * 1) - 2);
    	a786258498 = (a2061425267 + -4);
    	a1125477212 = 34 ;
    	a76745981 = 32 ;
    	a1249952537 = ((a1916853335 / a2130193413) - -6);
    	a1478681170 = (a1830659124 + -8);
    	a2073482783 = 32 ;
    	a1675035970 = (((((a1254983042 * a30494462) % 14999) / 5) + -11808) - 16080);
    	a4442917 = (a190525986 - 6);
    	a2026977784 = (a190525986 + -2); 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((((a26346326 == 34 && a1318526106 == 34) && a1895304149 == 34) && ((a708839806 == 34 && (( cf==1  && (input == 14)) && a302110279 == 34)) && a263151501 == 34))) {
    	cf = 0;
    	a709568404 = 34 ;
    	a1675035970 = ((((((a999024345 * a620105235) % 14999) + -6115) % 51) + 260) + 1);
    	a1478681170 = (a1241576728 + -3);
    	a302110279 = 34 ;
    	a1983740902 = 34 ;
    	a786258498 = (a2087535773 + 5);
    	a1210910088 = ((a2087535773 / a2087535773) - -2);
    	a1574467713 = ((a1916853335 - a1895857334) - -5);
    	a1318526106 = 34 ;
    	a708839806 = 34 ;
    	a4442917 = ((a2130193413 - a778006913) + -1);
    	a778006913 = ((a1241576728 / a1241576728) + 2);
    	a263638061 = ((a190525986 + a1959068056) + -10);
    	a2073482783 = 34 ;
    	a1249952537 = ((a1830659124 - a1574467713) - 4);
    	a620105235 = ((((((a620105235 * a999024345) % 14999) - -12350) - -431) % 94) + -64);
    	a260539918 = (((((((a260539918 * a1254983042) % 14999) % 73) - -65) + 3) - 8936) - -8934);
    	a63333937 = ((((((a1569588614 * a813082108) + -1152) % 106) + 137) + -3273) - -3273);
    	a1625516355 = (((((a1625516355 * a1018383389) / 5) * 5) % 37) - 15);
    	a190525986 = ((a1241576728 + a2061425267) + -9);
    	a813082108 = (((((((a2130183577 * a30494462) % 14999) % 69) + 144) * 5) % 69) - -154);
    	a2026977784 = (a2087535773 + 4); 
    	 printf("%d\n", 17); fflush(stdout); 
    } 
}
 void calculate_outputm197(int input) {
    if((((a4442917 == 7 && a2130193413 == 11) && a190525986 == 11) && (((( cf==1  && (input == 9)) && ((-160 < a620105235) && (30 >= a620105235))) && a1180594800 == 34) && a1895304149 == 34))) {
    	cf = 0;
    	 
    	 printf("%d\n", 19); fflush(stdout); 
    } if(((((input == 14) &&  cf==1 ) && a2087535773 == 5) && ((a190525986 == 11 && (((-160 < a620105235) && (30 >= a620105235)) && (a1478681170 == 5 && a4442917 == 7))) && a601495656 == 34))) {
    	cf = 0;
    	a2004613952 = ((a2026977784 - a4442917) - -11);
    	a1260876233 = ((((((a1985899004 * a1985899004) % 14999) - -5889) + 4754) % 92) + 17);
    	a1895857334 = ((a1478681170 - a1249952537) + 8); 
    	 printf("%d\n", 16); fflush(stdout); 
    } 
}
 void calculate_outputm198(int input) {
    if(((((-160 < a620105235) && (30 >= a620105235)) && (((-59 < a217799639) && (-1 >= a217799639)) && a1895304149 == 34)) && (a2087535773 == 5 && (((207 < a1675035970) && (311 >= a1675035970)) && (a263151501 == 34 && ( cf==1  && (input == 8))))))) {
    	cf = 0;
    	a1241576728 = (a1830659124 - 5);
    	a1574467713 = (a1959068056 - 7);
    	a620105235 = ((((((a620105235 * a1151361287) % 14999) % 14909) + -15090) + 13577) - 13577);
    	a302110279 = 33 ;
    	a1474668405 = ((((((a1254983042 * a1625516355) % 14999) - 7595) * 1) - -18089) + -18228);
    	a1210910088 = ((a2061425267 + a190525986) - 22);
    	a1983740902 = 34 ;
    	a2073482783 = 32 ;
    	a1675035970 = (((((a1675035970 * a30494462) % 14999) + -20085) - 7626) - 2034);
    	a1625516355 = (((((((a999024345 * a63333937) % 14999) - -6528) % 13) + -107) * 9) / 10);
    	a709568404 = 32 ;
    	a778006913 = (a786258498 + -9);
    	a217799639 = ((((((a217799639 * a813082108) % 28) + -29) / 5) * 10) / 9); 
    	 printf("%d\n", 17); fflush(stdout); 
    } 
}
 void calculate_outputm199(int input) {
    if(((a263151501 == 34 && (((104 < a813082108) && (243 >= a813082108)) && a302110279 == 34)) && ((((202 < a1254983042) && (414 >= a1254983042)) && (( cf==1  && (input == 4)) && a1241576728 == 8)) && a2073482783 == 34))) {
    	cf = 0;
    	a1260876233 = ((((((a983758263 * a999024345) % 14999) % 53) + -53) + 1) + 8);
    	a2004613952 = (a786258498 - -3);
    	a1895857334 = a1916853335; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((a1249952537 == 6 && ((a2061425267 == 12 && ((230 < a2130183577) && (255 >= a2130183577))) && a1916853335 == 7)) && ((a1180594800 == 34 && ( cf==1  && (input == 8))) && ((124 < a30494462) && (296 >= a30494462))))) {
    	a990043066 += (a990043066 + 20) > a990043066 ? 3 : 0;
    	cf = 0;
    	a2097567994 = 34 ;
    	a260539918 = ((((((a217799639 * a63333937) % 17) + -24) * 5) % 17) - 11);
    	a2026977784 = ((a1478681170 - a1830659124) - -15);
    	a999024345 = (((((a260539918 * a1625516355) % 41) - -63) + 28) - 29);
    	a1916853335 = (a1895857334 + -6);
    	a2130193413 = (a1830659124 + -1);
    	a1254983042 = (((((((a1254983042 * a999024345) % 14999) / 5) % 101) + -1) - -1422) - 1322);
    	a1983740902 = 33 ;
    	a983758263 = (((((((a983758263 * a1774184757) % 14999) % 104) - -70) / 5) + 10710) - 10677);
    	a1969216760 = 36 ;
    	a1211013485 = 33 ;
    	a1210910088 = (a1830659124 + -9);
    	a813082108 = ((((((a1625516355 * a999024345) % 50) - -102) * 9) / 10) + -13);
    	a1241576728 = ((a4442917 / a1210910088) + 4);
    	a1625516355 = (((((((a999024345 * a217799639) + -19869) % 13) - 90) * 5) % 13) - 85);
    	a1125477212 = 32 ;
    	a2087535773 = (a190525986 - 8);
    	a1774184757 = ((((((a2130183577 * a2130183577) % 14999) % 92) + -91) / 5) / 5);
    	a30494462 = ((((((a30494462 * a1254983042) % 14999) % 92) - -31) + -1982) - -1981);
    	a778006913 = (a1574467713 + -5);
    	a1675035970 = (((((((a1675035970 * a813082108) % 14999) + -11289) + -8258) * 1) % 17) - -205);
    	a1249952537 = (a1895857334 + -7);
    	a709568404 = 32 ;
    	a1151361287 = ((((((a1151361287 * a1774184757) % 14999) - -455) % 86) - -161) - 0);
    	a4442917 = ((a778006913 * a1210910088) - -1);
    	a786258498 = (a1895857334 - 2);
    	a601495656 = 33 ;
    	a76745981 = 32 ;
    	a2130183577 = (((((((a2130183577 * a217799639) * 2) % 63) + 203) * 5) % 63) - -159);
    	a721272783 = (a1959068056 + 5);
    	a1018383389 = (((((((a1018383389 * a620105235) % 14999) % 74) + 93) - 1) - -28584) - 28584);
    	a1895304149 = 33 ;
    	a1959068056 = (a190525986 + -2);
    	a1180594800 = 33 ;
    	a2061425267 = ((a1241576728 * a2130193413) - 60);
    	a217799639 = ((((a217799639 * a999024345) + 1790) / 5) + -25084); 
    	 printf("%d\n", 20); fflush(stdout); 
    } if(((((-59 < a217799639) && (-1 >= a217799639)) && (((((-81 < a1625516355) && (-5 >= a1625516355)) && ((input == 12) &&  cf==1 )) && a4442917 == 7) && a1644957382 == 34)) && (a1830659124 == 11 && a709568404 == 34))) {
    	cf = 0;
    	a1574467713 = (a1916853335 - 4);
    	a1474668405 = (((((((a983758263 * a983758263) % 14999) - -1212) % 76) - 132) + 25913) + -25932); 
    	 printf("%d\n", 18); fflush(stdout); 
    } 
}
 void calculate_outputm200(int input) {
    if((((((-59 < a217799639) && (-1 >= a217799639)) && ((104 < a813082108) && (243 >= a813082108))) && a786258498 == 10) && (((((input == 14) &&  cf==1 ) && ((131 < a999024345) && (260 >= a999024345))) && a709568404 == 34) && a1644957382 == 34))) {
    	cf = 0;
    	a721272783 = ((a1830659124 * a1830659124) + -107);
    	a620105235 = ((((((((a620105235 * a983758263) % 14999) % 10) - 170) * 1) * 5) % 10) + -169);
    	a1018383389 = ((((((a1018383389 * a217799639) % 74) + 158) + -25) * 9) / 10);
    	a999024345 = (((((((a999024345 * a620105235) % 14999) % 41) + 90) + 1) - 12377) + 12375);
    	a1254983042 = ((((((a1254983042 * a1625516355) % 14999) - 5773) % 101) - -122) + 20);
    	a1210910088 = ((a2061425267 + a190525986) + -21);
    	a1895304149 = 33 ;
    	a983758263 = (((((((a983758263 * a1774184757) % 14999) + 11021) % 104) + -5) - 8471) + 8482);
    	a1891437507 = 35 ;
    	a30494462 = ((((((a30494462 * a217799639) % 92) + 40) + -19088) - 1905) - -21017);
    	a813082108 = ((((((a813082108 * a2130183577) % 14999) - 8638) * 3) % 50) - -54);
    	a1644957382 = 33 ;
    	a1345687529 = (((((((a63333937 * a2130183577) % 14999) + 4673) * 10) / 9) * 10) / 9);
    	a63333937 = ((((((a63333937 * a620105235) % 14999) % 81) + -51) + -2) - -2);
    	a2130183577 = (((((a2130183577 * a1625516355) % 63) + 228) + 1) + -61); 
    	 printf("%d\n", 20); fflush(stdout); 
    } if(((a2130193413 == 11 && a1249952537 == 6) && ((((( cf==1  && (input == 6)) && a1210910088 == 3) && a1211013485 == 34) && a1830659124 == 11) && a1644957382 == 34))) {
    	cf = 0;
    	a983758263 = ((((a983758263 + 12211) * 2) % 104) + -5);
    	a620105235 = ((((((((a620105235 * a30494462) % 14999) / 5) % 10) + -169) / 5) * 51) / 10);
    	a30494462 = (((((((a999024345 * a983758263) % 14999) + 8227) % 92) - -31) - -10656) - 10654);
    	a1959068056 = (a190525986 + -2);
    	a217799639 = (((((((a217799639 * a1675035970) % 69) + -126) + -2) * 5) % 69) - 118);
    	a721272783 = ((a1574467713 * a1895857334) - 61);
    	a1210910088 = ((a778006913 - a778006913) - -2);
    	a1474668405 = (((((((a983758263 * a983758263) % 14999) * 2) - 2) - -1) % 76) - 82);
    	a1964635488 = 32 ;
    	a1018383389 = (((((((a1018383389 * a2130183577) % 14999) / 5) % 74) + 59) * 9) / 10);
    	a1774184757 = (((((((a1774184757 * a813082108) % 14999) - -6155) - 8413) * 2) % 92) - 58);
    	a1916853335 = (a1241576728 - 1);
    	a1895304149 = 33 ;
    	a1180594800 = 33 ;
    	a1318526106 = 33 ;
    	a1830659124 = (a1478681170 - -6);
    	a2130183577 = (((((((a2130183577 * a620105235) % 14999) % 63) + 166) + 0) - 11593) + 11594); 
    	 printf("%d\n", 26); fflush(stdout); 
    } 
}
 void calculate_outputm201(int input) {
    if((((a1241576728 == 8 && ((a786258498 == 10 && ( cf==1  && (input == 5))) && a601495656 == 34)) && ((-160 < a620105235) && (30 >= a620105235))) && (a778006913 == 3 && a263151501 == 34))) {
    	cf = 0;
    	a260539918 = (((((((a217799639 * a2130183577) % 73) + 81) * 10) / 9) * 10) / 9);
    	a1625516355 = (((((a1774184757 * a217799639) - -25739) % 37) - 75) + 25);
    	a620105235 = ((((((a620105235 * a30494462) % 14999) + -6937) + 16730) % 94) - 65);
    	a1210910088 = (a1830659124 + -8);
    	a1574467713 = ((a786258498 - a190525986) - -2);
    	a1318526106 = 34 ;
    	a1249952537 = (a1959068056 + -4);
    	a1478681170 = (a2061425267 - 7);
    	a63333937 = ((((((((a63333937 * a1018383389) % 14999) % 106) + 33) * 1) * 5) % 106) - -58);
    	a26346326 = 34 ;
    	a813082108 = ((((((((a1675035970 * a999024345) % 14999) - 3612) % 69) - -173) * 5) % 69) + 124);
    	a302110279 = 34 ;
    	a709568404 = 34 ;
    	a1983740902 = 34 ;
    	a263638061 = (a1959068056 + 1);
    	a778006913 = (a2130193413 - 8);
    	a190525986 = ((a1959068056 * a1959068056) - 89);
    	a708839806 = 34 ;
    	a2026977784 = ((a1916853335 + a2061425267) + -10); 
    	 printf("%d\n", 17); fflush(stdout); 
    } if(((((29 < a63333937) && (243 >= a63333937)) && ((((( cf==1  && (input == 6)) && a2087535773 == 5) && a4442917 == 7) && ((371 < a1985899004) && (524 >= a1985899004))) && ((131 < a999024345) && (260 >= a999024345)))) && a1644957382 == 34)) {
    	cf = 0;
    	a2026977784 = ((a2087535773 + a1830659124) + -7);
    	a709568404 = 34 ;
    	a708839806 = 34 ;
    	a1478681170 = ((a190525986 * a4442917) + -72);
    	a1574467713 = (a786258498 + -9);
    	a26346326 = 34 ;
    	a302110279 = 34 ;
    	a813082108 = ((((((a1018383389 * a1151361287) % 14999) + 1666) - -709) % 69) - -114);
    	a263638061 = a190525986;
    	a63333937 = ((((((a63333937 * a1254983042) % 14999) % 106) + 131) - -27444) + -27487);
    	a1210910088 = (a1241576728 - 5);
    	a620105235 = ((((((a620105235 * a1675035970) % 14999) + 7809) % 94) - 64) + 1);
    	a1625516355 = (((((((a1985899004 * a1774184757) % 14999) / 5) - 18228) / 5) % 37) + -41);
    	a1983740902 = 34 ;
    	a778006913 = (a1830659124 + -8);
    	a260539918 = (((((((a30494462 * a999024345) % 14999) + -25983) * 1) + 20929) % 73) + 66);
    	a1318526106 = 34 ;
    	a1249952537 = (a1895857334 - 5);
    	a190525986 = a1895857334; 
    	 printf("%d\n", 17); fflush(stdout); 
    } if((((( cf==1  && (input == 11)) && a778006913 == 3) && ((-59 < a217799639) && (-1 >= a217799639))) && ((a1318526106 == 34 && (a1180594800 == 34 && a1211013485 == 34)) && a263151501 == 34))) {
    	cf = 0;
    	a983758263 = ((((((a983758263 * a2130183577) % 14999) - 13445) % 104) - -98) - -2);
    	a1774184757 = ((((((a1774184757 * a1018383389) % 14999) + 2783) - -5707) % 92) - 134);
    	a1474668405 = (((((((a999024345 * a999024345) % 14999) - -10969) + -48) / 5) % 76) + -97);
    	a30494462 = (((((((a30494462 * a1625516355) % 14999) % 92) + 30) / 5) + -6189) - -6211);
    	a721272783 = ((a190525986 * a1895857334) - 105);
    	a1675035970 = ((((((((a1675035970 * a63333937) % 14999) % 17) + 187) - -4) * 5) % 17) + 188);
    	a1478681170 = ((a190525986 / a2087535773) + 2);
    	a2130183577 = ((((((a1774184757 * a983758263) % 14999) - 13951) - 1047) % 63) - -167);
    	a1318526106 = 33 ;
    	a1644957382 = 33 ;
    	a1916853335 = ((a1241576728 * a4442917) - 50);
    	a1959068056 = ((a1916853335 + a1895857334) + -8);
    	a1895304149 = 33 ;
    	a1830659124 = ((a1574467713 * a1574467713) + -39);
    	a620105235 = ((((((a620105235 * a217799639) * 3) % 10) + -169) + -28983) + 28981);
    	a778006913 = (a2026977784 + -6);
    	a1964635488 = 33 ;
    	a1241576728 = (a786258498 + -3); 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm202(int input) {
    if(((a1644957382 == 34 && ((input == 2) &&  cf==1 )) && (((35 < a1774184757) && (169 >= a1774184757)) && (((((29 < a63333937) && (243 >= a63333937)) && a1830659124 == 11) && a1478681170 == 5) && ((-8 < a260539918) && (140 >= a260539918)))))) {
    	cf = 0;
    	a63333937 = (((((a63333937 * a620105235) % 14999) / 5) / 5) - 21231);
    	a708839806 = 32 ;
    	a1211013485 = 34 ;
    	a4442917 = (a1210910088 + 2);
    	a786258498 = (a1241576728 - -2);
    	a2073482783 = 32 ;
    	a190525986 = (a1830659124 - 2);
    	a778006913 = (a1210910088 - 2);
    	a2087535773 = (a1574467713 + -5);
    	a709568404 = 32 ;
    	a1352986605 = (((((a1985899004 * a2130183577) % 14999) - 17899) / 5) + -6411);
    	a1895857334 = ((a2026977784 - a1916853335) - -4);
    	a620105235 = (((((a983758263 * a30494462) % 14999) - 22688) + -5470) * 1);
    	a1625516355 = ((((((a1625516355 * a983758263) % 14999) - 14037) * 1) + 28741) - 24528);
    	a1241576728 = (a2130193413 - 5);
    	a1983740902 = 33 ;
    	a26346326 = 32 ;
    	a1916853335 = (a1249952537 - 1);
    	a1318526106 = 32 ;
    	a1478681170 = ((a2061425267 * a2061425267) - 139);
    	a1895304149 = 32 ;
    	a263151501 = 32 ;
    	a217799639 = (((((a1151361287 * a1985899004) % 14999) - 24804) - 3120) + -187);
    	a1125477212 = 34 ;
    	a260339255 = ((((((a983758263 * a983758263) % 14999) + -19723) % 24) + 49) + 12);
    	a302110279 = 32 ;
    	a1985899004 = (((((a1985899004 * a1018383389) % 14999) + 3320) + -25415) * 1);
    	a813082108 = ((((((a260539918 * a999024345) % 14999) * 2) * 1) % 15001) + -14997);
    	a2130183577 = (((((a2130183577 * a1675035970) % 14999) + -18371) + -11272) / 5); 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((((230 < a2130183577) && (255 >= a2130183577)) && a302110279 == 34) && a263151501 == 34) && ((a1916853335 == 7 && (a190525986 == 11 && ( cf==1  && (input == 6)))) && ((131 < a999024345) && (260 >= a999024345))))) {
    	cf = 0;
    	a1018383389 = (((((((a1018383389 * a1774184757) % 14999) % 74) - -36) * 9) / 10) - -48);
    	a1478681170 = ((a1916853335 * a1916853335) + -45);
    	a813082108 = (((((a1774184757 * a1018383389) % 50) + 22) + -4794) + 4805);
    	a1125477212 = 32 ;
    	a1254983042 = ((((((((a1254983042 * a1774184757) % 14999) % 101) - -84) * 9) / 10) - -15236) + -15259);
    	a63333937 = (((((((a63333937 * a1675035970) % 14999) % 81) + -82) + 18391) + 10650) - 29092);
    	a757937656 = ((a2130193413 - a1916853335) + -2);
    	a1644957382 = 33 ;
    	a1151361287 = ((((((a1151361287 * a983758263) % 14999) + 872) * 1) % 86) - -95);
    	a217799639 = (((((a2130183577 * a1018383389) % 14999) / 5) + -13177) / 5);
    	a1210910088 = ((a1574467713 * a1478681170) + -30);
    	a2130193413 = a1959068056;
    	a263151501 = 33 ;
    	a1249952537 = (a1241576728 - 3);
    	a30494462 = (((((a30494462 * a1625516355) % 92) + 58) - 18) + 41);
    	a1241576728 = ((a1478681170 * a1916853335) - 21);
    	a1959068056 = (a1478681170 + 4);
    	a1830659124 = (a1210910088 - -8);
    	a721272783 = (a2061425267 + 3);
    	a1675035970 = ((((((a1675035970 * a1985899004) % 14999) - 12824) % 17) - -189) - 1);
    	a1985899004 = ((((a1018383389 * a1018383389) * -1) - 1441) * 1);
    	a2026977784 = (a2087535773 - -3);
    	a2061425267 = (a786258498 + 1);
    	a1318526106 = 33 ;
    	a260539918 = ((((((a260539918 * a1774184757) % 17) + -24) + -2) + 16640) - 16638);
    	a1895304149 = 33 ;
    	a1625516355 = ((((((a1018383389 * a1774184757) - -1649) % 13) + -103) + 5131) - 5131);
    	a999024345 = ((((((a999024345 * a620105235) % 14999) + 14755) / 5) % 41) + 90);
    	a620105235 = ((((((a1254983042 * a2130183577) % 14999) - -8766) - -4560) % 10) - 170);
    	a601495656 = 33 ;
    	a708839806 = 33 ;
    	a983758263 = (((a983758263 + 20400) - 20607) / 5);
    	a778006913 = (a1916853335 - 5);
    	a2087535773 = (a1895857334 - 8);
    	a4442917 = ((a2026977784 + a1916853335) + -9);
    	a1180594800 = 33 ;
    	a76745981 = 33 ;
    	a2073482783 = 33 ;
    	a2097567994 = 32 ;
    	a2130183577 = ((((((a2130183577 * a1774184757) % 14999) + -2798) / 5) % 63) + 167);
    	a1774184757 = ((((((a1774184757 * a1018383389) % 92) + -87) / 5) - -5432) + -5531);
    	a302110279 = 33 ;
    	a1916853335 = ((a190525986 / a786258498) - -4);
    	a190525986 = ((a786258498 * a786258498) + -72); 
    	 printf("%d\n", 20); fflush(stdout); 
    } if(((a76745981 == 34 && ((a1241576728 == 8 && (a1959068056 == 10 && a1210910088 == 3)) && a2130193413 == 11)) && (((input == 12) &&  cf==1 ) && a1478681170 == 5))) {
    	a1933720537 += (a1933720537 + 20) > a1933720537 ? 1 : 0;
    	a1233331030 -= (a1233331030 - 20) < a1233331030 ? 4 : 0;
    	cf = 0;
    	a2073482783 = 32 ;
    	a63333937 = (((((((a63333937 * a1985899004) % 14999) - 19500) % 81) + 5) - -28538) - 28552);
    	a721272783 = ((a1830659124 / a1574467713) + 9);
    	a983758263 = (((((((a983758263 * a1774184757) % 14999) % 104) + 84) + 28731) - -5) - 28819);
    	a803418896 = ((((((a983758263 * a999024345) % 14999) % 14961) - -15037) - 0) - 0);
    	a30494462 = (((((((a30494462 * a2130183577) % 14999) / 5) - 25593) / 5) % 92) - -42);
    	a1318526106 = 33 ;
    	a1254983042 = ((((((a1254983042 * a1625516355) % 14999) / 5) + -17868) % 101) + 140);
    	a1895304149 = 33 ;
    	a190525986 = a1959068056;
    	a1249952537 = (a1241576728 + -3);
    	a1774184757 = ((((((a1985899004 * a1254983042) % 14999) % 92) + -56) + 24956) + -24956);
    	a1916853335 = (a2130193413 + -5);
    	a601495656 = 32 ;
    	a2130183577 = (((((((a1985899004 * a620105235) % 14999) % 63) + 166) - -13767) / 5) - 2623);
    	a703247202 = 36 ;
    	a4442917 = ((a2026977784 - a1249952537) - -1);
    	a1625516355 = (((((a63333937 * a63333937) % 13) - 94) - -10020) - 10020);
    	a1180594800 = 33 ;
    	a999024345 = (((((a983758263 * a260539918) % 41) - -89) - 29778) + 29778);
    	a786258498 = ((a1478681170 * a2026977784) - 37);
    	a302110279 = 33 ;
    	a1241576728 = a1916853335;
    	a778006913 = (a2130193413 - 10);
    	a263151501 = 32 ;
    	a1830659124 = ((a1478681170 - a1478681170) - -10);
    	a1959068056 = ((a2026977784 * a1895857334) - 91);
    	a1985899004 = ((((((a1985899004 * a1018383389) % 14999) % 98) + 237) - 4632) - -4618);
    	a76745981 = 32 ;
    	a1210910088 = ((a2061425267 / a2130193413) + 1);
    	a2087535773 = ((a1895857334 - a2061425267) + 5);
    	a1644957382 = 32 ;
    	a620105235 = ((((((a620105235 * a1675035970) % 14999) % 14909) - 15090) - 2) - 0);
    	a1675035970 = ((((((((a1675035970 * a260539918) % 14999) % 17) + 190) + -5061) * 5) % 17) + 190);
    	a260539918 = ((((((a1151361287 * a30494462) % 14999) % 14978) - 15021) - 1) - 1);
    	a708839806 = 32 ;
    	a813082108 = (((((a803418896 * a1774184757) % 14999) / 5) - 23847) - 373);
    	a1478681170 = ((a1249952537 * a721272783) - 47);
    	a2061425267 = a2130193413; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((((a190525986 == 11 && ((input == 14) &&  cf==1 )) && a1644957382 == 34) && ((-81 < a1625516355) && (-5 >= a1625516355))) && (((131 < a999024345) && (260 >= a999024345)) && (((-160 < a620105235) && (30 >= a620105235)) && a4442917 == 7)))) {
    	cf = 0;
    	a1983740902 = 34 ;
    	a786258498 = (a2087535773 + 5);
    	a1125477212 = 32 ;
    	a63333937 = (((((a63333937 * a1254983042) % 14999) + -15581) * 1) + -12382);
    	a1774184757 = (((((a1774184757 * a1151361287) % 14999) - 12933) + 25677) - 31743);
    	a620105235 = ((((a620105235 * a260539918) + 11523) - 5078) - 13037);
    	a1985899004 = (((((a1985899004 * a2130183577) % 14999) + -23786) - -31397) / -5);
    	a263151501 = 32 ;
    	a1625516355 = (((((a1625516355 * a260539918) - 16154) - 1071) - -34953) - 36109);
    	a778006913 = ((a1916853335 - a1959068056) - -4);
    	a302110279 = 32 ;
    	a813082108 = ((((((a1675035970 * a1018383389) % 14999) - 11869) % 50) + 53) * 1);
    	a2130193413 = ((a2087535773 * a2087535773) - 16);
    	a1478681170 = (a190525986 + -6);
    	a1318526106 = 32 ;
    	a76745981 = 32 ;
    	a2130183577 = (((((a2130183577 * a1151361287) % 14999) / 5) - 13585) - 15235);
    	a709568404 = 34 ;
    	a190525986 = ((a2061425267 * a1249952537) + -63);
    	a217799639 = (((((((a1151361287 * a1018383389) % 14999) - 2282) * 2) - -531) % 14901) - 15098);
    	a1211013485 = 34 ;
    	a26346326 = 32 ;
    	a965340096 = 35 ;
    	a260539918 = (((((((a260539918 * a30494462) % 14999) * 2) - 0) * 1) % 73) + 67); 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm203(int input) {
    if(((a1249952537 == 6 && ((124 < a30494462) && (296 >= a30494462))) && (a1983740902 == 34 && (a1211013485 == 34 && (a1916853335 == 7 && (a2073482783 == 34 && ( cf==1  && (input == 8)))))))) {
    	cf = 0;
    	a2061425267 = ((a1249952537 + a1574467713) - 4);
    	a1211013485 = 32 ;
    	a4442917 = (a1210910088 - -2);
    	a2026977784 = ((a4442917 + a4442917) - 3);
    	a30494462 = ((((((a30494462 * a217799639) % 14999) + -1559) * 1) + 3157) - 3743);
    	a983758263 = (((a983758263 + -15250) * 1) * 1);
    	a1180594800 = 32 ;
    	a2073482783 = 33 ;
    	a1644957382 = 32 ;
    	a1254983042 = ((((((a1254983042 * a1774184757) % 14999) + -13987) + -469) + 29450) + -21567);
    	a1210910088 = (a2087535773 + -3);
    	a1983740902 = 33 ;
    	a1521644128 = (a1916853335 - 2);
    	a1830659124 = ((a778006913 * a1249952537) + 3);
    	a341216798 = ((((((a983758263 * a983758263) % 14999) + 3613) * 1) + -32036) + 33849);
    	a708839806 = 32 ;
    	a1959068056 = ((a1895857334 - a786258498) + 7);
    	a1895304149 = 32 ;
    	a1151361287 = (((((a1151361287 * a999024345) % 14999) - 10141) + -9283) * 1);
    	a1241576728 = (a2061425267 - 4);
    	a786258498 = (a1916853335 + 1);
    	a999024345 = (((((a999024345 * a620105235) % 14999) - 13907) * 1) + -393);
    	a965340096 = 33 ;
    	a1916853335 = (a1830659124 - 4); 
    	 printf("%d\n", 17); fflush(stdout); 
    } 
}
 void calculate_outputm18(int input) {
    if(((a26346326 == 34 && (a2130193413 == 11 && ((371 < a1985899004) && (524 >= a1985899004)))) && (((( cf==1  && a1574467713 == 1) && a1241576728 == 8) && a263151501 == 34) && a1125477212 == 34))) {
    	if((((a1830659124 == 11 && a1478681170 == 5) && a1959068056 == 10) && (((124 < a30494462) && (296 >= a30494462)) && (a2026977784 == 9 && (a76745981 == 34 && ( cf==1  && a263638061 == 6)))))) {
    		calculate_outputm188(input);
    	} 
    	if(((((249 < a1151361287) && (291 >= a1151361287)) && (a1180594800 == 34 && a1830659124 == 11)) && ((((a263638061 == 11 &&  cf==1 ) && a1125477212 == 34) && a1916853335 == 7) && a263151501 == 34))) {
    		calculate_outputm190(input);
    	} 
    	if((((((104 < a813082108) && (243 >= a813082108)) && (a263638061 == 12 &&  cf==1 )) && ((35 < a1774184757) && (169 >= a1774184757))) && (((((-8 < a260539918) && (140 >= a260539918)) && a4442917 == 7) && a1830659124 == 11) && a302110279 == 34))) {
    		calculate_outputm191(input);
    	} 
    } 
    if((((((202 < a1254983042) && (414 >= a1254983042)) && (( cf==1  && a1574467713 == 3) && ((124 < a30494462) && (296 >= a30494462)))) && a1249952537 == 6) && ((((167 < a1018383389) && (211 >= a1018383389)) && a76745981 == 34) && ((230 < a2130183577) && (255 >= a2130183577))))) {
    	if(((((104 < a813082108) && (243 >= a813082108)) && (a4442917 == 7 && (( cf==1  && a1474668405 <=  -160) && a1125477212 == 34))) && (a786258498 == 10 && (a1318526106 == 34 && a708839806 == 34)))) {
    		calculate_outputm192(input);
    	} 
    	if((((((371 < a1985899004) && (524 >= a1985899004)) && (((-6 < a1474668405) && (87 >= a1474668405)) &&  cf==1 )) && a4442917 == 7) && ((a1210910088 == 3 && (a2087535773 == 5 && a1180594800 == 34)) && a601495656 == 34))) {
    		calculate_outputm194(input);
    	} 
    } 
    if(((a2061425267 == 12 && (a1318526106 == 34 && ((a1574467713 == 4 &&  cf==1 ) && a190525986 == 11))) && ((a1180594800 == 34 && a708839806 == 34) && a1211013485 == 34))) {
    	if((((( cf==1  && a1964635488 == 36) && a1249952537 == 6) && ((-81 < a1625516355) && (-5 >= a1625516355))) && (a1210910088 == 3 && (a2130193413 == 11 && (a2061425267 == 12 && ((249 < a1151361287) && (291 >= a1151361287))))))) {
    		calculate_outputm195(input);
    	} 
    } 
    if(((a263151501 == 34 && ((a2061425267 == 12 && a1211013485 == 34) && a601495656 == 34)) && (a1318526106 == 34 && ((a1574467713 == 6 &&  cf==1 ) && a778006913 == 3)))) {
    	if((((a1210910088 == 3 && (a2087535773 == 5 && ((35 < a1774184757) && (169 >= a1774184757)))) && ((-81 < a1625516355) && (-5 >= a1625516355))) && (a778006913 == 3 && (( cf==1  && ((-89 < a1569588614) && (73 >= a1569588614))) && ((-59 < a217799639) && (-1 >= a217799639)))))) {
    		calculate_outputm196(input);
    	} 
    	if((((((202 < a1254983042) && (414 >= a1254983042)) && a302110279 == 34) && a1125477212 == 34) && ((a190525986 == 11 && (a1830659124 == 11 && ( cf==1  && 167 < a1569588614))) && ((131 < a999024345) && (260 >= a999024345))))) {
    		calculate_outputm197(input);
    	} 
    } 
    if(((a1983740902 == 34 && (((-160 < a620105235) && (30 >= a620105235)) && (a1574467713 == 7 &&  cf==1 ))) && ((((167 < a1018383389) && (211 >= a1018383389)) && (a190525986 == 11 && a1916853335 == 7)) && a2061425267 == 12))) {
    	if((((( cf==1  && a620988906 == 32) && a2087535773 == 5) && a709568404 == 34) && (a786258498 == 10 && ((a601495656 == 34 && ((-160 < a620105235) && (30 >= a620105235))) && a190525986 == 11)))) {
    		calculate_outputm198(input);
    	} 
    	if((((( cf==1  && a620988906 == 33) && ((207 < a1675035970) && (311 >= a1675035970))) && a1249952537 == 6) && ((a2087535773 == 5 && (a190525986 == 11 && a709568404 == 34)) && ((249 < a1151361287) && (291 >= a1151361287))))) {
    		calculate_outputm199(input);
    	} 
    	if(((a1180594800 == 34 && (a2087535773 == 5 && (((35 < a1774184757) && (169 >= a1774184757)) && a2130193413 == 11))) && (((a620988906 == 34 &&  cf==1 ) && a1318526106 == 34) && ((371 < a1985899004) && (524 >= a1985899004))))) {
    		calculate_outputm200(input);
    	} 
    	if(((((35 < a1774184757) && (169 >= a1774184757)) && (a620988906 == 35 &&  cf==1 )) && ((((a1478681170 == 5 && a709568404 == 34) && a1180594800 == 34) && ((207 < a1675035970) && (311 >= a1675035970))) && ((29 < a63333937) && (243 >= a63333937))))) {
    		calculate_outputm201(input);
    	} 
    } 
    if(((a4442917 == 7 && ((((167 < a1018383389) && (211 >= a1018383389)) && ( cf==1  && a1574467713 == 8)) && a2026977784 == 9)) && (((249 < a1151361287) && (291 >= a1151361287)) && (((207 < a1675035970) && (311 >= a1675035970)) && a708839806 == 34)))) {
    	if((((a76745981 == 34 && (a1318526106 == 34 && (a965340096 == 34 &&  cf==1 ))) && a1830659124 == 11) && ((a1249952537 == 6 && ((202 < a1254983042) && (414 >= a1254983042))) && ((124 < a30494462) && (296 >= a30494462))))) {
    		calculate_outputm202(input);
    	} 
    	if((((((((207 < a1675035970) && (311 >= a1675035970)) && (a1210910088 == 3 && ( cf==1  && a965340096 == 35))) && a786258498 == 10) && ((249 < a1151361287) && (291 >= a1151361287))) && a4442917 == 7) && a1241576728 == 8)) {
    		calculate_outputm203(input);
    	} 
    } 
}
 void calculate_outputm205(int input) {
    if((a1959068056 == 10 && (a263151501 == 34 && (a302110279 == 34 && (((( cf==1  && (input == 2)) && a708839806 == 34) && a1644957382 == 34) && a2087535773 == 5))))) {
    	cf = 0;
    	a1826277115 = (((((((a983758263 * a983758263) % 14999) % 105) - 101) + -38) * 10) / 9);
    	a983758263 = ((((((a983758263 * a1826277115) % 14999) % 14796) + 15202) - -1) + 1);
    	a1180594800 = 33 ;
    	a1959068056 = a2026977784;
    	a1211013485 = 33 ;
    	a601495656 = 33 ;
    	a1942901885 = 33 ;
    	a1318526106 = 32 ;
    	a1625516355 = (((((((a983758263 * a30494462) % 14999) + 5825) % 37) - 74) - 5613) - -5629);
    	a260539918 = ((((((a1826277115 * a30494462) % 14999) * 2) / 5) % 73) + 65);
    	a1018383389 = ((((((a2130183577 * a1675035970) % 14999) % 21) + 190) + 11110) - 11112);
    	a30494462 = (((((((a30494462 * a983758263) % 14999) + 3205) * 1) / 5) % 92) + -16);
    	a2073482783 = 34 ;
    	a709568404 = 32 ;
    	a263219509 = (a1210910088 + 4);
    	a1151361287 = ((((((a813082108 * a1774184757) % 14999) % 20) + 253) - -25241) + -25232); 
    	 printf("%d\n", 19); fflush(stdout); 
    } if(((a709568404 == 34 && (a302110279 == 34 && (a1959068056 == 10 && (((207 < a1675035970) && (311 >= a1675035970)) && a1644957382 == 34)))) && (a4442917 == 7 && ((input == 15) &&  cf==1 )))) {
    	cf = 0;
    	a757937656 = (a1478681170 + 1);
    	a983758263 = (((((((a983758263 * a813082108) % 14999) / 5) % 104) + -5) - 29297) - -29305);
    	a1644957382 = 33 ;
    	a721272783 = (a190525986 - -4);
    	a2026977784 = (a721272783 - 7);
    	a1180594800 = 33 ;
    	a1241576728 = ((a4442917 + a757937656) + -6);
    	a786258498 = (a721272783 - 6);
    	a1210910088 = ((a2026977784 - a2061425267) + 6);
    	a1985899004 = ((((((a1985899004 * a999024345) % 14999) % 98) - -250) - 59) - -28);
    	a26346326 = 33 ;
    	a1895304149 = 33 ;
    	a1478681170 = (a1210910088 - -2);
    	a2097567994 = 32 ;
    	a30494462 = ((((((a30494462 * a1675035970) % 14999) % 92) - -33) + -43) + -51);
    	a1211013485 = 33 ;
    	a601495656 = 33 ;
    	a1675035970 = (((((((a1675035970 * a1018383389) % 14999) % 17) - -180) + -3) + 2896) - 2891); 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm206(int input) {
    if(((((a2087535773 == 5 && ((input == 4) &&  cf==1 )) && a4442917 == 7) && ((131 < a999024345) && (260 >= a999024345))) && ((((-8 < a260539918) && (140 >= a260539918)) && ((104 < a813082108) && (243 >= a813082108))) && a1318526106 == 34))) {
    	cf = 0;
    	a1830659124 = (a2061425267 + -2);
    	a2026977784 = ((a1478681170 + a1210910088) + 1);
    	a1249952537 = (a1895857334 + -7);
    	a76745981 = 33 ;
    	a1985899004 = ((((((a1985899004 * a1018383389) % 14999) % 98) + 244) - 15213) - -15225);
    	a2130193413 = (a1916853335 + 4);
    	a983758263 = ((((((a983758263 * a1254983042) % 14999) % 104) - 5) + 0) / 5);
    	a1959068056 = (a786258498 - 1);
    	a1474668405 = (((((((a260339255 * a983758263) % 14999) + 12896) + 1778) + 234) % 14920) + -15079);
    	a786258498 = (a4442917 - -3);
    	a1241576728 = ((a1959068056 * a1478681170) + -28);
    	a1644957382 = 34 ;
    	a1151361287 = (((((a983758263 * a1625516355) * 1) + 20258) % 20) + 269);
    	a1240243570 = (a2087535773 + 6);
    	a1180594800 = 34 ;
    	a721272783 = ((a190525986 * a1210910088) + -17);
    	a2087535773 = (a1830659124 + -5);
    	a1210910088 = (a190525986 - 9);
    	a4442917 = ((a1249952537 * a1916853335) - 23);
    	a26346326 = 33 ;
    	a999024345 = ((((((((a999024345 * a30494462) % 14999) % 41) - -79) + 9) / 5) * 29) / 10);
    	a1774184757 = (((((a1774184757 * a260539918) - -1476) + -14618) % 92) + -57);
    	a1895304149 = 33 ;
    	a30494462 = (((((((a30494462 * a813082108) % 14999) % 92) - -28) + -29) + 16375) - 16384);
    	a260539918 = (((((((a1985899004 * a1985899004) % 14999) - 23685) - -33630) / 5) % 73) - 5);
    	a263151501 = 34 ;
    	a813082108 = ((((((a813082108 * a217799639) % 50) + 86) * 10) / 9) / 5);
    	a601495656 = 34 ;
    	a2073482783 = 34 ;
    	a2061425267 = (a1249952537 + 6);
    	a1254983042 = ((((((a1474668405 * a2130183577) % 14999) % 105) - -308) / 5) + 196);
    	a217799639 = (((((((a983758263 * a983758263) % 14999) % 28) - 30) * 9) / 10) + 1);
    	a63333937 = ((((((((a1625516355 * a1675035970) % 106) - -216) * 10) / 9) * 5) % 106) - -113);
    	a1983740902 = 34 ;
    	a190525986 = (a778006913 + 8); 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm208(int input) {
    if((((((131 < a999024345) && (260 >= a999024345)) && (( cf==1  && (input == 2)) && ((35 < a1774184757) && (169 >= a1774184757)))) && a2130193413 == 11) && (a1211013485 == 34 && (((-59 < a217799639) && (-1 >= a217799639)) && a2073482783 == 34)))) {
    	cf = 0;
    	a813082108 = ((((((((a1985899004 * a1774184757) % 14999) % 69) - -123) * 5) + -10065) % 69) - -227);
    	a1942901885 = 33 ;
    	a601495656 = 33 ;
    	a1625516355 = ((((((((a30494462 * a813082108) % 14999) % 37) - 56) * 10) / 9) * 10) / 9);
    	a1895304149 = 34 ;
    	a1211013485 = 33 ;
    	a983758263 = (((((a983758263 * a2130183577) % 14999) - -14063) + -22473) + 20146);
    	a263219509 = (a786258498 - 3);
    	a4442917 = (a786258498 - 3);
    	a1959068056 = ((a1895857334 / a2061425267) - -8);
    	a1983740902 = 33 ;
    	a1180594800 = 33 ;
    	a30494462 = ((((((a30494462 * a63333937) % 14999) % 92) + 15) - -29326) - 29338);
    	a1826277115 = (((((((a983758263 * a983758263) % 14999) / 5) % 105) - 90) - -5311) - 5335); 
    	 printf("%d\n", 18); fflush(stdout); 
    } if((((((((35 < a1774184757) && (169 >= a1774184757)) && ((input == 6) &&  cf==1 )) && ((-8 < a260539918) && (140 >= a260539918))) && ((202 < a1254983042) && (414 >= a1254983042))) && a26346326 == 34) && (a76745981 == 34 && a263151501 == 34))) {
    	a156979206 -= (a156979206 - 20) < a156979206 ? 2 : 0;
    	a789762657 -= (a789762657 - 20) < a789762657 ? 3 : 0;
    	cf = 0;
    	a4442917 = (a1478681170 + 2);
    	a708839806 = 33 ;
    	a302110279 = 33 ;
    	a1895857334 = ((a190525986 / a1249952537) + 12);
    	a80157050 = (a1895857334 + -6);
    	a601495656 = 33 ;
    	a813082108 = ((((((a2130183577 * a1675035970) % 14999) % 69) + 106) - -3) - 2);
    	a2087632595 = 32 ;
    	a709568404 = 33 ;
    	a1895304149 = 34 ;
    	a1318526106 = 34 ;
    	a1983740902 = 33 ;
    	a1625516355 = (((((((a999024345 * a1018383389) % 14999) + 334) % 37) + -67) - 18336) + 18361); 
    	 printf("%d\n", 20); fflush(stdout); 
    } if(((a778006913 == 3 && ((input == 9) &&  cf==1 )) && (a1180594800 == 34 && (((a1959068056 == 10 && ((249 < a1151361287) && (291 >= a1151361287))) && ((167 < a1018383389) && (211 >= a1018383389))) && a2130193413 == 11)))) {
    	a1835250293 -= (a1835250293 - 20) < a1835250293 ? 2 : 0;
    	a1329406336 -= (a1329406336 - 20) < a1329406336 ? 6 : 0;
    	cf = 0;
    	a1318526106 = 34 ;
    	a983758263 = (((((((a983758263 * a1774184757) % 14999) + 3997) * 10) / 9) - 22348) + 25918);
    	a709568404 = 34 ;
    	a1895304149 = 34 ;
    	a1826277115 = ((((((((a999024345 * a1254983042) % 14999) % 62) - -85) * 10) / 9) - 4363) + 4375);
    	a1240243570 = (a778006913 - -4);
    	a601495656 = 34 ;
    	a965340096 = 33 ;
    	a4442917 = (a786258498 + -3); 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((((((131 < a999024345) && (260 >= a999024345)) && ((a2026977784 == 9 && (a1249952537 == 6 && ((input == 11) &&  cf==1 ))) && ((230 < a2130183577) && (255 >= a2130183577)))) && a1916853335 == 7) && a1241576728 == 8)) {
    	cf = 0;
    	a2026977784 = ((a1249952537 - a786258498) + 11);
    	a999024345 = (((((a1018383389 * a1018383389) % 14999) + -15962) - -9858) - 20426);
    	a63333937 = ((((((a63333937 * a999024345) % 14999) * 2) % 14932) + -15066) + -2);
    	a2130193413 = ((a190525986 * a778006913) + -24);
    	a834646264 = (a1916853335 + -2);
    	a2130183577 = (((((a1675035970 * a30494462) % 14999) - 11176) + -14280) - 2298);
    	a1180594800 = 32 ;
    	a1959068056 = (a2130193413 - 1);
    	a341216798 = (((((a983758263 * a983758263) % 14999) / 5) - 21977) - -2406);
    	a983758263 = (((((((a983758263 * a341216798) % 14999) / 5) / 5) - -23589) * -1) / 10);
    	a26346326 = 32 ;
    	a76745981 = 32 ;
    	a1241576728 = (a2026977784 + -1);
    	a30494462 = ((((((a30494462 * a2130183577) % 14999) / 5) - -23572) * 1) - 41167);
    	a778006913 = ((a786258498 - a1249952537) + -3);
    	a1254983042 = (((((a1254983042 * a63333937) % 14999) + -1795) + 9623) - 8396);
    	a1337636546 = (((((((a341216798 * a341216798) % 14999) % 14881) - -15117) - 16027) + 11310) - -4718);
    	a190525986 = (a4442917 + 4); 
    	 printf("%d\n", 19); fflush(stdout); 
    } 
}
 void calculate_outputm209(int input) {
    if((((a190525986 == 11 && ((a2087535773 == 5 && ((input == 7) &&  cf==1 )) && a786258498 == 10)) && a302110279 == 34) && (((131 < a999024345) && (260 >= a999024345)) && a1895304149 == 34))) {
    	cf = 0;
    	a813082108 = (((((a813082108 * a1774184757) % 14999) - 27236) * 1) + -1350);
    	a263151501 = 32 ;
    	a302110279 = 32 ;
    	a4442917 = (a1895857334 - 7);
    	a778006913 = (a1895857334 - 11);
    	a601495656 = 32 ;
    	a1959068056 = (a778006913 + 7);
    	a1241576728 = (a1478681170 + 1);
    	a1644957382 = 32 ;
    	a76745981 = 32 ;
    	a1625516355 = (((((a1018383389 * a1018383389) % 14999) - 27863) + -480) * 1);
    	a999024345 = (((((a999024345 * a2130183577) % 14999) / 5) - 11089) / 5);
    	a1895304149 = 32 ;
    	a2087535773 = (a190525986 + -8);
    	a30494462 = (((((a30494462 * a2130183577) % 14999) / 5) - 23135) - 6236);
    	a1125477212 = 32 ;
    	a260539918 = (((((a260539918 * a2130183577) % 14999) / 5) + -11158) - 15544);
    	a190525986 = ((a1916853335 + a1783229935) + -11);
    	a709568404 = 32 ;
    	a1151361287 = ((((a1774184757 * a1774184757) - 30366) - 400) + -430);
    	a1180594800 = 32 ;
    	a620105235 = (((((((a999024345 * a1774184757) % 14999) % 14909) + -15090) * 1) + 20879) + -20879);
    	a965340096 = 32 ;
    	a1830659124 = (a1895857334 + -3);
    	a786258498 = (a1241576728 + 2);
    	a1521644128 = (a1210910088 - -2);
    	a2026977784 = (a2130193413 + -2);
    	a63333937 = (((((a63333937 * a1625516355) % 14999) / 5) - 3631) - 22967);
    	a341216798 = ((((((a1774184757 * a983758263) % 14999) / 5) - 25994) * 10) / -9);
    	a26346326 = 32 ;
    	a1985899004 = (((((a1254983042 * a1151361287) % 14999) + -14967) + -14) - 14);
    	a983758263 = (((((a983758263 * a341216798) % 14999) - 28193) + 5581) - 310);
    	a1254983042 = ((((((a1254983042 * a1985899004) % 14999) - 15000) * 1) / 5) - 8642);
    	a2061425267 = (a1916853335 + 5);
    	a708839806 = 32 ;
    	a2130183577 = ((((((a1018383389 * a1774184757) % 14999) + 416) * 1) * 1) * -1);
    	a2073482783 = 32 ;
    	a1675035970 = ((((((a1675035970 * a620105235) % 14999) / 5) + -26473) - -44712) - 44470);
    	a1210910088 = ((a1521644128 - a1895857334) - -8);
    	a1774184757 = ((((((a1774184757 * a217799639) % 14999) + 29626) / 5) / 5) - 8371); 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((((input == 9) &&  cf==1 ) && a302110279 == 34) && ((((-160 < a620105235) && (30 >= a620105235)) && (((371 < a1985899004) && (524 >= a1985899004)) && (((167 < a1018383389) && (211 >= a1018383389)) && a26346326 == 34))) && a601495656 == 34))) {
    	cf = 0;
    	a620105235 = ((((((a260539918 * a30494462) % 14999) % 10) + -170) + 4955) + -4954);
    	a983758263 = (((((((a983758263 * a2130183577) % 14999) % 104) - 1) + 29764) - 27877) + -1802);
    	a1254983042 = ((((((a1254983042 * a620105235) % 14999) % 101) - -100) - -1) - 2);
    	a1345687529 = ((((((a1774184757 * a813082108) % 14999) + 11355) * 10) / 9) * 1);
    	a1478681170 = (a4442917 - 2);
    	a1210910088 = a778006913;
    	a26346326 = 33 ;
    	a999024345 = (((((((a999024345 * a2130183577) % 14999) + -18416) * 1) + 19680) % 41) + 75);
    	a302110279 = 33 ;
    	a1891437507 = 35 ;
    	a721272783 = (a1895857334 + 2);
    	a63333937 = (((((((a63333937 * a813082108) % 14999) - 1065) * 2) * 1) % 81) + -52);
    	a1675035970 = ((((((a1675035970 * a1345687529) % 14999) % 17) - -182) - 3) + -2);
    	a30494462 = (((((((a30494462 * a1625516355) % 14999) % 92) + 32) + -12398) + 41871) + -29473);
    	a1895304149 = 33 ;
    	a1018383389 = (((((((a1018383389 * a1151361287) % 14999) % 74) + 86) + 5) - 13481) + 13476);
    	a2130183577 = (((((((a1018383389 * a1985899004) % 14999) % 63) + 153) / 5) * 39) / 10);
    	a813082108 = ((((((a813082108 * a620105235) % 14999) / 5) / 5) % 50) + 54); 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((((104 < a813082108) && (243 >= a813082108)) && ((input == 15) &&  cf==1 )) && (a709568404 == 34 && ((a601495656 == 34 && (a1478681170 == 5 && ((29 < a63333937) && (243 >= a63333937)))) && a1210910088 == 3)))) {
    	cf = 0;
    	a1018383389 = (((((((a1985899004 * a1985899004) % 14999) / 5) % 74) - -93) * 9) / 10);
    	a1891437507 = 35 ;
    	a1254983042 = (((((((a1254983042 * a1018383389) % 14999) % 101) + -1) * 5) % 101) + 99);
    	a1210910088 = ((a190525986 + a190525986) + -20);
    	a302110279 = 33 ;
    	a1895304149 = 33 ;
    	a999024345 = ((((((a999024345 * a30494462) % 14999) - 12581) % 41) + 89) * 1);
    	a26346326 = 33 ;
    	a983758263 = (((((a983758263 / 5) * 9) / 10) - -17596) - 17547);
    	a2130183577 = ((((((a1018383389 * a813082108) % 14999) / 5) - 23316) % 63) + 185);
    	a30494462 = (((((((a30494462 * a1625516355) % 14999) + -11833) - -17670) - 18659) % 92) + 89);
    	a1675035970 = (((((((a1675035970 * a63333937) % 14999) % 17) - -189) - 26429) + 2897) + 23516);
    	a620105235 = ((((((((a620105235 * a1254983042) % 14999) % 10) + -170) * 5) * 5) % 10) + -167);
    	a1478681170 = (a2061425267 - 8);
    	a63333937 = ((((((a63333937 * a1151361287) % 14999) - -7758) % 81) + -69) + 7);
    	a721272783 = (a1241576728 + 6);
    	a813082108 = (((((((a813082108 * a2130183577) % 14999) + 6449) % 50) - -12) * 9) / 10);
    	a1345687529 = ((((((a983758263 * a983758263) % 14999) % 14962) - -15037) * 1) * 1); 
    	 printf("%d\n", 26); fflush(stdout); 
    } 
}
 void calculate_outputm211(int input) {
    if((((((-81 < a1625516355) && (-5 >= a1625516355)) && (( cf==1  && (input == 8)) && a1959068056 == 10)) && ((29 < a63333937) && (243 >= a63333937))) && ((a709568404 == 34 && ((-160 < a620105235) && (30 >= a620105235))) && a1211013485 == 34))) {
    	cf = 0;
    	a263151501 = 34 ;
    	a80157050 = (a2026977784 - 3);
    	a1644957382 = 34 ;
    	a1151361287 = ((((((((a1151361287 * a983758263) % 14999) - -5193) % 20) - -267) / 5) * 48) / 10);
    	a302110279 = 34 ;
    	a778006913 = (a1249952537 + -3);
    	a1125477212 = 34 ;
    	a1895857334 = (a1478681170 + 8);
    	a1211013485 = 34 ;
    	a1983740902 = 34 ;
    	a813082108 = (((((((a983758263 * a1018383389) % 14999) % 69) + 105) - -10418) / 5) + -1926);
    	a260539918 = (((((((a1018383389 * a1985899004) % 14999) % 73) + 53) * 10) / 9) / 5);
    	a1774184757 = ((((((a63333937 * a822442096) % 14999) % 92) + -73) + -77) + 0);
    	a708839806 = 34 ;
    	a620105235 = ((((((a620105235 * a1675035970) % 14999) % 94) + -63) + -1) - -1);
    	a2130183577 = ((((((a999024345 * a1625516355) + 21919) - 29679) * 1) % 12) + 251);
    	a2087632595 = 32 ;
    	a2026977784 = (a190525986 + -2); 
    	 printf("%d\n", 20); fflush(stdout); 
    } if(((a1644957382 == 34 && (a1180594800 == 34 && a1318526106 == 34)) && (a709568404 == 34 && (a2061425267 == 12 && (a1210910088 == 3 && ( cf==1  && (input == 15))))))) {
    	cf = 0;
    	a190525986 = ((a2026977784 / a2026977784) + 9);
    	a2130193413 = ((a1249952537 - a1249952537) - -10);
    	a1018383389 = ((((((((a813082108 * a813082108) % 74) - -92) * 9) / 10) * 5) % 74) + 45);
    	a778006913 = ((a1478681170 * a1210910088) + -12);
    	a1357285245 = (a1959068056 - 1);
    	a30494462 = ((((((a30494462 * a999024345) % 14999) / 5) % 92) + 9) - 67);
    	a1241576728 = (a2087535773 - -3);
    	a1644957382 = 33 ;
    	a1625516355 = (((((((a1018383389 * a260539918) % 13) + -92) + 6) / 5) * 49) / 10);
    	a1249952537 = (a2130193413 - 4);
    	a786258498 = ((a190525986 + a1210910088) + -4);
    	a1700231631 = (a1478681170 - -4);
    	a63333937 = ((((((a63333937 * a1985899004) % 14999) / 5) + 26877) % 81) - 64);
    	a4442917 = ((a2130193413 * a1210910088) - 24);
    	a1254983042 = ((((((a1254983042 * a260539918) * 1) + -1619) + 10074) % 101) + 101);
    	a263151501 = 33 ;
    	a302110279 = 34 ;
    	a2130183577 = (((((a822442096 * a260539918) % 12) + 252) - -2) + -11);
    	a721272783 = (a1916853335 + 10);
    	a1211013485 = 34 ;
    	a1125477212 = 34 ;
    	a983758263 = (((((((a983758263 * a822442096) % 14999) + 10496) + 1969) + -42356) % 104) + 144);
    	a1959068056 = (a1916853335 - -3);
    	a601495656 = 33 ;
    	a1318526106 = 33 ;
    	a1675035970 = ((((((((a1675035970 * a999024345) % 14999) % 17) - -184) * 1) * 5) % 17) + 173);
    	a709568404 = 33 ;
    	a1180594800 = 33 ;
    	a1983740902 = 34 ;
    	a1985899004 = ((((((a1985899004 * a1151361287) % 14999) % 76) - -426) / 5) + 312);
    	a708839806 = 33 ;
    	a1151361287 = (((((((a1151361287 * a1625516355) % 14999) % 86) + 163) / 5) + 12506) - 12316);
    	a2061425267 = ((a2130193413 - a1830659124) + 12);
    	a1916853335 = (a190525986 + -4);
    	a76745981 = 34 ;
    	a1478681170 = ((a1830659124 + a1830659124) + -18);
    	a26346326 = 33 ;
    	a1210910088 = (a2026977784 + -7);
    	a2073482783 = 33 ;
    	a1895304149 = 33 ;
    	a2087535773 = ((a2061425267 / a1895857334) + 4);
    	a2026977784 = (a1895857334 - 3);
    	a217799639 = ((((((a1774184757 * a620105235) % 69) + -127) * 5) % 69) - 59);
    	a999024345 = ((((((a999024345 * a620105235) % 14999) + 2222) % 41) + 90) + -1);
    	a1830659124 = (a1357285245 + 1);
    	a620105235 = (((((a620105235 * a260539918) / 5) % 94) + -65) - 1); 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm19(int input) {
    if(((a1180594800 == 34 && ((a1318526106 == 34 && a2026977784 == 9) && a1241576728 == 8)) && (a76745981 == 34 && (((-59 < a217799639) && (-1 >= a217799639)) && ( cf==1  && a2041520547 == 32))))) {
    	if(((a2061425267 == 12 && ((a601495656 == 34 && a1895304149 == 34) && a2087535773 == 5)) && (a1211013485 == 34 && (((-59 < a217799639) && (-1 >= a217799639)) && (a369798198 == 33 &&  cf==1 ))))) {
    		calculate_outputm205(input);
    	} 
    } 
    if(((a76745981 == 34 && (a2087535773 == 5 && (a2041520547 == 33 &&  cf==1 ))) && ((a2026977784 == 9 && (((-59 < a217799639) && (-1 >= a217799639)) && a1895304149 == 34)) && a2061425267 == 12))) {
    	if(((((167 < a1018383389) && (211 >= a1018383389)) && (a2130193413 == 11 && a1249952537 == 6)) && ((a2026977784 == 9 && (((35 < a1774184757) && (169 >= a1774184757)) && (248 < a260339255 &&  cf==1 ))) && a2073482783 == 34))) {
    		calculate_outputm206(input);
    	} 
    } 
    if((((((-8 < a260539918) && (140 >= a260539918)) && ((207 < a1675035970) && (311 >= a1675035970))) && a708839806 == 34) && (((a1125477212 == 34 && ( cf==1  && a2041520547 == 35)) && ((29 < a63333937) && (243 >= a63333937))) && a26346326 == 34))) {
    	if(((((35 < a1774184757) && (169 >= a1774184757)) && a76745981 == 34) && (((-8 < a260539918) && (140 >= a260539918)) && (((a786258498 == 10 && (a1783229935 == 9 &&  cf==1 )) && ((249 < a1151361287) && (291 >= a1151361287))) && a1983740902 == 34)))) {
    		calculate_outputm208(input);
    	} 
    	if(((a76745981 == 34 && ((( cf==1  && a1783229935 == 15) && a263151501 == 34) && a1210910088 == 3)) && (a601495656 == 34 && (((29 < a63333937) && (243 >= a63333937)) && a2026977784 == 9)))) {
    		calculate_outputm209(input);
    	} 
    } 
    if(((((249 < a1151361287) && (291 >= a1151361287)) && (a4442917 == 7 && ((207 < a1675035970) && (311 >= a1675035970)))) && (a263151501 == 34 && (a2087535773 == 5 && (( cf==1  && a2041520547 == 36) && a1241576728 == 8))))) {
    	if((((((207 < a1675035970) && (311 >= a1675035970)) && a708839806 == 34) && a1249952537 == 6) && ((a26346326 == 34 && (a601495656 == 34 && (((13 < a822442096) && (214 >= a822442096)) &&  cf==1 ))) && a709568404 == 34))) {
    		calculate_outputm211(input);
    	} 
    } 
}
 void calculate_outputm212(int input) {
    if((((a1959068056 == 10 && a1916853335 == 7) && ((202 < a1254983042) && (414 >= a1254983042))) && (((((input == 2) &&  cf==1 ) && a1241576728 == 8) && ((131 < a999024345) && (260 >= a999024345))) && a1895304149 == 34))) {
    	a789762657 -= (a789762657 - 20) < a789762657 ? 2 : 0;
    	cf = 0;
    	a620105235 = ((((((a63333937 * a30494462) % 14999) % 94) + -94) + 27469) - 27512);
    	a778006913 = ((a2087535773 / a1241576728) + 3);
    	a1774184757 = ((((((a999024345 * a217799639) % 92) - 43) + 16) + -5164) + 5185);
    	a813082108 = (((((((a30494462 * a30494462) % 14999) - -12940) % 69) - -117) * 10) / 9);
    	a302110279 = 34 ;
    	a1211013485 = 34 ;
    	a1644957382 = 34 ;
    	a2130183577 = ((((((a1254983042 * a1625516355) % 14999) % 12) - -242) - 0) * 1);
    	a708839806 = 34 ;
    	a1151361287 = ((((((a983758263 * a983758263) % 14999) % 20) + 259) * 5) / 5);
    	a263151501 = 34 ;
    	a1125477212 = 34 ;
    	a260539918 = ((((((a30494462 * a1675035970) % 14999) % 73) - 5) + -18434) + 18495);
    	a1983740902 = 34 ;
    	a2026977784 = (a1895857334 + -4); 
    	 printf("%d\n", 16); fflush(stdout); 
    } if(((a709568404 == 34 && a1210910088 == 3) && ((((124 < a30494462) && (296 >= a30494462)) && (a1249952537 == 6 && (( cf==1  && (input == 4)) && a76745981 == 34))) && a1959068056 == 10))) {
    	cf = 0;
    	a548050643 = 35 ;
    	a1125477212 = 34 ;
    	a983758263 = ((((((a983758263 * a63333937) % 14999) - 26631) * 1) * 1) - -37128);
    	a620105235 = ((((((((a1254983042 * a983758263) % 14999) - -12767) % 94) - 153) * 5) % 94) + -55);
    	a26346326 = 34 ;
    	a2130193413 = (a1478681170 - -6);
    	a404763935 = (a786258498 + 4);
    	a2061425267 = ((a1249952537 + a1830659124) - 5);
    	a1959068056 = ((a4442917 * a778006913) + -11);
    	a2073482783 = 34 ;
    	a30494462 = (((((((a30494462 * a1675035970) % 14999) - -2982) * 1) / 5) % 85) - -174);
    	a1211013485 = 34 ;
    	a601495656 = 34 ;
    	a1895304149 = 34 ;
    	a709568404 = 34 ;
    	a1318526106 = 34 ;
    	a1241576728 = (a404763935 - 6);
    	a1249952537 = a80157050;
    	a217799639 = (((((a217799639 * a813082108) / 5) / 5) % 28) - 3);
    	a1830659124 = (a778006913 + 8);
    	a1826277115 = (((((a983758263 * a983758263) % 14999) - 496) / 5) + 12452); 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((a1210910088 == 3 && ( cf==1  && (input == 6))) && ((a190525986 == 11 && (a1180594800 == 34 && (a2087535773 == 5 && ((371 < a1985899004) && (524 >= a1985899004))))) && ((167 < a1018383389) && (211 >= a1018383389))))) {
    	cf = 0;
    	a2061425267 = (a4442917 + 4);
    	a2073482783 = 33 ;
    	a1151361287 = (((((a217799639 * a217799639) * 5) % 86) - -88) - -16);
    	a1210910088 = ((a1249952537 / a80157050) + 1);
    	a30494462 = ((((((a30494462 * a1151361287) % 14999) % 92) + -21) / 5) / 5);
    	a26346326 = 33 ;
    	a1959068056 = (a1210910088 + 7);
    	a813082108 = ((((((a217799639 * a217799639) % 50) - -31) + 20) + -28803) - -28782);
    	a260539918 = ((((((a217799639 * a217799639) % 17) + -31) * 5) % 17) - 20);
    	a601495656 = 33 ;
    	a1318526106 = 33 ;
    	a1478681170 = (a786258498 - 6);
    	a1774184757 = ((((((a217799639 * a217799639) + -1643) * 5) + -11413) % 66) - -157);
    	a4442917 = (a1830659124 + -5);
    	a709568404 = 33 ;
    	a2130183577 = ((((((a217799639 * a217799639) - 17847) % 63) - -195) * 9) / 10);
    	a983758263 = (((((((a983758263 * a1625516355) % 14999) % 104) - -98) - -22452) - 7609) - 14842);
    	a1644957382 = 33 ;
    	a1254983042 = (((((a1254983042 * a260539918) - -21231) / 5) % 101) - 1);
    	a2087535773 = (a1895857334 - 9);
    	a721272783 = a786258498;
    	a63333937 = ((((((a63333937 * a2130183577) % 14999) + 3887) * 1) % 81) + -64);
    	a999024345 = (((((((a999024345 * a1018383389) % 14999) - -10656) * 1) * 1) % 41) + 52);
    	a1895304149 = 33 ;
    	a708839806 = 33 ;
    	a1675035970 = (((((((a1675035970 * a1985899004) % 14999) - -3643) % 17) - -178) - 19964) + 19958);
    	a1211013485 = 33 ;
    	a1348848030 = (a1916853335 - -7);
    	a1625516355 = (((((a813082108 * a63333937) / 5) / 5) % 13) + -95);
    	a803418896 = (((((((a983758263 * a983758263) % 14999) % 89) + -83) - -18228) * 1) + -18228);
    	a786258498 = ((a1959068056 + a190525986) + -11);
    	a190525986 = (a2130193413 + -1);
    	a1916853335 = a80157050; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((((a2061425267 == 12 && a2087535773 == 5) && ((-59 < a217799639) && (-1 >= a217799639))) && a601495656 == 34) && ((a76745981 == 34 && ( cf==1  && (input == 14))) && a1959068056 == 10))) {
    	cf = 0;
    	a822442096 = ((((((((a983758263 * a983758263) % 14999) % 100) - -53) - -5696) / 5) * 1) / 10);
    	a1895857334 = ((a4442917 * a1249952537) + -30);
    	a2041520547 = 36 ;
    	a260539918 = (((((((a1018383389 * a822442096) % 14999) % 17) + -28) * 10) / 9) + 1);
    	a813082108 = (((((((a63333937 * a620105235) % 14999) + -7364) % 50) - -53) + -20466) - -20467); 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm213(int input) {
    if(((a1211013485 == 34 && (a1180594800 == 34 && ((a2073482783 == 34 && ((input == 4) &&  cf==1 )) && ((29 < a63333937) && (243 >= a63333937))))) && (a1318526106 == 34 && ((-160 < a620105235) && (30 >= a620105235))))) {
    	cf = 0;
    	a2130193413 = (a1916853335 + 3);
    	a983758263 = (((((((a983758263 * a1774184757) % 14999) % 104) - -26) + -10397) * 2) + 20737);
    	a1151361287 = (((((((a1151361287 * a30494462) % 14999) % 86) + 86) / 5) * 59) / 10);
    	a1249952537 = (a1241576728 + -3);
    	a263151501 = 33 ;
    	a1774184757 = (((((((a30494462 * a30494462) % 14999) / 5) - -19704) / 5) % 92) - 79);
    	a721272783 = ((a2026977784 * a190525986) + -84);
    	a1241576728 = (a1830659124 + -4);
    	a1895304149 = 33 ;
    	a1018383389 = (((((((a1018383389 * a30494462) % 14999) % 74) + 20) + -1) * 10) / 9);
    	a1440713788 = ((((a1625516355 * a983758263) - -17732) * 1) - -1255);
    	a1180594800 = 33 ;
    	a190525986 = ((a778006913 / a786258498) - -10);
    	a2026977784 = (a1895857334 - 5);
    	a999024345 = ((((((a999024345 * a1254983042) % 14999) / 5) % 41) - -76) + -7);
    	a26346326 = 33 ;
    	a1675035970 = ((((((a1675035970 * a1254983042) % 14999) + 8665) - 8962) % 17) - -189);
    	a63333937 = (((((((a63333937 * a2130183577) % 14999) % 81) - 93) * 5) % 81) + 19);
    	a813082108 = ((((((a813082108 * a260539918) % 14999) + -4554) * 1) % 50) - -54);
    	a1210910088 = (a1830659124 + -9);
    	a2097567994 = 35 ;
    	a1625516355 = (((((((a2130183577 * a260539918) % 14999) % 13) - 94) * 5) % 13) + -91);
    	a2130183577 = ((((((a2130183577 * a260539918) % 14999) + 13266) / 5) % 63) - -166);
    	a1478681170 = (a1210910088 + 2);
    	a30494462 = ((((((a30494462 * a1151361287) % 14999) % 92) - -24) + 20667) - 20687); 
    	 printf("%d\n", 16); fflush(stdout); 
    } if(((a1211013485 == 34 && ((124 < a30494462) && (296 >= a30494462))) && (a1916853335 == 7 && ((a1210910088 == 3 && (((input == 7) &&  cf==1 ) && ((131 < a999024345) && (260 >= a999024345)))) && ((230 < a2130183577) && (255 >= a2130183577)))))) {
    	a1761958712 += (a1761958712 + 20) > a1761958712 ? 6 : 0;
    	a1054543477 -= (a1054543477 - 20) < a1054543477 ? 4 : 0;
    	cf = 0;
    	a965340096 = 33 ;
    	a302110279 = 34 ;
    	a1240243570 = ((a2130193413 * a1478681170) - 48);
    	a708839806 = 34 ;
    	a709568404 = 34 ;
    	a1826277115 = ((((((((a1254983042 * a999024345) % 14999) % 62) - -106) * 9) / 10) + 23907) + -23883);
    	a1983740902 = 34 ;
    	a601495656 = 34 ;
    	a813082108 = ((((((((a813082108 * a1254983042) % 14999) % 50) - -43) * 10) / 9) + 25397) + -25400);
    	a983758263 = (((((((a983758263 * a1826277115) % 14999) - -561) * 10) / 9) - 11830) + 17991);
    	a1625516355 = ((((((a1625516355 * a260539918) % 13) - 94) * 1) + -10125) + 10125); 
    	 printf("%d\n", 19); fflush(stdout); 
    } if(((((a1895304149 == 34 && a778006913 == 3) && a263151501 == 34) && a1241576728 == 8) && ((((104 < a813082108) && (243 >= a813082108)) && ((input == 12) &&  cf==1 )) && a4442917 == 7))) {
    	cf = 0;
    	a983758263 = (((a983758263 - -8390) * 3) / 5);
    	a302110279 = 32 ;
    	a1521644128 = ((a1249952537 * a2087535773) - 23);
    	a708839806 = 34 ;
    	a1254983042 = ((((((a1254983042 * a1018383389) % 14999) % 101) - 1) + 0) - 0);
    	a1830659124 = (a1895857334 - 3);
    	a1151361287 = ((((((a1151361287 * a620105235) % 14999) + -5881) / 5) % 86) - -163);
    	a709568404 = 34 ;
    	a1249952537 = ((a1959068056 / a190525986) - -5);
    	a1826277115 = ((((((a983758263 * a983758263) % 14999) - -4060) % 62) + 90) - -9);
    	a601495656 = 34 ;
    	a1625516355 = (((((a1625516355 * a1018383389) % 13) + -95) - 21677) - -21676);
    	a620105235 = ((((((a1985899004 * a813082108) % 14999) / 5) % 10) - 178) + 1);
    	a1774184757 = ((((((a1774184757 * a983758263) % 14999) - 2317) - 18535) + 9458) - 15293);
    	a2061425267 = ((a1916853335 - a778006913) - -7);
    	a965340096 = 32 ;
    	a2087535773 = (a778006913 + 1);
    	a190525986 = (a1521644128 + 3); 
    	 printf("%d\n", 16); fflush(stdout); 
    } 
}
 void calculate_outputm214(int input) {
    if(((((207 < a1675035970) && (311 >= a1675035970)) && (a76745981 == 34 && (a1959068056 == 10 && ((input == 5) &&  cf==1 )))) && ((a263151501 == 34 && ((35 < a1774184757) && (169 >= a1774184757))) && a1644957382 == 34))) {
    	cf = 0;
    	a260539918 = ((((((((a266166646 * a2130183577) % 14999) % 73) + 67) * 5) + 3504) % 73) - -38);
    	a2004613952 = ((a1249952537 - a1241576728) + 11);
    	a1625516355 = (((((((a983758263 * a1254983042) % 14999) % 37) - 59) - -18) * 10) / 9);
    	a1675035970 = ((((((a1675035970 * a1625516355) % 51) + 271) + 24) / 5) + 187);
    	a1210910088 = (a1478681170 - 2);
    	a708839806 = 34 ;
    	a302110279 = 34 ;
    	a1644957382 = 34 ;
    	a1151361287 = (((((a1625516355 * a813082108) * 1) + 23606) % 20) - -257);
    	a1180594800 = 34 ;
    	a1985899004 = (((((a217799639 * a983758263) / 5) / 5) % 76) - -501);
    	a1211013485 = 34 ;
    	a1337636546 = (((((((a266166646 * a983758263) % 14999) + 1109) * 1) + -5703) % 14881) + 15117);
    	a813082108 = ((((((((a217799639 * a266166646) % 14999) + 8153) % 69) - -173) * 5) % 69) - -127);
    	a2130183577 = ((((((a2130183577 * a30494462) % 14999) % 12) + 231) - -6) * 1);
    	a1895857334 = (a2004613952 + -2); 
    	 printf("%d\n", 17); fflush(stdout); 
    } if(((((a1249952537 == 6 && (a190525986 == 11 && (((104 < a813082108) && (243 >= a813082108)) && ((-59 < a217799639) && (-1 >= a217799639))))) && a1644957382 == 34) && ((207 < a1675035970) && (311 >= a1675035970))) && ( cf==1  && (input == 6)))) {
    	cf = 0;
    	a1241576728 = ((a1895857334 + a1249952537) + -13);
    	a263151501 = 34 ;
    	a2130183577 = ((((((a2130183577 * a999024345) % 14999) + 2485) % 12) - -232) - 1);
    	a1983740902 = 34 ;
    	a1644957382 = 34 ;
    	a983758263 = ((((((a983758263 * a813082108) % 14999) + -26411) - -14636) / 5) + -5567);
    	a786258498 = (a4442917 + 1);
    	a2073482783 = 34 ;
    	a30494462 = (((((a30494462 * a260539918) % 14999) - 9323) / 5) * 5);
    	a813082108 = (((((((a813082108 * a1774184757) % 14999) - 7510) - 11730) - 5623) % 69) + 219);
    	a2061425267 = (a1210910088 - -7);
    	a778006913 = (a1241576728 + -5);
    	a2130193413 = (a786258498 - -1);
    	a104481388 = ((a4442917 / a1959068056) + 10);
    	a217799639 = (((((((a217799639 * a266166646) % 14999) % 14901) - 15098) / 5) / 5) + -8865);
    	a1774184757 = (((((a1774184757 * a1254983042) % 14999) - 23883) * 1) * 1);
    	a76745981 = 32 ;
    	a1305578599 = 33 ;
    	a341216798 = (((((((a983758263 * a983758263) % 14999) % 18) - -200) + -1) / 5) - -173);
    	a26346326 = 32 ;
    	a1675035970 = ((((((a1675035970 * a1985899004) % 14999) * 2) % 51) - -260) - -1);
    	a1254983042 = (((((a1254983042 * a1018383389) % 14999) / 5) + -6036) + -17577);
    	a620105235 = ((((((a260539918 * a1985899004) % 14999) % 94) + -65) - 1) - 0);
    	a1959068056 = (a1830659124 - 3);
    	a2026977784 = ((a1916853335 - a190525986) + 11);
    	a63333937 = ((((((a1985899004 * a1985899004) % 14999) % 106) - -136) / 5) + 181);
    	a1249952537 = ((a1241576728 * a1241576728) - 30);
    	a1830659124 = (a1478681170 + 6);
    	a999024345 = ((((((a999024345 * a1625516355) % 14999) + -6946) * 1) + 29816) * -1);
    	a1916853335 = (a1241576728 - -1);
    	a4442917 = a1478681170;
    	a190525986 = (a1241576728 - -5);
    	a1210910088 = (a1478681170 - 2);
    	a1478681170 = (a2087535773 + -2);
    	a2087535773 = (a1241576728 - 1); 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a786258498 == 10 && ((a1478681170 == 5 && a4442917 == 7) && a2061425267 == 12)) && ((a263151501 == 34 && ((input == 7) &&  cf==1 )) && ((124 < a30494462) && (296 >= a30494462))))) {
    	cf = 0;
    	a1125477212 = 34 ;
    	a63333937 = (((((((a2130183577 * a1675035970) % 14999) - -3681) - 17820) / 5) % 81) - 53);
    	a813082108 = (((((((a813082108 * a983758263) % 14999) % 50) - -45) * 5) % 50) + 44);
    	a302110279 = 34 ;
    	a1211013485 = 34 ;
    	a2004613952 = a1916853335;
    	a1357285245 = (a2130193413 - 3);
    	a1985899004 = (((((((a30494462 * a1774184757) % 14999) % 76) + 445) - -4) / 5) + 386);
    	a1895857334 = ((a2087535773 - a2004613952) - -9);
    	a1018383389 = (((((((a266166646 * a217799639) % 14999) / 5) + -20123) - -27129) % 74) + 68);
    	a1318526106 = 34 ;
    	a709568404 = 34 ;
    	a1210910088 = (a190525986 + -9);
    	a1895304149 = 33 ;
    	a26346326 = 33 ;
    	a1625516355 = (((((((a2130183577 * a2130183577) % 14999) % 37) + -74) - 3) - -1462) - 1458);
    	a2130183577 = ((((((a2130183577 * a983758263) % 14999) % 63) + 117) / 5) - -143);
    	a1151361287 = ((((((a266166646 * a217799639) % 14999) % 86) + 161) + 29577) - 29575);
    	a4442917 = ((a1241576728 - a2061425267) + 10); 
    	 printf("%d\n", 18); fflush(stdout); 
    } 
}
 void calculate_outputm215(int input) {
    if(((a1959068056 == 10 && (( cf==1  && (input == 8)) && a2026977784 == 9)) && (((a2061425267 == 12 && ((-81 < a1625516355) && (-5 >= a1625516355))) && a1180594800 == 34) && ((124 < a30494462) && (296 >= a30494462))))) {
    	cf = 0;
    	a813082108 = (((((a813082108 * a1625516355) * 10) / 9) / 5) * 5);
    	a2087535773 = (a1249952537 + -3);
    	a2130183577 = (((((a260539918 * a1254983042) % 14999) + -14977) - 5) - 8);
    	a263151501 = 32 ;
    	a983758263 = (((((a983758263 * a266166646) % 14999) - 25733) + -2152) - 1968);
    	a341216798 = (((((a983758263 * a266166646) % 14999) / 5) + 27873) / 5);
    	a1521644128 = (a2130193413 + -7);
    	a190525986 = (a1249952537 - -5);
    	a1151361287 = (((((a1151361287 * a813082108) % 14999) + -14924) + -76) * 1);
    	a1478681170 = a778006913;
    	a1550739565 = ((a1830659124 * a4442917) + -71);
    	a302110279 = 32 ;
    	a1983740902 = 32 ;
    	a30494462 = ((((((a30494462 * a1018383389) % 14999) - 23377) - 3449) * 10) / 9);
    	a217799639 = ((((((a217799639 * a620105235) * 3) % 14901) - 15098) + 18866) + -18866);
    	a999024345 = ((((((a999024345 * a1625516355) * 10) / 9) * 10) / 9) * 1);
    	a1675035970 = (((((a1625516355 * a2130183577) % 14999) - 14857) - 108) - 2);
    	a601495656 = 32 ;
    	a2026977784 = ((a1241576728 - a2087535773) - -2);
    	a2073482783 = 32 ;
    	a1895304149 = 32 ;
    	a1241576728 = ((a2061425267 + a2061425267) - 18);
    	a1180594800 = 32 ;
    	a76745981 = 32 ;
    	a1916853335 = (a778006913 + 2);
    	a1644957382 = 34 ;
    	a709568404 = 32 ;
    	a1774184757 = (((((a1625516355 * a1625516355) - -10489) * 1) * 10) / -9);
    	a1211013485 = 32 ;
    	a786258498 = ((a778006913 - a2130193413) - -16);
    	a4442917 = (a1210910088 + 2);
    	a1125477212 = 32 ;
    	a778006913 = (a2026977784 + -6);
    	a2130193413 = (a1959068056 + -1);
    	a1625516355 = ((((((a1625516355 * a983758263) % 14999) - 25272) - 1464) * 10) / 9); 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((((a709568404 == 34 && a1916853335 == 7) && ((-8 < a260539918) && (140 >= a260539918))) && a1318526106 == 34) && ((( cf==1  && (input == 13)) && ((104 < a813082108) && (243 >= a813082108))) && a2073482783 == 34))) {
    	cf = 0;
    	a1348848030 = (a2026977784 - -5);
    	a1210910088 = (a1478681170 + -3);
    	a709568404 = 33 ;
    	a2061425267 = ((a1348848030 / a786258498) - -10);
    	a26346326 = 33 ;
    	a1125477212 = 34 ;
    	a1254983042 = (((((((a1254983042 * a1018383389) % 14999) - 20761) - -22468) + 2239) % 101) - 1);
    	a30494462 = ((((((a30494462 * a1018383389) % 14999) % 92) - 60) / 5) + 115);
    	a1983740902 = 34 ;
    	a2073482783 = 33 ;
    	a983758263 = (((((((a983758263 * a266166646) % 14999) % 104) + -1) + -9481) + 3649) - -5886);
    	a999024345 = ((((((a999024345 * a1675035970) % 14999) % 41) + 73) + 15) - 38);
    	a708839806 = 33 ;
    	a721272783 = (a1241576728 - -2);
    	a1916853335 = ((a2130193413 - a190525986) - -5);
    	a1318526106 = 33 ;
    	a260539918 = ((((((((a1254983042 * a1675035970) % 14999) % 17) + -26) - 1) / 5) * 49) / 10);
    	a803418896 = ((((((a1625516355 * a63333937) % 89) + -30) + 28) * 9) / 10);
    	a4442917 = ((a2087535773 * a1210910088) + -2);
    	a302110279 = 34 ;
    	a1895304149 = 33 ;
    	a1151361287 = ((((((a1151361287 * a2130183577) % 14999) - -4798) / 5) % 86) + 83);
    	a1774184757 = (((((((a813082108 * a217799639) % 66) + 157) * 9) / 10) * 10) / 9);
    	a63333937 = ((((((a620105235 * a620105235) + -19570) % 81) + -53) + 1970) - 1969);
    	a1625516355 = (((((((a260539918 * a1254983042) % 13) - 94) - -1) * 5) % 13) - 87);
    	a1959068056 = ((a1916853335 - a1478681170) - -8);
    	a786258498 = ((a1830659124 * a1210910088) + -13);
    	a813082108 = ((((((a813082108 * a217799639) % 50) - -76) + 23551) + 1408) - 24935);
    	a1478681170 = ((a721272783 * a2087535773) - 36); 
    	 printf("%d\n", 16); fflush(stdout); 
    } if((((a1241576728 == 8 && (((input == 14) &&  cf==1 ) && a1916853335 == 7)) && a709568404 == 34) && (a1895304149 == 34 && (((249 < a1151361287) && (291 >= a1151361287)) && ((-160 < a620105235) && (30 >= a620105235)))))) {
    	cf = 0;
    	a721272783 = (a1241576728 + 9);
    	a63333937 = ((((((((a63333937 * a2130183577) % 14999) % 81) - 72) + -1) * 5) % 81) - 52);
    	a369798198 = 34 ;
    	a1210910088 = (a778006913 - 1);
    	a983758263 = ((((((a983758263 * a266166646) % 14999) % 104) - 1) + 20863) + -20864);
    	a1916853335 = (a786258498 - 4);
    	a813082108 = (((((((a813082108 * a266166646) % 14999) - 2649) + 8929) + -12467) % 50) + 54);
    	a217799639 = ((((((a217799639 * a266166646) % 69) + -72) * 5) % 69) + -97);
    	a1830659124 = a1959068056;
    	a1151361287 = (((((((a1675035970 * a1018383389) % 14999) - -8273) % 86) + 92) + 7206) - 7205);
    	a2026977784 = (a2130193413 - 3);
    	a1700231631 = (a778006913 - -3);
    	a709568404 = 33 ;
    	a76745981 = 33 ;
    	a30494462 = ((((((a30494462 * a1254983042) % 14999) - 20289) + 5321) % 92) - -32);
    	a999024345 = ((((((((a999024345 * a1625516355) % 41) + 103) * 9) / 10) * 5) % 41) - -68);
    	a26346326 = 33 ;
    	a1249952537 = ((a721272783 * a1478681170) - 80);
    	a786258498 = (a2026977784 + 1);
    	a620105235 = ((((((a620105235 * a1625516355) % 10) + -169) - -26032) + 2402) - 28435);
    	a1895304149 = 33 ;
    	a1254983042 = ((((((((a1254983042 * a1018383389) % 14999) % 101) - 1) * 5) - -12647) % 101) + 83);
    	a2073482783 = 33 ;
    	a1625516355 = (((((a1625516355 * a1151361287) % 13) - 82) * 5) / 5); 
    	 printf("%d\n", 17); fflush(stdout); 
    } 
}
 void calculate_outputm216(int input) {
    if((((a1180594800 == 34 && ((167 < a1018383389) && (211 >= a1018383389))) && ((124 < a30494462) && (296 >= a30494462))) && ((a302110279 == 34 && (((input == 12) &&  cf==1 ) && ((371 < a1985899004) && (524 >= a1985899004)))) && a1959068056 == 10))) {
    	cf = 0;
    	a404763935 = ((a1249952537 + a1916853335) + 1);
    	a1826277115 = (((((a813082108 * a1254983042) % 14999) - -7412) / 5) + 16357);
    	a217799639 = (((((a217799639 * a260539918) + 11773) % 28) + -36) - 13);
    	a1249952537 = (a1478681170 - -1);
    	a1895304149 = 34 ;
    	a1241576728 = (a786258498 - 2);
    	a2073482783 = 34 ;
    	a983758263 = (((((a983758263 * a1985899004) % 14999) - -12109) + 185) * 1);
    	a548050643 = 35 ;
    	a1318526106 = 34 ;
    	a620105235 = (((((((a30494462 * a1018383389) % 14999) % 94) + -114) - -29209) - -255) + -29452);
    	a26346326 = 34 ;
    	a601495656 = 34 ;
    	a1125477212 = 34 ;
    	a1830659124 = ((a190525986 - a1959068056) + 10);
    	a2061425267 = ((a404763935 / a2087535773) + 10);
    	a30494462 = ((((((a30494462 * a1151361287) % 14999) - -5313) * 1) % 85) - -146);
    	a2130193413 = ((a1478681170 / a2026977784) - -11);
    	a1211013485 = 34 ;
    	a709568404 = 34 ;
    	a1959068056 = (a190525986 + -1); 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((((((29 < a63333937) && (243 >= a63333937)) && ((-81 < a1625516355) && (-5 >= a1625516355))) && a1211013485 == 34) && a2026977784 == 9) && (a778006913 == 3 && (((230 < a2130183577) && (255 >= a2130183577)) && ( cf==1  && (input == 14)))))) {
    	cf = 0;
    	a983758263 = ((((((a983758263 * a266166646) % 14999) + -23700) - -30961) + -28927) - -32712);
    	a1826277115 = ((((((a983758263 * a983758263) % 14999) % 105) + -63) - -10) + 1);
    	a76745981 = 32 ;
    	a1912617323 = (a1895857334 + 1);
    	a263219509 = (a2026977784 + -4); 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((((((167 < a1018383389) && (211 >= a1018383389)) && (((230 < a2130183577) && (255 >= a2130183577)) && ((-59 < a217799639) && (-1 >= a217799639)))) && ((202 < a1254983042) && (414 >= a1254983042))) && a708839806 == 34) && (a601495656 == 34 && ((input == 3) &&  cf==1 )))) {
    	cf = 0;
    	a341216798 = ((((((a999024345 * a1774184757) % 14999) - 6932) * 3) % 31) - -267);
    	a965340096 = 34 ;
    	a1826277115 = (((((((a266166646 * a63333937) % 14999) % 62) - -54) - 0) - -11545) - 11499);
    	a983758263 = (((((a983758263 * a1774184757) % 14999) + 5776) - -3573) + 427); 
    	 printf("%d\n", 18); fflush(stdout); 
    } 
}
 void calculate_outputm217(int input) {
    if(((((29 < a63333937) && (243 >= a63333937)) && ((a76745981 == 34 && (a1241576728 == 8 && a2130193413 == 11)) && a1830659124 == 11)) && (a1983740902 == 34 && ( cf==1  && (input == 15))))) {
    	a295012665 += (a295012665 + 20) > a295012665 ? 4 : 0;
    	cf = 0;
    	a1345687529 = ((((a1625516355 * a813082108) + 23331) - -2433) + 2886);
    	a999024345 = ((((((a1018383389 * a1018383389) % 41) + 61) * 9) / 10) - -28);
    	a4442917 = (a1830659124 + -5);
    	a813082108 = ((((((a1018383389 * a1625516355) % 50) - -98) * 9) / 10) - 26);
    	a1675035970 = (((((((a1675035970 * a999024345) % 14999) % 17) - -180) - 8036) + 18548) - 10517);
    	a1254983042 = ((((((a1254983042 * a983758263) % 14999) % 101) + -1) + 94) - 46);
    	a63333937 = ((((((a1151361287 * a1625516355) / 5) % 81) - -28) + -20170) + 20168);
    	a30494462 = (((((((a30494462 * a63333937) % 14999) - 2802) * 1) / 5) % 92) - -30);
    	a26346326 = 33 ;
    	a721272783 = (a1478681170 - -9);
    	a2130183577 = (((((((a2130183577 * a63333937) % 14999) % 63) - -167) - -19621) * 1) + -19621);
    	a1478681170 = (a1210910088 + 2);
    	a2073482783 = 33 ;
    	a983758263 = (((((((a983758263 * a1774184757) % 14999) + 13750) * 1) * 1) % 104) - -71);
    	a1891437507 = 35 ;
    	a1625516355 = ((((((a1625516355 * a1254983042) % 13) + -95) - -19132) + -39050) + 19917); 
    	 printf("%d\n", 26); fflush(stdout); 
    } 
}
 void calculate_outputm219(int input) {
    if(((a778006913 == 3 && (a1916853335 == 7 && (a1241576728 == 8 && a190525986 == 11))) && (a1830659124 == 11 && (( cf==1  && (input == 4)) && a1478681170 == 5)))) {
    	cf = 0;
    	a1249952537 = (a1916853335 - 1);
    	a709568404 = 34 ;
    	a2061425267 = ((a1830659124 / a2026977784) + 11);
    	a1826277115 = (((((a983758263 * a983758263) % 14999) - -4720) + 9192) * 1);
    	a1830659124 = (a1916853335 - -4);
    	a30494462 = ((((((a30494462 * a2130183577) % 14999) % 85) - -144) + 15376) + -15330);
    	a404763935 = ((a778006913 + a1210910088) - -8);
    	a26346326 = 34 ;
    	a983758263 = (((((a983758263 * a2130183577) % 14999) - -8595) + 2157) + 2020);
    	a1241576728 = ((a1478681170 - a1959068056) - -13);
    	a1959068056 = (a2026977784 - -1);
    	a601495656 = 34 ;
    	a1211013485 = 34 ;
    	a1318526106 = 34 ;
    	a2073482783 = 34 ;
    	a1895304149 = 34 ;
    	a620105235 = ((((((a620105235 * a217799639) % 94) + -64) + 1) - 22761) - -22760);
    	a2130193413 = ((a1895857334 / a778006913) + 7);
    	a1125477212 = 34 ;
    	a548050643 = 35 ;
    	a217799639 = (((((a217799639 * a813082108) % 28) + -13) + 11) + 1); 
    	 printf("%d\n", 16); fflush(stdout); 
    } if((((((131 < a999024345) && (260 >= a999024345)) && (a2061425267 == 12 && a190525986 == 11)) && a1830659124 == 11) && ((a263151501 == 34 && ( cf==1  && (input == 6))) && a786258498 == 10))) {
    	cf = 0;
    	a341216798 = (((((a1254983042 * a1254983042) % 14999) + 2713) * 1) - -1490);
    	a1241576728 = ((a1210910088 - a1875686186) - -16);
    	a1211013485 = 32 ;
    	a1521644128 = ((a4442917 - a1916853335) - -5);
    	a786258498 = ((a1959068056 * a2061425267) + -112);
    	a999024345 = (((((a1254983042 * a1254983042) % 14999) - 7669) + 20897) + -32770);
    	a601495656 = 32 ;
    	a1959068056 = ((a2087535773 / a190525986) + 8);
    	a1151361287 = ((((((a1151361287 * a813082108) % 14999) + -22347) * 10) / 9) - 2707);
    	a983758263 = (((((a983758263 * a1774184757) % 14999) - 17298) * 1) / 5);
    	a1675035970 = ((((((a1151361287 * a999024345) % 14999) - 11374) * 1) / 5) - 10056);
    	a1180594800 = 32 ;
    	a1830659124 = (a1249952537 + 3);
    	a813082108 = (((((a813082108 * a1675035970) % 14999) - 14998) + -4) - 0);
    	a2130183577 = (((((a2130183577 * a1151361287) % 14999) + -14929) - 60) * 1);
    	a620105235 = ((((((a341216798 * a341216798) % 14999) - -1042) * 10) / -9) - 7795);
    	a1644957382 = 32 ;
    	a1125477212 = 32 ;
    	a1774184757 = (((((((a30494462 * a1151361287) % 14999) + -6307) - 3181) + 7073) % 14924) - 15074);
    	a1210910088 = (a1875686186 + -12);
    	a4442917 = (a1895857334 - 8);
    	a260539918 = ((((((a1985899004 * a1675035970) % 14999) % 14978) + -15021) - 2) + 0);
    	a2061425267 = (a1241576728 - -4);
    	a1985899004 = (((((a620105235 * a983758263) % 14999) - 19102) - -27636) / -5);
    	a709568404 = 32 ;
    	a2087535773 = (a1478681170 + -2);
    	a263151501 = 32 ;
    	a1983740902 = 33 ;
    	a2073482783 = 32 ;
    	a190525986 = (a778006913 + 6);
    	a76745981 = 32 ;
    	a965340096 = 32 ;
    	a63333937 = ((((((a1675035970 * a30494462) % 14999) / 5) * 5) % 14932) + -15066);
    	a2130193413 = (a1249952537 - -3);
    	a26346326 = 32 ;
    	a778006913 = (a1241576728 + -5);
    	a30494462 = ((((((a1254983042 * a341216798) % 14999) - -1385) + -17250) * 10) / 9);
    	a1895304149 = 32 ;
    	a2026977784 = a1916853335;
    	a1625516355 = (((((a1254983042 * a1254983042) % 14999) - -5494) + -33021) - 99);
    	a1249952537 = (a2026977784 + -3);
    	a1254983042 = ((((a1254983042 * a217799639) / 5) / 5) * 5);
    	a302110279 = 32 ;
    	a217799639 = ((((((a341216798 * a341216798) % 14999) + -14948) * 2) % 14901) - 15098);
    	a708839806 = 32 ;
    	a1916853335 = (a1875686186 - 8); 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((a2087535773 == 5 && (((207 < a1675035970) && (311 >= a1675035970)) && (((input == 8) &&  cf==1 ) && ((-59 < a217799639) && (-1 >= a217799639))))) && (a2061425267 == 12 && (a1916853335 == 7 && a709568404 == 34)))) {
    	cf = 0;
    	a778006913 = ((a2026977784 * a2087535773) + -42);
    	a709568404 = 34 ;
    	a1249952537 = (a1478681170 + 1);
    	a1625516355 = (((((((a620105235 * a1254983042) % 14999) % 37) - 41) * 1) / 5) + -6);
    	a260539918 = ((((((a30494462 * a813082108) % 14999) / 5) % 73) + -4) / 5);
    	a620105235 = ((((((a620105235 * a983758263) % 14999) % 94) + -65) + -19433) + 19433);
    	a708839806 = 34 ;
    	a1318526106 = 34 ;
    	a1983740902 = 34 ;
    	a1895857334 = (a1210910088 + 8);
    	a302110279 = 34 ;
    	a263638061 = ((a2026977784 * a2026977784) + -70);
    	a1574467713 = ((a2026977784 * a263638061) - 98);
    	a813082108 = (((((((a813082108 * a1151361287) % 14999) / 5) % 69) + 121) * 10) / 9);
    	a190525986 = (a1959068056 + 1);
    	a1478681170 = (a2026977784 + -4);
    	a1210910088 = (a786258498 + -7);
    	a63333937 = ((((((a1151361287 * a1774184757) % 14999) / 5) + -19552) % 106) - -225);
    	a2026977784 = (a4442917 + 2); 
    	 printf("%d\n", 20); fflush(stdout); 
    } if(((((-160 < a620105235) && (30 >= a620105235)) && a786258498 == 10) && (a709568404 == 34 && (((371 < a1985899004) && (524 >= a1985899004)) && ((( cf==1  && (input == 9)) && ((230 < a2130183577) && (255 >= a2130183577))) && a708839806 == 34))))) {
    	cf = 0;
    	a1211013485 = 32 ;
    	a999024345 = (((((a999024345 * a217799639) + -3220) - 4594) - -24669) - 26515);
    	a4442917 = ((a1249952537 / a2061425267) + 5);
    	a983758263 = ((((a983758263 + 14228) / 5) * -1) / 10);
    	a30494462 = ((((((a30494462 * a620105235) % 14999) % 14969) + -15030) - 1) + 0);
    	a1983740902 = 33 ;
    	a260539918 = ((((((a999024345 * a999024345) % 14999) / 5) - -20704) * 10) / -9);
    	a1774184757 = (((((a1774184757 * a2130183577) % 14999) + -3496) - 20358) * 1);
    	a2130183577 = (((((a2130183577 * a1151361287) % 14999) - 13574) - 5299) * 1);
    	a341216798 = (((((((a983758263 * a983758263) % 14999) % 31) + 252) + 5508) - 25946) + 20442);
    	a1644957382 = 32 ;
    	a1254983042 = ((((a1254983042 * a217799639) + -5081) - 486) + -62);
    	a1700231631 = (a2061425267 + -7);
    	a1895304149 = 32 ;
    	a1675035970 = ((((((a1675035970 * a341216798) % 14999) / 5) - -25260) * 1) * -1);
    	a26346326 = 32 ;
    	a778006913 = (a2026977784 + -8);
    	a1985899004 = (((((a1985899004 * a260539918) % 14999) / 5) + -20347) * 1);
    	a263151501 = 32 ;
    	a1241576728 = (a1916853335 + -1);
    	a1959068056 = (a1895857334 - 5);
    	a620105235 = (((((((a1254983042 * a999024345) % 14999) / 5) % 10) + -170) - -9107) - 9108);
    	a1756173294 = ((((((a341216798 * a341216798) % 14999) - -4382) / -5) * 10) / 9);
    	a708839806 = 32 ;
    	a302110279 = 32 ;
    	a1151361287 = (((((a1151361287 * a260539918) % 14999) - -9382) - -5570) + -27028);
    	a2130193413 = (a190525986 - 2);
    	a76745981 = 32 ;
    	a709568404 = 32 ;
    	a813082108 = ((((((a813082108 * a1985899004) % 14999) * 2) % 15001) + -14997) + -1);
    	a217799639 = ((((((a1254983042 * a1254983042) % 14999) + -15979) - 6097) * 10) / 9);
    	a2087535773 = ((a1830659124 * a1830659124) + -118);
    	a786258498 = ((a2026977784 - a1241576728) - -5);
    	a1249952537 = (a190525986 + -7); 
    	 printf("%d\n", 17); fflush(stdout); 
    } 
}
 void calculate_outputm220(int input) {
    if(((((a2061425267 == 12 && a1249952537 == 6) && ((29 < a63333937) && (243 >= a63333937))) && a302110279 == 34) && (a4442917 == 7 && (((207 < a1675035970) && (311 >= a1675035970)) && ((input == 2) &&  cf==1 ))))) {
    	cf = 0;
    	a1985899004 = ((((((a30494462 * a2130183577) % 14999) % 76) + 410) * 1) - 30);
    	a190525986 = (a786258498 + 1);
    	a263151501 = 34 ;
    	a708839806 = 34 ;
    	a1625516355 = (((((((a813082108 * a813082108) % 14999) % 37) + -41) / 5) / 5) - 61);
    	a1983740902 = 34 ;
    	a1151361287 = ((((((((a260539918 * a813082108) % 14999) * 2) % 20) + 270) * 5) % 20) + 258);
    	a1180594800 = 34 ;
    	a1916853335 = (a1959068056 - 3);
    	a1478681170 = (a4442917 - 2);
    	a1210910088 = (a2061425267 - 9);
    	a2026977784 = ((a4442917 / a2104091782) + 8); 
    	 printf("%d\n", 16); fflush(stdout); 
    } if(((a2073482783 == 34 && ((((230 < a2130183577) && (255 >= a2130183577)) && ((input == 15) &&  cf==1 )) && a1241576728 == 8)) && ((a2130193413 == 11 && a2061425267 == 12) && ((35 < a1774184757) && (169 >= a1774184757))))) {
    	cf = 0;
    	a2130193413 = (a778006913 + 8);
    	a1318526106 = 34 ;
    	a620105235 = ((((((a260539918 * a813082108) % 14999) - -10566) - -1095) % 94) - 65);
    	a404763935 = (a2087535773 - -9);
    	a1959068056 = (a1830659124 + -1);
    	a1125477212 = 34 ;
    	a30494462 = (((((((a30494462 * a2130183577) % 14999) % 85) + 142) + -16959) * 1) + 17028);
    	a709568404 = 34 ;
    	a2061425267 = (a786258498 - -2);
    	a1826277115 = (((((a1774184757 * a999024345) % 14999) - -5683) - -3736) / 5);
    	a1895304149 = 34 ;
    	a2073482783 = 34 ;
    	a217799639 = ((((((a217799639 * a260539918) % 28) + -29) + 1) + -10023) + 10020);
    	a548050643 = 35 ;
    	a1241576728 = ((a786258498 * a1249952537) - 52);
    	a601495656 = 34 ;
    	a1211013485 = 34 ;
    	a1249952537 = (a1830659124 - 5);
    	a983758263 = (((((((a983758263 * a1826277115) % 14999) - -4056) * 10) / 9) * 10) / 9);
    	a26346326 = 34 ;
    	a1830659124 = (a2104091782 - -7); 
    	 printf("%d\n", 16); fflush(stdout); 
    } 
}
 void calculate_outputm221(int input) {
    if(((((((input == 4) &&  cf==1 ) && a1916853335 == 7) && a76745981 == 34) && a1644957382 == 34) && (((-81 < a1625516355) && (-5 >= a1625516355)) && (a1983740902 == 34 && a1210910088 == 3)))) {
    	cf = 0;
    	a1826277115 = (((((((a983758263 * a983758263) % 14999) % 62) + 79) + -15) - -16131) - 16128);
    	a1521644128 = (a2087535773 + 5);
    	a965340096 = 32 ;
    	a983758263 = (((((a983758263 * a1774184757) % 14999) + -1586) - -338) - -9601); 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((((-160 < a620105235) && (30 >= a620105235)) && (((131 < a999024345) && (260 >= a999024345)) && (a302110279 == 34 && a2073482783 == 34))) && (((-8 < a260539918) && (140 >= a260539918)) && (((input == 5) &&  cf==1 ) && ((-81 < a1625516355) && (-5 >= a1625516355)))))) {
    	cf = 0;
    	a1625516355 = (((((a1625516355 * a30494462) / 5) * 5) % 37) + -22);
    	a1983740902 = 34 ;
    	a1895857334 = (a1249952537 - -5);
    	a709568404 = 34 ;
    	a2026977784 = (a2104091782 - -1);
    	a260539918 = ((((((((a260539918 * a1985899004) % 14999) * 2) % 73) - -65) * 5) % 73) - -66);
    	a263638061 = a190525986;
    	a1574467713 = ((a190525986 - a1895857334) - -1);
    	a708839806 = 34 ;
    	a302110279 = 34 ;
    	a63333937 = ((((((((a30494462 * a1151361287) % 14999) % 106) + 49) * 5) * 5) % 106) + 39);
    	a1318526106 = 34 ;
    	a620105235 = (((((((a620105235 * a813082108) % 14999) % 94) - 65) - 1) + -18723) + 18723);
    	a1478681170 = (a190525986 + -6);
    	a1249952537 = (a1895857334 - 5);
    	a813082108 = ((((((a217799639 * a999024345) % 69) + 187) - 2) / 5) + 161);
    	a778006913 = ((a2130193413 + a2130193413) - 19);
    	a190525986 = (a1210910088 - -8);
    	a1210910088 = (a4442917 - 4); 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((((( cf==1  && (input == 7)) && a26346326 == 34) && ((131 < a999024345) && (260 >= a999024345))) && a1916853335 == 7) && (((202 < a1254983042) && (414 >= a1254983042)) && (((124 < a30494462) && (296 >= a30494462)) && a1983740902 == 34)))) {
    	a1186775761 -= (a1186775761 - 20) < a1186775761 ? 4 : 0;
    	cf = 0;
    	a30494462 = (((((a30494462 * a217799639) / 5) - 23299) % 85) + 217);
    	a2130193413 = ((a786258498 / a1959068056) - -10);
    	a1211013485 = 34 ;
    	a983758263 = ((((a983758263 / 5) - -11509) * 10) / 9);
    	a217799639 = (((((((a1625516355 * a1254983042) % 14999) % 28) + -30) * 5) % 28) - 6);
    	a1125477212 = 34 ;
    	a1826277115 = (((((((a983758263 * a983758263) % 14999) + 2470) + -13117) * 2) % 14910) - -15088);
    	a601495656 = 34 ;
    	a1895304149 = 34 ;
    	a2061425267 = (a2026977784 - -3);
    	a1318526106 = 34 ;
    	a2073482783 = 34 ;
    	a1959068056 = ((a1478681170 / a1830659124) + 10);
    	a548050643 = 35 ;
    	a404763935 = (a2104091782 + 6);
    	a1241576728 = (a2087535773 + 3);
    	a1830659124 = (a2087535773 + 6);
    	a26346326 = 34 ;
    	a709568404 = 34 ;
    	a620105235 = ((((((a620105235 * a1985899004) % 14999) / 5) / 5) % 94) - 64);
    	a1249952537 = (a2087535773 - -1); 
    	 printf("%d\n", 16); fflush(stdout); 
    } if(((((( cf==1  && (input == 9)) && a302110279 == 34) && a26346326 == 34) && a601495656 == 34) && (a1211013485 == 34 && (a1249952537 == 6 && ((207 < a1675035970) && (311 >= a1675035970)))))) {
    	cf = 0;
    	a1521644128 = (a1895857334 - 3);
    	a1826277115 = (((((((a1254983042 * a1254983042) % 14999) % 62) + 65) + -1) / 5) - -53);
    	a965340096 = 32 ;
    	a983758263 = (((((((a983758263 * a1625516355) % 14999) + 16725) * 1) / 5) * 12) / 10); 
    	 printf("%d\n", 18); fflush(stdout); 
    } 
}
 void calculate_outputm20(int input) {
    if((((((131 < a999024345) && (260 >= a999024345)) && ((((207 < a1675035970) && (311 >= a1675035970)) && ((167 < a1018383389) && (211 >= a1018383389))) && a1318526106 == 34)) && a786258498 == 10) && (a2087535773 == 5 && ( cf==1  && a2087632595 == 32)))) {
    	if(((a2087535773 == 5 && (a2130193413 == 11 && (a80157050 == 6 &&  cf==1 ))) && (((((202 < a1254983042) && (414 >= a1254983042)) && a1478681170 == 5) && a601495656 == 34) && a26346326 == 34))) {
    		calculate_outputm212(input);
    	} 
    	if((((a2061425267 == 12 && (a2130193413 == 11 && a1916853335 == 7)) && ((124 < a30494462) && (296 >= a30494462))) && ((((249 < a1151361287) && (291 >= a1151361287)) && (a80157050 == 7 &&  cf==1 )) && ((-8 < a260539918) && (140 >= a260539918))))) {
    		calculate_outputm213(input);
    	} 
    } 
    if(((((a2026977784 == 9 && ((131 < a999024345) && (260 >= a999024345))) && a1241576728 == 8) && a1210910088 == 3) && (a2061425267 == 12 && ((a2087632595 == 34 &&  cf==1 ) && a778006913 == 3)))) {
    	if((((((230 < a2130183577) && (255 >= a2130183577)) && (((104 < a813082108) && (243 >= a813082108)) && ( cf==1  && a266166646 <=  158))) && a2026977784 == 9) && (a2130193413 == 11 && (a1959068056 == 10 && a786258498 == 10)))) {
    		calculate_outputm214(input);
    	} 
    	if(((((167 < a1018383389) && (211 >= a1018383389)) && (a1478681170 == 5 && (((158 < a266166646) && (313 >= a266166646)) &&  cf==1 ))) && (((-59 < a217799639) && (-1 >= a217799639)) && (a1916853335 == 7 && (a1830659124 == 11 && a1959068056 == 10))))) {
    		calculate_outputm215(input);
    	} 
    	if((((a263151501 == 34 && (a786258498 == 10 && (((371 < a1985899004) && (524 >= a1985899004)) && a2073482783 == 34))) && ((202 < a1254983042) && (414 >= a1254983042))) && (( cf==1  && ((313 < a266166646) && (352 >= a266166646))) && a1959068056 == 10))) {
    		calculate_outputm216(input);
    	} 
    } 
    if(((a4442917 == 7 && (((230 < a2130183577) && (255 >= a2130183577)) && (a786258498 == 10 && ((35 < a1774184757) && (169 >= a1774184757))))) && ((( cf==1  && a2087632595 == 35) && a190525986 == 11) && ((207 < a1675035970) && (311 >= a1675035970))))) {
    	if(((a1180594800 == 34 && (((a190525986 == 11 && a2073482783 == 34) && ((35 < a1774184757) && (169 >= a1774184757))) && a786258498 == 10)) && (a709568404 == 34 && ( cf==1  && a1875686186 == 10)))) {
    		calculate_outputm217(input);
    	} 
    	if(((((371 < a1985899004) && (524 >= a1985899004)) && ((((249 < a1151361287) && (291 >= a1151361287)) && ((104 < a813082108) && (243 >= a813082108))) && a26346326 == 34)) && ((a1644957382 == 34 && (a1875686186 == 13 &&  cf==1 )) && a2073482783 == 34))) {
    		calculate_outputm219(input);
    	} 
    } 
    if((((( cf==1  && a2087632595 == 36) && ((35 < a1774184757) && (169 >= a1774184757))) && a2073482783 == 34) && (((((104 < a813082108) && (243 >= a813082108)) && a26346326 == 34) && a1211013485 == 34) && ((-59 < a217799639) && (-1 >= a217799639))))) {
    	if(((((124 < a30494462) && (296 >= a30494462)) && ((((207 < a1675035970) && (311 >= a1675035970)) && ((a778006913 == 3 && ((-8 < a260539918) && (140 >= a260539918))) && a1644957382 == 34)) && a1318526106 == 34)) && (a2104091782 == 4 &&  cf==1 ))) {
    		calculate_outputm220(input);
    	} 
    	if(((((a1830659124 == 11 && (a2104091782 == 8 &&  cf==1 )) && a778006913 == 3) && a2073482783 == 34) && (a26346326 == 34 && (a601495656 == 34 && a76745981 == 34)))) {
    		calculate_outputm221(input);
    	} 
    } 
}
 void calculate_outputm222(int input) {
    if(((((a1125477212 == 34 && a2026977784 == 9) && a1241576728 == 8) && a4442917 == 7) && ((((input == 8) &&  cf==1 ) && a2073482783 == 34) && a1830659124 == 11))) {
    	cf = 0;
    	a1625516355 = (((((((a1774184757 * a999024345) % 14999) / 5) - -7048) - 33938) % 37) - 21);
    	a1675035970 = ((((((a1774184757 * a260539918) - 23151) / 5) + -4159) % 51) - -272);
    	a813082108 = ((((((a1625516355 * a1625516355) + 3100) % 69) - -172) * 9) / 10);
    	a709568404 = 34 ;
    	a404763935 = (a2061425267 + 2);
    	a1249952537 = ((a4442917 / a1210910088) + 4);
    	a548050643 = 35 ;
    	a217799639 = ((((((((a813082108 * a813082108) % 14999) + -7603) % 28) - 30) * 5) % 28) - 23);
    	a1478681170 = (a2026977784 + -4);
    	a1254983042 = ((((((a983758263 * a813082108) % 14999) + 6106) % 105) + 231) - -10);
    	a1241576728 = (a1210910088 + 5);
    	a620105235 = ((((((a1774184757 * a63333937) % 14999) % 94) + -112) / 5) / 5);
    	a26346326 = 34 ;
    	a2130193413 = (a2026977784 - -2);
    	a2130183577 = (((((((a999024345 * a1675035970) % 14999) / 5) % 12) + 241) - 2063) - -2056);
    	a2073482783 = 34 ;
    	a1830659124 = (a4442917 + 4);
    	a1318526106 = 34 ;
    	a1826277115 = (((((a1826277115 * a983758263) % 14999) - -20475) + 4994) * 1);
    	a1895304149 = 34 ;
    	a1125477212 = 34 ;
    	a2087535773 = a1478681170;
    	a2061425267 = (a778006913 - -9);
    	a1211013485 = 34 ;
    	a30494462 = (((((a1675035970 * a1625516355) - -19238) * 1) % 85) + 211);
    	a601495656 = 34 ;
    	a1959068056 = (a1916853335 - -3); 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((((((249 < a1151361287) && (291 >= a1151361287)) && a1983740902 == 34) && a2130193413 == 11) && a1644957382 == 34) && ((a786258498 == 10 && ((input == 9) &&  cf==1 )) && ((29 < a63333937) && (243 >= a63333937))))) {
    	cf = 0;
    	a1345687529 = (((((a1826277115 * a1826277115) % 14999) - -11262) - -478) - -116);
    	a302110279 = 33 ;
    	a63333937 = ((((((a63333937 * a260539918) % 14999) / 5) / 5) % 81) + -52);
    	a1895304149 = 33 ;
    	a2130183577 = ((((((((a63333937 * a1345687529) % 14999) % 63) + 167) - -529) * 5) % 63) - -152);
    	a30494462 = ((((((a1625516355 * a2130183577) - 1033) % 92) - -95) + 3681) + -3728);
    	a1151361287 = (((((((a1151361287 * a999024345) % 14999) + -19138) % 86) + 199) + -18545) + 18543);
    	a721272783 = (a778006913 - -11);
    	a778006913 = ((a1916853335 * a1916853335) - 47);
    	a1891437507 = 35 ;
    	a999024345 = (((((((a1985899004 * a63333937) % 14999) % 41) + 90) - -1) + 6669) - 6669);
    	a26346326 = 33 ;
    	a813082108 = (((((((a1345687529 * a1345687529) % 14999) - -11667) - 5741) * 1) % 50) - -14);
    	a1254983042 = (((((((a1018383389 * a1345687529) % 14999) / 5) % 101) - -4) - -11203) + -11143);
    	a983758263 = ((((((a983758263 * a1774184757) % 14999) % 104) - -99) - -1) / 5);
    	a1478681170 = ((a721272783 / a2130193413) - -3);
    	a1210910088 = ((a4442917 - a2061425267) - -7);
    	a620105235 = (((((a30494462 * a63333937) + -4260) % 10) - 171) + -1);
    	a2073482783 = 33 ;
    	a1644957382 = 33 ;
    	a1018383389 = (((((a1018383389 * a813082108) / 5) + 19662) % 74) + 66);
    	a1675035970 = ((((((((a1151361287 * a1254983042) % 14999) * 2) % 17) + 188) / 5) * 51) / 10);
    	a4442917 = (a1916853335 + -1); 
    	 printf("%d\n", 26); fflush(stdout); 
    } if((((((-8 < a260539918) && (140 >= a260539918)) && a1318526106 == 34) && a1180594800 == 34) && (a708839806 == 34 && ((((input == 12) &&  cf==1 ) && a601495656 == 34) && a1983740902 == 34)))) {
    	cf = 0;
    	a2073482783 = 32 ;
    	a1210910088 = (a2061425267 + -11);
    	a63333937 = (((((a63333937 * a1151361287) % 14999) - 29968) - 1) * 1);
    	a260539918 = (((((a260539918 * a1675035970) % 14999) / 5) + -6606) * 3);
    	a263151501 = 32 ;
    	a341216798 = ((((((a983758263 * a1826277115) % 14999) + -4539) - 10373) + 17651) + -4120);
    	a1241576728 = (a1916853335 + -1);
    	a1644957382 = 32 ;
    	a1625516355 = (((((((a260539918 * a620105235) % 14999) - -833) / 5) * 5) % 13) + -95);
    	a1151361287 = (((((((a63333937 * a2130183577) % 14999) - 355) - 4586) - 9299) % 86) + 163);
    	a1213722969 = a1830659124;
    	a834646264 = (a786258498 - 4);
    	a1318526106 = 32 ;
    	a999024345 = (((((a999024345 * a813082108) % 14999) - 14991) + -11) + 0);
    	a1180594800 = 32 ;
    	a601495656 = 32 ;
    	a4442917 = ((a1210910088 / a2130193413) - -5);
    	a1830659124 = (a1249952537 - -3);
    	a983758263 = (((((((a983758263 * a341216798) % 14999) % 14997) + -15002) + 17777) * 1) + -17777);
    	a302110279 = 33 ;
    	a778006913 = (a1916853335 - 6);
    	a1018383389 = (((((((a1018383389 * a30494462) % 14999) % 74) + 91) + 0) - -26183) - 26182);
    	a708839806 = 32 ;
    	a786258498 = (a1478681170 - -5); 
    	 printf("%d\n", 16); fflush(stdout); 
    } 
}
 void calculate_outputm224(int input) {
    if(((((-59 < a217799639) && (-1 >= a217799639)) && (a786258498 == 10 && (a2130193413 == 11 && ((-160 < a620105235) && (30 >= a620105235))))) && ((((202 < a1254983042) && (414 >= a1254983042)) && ((input == 12) &&  cf==1 )) && ((230 < a2130183577) && (255 >= a2130183577))))) {
    	cf = 0;
    	a2130193413 = (a1249952537 + 4);
    	a26346326 = 33 ;
    	a263151501 = 32 ;
    	a1625516355 = (((((a620105235 * a1774184757) / 5) - -25879) % 13) + -102);
    	a1354435613 = 35 ;
    	a1254983042 = (((((((a1151361287 * a1018383389) % 14999) + 14585) % 101) - -24) + 14554) + -14508);
    	a1895304149 = 33 ;
    	a2130183577 = ((((((a2130183577 * a1625516355) * 1) % 63) + 183) + -17004) + 17011);
    	a983758263 = ((((((a983758263 * a1826277115) % 14999) % 104) - -98) / 5) * 5);
    	a76745981 = 32 ;
    	a1774184757 = ((((((a1254983042 * a1018383389) % 14999) % 92) + -57) - 1) - 1);
    	a601495656 = 33 ;
    	a778006913 = (a263638061 + -8);
    	a2061425267 = (a2130193413 - -1);
    	a721272783 = (a1916853335 - -4);
    	a1675035970 = ((((((a1675035970 * a1625516355) % 14999) % 17) + 190) + 1) + -3);
    	a999024345 = (((((((a999024345 * a1625516355) % 41) - -93) + 6) / 5) * 49) / 10);
    	a1830659124 = (a2061425267 + -2);
    	a786258498 = ((a1241576728 * a1249952537) - 33);
    	a217799639 = (((((a217799639 * a63333937) * 3) / 5) % 69) - 127);
    	a1318526106 = 32 ;
    	a2087535773 = ((a2130193413 + a2061425267) - 18);
    	a4442917 = (a2061425267 + -5);
    	a1125477212 = 33 ;
    	a1018383389 = ((((((a1151361287 * a983758263) % 14999) / 5) / 5) % 21) + 188);
    	a709568404 = 32 ;
    	a1644957382 = 32 ;
    	a30494462 = ((((((a30494462 * a1625516355) % 14999) + 29392) % 92) + -32) - -55);
    	a708839806 = 33 ;
    	a620105235 = ((((((a620105235 * a2130183577) % 14999) * 2) * 1) % 14909) + -15090);
    	a1478681170 = (a1959068056 + -5);
    	a1983740902 = 33 ;
    	a190525986 = (a2026977784 - -2);
    	a1985899004 = ((((a1774184757 * a1774184757) - 24272) - 392) - 12);
    	a1180594800 = 32 ;
    	a1916853335 = ((a1249952537 * a1210910088) + -6);
    	a260539918 = ((((((a2130183577 * a63333937) % 14999) % 14978) - 15021) + 0) + -2);
    	a524719993 = 34 ;
    	a1249952537 = (a721272783 - 5); 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm226(int input) {
    if(((((124 < a30494462) && (296 >= a30494462)) && ((((input == 6) &&  cf==1 ) && a1241576728 == 8) && a1125477212 == 34)) && ((a708839806 == 34 && ((104 < a813082108) && (243 >= a813082108))) && a26346326 == 34))) {
    	cf = 0;
    	a709568404 = 34 ;
    	a983758263 = ((((((((a983758263 * a1826277115) % 14999) - 7055) % 101) - -311) * 5) % 101) - -266);
    	a620105235 = (((((((a1826277115 * a1675035970) % 14999) - -19655) / 5) * 5) % 94) - 132);
    	a263638061 = (a1478681170 + 6);
    	a1249952537 = (a1478681170 - -1);
    	a708839806 = 34 ;
    	a813082108 = (((((((a813082108 * a1254983042) % 14999) / 5) + 24169) * 1) % 69) - -127);
    	a302110279 = 34 ;
    	a1983740902 = 34 ;
    	a1574467713 = (a1916853335 - 6);
    	a1318526106 = 34 ;
    	a260539918 = (((((((a260539918 * a1774184757) % 73) + 66) * 5) * 5) % 73) - -66);
    	a63333937 = ((((((a63333937 * a1255449606) % 14999) + -10144) % 106) + 135) - 0);
    	a1478681170 = ((a4442917 - a2087535773) - -3);
    	a1895857334 = ((a778006913 + a190525986) - 3);
    	a1625516355 = (((((((a1018383389 * a1826277115) % 14999) % 37) - 41) + -2) - 29222) - -29222);
    	a778006913 = (a2026977784 / a1210910088);
    	a190525986 = ((a4442917 + a1830659124) + -7);
    	a1210910088 = ((a1959068056 - a2087535773) + -2);
    	a2026977784 = (a786258498 + -1); 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a1916853335 == 7 && a1830659124 == 11) && ((((a1210910088 == 3 && ((input == 14) &&  cf==1 )) && a76745981 == 34) && a1644957382 == 34) && a2026977784 == 9))) {
    	cf = 0;
    	a2087535773 = (a1830659124 - 6);
    	a1985899004 = ((((((a1018383389 * a260539918) % 76) - -447) + -14306) - 3346) - -17653);
    	a1254983042 = ((((((a1255449606 * a217799639) + 21942) / 5) * 5) % 105) - -308);
    	a1675035970 = (((((a1255449606 * a217799639) % 51) - -299) - 9) + 17);
    	a1211013485 = 34 ;
    	a1959068056 = (a1478681170 - -5);
    	a1151361287 = (((((((a217799639 * a1774184757) % 20) + 289) + -2762) * 5) % 20) - -289);
    	a1180594800 = 34 ;
    	a2130193413 = ((a1241576728 - a4442917) - -10);
    	a2130183577 = (((((((a1255449606 * a30494462) % 14999) % 12) - -233) - 2) + 8873) - 8861); 
    	 printf("%d\n", 18); fflush(stdout); 
    } 
}
 void calculate_outputm227(int input) {
    if(((((-81 < a1625516355) && (-5 >= a1625516355)) && (a1241576728 == 8 && (a1959068056 == 10 && a1644957382 == 34))) && (((35 < a1774184757) && (169 >= a1774184757)) && (( cf==1  && (input == 2)) && a1211013485 == 34)))) {
    	cf = 0;
    	a709568404 = 32 ;
    	a263219509 = (a1210910088 - -4);
    	a1942901885 = 33 ;
    	a1211013485 = 33 ;
    	a30494462 = (((((((a30494462 * a1151361287) % 14999) / 5) % 92) - -26) * 9) / 10);
    	a601495656 = 33 ;
    	a1826277115 = (((((((a1826277115 * a1018383389) % 14999) % 105) + -52) + -1) - -28818) - 28816);
    	a1318526106 = 32 ;
    	a1983740902 = 33 ;
    	a1180594800 = 33 ;
    	a1959068056 = (a4442917 - -2); 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((((249 < a1151361287) && (291 >= a1151361287)) && ((167 < a1018383389) && (211 >= a1018383389))) && (a302110279 == 34 && (a2026977784 == 9 && ((a1644957382 == 34 && ( cf==1  && (input == 15))) && a190525986 == 11))))) {
    	a462273359 -= (a462273359 - 20) < a462273359 ? 2 : 0;
    	a1933720537 -= (a1933720537 - 20) < a1933720537 ? 4 : 0;
    	cf = 0;
    	a76745981 = 32 ;
    	a263219509 = ((a2061425267 - a1213722969) + 4);
    	a1912617323 = (a1213722969 + 3);
    	a1826277115 = ((((((a1826277115 * a983758263) % 14999) % 105) - 51) - 23) / 5); 
    	 printf("%d\n", 16); fflush(stdout); 
    } if((((a4442917 == 7 && (((-59 < a217799639) && (-1 >= a217799639)) && ( cf==1  && (input == 13)))) && (((a1210910088 == 3 && a1249952537 == 6) && ((230 < a2130183577) && (255 >= a2130183577))) && a1959068056 == 10)) && a707706067 == 18)) {
    	cf = 0;
    	a965340096 = 32 ;
    	a1521644128 = (a2026977784 - 6);
    	a1826277115 = ((((((((a1826277115 * a983758263) % 14999) - 13899) % 62) - -145) * 5) % 62) - -91); 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((((a4442917 == 7 && a76745981 == 34) && ((202 < a1254983042) && (414 >= a1254983042))) && a1318526106 == 34) && (a1916853335 == 7 && (( cf==1  && (input == 4)) && a1895304149 == 34))) && a1844895357 == 0)) {
    	cf = 0;
    	a983758263 = (((((((a983758263 * a2130183577) % 14999) - -12506) * 1) / 5) % 104) + -2);
    	a757937656 = ((a1241576728 * a1213722969) + -80);
    	a1345687529 = (((((((a1826277115 * a983758263) % 14999) % 73) - -1) - -1) + 27382) + -27382);
    	a721272783 = (a1959068056 + 4); 
    	 printf("%d\n", 19); fflush(stdout); 
    } if((((a778006913 == 3 && a2130193413 == 11) && ((a263151501 == 34 && (a601495656 == 34 && (a786258498 == 10 && ((input == 10) &&  cf==1 )))) && ((202 < a1254983042) && (414 >= a1254983042)))) && a1761958712 == 3)) {
    	cf = 0;
    	a1895857334 = ((a1213722969 * a4442917) - 66);
    	a263638061 = ((a1249952537 - a2087535773) - -6);
    	a983758263 = (((((((a983758263 * a1675035970) % 14999) + -3699) - 16757) + -5911) % 101) - -315);
    	a1574467713 = (a1895857334 + -10); 
    	 printf("%d\n", 18); fflush(stdout); 
    } if((((a2061425267 == 12 && (((35 < a1774184757) && (169 >= a1774184757)) && ((input == 9) &&  cf==1 ))) && ((((-59 < a217799639) && (-1 >= a217799639)) && (a1211013485 == 34 && ((230 < a2130183577) && (255 >= a2130183577)))) && ((131 < a999024345) && (260 >= a999024345)))) && a698359753 == 15)) {
    	cf = 0;
    	a1569588614 = (((((((a2130183577 * a1254983042) % 14999) - -6718) - 29546) + 19987) % 46) + 120);
    	a721272783 = (a2026977784 + 3);
    	a983758263 = ((((((a983758263 * a1569588614) % 14999) + 12272) * 1) % 104) + -1);
    	a1574467713 = ((a190525986 - a721272783) - -3); 
    	 printf("%d\n", 26); fflush(stdout); 
    } if((((((202 < a1254983042) && (414 >= a1254983042)) && ((((input == 14) &&  cf==1 ) && a1895304149 == 34) && a708839806 == 34)) && ((a190525986 == 11 && a1241576728 == 8) && ((-160 < a620105235) && (30 >= a620105235)))) && a1711183540 == -1)) {
    	cf = 0;
    	a965340096 = 35 ;
    	a834646264 = ((a1213722969 - a1249952537) - -3);
    	a1826277115 = ((((((a1826277115 * a983758263) % 14999) / 5) - 23931) % 62) - -118); 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((((((371 < a1985899004) && (524 >= a1985899004)) && a4442917 == 7) && ((104 < a813082108) && (243 >= a813082108))) && (a1478681170 == 5 && ((a302110279 == 34 && ( cf==1  && (input == 12))) && ((-8 < a260539918) && (140 >= a260539918))))) && a1451139861 == -16)) {
    	cf = 0;
    	a2041520547 = 34 ;
    	a983758263 = (((((((a983758263 * a999024345) % 14999) / 5) - -17417) + -5275) % 101) - -278);
    	a1895857334 = (a4442917 + 5);
    	a617559344 = ((((((a1985899004 * a63333937) % 14999) % 60) - -461) * 1) + -34); 
    	 printf("%d\n", 18); fflush(stdout); 
    } if((((((29 < a63333937) && (243 >= a63333937)) && (a2026977784 == 9 && (a1125477212 == 34 && (((230 < a2130183577) && (255 >= a2130183577)) && ((input == 5) &&  cf==1 ))))) && (a786258498 == 10 && a1644957382 == 34)) && a639488566 == 16)) {
    	cf = 0;
    	a1895857334 = ((a2087535773 + a778006913) + -1);
    	a721272783 = ((a1916853335 + a1210910088) + 1);
    	a524719993 = 36 ;
    	a983758263 = (((((a983758263 * a1774184757) % 14999) / 5) / 5) / 5); 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((((((-59 < a217799639) && (-1 >= a217799639)) && ((((124 < a30494462) && (296 >= a30494462)) && (a1211013485 == 34 && a190525986 == 11)) && ((-8 < a260539918) && (140 >= a260539918)))) && (( cf==1  && (input == 6)) && a1959068056 == 10)) && a854924571 == 5)) {
    	cf = 0;
    	a965340096 = 35 ;
    	a1826277115 = (((((((a1826277115 * a1254983042) % 14999) / 5) - -18361) + 38) % 62) + 88);
    	a834646264 = (a2061425267 - 5); 
    	 printf("%d\n", 18); fflush(stdout); 
    } if(((((((a76745981 == 34 && (a1210910088 == 3 && a190525986 == 11)) && ((104 < a813082108) && (243 >= a813082108))) && a2061425267 == 12) && a1983740902 == 34) && ((input == 8) &&  cf==1 )) && a1835250293 == -9)) {
    	cf = 0;
    	a721272783 = ((a2026977784 - a1213722969) - -13);
    	a524719993 = 32 ;
    	a1728405119 = ((((a1774184757 * a1774184757) / 5) * 5) - -561);
    	a983758263 = ((((((a983758263 * a1985899004) % 14999) - -104) % 104) + 72) / 5); 
    	 printf("%d\n", 17); fflush(stdout); 
    } if((((a190525986 == 11 && (((29 < a63333937) && (243 >= a63333937)) && (((a1916853335 == 7 && ( cf==1  && (input == 7))) && a76745981 == 34) && a1983740902 == 34))) && ((104 < a813082108) && (243 >= a813082108))) && a213897350 == 13)) {
    	cf = 0;
    	a983758263 = ((((((a983758263 * a1826277115) % 14999) - -1843) - 14039) % 101) - -352);
    	a1895857334 = (a778006913 - -10);
    	a2087632595 = 35 ;
    	a1875686186 = (a1241576728 + 4); 
    	 printf("%d\n", 26); fflush(stdout); 
    } 
}
 void calculate_outputm228(int input) {
    if((((((-160 < a620105235) && (30 >= a620105235)) && ((202 < a1254983042) && (414 >= a1254983042))) && a1210910088 == 3) && (((29 < a63333937) && (243 >= a63333937)) && (a601495656 == 34 && (a302110279 == 34 && ((input == 2) &&  cf==1 )))))) {
    	cf = 0;
    	a1254983042 = ((((((a1254983042 * a30494462) % 14999) % 105) - -226) - 25685) - -25732);
    	a1675035970 = ((((((a1675035970 * a813082108) % 14999) % 51) - -247) + 1) - -11);
    	a1985899004 = (((((((a1985899004 * a1018383389) % 14999) + 6657) + 4489) - 23231) % 76) - -447);
    	a1211013485 = 34 ;
    	a1959068056 = ((a1210910088 + a1249952537) - -1);
    	a1180594800 = 34 ;
    	a2087535773 = (a1916853335 + -2);
    	a2130183577 = ((((((a2130183577 * a63333937) % 14999) % 12) - -234) / 5) + 201);
    	a1151361287 = (((((((a1151361287 * a63333937) % 14999) % 20) - -269) / 5) * 48) / 10);
    	a2130193413 = (a2026977784 - -2);
    	a153649526 = 34 ;
    	a1255449606 = (((((((a1826277115 * a1826277115) % 14999) + 10407) - 30808) + 22363) % 52) + 46); 
    	 printf("%d\n", 26); fflush(stdout); 
    } if(((((35 < a1774184757) && (169 >= a1774184757)) && (a2073482783 == 34 && ((167 < a1018383389) && (211 >= a1018383389)))) && (a1644957382 == 34 && (a190525986 == 11 && (((input == 11) &&  cf==1 ) && a1180594800 == 34))))) {
    	cf = 0;
    	a76745981 = 32 ;
    	a260539918 = (((((a1985899004 * a1018383389) % 14999) - 14032) - 13851) + -1418);
    	a1018383389 = (((((((a1018383389 * a999024345) % 14999) % 74) - -46) + 39) - 17530) + 17537);
    	a1241576728 = ((a786258498 * a2061425267) + -114);
    	a983758263 = (((((a983758263 * a1774184757) % 14999) + -16233) - 6916) / 5);
    	a302110279 = 33 ;
    	a834646264 = (a2026977784 + -3);
    	a4442917 = (a1249952537 - 1);
    	a2087535773 = ((a4442917 / a786258498) - -3);
    	a813082108 = ((((((a813082108 * a260539918) % 14999) - 9618) + -430) + 23036) - 19573);
    	a1211013485 = 32 ;
    	a30494462 = (((((a1985899004 * a1985899004) % 14999) - 23483) + -2830) * 1);
    	a1644957382 = 32 ;
    	a1213722969 = ((a1830659124 - a1830659124) - -11);
    	a26346326 = 32 ;
    	a1180594800 = 32 ;
    	a263151501 = 32 ;
    	a1210910088 = (a2087535773 - 2);
    	a1625516355 = ((((((a1151361287 * a1151361287) % 14999) % 13) + -101) / 5) - 76);
    	a1959068056 = ((a190525986 - a2026977784) - -6);
    	a1830659124 = ((a834646264 + a786258498) - 7);
    	a708839806 = 32 ;
    	a999024345 = ((((((a999024345 * a260539918) % 14999) - -8096) - 9902) - -7167) - 7772);
    	a1318526106 = 32 ;
    	a1254983042 = (((((a983758263 * a1675035970) % 14999) / 5) + -12195) + -14156);
    	a1675035970 = (((((a30494462 * a1151361287) % 14999) - 13759) - 676) * 1);
    	a620105235 = ((((((a620105235 * a1826277115) % 14999) / 5) - 8019) + 9975) + -21424);
    	a1895304149 = 32 ;
    	a601495656 = 32 ;
    	a778006913 = (a2026977784 + -8);
    	a341216798 = (((((a983758263 * a1826277115) % 14999) - 16004) + -12822) + -974);
    	a1478681170 = ((a2026977784 - a2130193413) + 5);
    	a63333937 = (((((a63333937 * a1254983042) % 14999) - 7256) - -14561) - 19549);
    	a2130183577 = (((((a2130183577 * a30494462) % 14999) - -20475) + 6269) - 31820);
    	a786258498 = (a778006913 * a1959068056);
    	a2073482783 = 32 ;
    	a1151361287 = (((((((a1151361287 * a260539918) % 14999) % 86) - -161) - 24591) - -41656) + -17064); 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((((249 < a1151361287) && (291 >= a1151361287)) && (a708839806 == 34 && ((input == 13) &&  cf==1 ))) && (((a778006913 == 3 && ((207 < a1675035970) && (311 >= a1675035970))) && ((230 < a2130183577) && (255 >= a2130183577))) && ((29 < a63333937) && (243 >= a63333937))))) {
    	cf = 0;
    	a813082108 = (((((((a813082108 * a1985899004) % 14999) % 69) - -137) + -2) * 9) / 10);
    	a707417839 = (((((a1826277115 * a1826277115) % 14999) - -14847) - -49) / 5);
    	a1352986605 = (((((((a2130183577 * a983758263) % 14999) - 5486) % 31) + 117) + 2004) + -2004);
    	a1644957382 = 34 ;
    	a1895857334 = (a2087535773 + 1);
    	a1625516355 = (((((((a2130183577 * a1018383389) % 14999) - -11809) * 1) * 1) % 37) - 69);
    	a1210910088 = (a2061425267 - 9);
    	a983758263 = (((((((a983758263 * a707417839) % 14999) / 5) % 101) - -212) - 23774) + 23794);
    	a1916853335 = (a778006913 - -4);
    	a1985899004 = (((((((((a1985899004 * a63333937) % 14999) % 76) + 447) * 9) / 10) / 5) * 47) / 10);
    	a2087535773 = ((a778006913 - a4442917) + 9);
    	a778006913 = (a2026977784 + -6);
    	a63333937 = ((((((a63333937 * a1675035970) % 14999) + -20133) + -7511) % 106) + 136); 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm21(int input) {
    if(((((((249 < a1151361287) && (291 >= a1151361287)) && ( cf==1  && a153649526 == 32)) && a1241576728 == 8) && a302110279 == 34) && ((a1180594800 == 34 && a1125477212 == 34) && a1210910088 == 3))) {
    	if(((((a524719993 == 33 &&  cf==1 ) && a1916853335 == 7) && a1180594800 == 34) && ((((29 < a63333937) && (243 >= a63333937)) && (a1249952537 == 6 && a2130193413 == 11)) && ((371 < a1985899004) && (524 >= a1985899004))))) {
    		calculate_outputm222(input);
    	} 
    } 
    if(((((207 < a1675035970) && (311 >= a1675035970)) && (( cf==1  && a153649526 == 33) && a708839806 == 34)) && ((((-81 < a1625516355) && (-5 >= a1625516355)) && (a190525986 == 11 && a1478681170 == 5)) && a26346326 == 34))) {
    	if(((a1895304149 == 34 && ((a1478681170 == 5 && (a778006913 == 3 && a76745981 == 34)) && a601495656 == 34)) && (( cf==1  && a263638061 == 10) && ((124 < a30494462) && (296 >= a30494462))))) {
    		calculate_outputm224(input);
    	} 
    } 
    if(((((a2026977784 == 9 && (a153649526 == 34 &&  cf==1 )) && a2073482783 == 34) && a1241576728 == 8) && (((124 < a30494462) && (296 >= a30494462)) && (a302110279 == 34 && ((29 < a63333937) && (243 >= a63333937)))))) {
    	if(((((a601495656 == 34 && ( cf==1  && ((37 < a1255449606) && (143 >= a1255449606)))) && a1895304149 == 34) && a1241576728 == 8) && ((((-8 < a260539918) && (140 >= a260539918)) && ((-59 < a217799639) && (-1 >= a217799639))) && a1125477212 == 34))) {
    		calculate_outputm226(input);
    	} 
    } 
    if((((a1210910088 == 3 && (a1125477212 == 34 && (a153649526 == 36 &&  cf==1 ))) && ((-160 < a620105235) && (30 >= a620105235))) && ((a601495656 == 34 && a302110279 == 34) && ((104 < a813082108) && (243 >= a813082108))))) {
    	if(((a190525986 == 11 && a1211013485 == 34) && (((29 < a63333937) && (243 >= a63333937)) && (((((-59 < a217799639) && (-1 >= a217799639)) && ( cf==1  && a1213722969 == 11)) && a263151501 == 34) && ((230 < a2130183577) && (255 >= a2130183577)))))) {
    		calculate_outputm227(input);
    	} 
    	if(((((a26346326 == 34 && (a2130193413 == 11 && ((249 < a1151361287) && (291 >= a1151361287)))) && ((104 < a813082108) && (243 >= a813082108))) && ((371 < a1985899004) && (524 >= a1985899004))) && ((a1213722969 == 13 &&  cf==1 ) && ((-160 < a620105235) && (30 >= a620105235))))) {
    		calculate_outputm228(input);
    	} 
    } 
}
 void calculate_outputm229(int input) {
    if((((a2061425267 == 12 && (a1983740902 == 34 && a1249952537 == 6)) && a1241576728 == 8) && (((249 < a1151361287) && (291 >= a1151361287)) && (a1895304149 == 34 && ( cf==1  && (input == 2)))))) {
    	cf = 0;
    	a302110279 = 34 ;
    	a1574467713 = (a2061425267 + -11);
    	a1983740902 = 34 ;
    	a263638061 = (a263219509 + 6);
    	a1478681170 = (a1210910088 + 2);
    	a1318526106 = 34 ;
    	a1895857334 = a190525986;
    	a1210910088 = ((a1912617323 - a1574467713) - 5);
    	a190525986 = (a4442917 - -4);
    	a983758263 = ((((((a983758263 * a1826277115) % 14999) / 5) / 5) % 101) - -305);
    	a620105235 = ((((((a260539918 * a1826277115) + -959) / 5) + 19595) % 94) - 131);
    	a260539918 = (((((((a813082108 * a999024345) % 14999) % 73) + -6) + -1) + 25937) - 25914);
    	a1625516355 = (((((a1625516355 * a30494462) * 1) / 5) % 37) + -16);
    	a813082108 = (((((((a813082108 * a1254983042) % 14999) + -864) * 2) / 5) % 69) - -173);
    	a709568404 = 34 ;
    	a778006913 = ((a1895857334 + a2130193413) + -19);
    	a708839806 = 34 ;
    	a1249952537 = (a1959068056 + -4);
    	a63333937 = (((((((a1985899004 * a217799639) % 14999) - 12403) % 106) - -142) - 16328) + 16342);
    	a2026977784 = ((a1241576728 * a2087535773) + -31); 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((((371 < a1985899004) && (524 >= a1985899004)) && (a2087535773 == 5 && a601495656 == 34)) && (a190525986 == 11 && (a1959068056 == 10 && (((input == 5) &&  cf==1 ) && a1249952537 == 6))))) {
    	cf = 0;
    	a1213722969 = ((a2061425267 + a263219509) + -6);
    	a1826277115 = (((((((a1826277115 * a999024345) % 14999) + 3398) + -5039) + 8601) % 14921) + -15078);
    	a709568404 = 34 ;
    	a153649526 = 36 ;
    	a63333937 = (((((((a1151361287 * a620105235) % 14999) / 5) % 106) - -135) / 5) - -155); 
    	 printf("%d\n", 26); fflush(stdout); 
    } if(((((124 < a30494462) && (296 >= a30494462)) && ((((371 < a1985899004) && (524 >= a1985899004)) && a76745981 == 34) && a1211013485 == 34)) && ((((207 < a1675035970) && (311 >= a1675035970)) && ((input == 11) &&  cf==1 )) && ((-81 < a1625516355) && (-5 >= a1625516355))))) {
    	cf = 0;
    	a620105235 = (((((((a1675035970 * a2130183577) % 14999) / 5) % 94) - 151) - -16263) - 16227);
    	a2026977784 = ((a190525986 + a2087535773) - 7);
    	a1180594800 = 34 ;
    	a2073482783 = 34 ;
    	a302110279 = 34 ;
    	a1018383389 = ((((((((a2130183577 * a813082108) % 14999) + -7426) % 21) + 189) * 5) % 21) - -170);
    	a1774184757 = (((((((a1254983042 * a813082108) % 14999) % 66) + 69) - -26266) + -10165) - 16082);
    	a1318526106 = 34 ;
    	a1478681170 = (a4442917 - 2); 
    	 printf("%d\n", 18); fflush(stdout); 
    } if(((((-81 < a1625516355) && (-5 >= a1625516355)) && (a1983740902 == 34 && (((230 < a2130183577) && (255 >= a2130183577)) && a1959068056 == 10))) && (((124 < a30494462) && (296 >= a30494462)) && (a1830659124 == 11 && ((input == 15) &&  cf==1 ))))) {
    	cf = 0;
    	a63333937 = (((((((a983758263 * a1675035970) % 14999) / 5) % 106) - -67) + 3896) + -3866);
    	a709568404 = 34 ;
    	a1213722969 = a2130193413;
    	a153649526 = 36 ;
    	a1826277115 = ((((((a1826277115 * a1254983042) % 14999) % 14921) + -15078) + -1) * 1); 
    	 printf("%d\n", 18); fflush(stdout); 
    } if(((a26346326 == 34 && (((230 < a2130183577) && (255 >= a2130183577)) && a778006913 == 3)) && (a1644957382 == 34 && (a76745981 == 34 && (a1241576728 == 8 && ( cf==1  && (input == 12))))))) {
    	cf = 0;
    	a1211013485 = 32 ;
    	a983758263 = ((((((a983758263 * a260539918) % 14999) % 14997) + -15002) - 1) + -1);
    	a1756173294 = (((((a1254983042 * a1625516355) % 14999) / 5) - 26121) - 218);
    	a341216798 = (((((((a999024345 * a1756173294) % 14999) * 2) % 31) - -265) - -1247) - 1244);
    	a1700231631 = a1210910088;
    	a4442917 = (a786258498 + -5);
    	a1210910088 = ((a1912617323 / a778006913) + -2);
    	a263151501 = 32 ;
    	a260539918 = (((((((a2130183577 * a1826277115) % 14999) % 14978) - 15021) / 5) / 5) - 19700);
    	a76745981 = 32 ;
    	a1644957382 = 32 ;
    	a1254983042 = (((((a2130183577 * a217799639) * 10) / 9) - 10724) / 5);
    	a1985899004 = ((((((a1985899004 * a1151361287) % 14999) + 14949) * 1) / 5) - 20157);
    	a1895304149 = 32 ;
    	a2087535773 = (a1830659124 + -8);
    	a778006913 = (a786258498 + -9);
    	a30494462 = (((((a30494462 * a63333937) % 14999) + -12192) * 1) + 7697);
    	a1241576728 = (a1916853335 + -1);
    	a813082108 = ((((((a813082108 * a63333937) % 14999) + 17755) + 11085) / 5) - 7173);
    	a217799639 = (((((a217799639 * a983758263) % 14999) + -28236) + -1122) / 5);
    	a2130193413 = ((a1916853335 + a786258498) - 8);
    	a190525986 = ((a1916853335 / a1959068056) + 9); 
    	 printf("%d\n", 18); fflush(stdout); 
    } 
}
 void calculate_outputm231(int input) {
    if(((((-8 < a260539918) && (140 >= a260539918)) && (((104 < a813082108) && (243 >= a813082108)) && ((input == 7) &&  cf==1 ))) && (a263151501 == 34 && ((a1180594800 == 34 && a1125477212 == 34) && a601495656 == 34)))) {
    	a213897350 += (a213897350 + 20) > a213897350 ? 4 : 0;
    	a295012665 -= (a295012665 - 20) < a295012665 ? 4 : 0;
    	cf = 0;
    	a63333937 = (((((a1826277115 * a1826277115) / 5) - -4086) * 3) + -27354);
    	a1241576728 = (a1912617323 + -8);
    	a190525986 = ((a1249952537 * a1916853335) - 33);
    	a778006913 = (a1241576728 - 5);
    	a2130183577 = ((((((a2130183577 * a1774184757) % 14999) + 12178) * 1) / 5) * -5);
    	a1151361287 = ((((((a1151361287 * a1675035970) % 14999) % 86) + 135) - 20195) - -20213);
    	a263151501 = 32 ;
    	a1018383389 = ((((((a1018383389 * a1254983042) % 14999) + -17254) + -775) * 10) / 9);
    	a2073482783 = 32 ;
    	a2130193413 = (a190525986 - -1);
    	a4442917 = ((a1249952537 / a778006913) - 1);
    	a834646264 = ((a1210910088 * a1959068056) - 21);
    	a356054071 = (((((a1625516355 * a999024345) * 10) / -9) + 4910) / 5);
    	a1625516355 = ((((((a1826277115 * a813082108) % 14999) + 3417) % 14945) + -15053) * 1);
    	a260539918 = ((((((a260539918 * a30494462) % 14999) - 7834) % 14978) + -15021) + -2);
    	a1211013485 = 33 ;
    	a341216798 = (((((a1774184757 * a1774184757) * -1) / 5) * 10) / 9);
    	a217799639 = (((((a217799639 * a1675035970) - 199) + -5866) + 6740) - 1084);
    	a26346326 = 32 ;
    	a999024345 = ((((((a620105235 * a217799639) % 14999) / 5) - -4267) % 41) - -77);
    	a620105235 = (((((a63333937 * a1826277115) % 14999) + -3209) / 5) + -3603);
    	a1959068056 = ((a2061425267 + a778006913) + -5);
    	a1983740902 = 33 ;
    	a786258498 = (a2087535773 - -3);
    	a30494462 = (((((a1254983042 * a1985899004) % 14999) + -16771) + -9387) * 1);
    	a2087535773 = (a1830659124 + -7);
    	a1180594800 = 33 ;
    	a708839806 = 32 ;
    	a1895304149 = 32 ;
    	a813082108 = ((((((a813082108 * a1774184757) % 14999) + -18558) * 10) / 9) + -8463);
    	a1830659124 = ((a263219509 + a263219509) + -1);
    	a1675035970 = ((((((a1985899004 * a2130183577) % 14999) % 17) - -190) / 5) + 161);
    	a1318526106 = 32 ;
    	a2061425267 = (a2026977784 + 1);
    	a709568404 = 32 ;
    	a1210910088 = (a190525986 - 8);
    	a601495656 = 32 ;
    	a1249952537 = a1478681170;
    	a983758263 = (((((((a983758263 * a1826277115) % 14999) * 2) % 14997) - 15002) / 5) + -1614);
    	a1774184757 = ((((((a1774184757 * a1985899004) % 14999) - 17695) % 92) + 16) - 8);
    	a1125477212 = 33 ;
    	a302110279 = 32 ;
    	a1478681170 = (a1912617323 - 10);
    	a2026977784 = (a1912617323 + -7); 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((((a4442917 == 7 && a1318526106 == 34) && ((230 < a2130183577) && (255 >= a2130183577))) && (((104 < a813082108) && (243 >= a813082108)) && (a1983740902 == 34 && (a1249952537 == 6 && ( cf==1  && (input == 8)))))) && a462273359 == -3)) {
    	cf = 0;
    	a965340096 = 33 ;
    	a1826277115 = ((((((a1826277115 * a983758263) % 14999) % 62) - -115) - -14181) - 14179);
    	a1240243570 = ((a2087535773 * a1830659124) + -43); 
    	 printf("%d\n", 18); fflush(stdout); 
    } if((((a1895304149 == 34 && (((a1180594800 == 34 && ((input == 11) &&  cf==1 )) && ((124 < a30494462) && (296 >= a30494462))) && a302110279 == 34)) && (a1644957382 == 34 && a2087535773 == 5)) && a1329406336 == -19)) {
    	cf = 0;
    	a1826277115 = (((((((a1826277115 * a1675035970) % 14999) % 14910) - -15088) * 1) / 5) - -16889);
    	a404763935 = ((a4442917 / a1210910088) + 9);
    	a350392085 = ((a1916853335 - a404763935) + 10); 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((((((167 < a1018383389) && (211 >= a1018383389)) && (((input == 6) &&  cf==1 ) && a263151501 == 34)) && (((131 < a999024345) && (260 >= a999024345)) && (((202 < a1254983042) && (414 >= a1254983042)) && (a1180594800 == 34 && ((35 < a1774184757) && (169 >= a1774184757)))))) && a990043066 <= -5)) {
    	cf = 0;
    	a1323955799 = 32 ;
    	a1352986605 = ((((((((a983758263 * a1826277115) % 14999) % 84) - -233) * 5) * 5) % 84) - -204);
    	a1895857334 = (a190525986 - 5);
    	a76745981 = 34 ;
    	a983758263 = (((((((a983758263 * a1774184757) % 14999) + -25409) / 5) / 5) % 101) - -391); 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((((-59 < a217799639) && (-1 >= a217799639)) && (( cf==1  && (input == 13)) && a786258498 == 10)) && (a1983740902 == 34 && ((((-160 < a620105235) && (30 >= a620105235)) && a2073482783 == 34) && a1125477212 == 34))) && a419312954 == 4)) {
    	cf = 0;
    	a1213722969 = (a1478681170 + 3);
    	a983758263 = (((((((a983758263 * a1826277115) % 14999) + -12674) % 14997) - 15002) / 5) - 16074);
    	a778006913 = ((a1916853335 * a190525986) + -76);
    	a813082108 = (((((a813082108 * a260539918) % 14999) + -15001) - 1) + 0);
    	a26346326 = 32 ;
    	a2130183577 = (((((a2130183577 * a1774184757) % 14999) - 29743) / 5) + -5723);
    	a30494462 = ((((((a30494462 * a2130183577) % 14999) + -5929) - 7503) % 14969) - 15030);
    	a341216798 = (((((a260539918 * a63333937) % 14999) - 7373) + -7446) + -157);
    	a834646264 = (a1830659124 - 5);
    	a1254983042 = ((((((a1254983042 * a341216798) % 14999) + 14342) - -398) * 1) + -29741);
    	a4442917 = ((a1210910088 - a263219509) - -7);
    	a63333937 = ((((((a2130183577 * a1774184757) % 14999) + 10393) + -19025) % 14932) - 15066);
    	a1125477212 = 32 ;
    	a1895304149 = 32 ;
    	a601495656 = 32 ;
    	a709568404 = 32 ;
    	a1018383389 = (((((a1018383389 * a1774184757) % 14999) + -27803) + -417) - 1688);
    	a1625516355 = ((((a1625516355 * a620105235) + -17371) / 5) * 5);
    	a1180594800 = 32 ;
    	a1318526106 = 32 ;
    	a1241576728 = (a2087535773 + 1); 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((((167 < a1018383389) && (211 >= a1018383389)) && (a302110279 == 34 && ((input == 10) &&  cf==1 ))) && ((a708839806 == 34 && (a1895304149 == 34 && a1959068056 == 10)) && a2026977784 == 9)) && a1054543477 <= -15)) {
    	cf = 0;
    	a190525986 = a786258498;
    	a1625516355 = (((((a1625516355 * a1826277115) % 13) + -93) + -3) + 3);
    	a1180594800 = 33 ;
    	a1254983042 = ((((((((a1254983042 * a1826277115) % 14999) + 7658) % 101) + 101) * 5) % 101) + 56);
    	a721272783 = ((a1249952537 - a4442917) + 15);
    	a1895304149 = 33 ;
    	a26346326 = 33 ;
    	a1345687529 = ((((((a983758263 * a1985899004) % 14999) / 5) + 17539) * 10) / 9);
    	a1210910088 = (a4442917 + -5);
    	a2130183577 = (((((((a2130183577 * a1018383389) % 14999) % 63) - -118) + -17156) - -28776) - 11629);
    	a302110279 = 33 ;
    	a620105235 = (((((((a620105235 * a999024345) % 14999) % 10) - 169) * 1) + -5562) + 5559);
    	a1478681170 = ((a778006913 - a2087535773) + 6);
    	a1891437507 = 32 ;
    	a1249952537 = ((a1916853335 - a1912617323) + 12);
    	a983758263 = (((((((a983758263 * a1826277115) % 14999) / 5) / 5) / 5) % 104) - -99);
    	a1018383389 = (((((((a63333937 * a813082108) % 14999) - -2693) % 74) - -35) - 17583) + 17570);
    	a30494462 = ((((((a30494462 * a1675035970) % 14999) % 92) - 36) + -12) + -13);
    	a2073482783 = 33 ;
    	a63333937 = ((((((((a63333937 * a260539918) % 14999) % 81) - 53) * 5) + -16283) % 81) + -36);
    	a1675035970 = ((((((a1675035970 * a217799639) % 17) + 204) + -2) + -13936) + 13938);
    	a2087535773 = (a778006913 - -1); 
    	 printf("%d\n", 26); fflush(stdout); 
    } if((((((104 < a813082108) && (243 >= a813082108)) && ((a1478681170 == 5 && a709568404 == 34) && a2026977784 == 9)) && ((a1983740902 == 34 && ((input == 4) &&  cf==1 )) && a1180594800 == 34)) && a156979206 <= -11)) {
    	cf = 0;
    	a661990791 = ((a1241576728 * a1916853335) - 45);
    	a263219509 = ((a661990791 * a1912617323) + -143); 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((( cf==1  && (input == 1)) && a2061425267 == 12) && (a1830659124 == 11 && (a778006913 == 3 && ((((202 < a1254983042) && (414 >= a1254983042)) && ((124 < a30494462) && (296 >= a30494462))) && a1478681170 == 5)))) && a1785777793 <= -29)) {
    	a990043066 += (a990043066 + 20) > a990043066 ? 4 : 0;
    	cf = 0;
    	a1895304149 = 33 ;
    	a1675035970 = (((((((a1675035970 * a2130183577) % 14999) + 5825) - 16509) + -4111) % 17) + 189);
    	a1478681170 = ((a1249952537 + a1912617323) + -16);
    	a26346326 = 33 ;
    	a983758263 = ((((((a983758263 * a1826277115) % 14999) % 104) - -99) + -1) - 0);
    	a30494462 = (((((((a30494462 * a260539918) % 14999) % 92) - -30) * 5) % 92) - -30);
    	a4442917 = (a1478681170 + 2);
    	a1318526106 = 33 ;
    	a2061425267 = (a1912617323 - 3);
    	a1830659124 = ((a1959068056 - a1959068056) - -10);
    	a620105235 = (((((((a1018383389 * a1018383389) % 14999) % 10) - 178) - 18677) - -16886) - -1797);
    	a786258498 = (a190525986 - 2);
    	a2130183577 = ((((((((a2130183577 * a1985899004) % 14999) % 63) - -112) * 5) * 5) % 63) + 155);
    	a1254983042 = ((((((a1254983042 * a620105235) % 14999) / 5) / 5) % 101) + 101);
    	a1211013485 = 33 ;
    	a63333937 = ((((((a63333937 * a1151361287) % 14999) - 8132) - -14403) % 81) + -94);
    	a1625516355 = ((((((a1625516355 * a260539918) % 13) - 94) + -29604) + 24028) - -5576);
    	a1597554373 = 36 ;
    	a1916853335 = ((a263219509 / a786258498) + 6);
    	a721272783 = (a1241576728 + 5);
    	a813082108 = (((((((a813082108 * a1985899004) % 14999) + 6020) % 50) + 36) + 17859) - 17845);
    	a1075307847 = 35 ;
    	a1210910088 = (a2087535773 - 3); 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((((((-8 < a260539918) && (140 >= a260539918)) && (a1983740902 == 34 && a4442917 == 7)) && ((29 < a63333937) && (243 >= a63333937))) && ((((input == 3) &&  cf==1 ) && ((124 < a30494462) && (296 >= a30494462))) && a1959068056 == 10)) && a295012665 <= -42)) {
    	cf = 0;
    	a1249952537 = (a786258498 + -6);
    	a1830659124 = (a2087535773 - -4);
    	a983758263 = (((((a983758263 * a2130183577) % 14999) - 20498) - -6513) + -5813);
    	a1210910088 = ((a190525986 * a2026977784) + -98);
    	a263151501 = 32 ;
    	a1756173294 = (((((((a1826277115 * a1254983042) % 14999) + 4876) / 5) / 5) % 53) + 167);
    	a1125477212 = 32 ;
    	a341216798 = ((((((a1774184757 * a1756173294) % 14999) % 31) + 265) + -27012) - -26990);
    	a2130193413 = (a1912617323 + -5);
    	a1151361287 = (((((a1151361287 * a30494462) % 14999) - 17904) - 5402) / 5);
    	a1985899004 = (((((a1985899004 * a1675035970) % 14999) - -7858) - 1430) * -1);
    	a1337636546 = ((((((a983758263 * a999024345) % 14999) - 715) % 38) - -56) + -16);
    	a260539918 = (((((a260539918 * a1018383389) + -12220) * 1) % 14978) + -15021);
    	a2087535773 = (a786258498 - 7);
    	a813082108 = (((((a813082108 * a217799639) + 16766) * -1) * 10) / 9);
    	a30494462 = ((((a1625516355 * a217799639) + -29408) * 1) * 1);
    	a1211013485 = 32 ;
    	a1895304149 = 32 ;
    	a2061425267 = (a263219509 + a263219509);
    	a1254983042 = (((((a1254983042 * a63333937) % 14999) + -23842) - 5125) + -251);
    	a4442917 = (a778006913 - -2);
    	a1241576728 = (a778006913 + 3);
    	a778006913 = (a190525986 - 10);
    	a217799639 = ((((((a217799639 * a1151361287) % 14999) * 2) % 14901) - 15098) + 0); 
    	 printf("%d\n", 20); fflush(stdout); 
    } if((((a1830659124 == 11 && (a190525986 == 11 && ((input == 15) &&  cf==1 ))) && (((a1895304149 == 34 && a1241576728 == 8) && a709568404 == 34) && ((-160 < a620105235) && (30 >= a620105235)))) && a1933720537 <= -56)) {
    	cf = 0;
    	a1826277115 = (((((((a1826277115 * a983758263) % 14999) + 8289) % 14910) + 15088) + -2262) + 2265);
    	a548050643 = 32 ;
    	a404763935 = ((a263219509 - a1478681170) - -14); 
    	 printf("%d\n", 17); fflush(stdout); 
    } if((((((((a709568404 == 34 && ((input == 14) &&  cf==1 )) && ((202 < a1254983042) && (414 >= a1254983042))) && a2073482783 == 34) && a1983740902 == 34) && a601495656 == 34) && ((371 < a1985899004) && (524 >= a1985899004))) && a1224489519 == 32)) {
    	cf = 0;
    	a1895857334 = (a2026977784 + -2);
    	a983758263 = ((((((a983758263 * a260539918) % 14999) + -547) - -3969) % 101) + 305);
    	a1969216760 = 32 ;
    	a2004613952 = (a1912617323 + -6); 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm234(int input) {
    if(((( cf==1  && (input == 4)) && ((230 < a2130183577) && (255 >= a2130183577))) && (a1644957382 == 34 && (a1478681170 == 5 && (a1125477212 == 34 && (a708839806 == 34 && ((249 < a1151361287) && (291 >= a1151361287)))))))) {
    	cf = 0;
    	a1318526106 = 34 ;
    	a708839806 = 33 ;
    	a2087632595 = 32 ;
    	a302110279 = 33 ;
    	a1959068056 = (a1249952537 - -4);
    	a80157050 = ((a778006913 - a1830659124) - -15);
    	a1211013485 = 34 ;
    	a709568404 = 33 ;
    	a1895857334 = ((a2026977784 - a2061425267) + 16);
    	a1180594800 = 34 ;
    	a30494462 = ((((((a1826277115 * a260539918) % 85) + 211) - -1) / 5) - -181);
    	a983758263 = ((((((((a983758263 * a1826277115) % 14999) * 2) % 101) + 305) * 5) % 101) + 252); 
    	 printf("%d\n", 19); fflush(stdout); 
    } if(((a2026977784 == 9 && ((35 < a1774184757) && (169 >= a1774184757))) && (((104 < a813082108) && (243 >= a813082108)) && ((a1241576728 == 8 && (( cf==1  && (input == 6)) && ((371 < a1985899004) && (524 >= a1985899004)))) && a4442917 == 7)))) {
    	cf = 0;
    	a2026977784 = (a2087535773 + 3);
    	a708839806 = 33 ;
    	a1210910088 = (a2026977784 + -6);
    	a1318526106 = 33 ;
    	a302110279 = 33 ;
    	a1830659124 = ((a1210910088 + a190525986) + -3);
    	a76745981 = 33 ;
    	a778006913 = (a2087535773 + -3);
    	a2061425267 = ((a2087535773 / a2130193413) + 11);
    	a1774184757 = (((((((a620105235 * a1018383389) % 14999) % 92) - 57) / 5) - -8583) + -8570);
    	a1241576728 = (a1830659124 - 3);
    	a1249952537 = (a1210910088 - -3);
    	a1625516355 = ((((((a1625516355 * a217799639) % 13) - 107) * 9) / 10) - -4);
    	a999024345 = ((((((((a999024345 * a1985899004) % 14999) % 41) - -71) * 10) / 9) - -10484) - 10493);
    	a2073482783 = 33 ;
    	a1151361287 = (((((((a1151361287 * a2130183577) % 14999) + 9479) / 5) / 5) % 86) - -156);
    	a1985899004 = (((((((a1018383389 * a1826277115) % 14999) % 98) + 272) * 5) % 98) + 218);
    	a1254983042 = ((((((a1018383389 * a1018383389) % 14999) + -10257) % 101) - -100) - 1);
    	a26346326 = 33 ;
    	a757937656 = (a4442917 - -2);
    	a1675035970 = (((((((a1675035970 * a1774184757) % 14999) - -12045) - 14268) * 1) % 17) - -189);
    	a813082108 = (((((((a813082108 * a63333937) % 14999) + -15921) % 50) + 96) * 9) / 10);
    	a2097567994 = 32 ;
    	a1916853335 = (a1959068056 - 3);
    	a217799639 = ((((((a2130183577 * a2130183577) % 14999) / 5) / 5) % 69) + -156);
    	a1644957382 = 33 ;
    	a786258498 = ((a263219509 * a2130193413) + -68);
    	a1478681170 = (a1916853335 - 2);
    	a63333937 = (((((((a63333937 * a1254983042) % 14999) % 81) - 52) / 5) + 4355) - 4457);
    	a721272783 = ((a2130193413 / a757937656) + 14);
    	a2130183577 = (((((((a2130183577 * a260539918) % 14999) - -9443) % 63) + 166) / 5) + 96);
    	a983758263 = (((((((a983758263 * a1826277115) % 14999) % 104) + 98) + -27111) * 1) - -27112);
    	a1125477212 = 33 ;
    	a4442917 = (a2087535773 - -1);
    	a190525986 = (a1959068056 + 1);
    	a260539918 = (((((((a260539918 * a620105235) * 1) % 17) - 24) * 5) % 17) + -11);
    	a620105235 = (((((((a1018383389 * a1018383389) % 14999) + -19215) * 1) + -1804) % 10) + -162);
    	a1895304149 = 33 ;
    	a2130193413 = (a2061425267 + -1);
    	a709568404 = 33 ;
    	a2087535773 = (a2026977784 - 4);
    	a1018383389 = (((((a1018383389 * a30494462) % 74) - -91) / 5) - -62); 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((((input == 14) &&  cf==1 ) && a190525986 == 11) && ((((230 < a2130183577) && (255 >= a2130183577)) && ((((167 < a1018383389) && (211 >= a1018383389)) && ((-160 < a620105235) && (30 >= a620105235))) && a1478681170 == 5)) && ((104 < a813082108) && (243 >= a813082108)))) && a1233331030 == 39)) {
    	cf = 0;
    	a26346326 = 33 ;
    	a983758263 = ((((((a983758263 * a1826277115) % 14999) + 1628) % 104) + 99) / 5);
    	a76745981 = 33 ;
    	a1018383389 = (((((a217799639 * a2130183577) % 74) - -148) - 5823) - -5803);
    	a813082108 = (((((((a813082108 * a983758263) % 14999) * 2) * 1) / 5) % 50) - -53);
    	a1625516355 = (((((a1625516355 * a217799639) % 13) - 93) * 1) - 6);
    	a620105235 = (((((a620105235 * a30494462) / 5) - -16758) % 10) - 174);
    	a721272783 = (a1916853335 + 8);
    	a757937656 = ((a1249952537 - a2026977784) - -7);
    	a260539918 = ((((((a260539918 * a999024345) % 14999) % 17) - 26) / 5) + -6);
    	a1151361287 = ((((((((a1151361287 * a1774184757) % 14999) / 5) % 86) - -136) * 5) % 86) + 146);
    	a1895304149 = 33 ;
    	a2026977784 = ((a1478681170 / a1478681170) - -7);
    	a2097567994 = 32 ;
    	a1241576728 = ((a1478681170 - a2061425267) - -14);
    	a1210910088 = ((a2061425267 / a786258498) - -1);
    	a63333937 = ((((((a63333937 * a1018383389) % 14999) / 5) + 7615) % 81) + -89);
    	a1675035970 = ((((((a1675035970 * a1625516355) % 14999) % 17) - -190) - -1) + -3);
    	a1478681170 = (a190525986 - 7); 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((((207 < a1675035970) && (311 >= a1675035970)) && ((a4442917 == 7 && (a190525986 == 11 && ((input == 9) &&  cf==1 ))) && a302110279 == 34)) && (((371 < a1985899004) && (524 >= a1985899004)) && a778006913 == 3)) && a1186775761 == 43)) {
    	cf = 0;
    	a1830659124 = ((a1916853335 * a263219509) - 39);
    	a26346326 = 33 ;
    	a217799639 = (((((a217799639 * a30494462) + -7771) % 69) - 115) - 2);
    	a617559344 = (((((((a1826277115 * a999024345) % 14999) + -14486) / 5) - -5803) % 109) - -307);
    	a1210910088 = (a1241576728 + -6);
    	a1700231631 = ((a190525986 - a2130193413) + 10);
    	a983758263 = ((((((a983758263 * a1826277115) % 14999) * 2) - -1) % 104) + 98);
    	a2073482783 = 33 ;
    	a721272783 = ((a2087535773 * a786258498) + -33);
    	a1675035970 = (((((((a1675035970 * a1018383389) % 14999) % 17) + 187) * 5) % 17) - -180);
    	a1625516355 = ((((((a1625516355 * a813082108) % 13) - 82) * 5) % 13) + -90);
    	a1985899004 = ((((((a1985899004 * a1774184757) % 14999) + 13701) + -26088) % 98) + 273);
    	a1151361287 = ((((((a1151361287 * a620105235) % 14999) % 86) - -162) - -2) - 3);
    	a1478681170 = (a1249952537 + -2);
    	a1895304149 = 33 ;
    	a786258498 = (a1830659124 - 1);
    	a1916853335 = (a190525986 - 5);
    	a1644957382 = 33 ;
    	a260539918 = (((((a260539918 * a1675035970) % 17) - 24) - 1) - -1); 
    	 printf("%d\n", 26); fflush(stdout); 
    } if((((((input == 11) &&  cf==1 ) && ((-8 < a260539918) && (140 >= a260539918))) && (((104 < a813082108) && (243 >= a813082108)) && ((a2073482783 == 34 && (a302110279 == 34 && a26346326 == 34)) && ((-59 < a217799639) && (-1 >= a217799639))))) && a789762657 == 26)) {
    	cf = 0;
    	a76745981 = 32 ;
    	a30494462 = (((((a813082108 * a813082108) % 14999) - 17193) + -12500) + -134);
    	a1180594800 = 32 ;
    	a601495656 = 32 ;
    	a1774184757 = (((((a1774184757 * a30494462) % 14999) / 5) / 5) + -26761);
    	a1895304149 = 32 ;
    	a1249952537 = (a1210910088 + 1);
    	a834646264 = ((a1478681170 + a1916853335) + -2);
    	a4442917 = (a2130193413 - 6);
    	a190525986 = (a1830659124 - 2);
    	a1959068056 = (a263219509 + 1);
    	a803418896 = ((((((a1826277115 * a1826277115) % 14913) - 15086) + -1) / 5) - 19510);
    	a1241576728 = (a190525986 + -3);
    	a341216798 = ((((((a983758263 * a983758263) % 14999) - 25508) * 1) * 10) / 9);
    	a2130183577 = (((((a2130183577 * a1985899004) % 14999) + 9512) + 2567) + -39921);
    	a983758263 = (((((((a983758263 * a1826277115) % 14999) + 6817) % 14997) + -15002) + 23943) + -23944);
    	a63333937 = (((((a63333937 * a803418896) % 14999) + -9875) * 1) / 5);
    	a302110279 = 32 ;
    	a2026977784 = (a2087535773 + 2);
    	a778006913 = (a2087535773 - 4); 
    	 printf("%d\n", 17); fflush(stdout); 
    } if(((((a708839806 == 34 && ((a2087535773 == 5 && a263151501 == 34) && ((35 < a1774184757) && (169 >= a1774184757)))) && a2026977784 == 9) && (( cf==1  && (input == 8)) && ((104 < a813082108) && (243 >= a813082108)))) && a456906074 <= -108)) {
    	cf = 0;
    	a721272783 = (a1241576728 - -4);
    	a1210910088 = (a1830659124 + -9);
    	a1916853335 = ((a721272783 / a263219509) + 5);
    	a1895304149 = 33 ;
    	a620105235 = (((((((a1018383389 * a1018383389) % 14999) % 10) - 175) / 5) * 10) / 2);
    	a983758263 = (((((((a983758263 * a1826277115) % 14999) % 104) - -98) + 0) - -16276) + -16274);
    	a1574467713 = (a1249952537 - 1);
    	a260539918 = ((((((a260539918 * a620105235) / 5) * 5) + 16867) % 17) + -26);
    	a26346326 = 33 ;
    	a1569588614 = (((((((a2130183577 * a999024345) % 14999) % 46) - -85) + 33) + 7489) + -7526);
    	a1249952537 = (a1916853335 + -1);
    	a1675035970 = (((((((a1675035970 * a30494462) % 14999) * 2) % 17) + 188) / 5) + 151);
    	a1018383389 = ((((((((a1018383389 * a2130183577) % 14999) % 74) + 57) * 9) / 10) * 9) / 10);
    	a999024345 = (((((((a813082108 * a63333937) % 14999) - -10268) % 41) + 55) * 10) / 9);
    	a1625516355 = ((((((a1625516355 * a1985899004) % 14999) % 13) + -95) * 1) + 2);
    	a217799639 = ((((((a217799639 * a813082108) + 28869) % 69) + -165) * 9) / 10);
    	a2130193413 = (a2087535773 + 5);
    	a786258498 = (a721272783 - 3);
    	a263151501 = 33 ;
    	a76745981 = 33 ;
    	a190525986 = (a263219509 - -3); 
    	 printf("%d\n", 16); fflush(stdout); 
    } if((((a263151501 == 34 && (a4442917 == 7 && a2073482783 == 34)) && (a76745981 == 34 && ((( cf==1  && (input == 5)) && a1210910088 == 3) && a1916853335 == 7))) && a170107731 == 62)) {
    	cf = 0;
    	a404763935 = ((a1830659124 * a1478681170) - 44);
    	a1826277115 = (((((((a1826277115 * a983758263) % 14999) % 14910) - -15088) - 0) + -22656) - -22658);
    	a350392085 = (a2087535773 - -4); 
    	 printf("%d\n", 16); fflush(stdout); 
    } 
}
 void calculate_outputm236(int input) {
    if(((a1210910088 == 3 && a1895304149 == 34) && ((((((input == 5) &&  cf==1 ) && a1959068056 == 10) && a1180594800 == 34) && a1249952537 == 6) && ((371 < a1985899004) && (524 >= a1985899004))))) {
    	cf = 0;
    	a26346326 = 33 ;
    	a263151501 = 33 ;
    	a302110279 = 33 ;
    	a30494462 = (((((63 / 5) * 9) / 10) + 21955) + -21999);
    	a260539918 = (((((a1625516355 * a30494462) * 3) * 1) % 17) + -26);
    	a1241576728 = (a1210910088 + 4);
    	a1959068056 = ((a2026977784 * a2130193413) + -79);
    	a190525986 = (a1241576728 - -3);
    	a1180594800 = 33 ;
    	a983758263 = ((((((a983758263 * a1826277115) % 14999) % 104) - -99) - -1) + -1);
    	a1574467713 = ((a1478681170 / a1210910088) + 7);
    	a2130193413 = ((a1210910088 / a1210910088) + 9);
    	a1983740902 = 33 ;
    	a1774184757 = ((((((a1625516355 * a1625516355) + 1525) * 3) * 1) % 92) + -104);
    	a1895304149 = 33 ;
    	a778006913 = (a2026977784 - 6);
    	a721272783 = (a263219509 + 4);
    	a4442917 = ((a1959068056 - a1249952537) + 3);
    	a1675035970 = (((((a260539918 * a30494462) % 17) - -190) - -16772) - 16773);
    	a1478681170 = ((a1916853335 / a1959068056) + 4);
    	a1249952537 = ((a1959068056 / a778006913) + 1);
    	a1211013485 = 33 ;
    	a1569588614 = ((((((a1826277115 * a1826277115) % 46) - -119) / 5) * 5) - -4);
    	a76745981 = 33 ;
    	a999024345 = (((((((a999024345 * a813082108) % 14999) % 41) + 86) + -23) - -11939) - 11939);
    	a217799639 = (((((a260539918 * a1151361287) - -30932) % 69) - 140) - -1);
    	a2130183577 = (((((((a2130183577 * a63333937) % 14999) % 63) - -127) * 10) / 9) - 26);
    	a786258498 = (a721272783 + -3);
    	a601495656 = 33 ;
    	a1625516355 = ((((((((a1625516355 * a1985899004) % 14999) - -3033) % 13) + -94) * 5) % 13) + -95);
    	a2061425267 = (a1210910088 - -9);
    	a813082108 = (((((((a813082108 * a1774184757) % 14999) * 2) % 50) - -54) * 9) / 10);
    	a2087535773 = ((a1210910088 * a1210910088) - 5);
    	a1125477212 = 33 ;
    	a1151361287 = ((((((a1151361287 * a217799639) % 14999) - 9529) * 1) % 86) - -170);
    	a1210910088 = (a2026977784 - 6); 
    	 printf("%d\n", 19); fflush(stdout); 
    } if(((((29 < a63333937) && (243 >= a63333937)) && (a709568404 == 34 && ((131 < a999024345) && (260 >= a999024345)))) && (((-8 < a260539918) && (140 >= a260539918)) && (a1241576728 == 8 && (((-81 < a1625516355) && (-5 >= a1625516355)) && ( cf==1  && (input == 14))))))) {
    	cf = 0;
    	a1211013485 = 34 ;
    	a620105235 = ((((((a999024345 * a1774184757) % 14999) / 5) / 5) % 94) + -99);
    	a30494462 = (((((((a999024345 * a999024345) % 14999) - -2331) % 85) - -166) - -15820) - 15829);
    	a76745981 = 34 ;
    	a2026977784 = (a2130193413 - 2);
    	a1213722969 = ((a1959068056 * a1210910088) + -19);
    	a1826277115 = (((((((a1826277115 * a983758263) % 14999) / 5) * 5) * 2) % 14921) - 15078);
    	a2061425267 = (a1959068056 - -2);
    	a153649526 = 36 ;
    	a1983740902 = 34 ;
    	a1675035970 = ((((((((a1018383389 * a63333937) % 14999) % 51) - -259) + 1) * 5) % 51) - -255); 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((((-8 < a260539918) && (140 >= a260539918)) && (a708839806 == 34 && ( cf==1  && (input == 9)))) && (a1916853335 == 7 && (((35 < a1774184757) && (169 >= a1774184757)) && (a2073482783 == 34 && ((29 < a63333937) && (243 >= a63333937))))))) {
    	a990043066 += (a990043066 + 20) > a990043066 ? 2 : 0;
    	cf = 0;
    	a1521644128 = (a2130193413 + -1);
    	a1895304149 = 32 ;
    	a1241576728 = ((a1521644128 / a1478681170) + 4);
    	a1151361287 = (((((a1151361287 * a260539918) % 14999) + -14992) + -6) + -4);
    	a341216798 = (((((((a983758263 * a983758263) % 14999) + -22603) - -27254) + -32981) * -1) / 10);
    	a1644957382 = 32 ;
    	a4442917 = (a190525986 - 6);
    	a1569588614 = (((((((a2130183577 * a63333937) % 14999) % 46) - -88) - 12) * 10) / 9);
    	a2130183577 = (((((a1675035970 * a1625516355) % 14999) - 14971) - 16) + -15);
    	a708839806 = 32 ;
    	a1180594800 = 32 ;
    	a778006913 = (a1241576728 + -5);
    	a709568404 = 32 ;
    	a983758263 = ((((((a983758263 * a1774184757) % 14999) + -24027) * 10) / 9) * 1);
    	a1774184757 = (((((a1985899004 * a1625516355) % 14999) / 5) + -15285) * 1);
    	a302110279 = 32 ;
    	a190525986 = (a1959068056 - 1); 
    	 printf("%d\n", 18); fflush(stdout); 
    } 
}
 void calculate_outputm237(int input) {
    if((((((202 < a1254983042) && (414 >= a1254983042)) && (a601495656 == 34 && a709568404 == 34)) && a4442917 == 7) && ((((input == 2) &&  cf==1 ) && a190525986 == 11) && a1644957382 == 34))) {
    	a419312954 += (a419312954 + 20) > a419312954 ? 2 : 0;
    	cf = 0;
    	a1774184757 = (((((((a2130183577 * a2130183577) % 14999) % 66) + 58) - 18) * 10) / 9);
    	a1210910088 = (a1241576728 - 5);
    	a1211013485 = 34 ;
    	a1826277115 = (((((a1826277115 * a1254983042) % 14999) / 5) + -19946) - 2635);
    	a260539918 = ((((((a1774184757 * a1625516355) % 73) + 80) + 36) * 10) / 9);
    	a153649526 = 36 ;
    	a620105235 = (((((((a30494462 * a1985899004) % 14999) / 5) % 94) - 102) * 10) / 9);
    	a1213722969 = ((a1916853335 / a1916853335) + 10); 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((((input == 7) &&  cf==1 ) && a2061425267 == 12) && a601495656 == 34) && (((((124 < a30494462) && (296 >= a30494462)) && ((167 < a1018383389) && (211 >= a1018383389))) && ((249 < a1151361287) && (291 >= a1151361287))) && a4442917 == 7))) {
    	cf = 0;
    	a1211013485 = 34 ;
    	a263219509 = (a2061425267 - 7);
    	a620105235 = (((((((a983758263 * a1675035970) % 14999) - -4610) % 94) + -137) * 9) / 10);
    	a1774184757 = (((((((a983758263 * a1018383389) % 14999) - -10579) % 66) - -82) * 9) / 10);
    	a1210910088 = ((a1249952537 * a1249952537) + -33);
    	a76745981 = 32 ;
    	a1912617323 = (a1959068056 - -4);
    	a260539918 = ((((((a1018383389 * a1151361287) % 14999) + -20165) + -3968) % 73) + 85); 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((((a709568404 == 34 && ((202 < a1254983042) && (414 >= a1254983042))) && ((230 < a2130183577) && (255 >= a2130183577))) && a2087535773 == 5) && (((167 < a1018383389) && (211 >= a1018383389)) && (( cf==1  && (input == 14)) && a2061425267 == 12)))) {
    	cf = 0;
    	a1478681170 = ((a1210910088 / a1241576728) + 4);
    	a721272783 = (a1916853335 - -5);
    	a2130193413 = (a1478681170 + 6);
    	a999024345 = (((((((a999024345 * a983758263) % 14999) % 41) + 65) * 5) % 41) + 77);
    	a1895304149 = 33 ;
    	a1249952537 = ((a1210910088 + a2130193413) + -7);
    	a1959068056 = a263219509;
    	a601495656 = 33 ;
    	a1151361287 = ((((((a1151361287 * a2130183577) % 14999) - 2362) % 86) + 162) + 2);
    	a76745981 = 33 ;
    	a26346326 = 33 ;
    	a1180594800 = 33 ;
    	a778006913 = (a4442917 + -5);
    	a813082108 = ((((((((a813082108 * a1826277115) % 14999) % 50) + 53) - -1) * 5) % 50) + 31);
    	a190525986 = ((a786258498 / a2061425267) - -10);
    	a217799639 = ((((((a217799639 * a260539918) - -22487) / 5) + 2060) % 69) - 193);
    	a2026977784 = (a1210910088 + 6);
    	a1983740902 = 33 ;
    	a2087535773 = ((a1959068056 + a4442917) - 12);
    	a786258498 = (a721272783 - 3);
    	a30494462 = (((((((a30494462 * a1774184757) % 14999) % 92) + 31) / 5) - -15968) - 15920);
    	a4442917 = (a2026977784 - 2);
    	a263151501 = 33 ;
    	a1569588614 = ((((((a1675035970 * a1625516355) / 5) * 5) - -26785) % 46) + 103);
    	a1675035970 = (((((((a983758263 * a1018383389) % 14999) - -6111) % 17) + 188) - -29310) + -29324);
    	a302110279 = 33 ;
    	a1125477212 = 33 ;
    	a2130183577 = ((((((((a2130183577 * a1018383389) % 14999) % 63) + 129) * 9) / 10) * 9) / 10);
    	a983758263 = ((((((a983758263 * a1569588614) % 14999) - 10736) % 104) - -99) - 1);
    	a1241576728 = (a1210910088 + 5);
    	a1625516355 = ((((((a1625516355 * a63333937) % 13) - 91) - 23976) * 1) + 23984);
    	a1574467713 = (a721272783 + -4); 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a1249952537 == 6 && ( cf==1  && (input == 6))) && (a1983740902 == 34 && (((29 < a63333937) && (243 >= a63333937)) && ((a1180594800 == 34 && a4442917 == 7) && a708839806 == 34))))) {
    	cf = 0;
    	a263219509 = ((a1241576728 * a2130193413) - 77);
    	a661990791 = (a2026977784 + -1); 
    	 printf("%d\n", 26); fflush(stdout); 
    } 
}
 void calculate_outputm238(int input) {
    if(((a1959068056 == 10 && (((35 < a1774184757) && (169 >= a1774184757)) && (a2130193413 == 11 && a1644957382 == 34))) && (((-59 < a217799639) && (-1 >= a217799639)) && (((input == 12) &&  cf==1 ) && a263151501 == 34)))) {
    	cf = 0;
    	a1895304149 = 34 ;
    	a1241576728 = (a1959068056 - 2);
    	a548050643 = 35 ;
    	a620105235 = ((((((a217799639 * a1625516355) + 16690) / 5) - -18973) % 94) - 125);
    	a1249952537 = (a263219509 + -3);
    	a30494462 = ((((((((a63333937 * a1254983042) % 14999) % 85) - -168) * 5) - -7330) % 85) + 211);
    	a1830659124 = ((a2026977784 - a778006913) - -5);
    	a1959068056 = (a190525986 + -1);
    	a1318526106 = 34 ;
    	a601495656 = 34 ;
    	a1125477212 = 34 ;
    	a2130193413 = (a786258498 + 1);
    	a217799639 = (((((a217799639 * a2130183577) + 8779) + -10831) % 28) - 30);
    	a1826277115 = ((((((a1826277115 * a983758263) % 14999) % 14910) - -15088) * 1) - -1);
    	a2061425267 = (a1210910088 - -9);
    	a709568404 = 34 ;
    	a1211013485 = 34 ;
    	a2073482783 = 34 ;
    	a26346326 = 34 ;
    	a404763935 = ((a4442917 / a1478681170) + 13); 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((((a302110279 == 34 && (a2061425267 == 12 && (a2026977784 == 9 && ((35 < a1774184757) && (169 >= a1774184757))))) && ((-81 < a1625516355) && (-5 >= a1625516355))) && a4442917 == 7) && ( cf==1  && (input == 14)))) {
    	cf = 0;
    	a1959068056 = (a2061425267 - 3);
    	a1180594800 = 33 ;
    	a1318526106 = 32 ;
    	a709568404 = 32 ;
    	a1983740902 = 33 ;
    	a1942901885 = 33 ;
    	a263219509 = (a2087535773 - -2); 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((a1210910088 == 3 && (((input == 9) &&  cf==1 ) && ((104 < a813082108) && (243 >= a813082108)))) && a1318526106 == 34) && (a1916853335 == 7 && (a4442917 == 7 && a708839806 == 34)))) {
    	cf = 0;
    	a263219509 = (a4442917 + -2);
    	a1912617323 = a786258498; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm239(int input) {
    if(((((230 < a2130183577) && (255 >= a2130183577)) && (a1211013485 == 34 && (((371 < a1985899004) && (524 >= a1985899004)) && ((((-8 < a260539918) && (140 >= a260539918)) && a709568404 == 34) && a263151501 == 34)))) && ( cf==1  && (input == 5)))) {
    	a1933720537 += (a1933720537 + 20) > a1933720537 ? 3 : 0;
    	cf = 0;
    	a1318526106 = 33 ;
    	a1895304149 = 32 ;
    	a786258498 = ((a1959068056 + a1249952537) - 6);
    	a1550739565 = ((a778006913 - a1478681170) - -13);
    	a778006913 = ((a1550739565 - a786258498) + -2);
    	a63333937 = ((((a63333937 * a1625516355) + -1111) / 5) * 5);
    	a1241576728 = ((a786258498 / a786258498) + 5);
    	a813082108 = (((((a813082108 * a30494462) % 14999) - 24033) * 1) * 1);
    	a1521644128 = (a1916853335 - 3);
    	a1830659124 = ((a1241576728 * a263219509) + -51);
    	a217799639 = ((((a217799639 * a1151361287) + -6546) + -3172) - 531);
    	a2130193413 = (a2026977784 + 2);
    	a260539918 = (((((a1018383389 * a1254983042) % 14999) + -17965) * 1) + -1419);
    	a2087535773 = (a2130193413 + -6);
    	a30494462 = (((((((a260539918 * a1151361287) % 14999) - 4836) + 13331) - -11111) * -1) / 10);
    	a983758263 = ((((((a983758263 * a1826277115) % 14999) % 14997) - 15002) - 1) * 1);
    	a341216798 = ((((a1774184757 * a1625516355) + 16210) + 4210) + 5620);
    	a999024345 = (((((a1018383389 * a63333937) % 14999) + -14122) * 1) * 1);
    	a1774184757 = ((((((a160322672 * a1254983042) % 14999) + 9149) * 1) / 5) + -19781);
    	a1644957382 = 33 ;
    	a263151501 = 32 ;
    	a1675035970 = (((((a1018383389 * a1018383389) % 14999) / 5) + -19851) + -9608);
    	a1625516355 = (((((a999024345 * a63333937) % 14999) / 5) - 10184) / 5);
    	a1254983042 = (((((a1254983042 * a260539918) % 14999) + -4818) * 1) * 1);
    	a4442917 = ((a190525986 / a1241576728) - -4);
    	a709568404 = 32 ;
    	a1985899004 = (((((a1985899004 * a2130183577) % 14999) - 25413) * 1) - 4206);
    	a2130183577 = (((((a1018383389 * a260539918) % 14999) - 1646) / 5) - 6628);
    	a302110279 = 32 ;
    	a1211013485 = 32 ;
    	a2073482783 = 32 ;
    	a1151361287 = (((((a1151361287 * a1675035970) % 14999) - 8816) * 1) - 6176); 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((a2073482783 == 34 && (((167 < a1018383389) && (211 >= a1018383389)) && (((input == 14) &&  cf==1 ) && ((207 < a1675035970) && (311 >= a1675035970))))) && ((a263151501 == 34 && a778006913 == 3) && a4442917 == 7))) {
    	a789762657 -= (a789762657 - 20) < a789762657 ? 3 : 0;
    	cf = 0;
    	a709568404 = 32 ;
    	a1211013485 = 32 ;
    	a2061425267 = a263219509;
    	a1774184757 = ((((((a260539918 * a1254983042) % 14999) % 14924) - 15074) + 14347) - 14348);
    	a1675035970 = (((((a1774184757 * a260539918) % 14999) + -14908) + -84) + -5);
    	a813082108 = ((((((a813082108 * a1774184757) % 14999) - 8519) * 10) / 9) - 1187);
    	a26346326 = 32 ;
    	a1830659124 = (a1241576728 + 1);
    	a1210910088 = (a263219509 + -9);
    	a620105235 = (((((a1774184757 * a1774184757) % 14999) / 5) - -20444) + -23675);
    	a4442917 = (a2061425267 + -5);
    	a999024345 = (((((a999024345 * a1675035970) % 14999) - 14957) + -21) / 5);
    	a1254983042 = (((((a1254983042 * a1774184757) % 14999) / 5) - 2387) * 5);
    	a2130193413 = a1830659124;
    	a965340096 = 32 ;
    	a2073482783 = 32 ;
    	a1895304149 = 32 ;
    	a341216798 = (((((a2130183577 * a1625516355) / 5) - -23783) - 20665) + 26401);
    	a63333937 = (((((((a63333937 * a983758263) % 14999) - 20015) / 5) - -7745) * -1) / 10);
    	a2087535773 = ((a1478681170 * a786258498) + -47);
    	a1983740902 = 33 ;
    	a263151501 = 32 ;
    	a1318526106 = 32 ;
    	a1151361287 = (((((a1151361287 * a160322672) % 14999) + -12112) - 10795) + 6031);
    	a217799639 = ((((a217799639 * a2130183577) + -11215) - -4307) * 1);
    	a1241576728 = a1249952537;
    	a1644957382 = 32 ;
    	a1521644128 = (a778006913 + 2);
    	a1125477212 = 32 ;
    	a2130183577 = (((((a260539918 * a1018383389) - 18623) - -10026) % 15051) - 14947);
    	a601495656 = 32 ;
    	a302110279 = 32 ;
    	a1625516355 = (((((a620105235 * a30494462) % 14999) - 8797) + -1494) / 5);
    	a983758263 = ((((((a983758263 * a1826277115) % 14999) % 14997) + -15002) - 1) + -1);
    	a778006913 = (a786258498 - 9);
    	a1985899004 = (((((a1985899004 * a1826277115) % 14999) + -14834) + -152) + -3);
    	a708839806 = 32 ;
    	a30494462 = (((((a260539918 * a260539918) - 20960) + 20973) - -6297) - 33231);
    	a786258498 = ((a2061425267 + a1916853335) + -9);
    	a1916853335 = (a1210910088 - -4);
    	a260539918 = ((((a260539918 * a1018383389) + 121) / 5) - 26898);
    	a1249952537 = ((a2026977784 / a190525986) - -4); 
    	 printf("%d\n", 26); fflush(stdout); 
    } if(((a1895304149 == 34 && (( cf==1  && (input == 15)) && a2073482783 == 34)) && (((202 < a1254983042) && (414 >= a1254983042)) && ((a1241576728 == 8 && a302110279 == 34) && ((124 < a30494462) && (296 >= a30494462)))))) {
    	cf = 0;
    	a2061425267 = a263219509;
    	a26346326 = 32 ;
    	a620105235 = (((((a1018383389 * a1018383389) % 14999) / 5) + -20452) / 5);
    	a1241576728 = (a2061425267 - 4);
    	a30494462 = (((((a1018383389 * a1254983042) % 14999) - 23152) - 5032) - 1184);
    	a1774184757 = (((((((a30494462 * a620105235) % 14999) + -26232) - 2558) + 38363) * -1) / 10);
    	a1210910088 = (a2061425267 + -9);
    	a263151501 = 32 ;
    	a965340096 = 32 ;
    	a341216798 = ((((((a160322672 * a1826277115) % 14999) / 5) - -17663) * 10) / 9);
    	a778006913 = a1210910088;
    	a601495656 = 32 ;
    	a1675035970 = (((((a30494462 * a620105235) % 14999) + -26784) - 3075) - 85);
    	a1983740902 = 33 ;
    	a1521644128 = (a1249952537 + -1);
    	a1895304149 = 32 ;
    	a63333937 = ((((((a63333937 * a1675035970) % 14999) % 14932) - 15066) / 5) - 9747);
    	a217799639 = (((((a217799639 * a160322672) + 29103) * -1) / 10) + -19136);
    	a302110279 = 32 ;
    	a2130193413 = ((a2087535773 / a786258498) - -9);
    	a813082108 = (((((a813082108 * a1774184757) % 14999) - 13147) + -687) + -565);
    	a1318526106 = 32 ;
    	a1985899004 = ((((((a1985899004 * a63333937) % 14999) + -9182) * 10) / 9) * 1);
    	a1625516355 = (((((a1625516355 * a217799639) % 14999) + -22447) - 1453) / 5);
    	a1151361287 = (((((a1151361287 * a341216798) % 14999) - -5763) - 35188) + -30);
    	a983758263 = ((((((a983758263 * a1254983042) % 14999) - -4473) * 1) - 5133) - 14998);
    	a1249952537 = (a263219509 - 6);
    	a2073482783 = 32 ;
    	a2087535773 = (a1830659124 - 8);
    	a1125477212 = 32 ;
    	a786258498 = ((a1210910088 + a1478681170) - -2);
    	a1830659124 = (a4442917 - -2);
    	a2130183577 = (((((a2130183577 * a260539918) % 14999) / 5) * 5) - 14989);
    	a708839806 = 32 ;
    	a999024345 = (((((a999024345 * a63333937) % 14999) - 12227) * 1) / 5);
    	a1211013485 = 32 ;
    	a709568404 = 32 ;
    	a1644957382 = 32 ;
    	a4442917 = (a190525986 + -4);
    	a260539918 = (((((a260539918 * a2130183577) % 14999) / 5) + -12232) + -12184);
    	a1916853335 = (a2026977784 - 2);
    	a1254983042 = (((((a1254983042 * a1018383389) % 14999) + 14354) + -43848) * 1); 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm240(int input) {
    if(((((202 < a1254983042) && (414 >= a1254983042)) && ((input == 7) &&  cf==1 )) && ((a1241576728 == 8 && (((124 < a30494462) && (296 >= a30494462)) && (((104 < a813082108) && (243 >= a813082108)) && a709568404 == 34))) && ((131 < a999024345) && (260 >= a999024345))))) {
    	cf = 0;
    	a1774184757 = ((((a1625516355 * a1018383389) / 5) + -15412) + -1796);
    	a999024345 = (((((a30494462 * a1774184757) % 14999) / 5) - 25115) + -1581);
    	a1151361287 = ((((((a1151361287 * a999024345) % 14999) / 5) + -13161) * 10) / 9);
    	a26346326 = 32 ;
    	a1756173294 = (((((a217799639 * a63333937) * 10) / 9) - -11438) + -21834);
    	a1249952537 = (a1210910088 - -1);
    	a4442917 = (a2026977784 + -4);
    	a983758263 = (((((a983758263 * a1826277115) % 14999) / 5) - 11967) + -9393);
    	a1241576728 = (a4442917 - -1);
    	a778006913 = (a661990791 - 5);
    	a1675035970 = (((((a1625516355 * a1774184757) % 14999) + -17650) * 1) + -10513);
    	a2130193413 = (a661990791 - -3);
    	a263151501 = 32 ;
    	a1254983042 = ((((((a999024345 * a1625516355) % 14999) * 2) * 1) / 5) - 14485);
    	a1700231631 = ((a2061425267 / a263219509) - -4);
    	a1959068056 = ((a1916853335 - a2130193413) + 10);
    	a1211013485 = 32 ;
    	a341216798 = ((((((a1826277115 * a1756173294) % 14999) * 2) / 5) % 31) - -265);
    	a217799639 = (((((a1985899004 * a30494462) % 14999) + -25845) / 5) - 6018);
    	a260539918 = (((((a1254983042 * a813082108) % 14999) - 8646) * 1) + 7479);
    	a30494462 = ((((((a999024345 * a1018383389) % 14999) - -9516) % 14969) + -15030) * 1);
    	a786258498 = (a2026977784 + -1);
    	a1985899004 = (((((a1985899004 * a2130183577) % 14999) + -9430) * 1) + -5422);
    	a76745981 = 32 ;
    	a709568404 = 32 ;
    	a1644957382 = 32 ;
    	a1318526106 = 32 ;
    	a813082108 = (((((a813082108 * a999024345) % 14999) + 14632) + -29632) * 1); 
    	 printf("%d\n", 20); fflush(stdout); 
    } if(((a1478681170 == 5 && (a1125477212 == 34 && (a2130193413 == 11 && ((a1916853335 == 7 && ( cf==1  && (input == 12))) && a1180594800 == 34)))) && a1318526106 == 34)) {
    	cf = 0;
    	a1352986605 = (((((a1826277115 * a983758263) % 14999) / 5) + -17670) * 1);
    	a983758263 = (((((((a983758263 * a1352986605) % 14999) / 5) % 101) + 304) + 24003) + -24002);
    	a260339255 = (((((((a983758263 * a1352986605) % 14999) * 2) * 1) - 2) % 15007) + -14992);
    	a1895857334 = (a263219509 - 5); 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm242(int input) {
    if(((((35 < a1774184757) && (169 >= a1774184757)) && a1644957382 == 34) && (((a1983740902 == 34 && (( cf==1  && (input == 4)) && ((207 < a1675035970) && (311 >= a1675035970)))) && a4442917 == 7) && a1830659124 == 11))) {
    	cf = 0;
    	a601495656 = 33 ;
    	a786258498 = ((a263219509 - a1830659124) + 9);
    	a1125477212 = 33 ;
    	a778006913 = (a1210910088 + -1);
    	a2073482783 = 33 ;
    	a813082108 = ((((((a1826277115 * a260539918) % 50) + 53) / 5) - -15238) + -15203);
    	a708839806 = 33 ;
    	a757937656 = (a1210910088 + 6);
    	a4442917 = ((a786258498 / a1210910088) + 3);
    	a1180594800 = 33 ;
    	a1774184757 = ((((((((a620105235 * a620105235) % 14999) % 92) - 134) + 6964) * 4) % 92) - 62);
    	a1018383389 = (((((((a1018383389 * a1254983042) % 14999) % 74) + 36) + 45) - 28107) + 28068);
    	a1644957382 = 33 ;
    	a1625516355 = ((((((a1625516355 * a1151361287) / 5) % 13) + -88) + 17552) + -17558);
    	a2097567994 = 32 ;
    	a217799639 = (((((a217799639 * a813082108) * 4) % 69) - 74) + 11);
    	a1318526106 = 33 ;
    	a1151361287 = ((((((a1774184757 * a1625516355) + 10816) % 86) - -79) / 5) + 96);
    	a63333937 = ((((((a1254983042 * a620105235) % 14999) + 17912) * 1) % 81) + -132);
    	a1211013485 = 33 ;
    	a721272783 = ((a2130193413 - a661990791) + 14);
    	a76745981 = 33 ;
    	a1985899004 = ((((((a1985899004 * a1254983042) % 14999) + -16664) % 98) - -286) * 1);
    	a1959068056 = (a2061425267 + -3);
    	a709568404 = 33 ;
    	a2061425267 = ((a786258498 * a786258498) + -70);
    	a999024345 = (((((((a999024345 * a1675035970) % 14999) % 41) - -80) * 5) % 41) + 87);
    	a30494462 = ((((((a30494462 * a999024345) % 14999) % 92) + -18) + -2374) + 2393);
    	a2130193413 = (a786258498 + 1);
    	a1249952537 = (a1916853335 + -2);
    	a2087535773 = (a786258498 + -5);
    	a1675035970 = ((((((a1675035970 * a30494462) % 14999) + 2410) % 17) - -190) - 1);
    	a1916853335 = ((a1830659124 / a190525986) - -5);
    	a1241576728 = (a2026977784 + -1);
    	a302110279 = 33 ;
    	a1983740902 = 33 ;
    	a983758263 = ((((((a983758263 * a1254983042) % 14999) % 104) - 4) - -6379) - 6294);
    	a26346326 = 33 ;
    	a1210910088 = (a1830659124 + -9);
    	a1830659124 = ((a786258498 * a1478681170) + -35);
    	a2130183577 = (((((a620105235 * a260539918) / 5) + -9135) % 63) - -200);
    	a1478681170 = (a786258498 - 5);
    	a1254983042 = (((((((a1254983042 * a620105235) % 14999) % 101) + 100) - -20633) / 5) - 4010); 
    	 printf("%d\n", 17); fflush(stdout); 
    } if(((a778006913 == 3 && ((((167 < a1018383389) && (211 >= a1018383389)) && a1959068056 == 10) && a2087535773 == 5)) && (a709568404 == 34 && (a302110279 == 34 && ((input == 7) &&  cf==1 ))))) {
    	cf = 0;
    	a260539918 = (((((a1151361287 * a2130183577) % 14999) / 5) + -15425) * 1);
    	a1675035970 = (((((a1675035970 * a260539918) % 14999) - 782) - 6572) * 1);
    	a778006913 = (a1916853335 + -6);
    	a263151501 = 32 ;
    	a1213722969 = ((a1478681170 - a661990791) - -16);
    	a1241576728 = (a786258498 - 4);
    	a1830659124 = (a1249952537 + 3);
    	a341216798 = (((((a1826277115 * a1826277115) % 15098) + -14900) / 5) * 5);
    	a999024345 = (((((a999024345 * a813082108) % 14999) / 5) - -25817) / -5);
    	a709568404 = 32 ;
    	a1478681170 = (a2087535773 - 2);
    	a1018383389 = (((((((a1018383389 * a1774184757) % 14999) - 10250) - 8936) - 7901) % 74) - -108);
    	a834646264 = (a2061425267 - 6);
    	a30494462 = (((((((a30494462 * a1826277115) % 14999) % 14969) - 15030) - 1) - -11068) + -11067);
    	a1644957382 = 32 ;
    	a302110279 = 33 ;
    	a983758263 = ((((((a983758263 * a341216798) % 14999) % 14997) + -15002) + -1) * 1);
    	a1151361287 = ((((((a1151361287 * a813082108) % 14999) - 8735) * 3) % 86) + 162);
    	a2073482783 = 32 ;
    	a1180594800 = 32 ;
    	a1959068056 = ((a1213722969 / a1210910088) - -5);
    	a1895304149 = 32 ;
    	a1254983042 = (((((a1254983042 * a260539918) % 14999) + -7121) * 1) + -559);
    	a813082108 = ((((((a813082108 * a1625516355) * 10) / 9) * 10) / 9) - 5171);
    	a1210910088 = (a1830659124 + -8);
    	a2087535773 = ((a263219509 + a263219509) - 19);
    	a1625516355 = (((((((a1625516355 * a2130183577) % 14999) * 2) * 1) + 2) % 13) + -93);
    	a4442917 = (a2130193413 - 6);
    	a26346326 = 32 ;
    	a620105235 = ((((((a260539918 * a1774184757) % 14999) - 11592) * 10) / 9) - 173);
    	a786258498 = (a778006913 - -7); 
    	 printf("%d\n", 18); fflush(stdout); 
    } if(((((input == 9) &&  cf==1 ) && ((207 < a1675035970) && (311 >= a1675035970))) && (((202 < a1254983042) && (414 >= a1254983042)) && ((a263151501 == 34 && (a2073482783 == 34 && ((124 < a30494462) && (296 >= a30494462)))) && a1830659124 == 11)))) {
    	cf = 0;
    	a1569588614 = ((((a1774184757 * a1625516355) + 18203) * 1) * 1);
    	a1959068056 = ((a786258498 / a1241576728) - -8);
    	a263151501 = 33 ;
    	a1180594800 = 33 ;
    	a786258498 = (a190525986 + -1);
    	a1625516355 = (((((((a217799639 * a1985899004) % 14999) % 13) - 94) - -19331) + 5135) - 24467);
    	a26346326 = 33 ;
    	a813082108 = ((((((((a813082108 * a1826277115) % 14999) % 50) + 54) * 5) + -15964) % 50) - -91);
    	a709568404 = 33 ;
    	a1675035970 = (((((((a1675035970 * a983758263) % 14999) - 2391) / 5) - -21920) % 17) - -172);
    	a1830659124 = a661990791;
    	a1125477212 = 33 ;
    	a30494462 = ((((((a30494462 * a983758263) % 14999) - 24147) / 5) % 92) - -91);
    	a721272783 = (a4442917 - -5);
    	a1597554373 = 33 ;
    	a4442917 = ((a1916853335 + a2061425267) + -13);
    	a2130193413 = a661990791;
    	a983758263 = (((((((a983758263 * a1569588614) % 14999) % 104) + -5) + -21280) + 7721) + 13603);
    	a1210910088 = (a1249952537 - 4);
    	a1241576728 = (a2061425267 - 5); 
    	 printf("%d\n", 26); fflush(stdout); 
    } 
}
 void calculate_outputm244(int input) {
    if((((a708839806 == 34 && (((-160 < a620105235) && (30 >= a620105235)) && a1959068056 == 10)) && ((167 < a1018383389) && (211 >= a1018383389))) && (((249 < a1151361287) && (291 >= a1151361287)) && (((input == 2) &&  cf==1 ) && a2061425267 == 12)))) {
    	cf = 0;
    	a2026977784 = (a1249952537 + 1);
    	a4442917 = (a2130193413 - 6);
    	a620105235 = ((((((a620105235 * a2130183577) % 14999) * 2) % 14909) - 15090) * 1);
    	a1644957382 = 32 ;
    	a1318526106 = 32 ;
    	a1521644128 = ((a190525986 * a1916853335) + -72);
    	a983758263 = ((((((a983758263 * a1826277115) % 14999) % 14997) + -15002) * 1) + -2);
    	a302110279 = 32 ;
    	a601495656 = 32 ;
    	a2087535773 = ((a2026977784 + a4442917) - 9);
    	a2130183577 = ((((a260539918 * a260539918) + -24500) * 1) + -1172);
    	a2130193413 = ((a2026977784 / a1249952537) + 8);
    	a1830659124 = (a786258498 - 1);
    	a999024345 = ((((((a999024345 * a1774184757) % 14999) / 5) - -1274) / 5) * -5);
    	a341216798 = ((((((a1826277115 * a1985899004) % 14999) * 2) % 14850) - -15148) + 1);
    	a813082108 = (((((a813082108 * a1018383389) % 14999) - 21914) * 1) - 6430);
    	a1241576728 = ((a1830659124 * a2061425267) + -102);
    	a1625516355 = ((((((a822442096 * a822442096) % 14999) + -19754) - 2266) + 15842) - 18548);
    	a1774184757 = ((((((a1774184757 * a1985899004) % 14999) - 20792) + -7479) + 14797) + -12749);
    	a965340096 = 32 ;
    	a217799639 = (((((a217799639 * a1018383389) + 23932) - 32470) - -16914) - 16603);
    	a778006913 = ((a1478681170 + a4442917) - 9);
    	a190525986 = (a778006913 - -8);
    	a1151361287 = (((((a1151361287 * a1985899004) % 14999) - 21242) * 1) / 5);
    	a260539918 = (((((((a63333937 * a30494462) % 14999) + -19534) * 1) + 34276) * -1) / 10);
    	a1125477212 = 32 ;
    	a2061425267 = a786258498;
    	a263151501 = 32 ;
    	a1916853335 = (a263219509 + -7);
    	a1210910088 = (a1959068056 - 9);
    	a1985899004 = ((((((a1985899004 * a1675035970) % 14999) - -7448) * 1) / 5) + -5672);
    	a26346326 = 32 ;
    	a786258498 = (a1959068056 - 2);
    	a708839806 = 32 ;
    	a709568404 = 32 ;
    	a1983740902 = 33 ;
    	a1959068056 = ((a1249952537 + a4442917) + -3);
    	a1249952537 = (a2026977784 + -3); 
    	 printf("%d\n", 26); fflush(stdout); 
    } if(((a778006913 == 3 && ((a2130193413 == 11 && a709568404 == 34) && ((-59 < a217799639) && (-1 >= a217799639)))) && ((((input == 6) &&  cf==1 ) && ((35 < a1774184757) && (169 >= a1774184757))) && a601495656 == 34))) {
    	cf = 0;
    	a601495656 = 32 ;
    	a786258498 = ((a2130193413 + a2130193413) - 14);
    	a983758263 = ((((((a983758263 * a999024345) % 14999) + -16092) + -8437) - -20442) - 24180);
    	a1959068056 = (a2061425267 + -4);
    	a341216798 = ((((((a983758263 * a2130183577) % 14999) / 5) - 18276) * 10) / 9);
    	a1625516355 = (((((((a1254983042 * a1675035970) % 14999) * 2) / 5) / 5) % 13) - 93);
    	a1318526106 = 32 ;
    	a999024345 = (((((a620105235 * a341216798) % 14999) / 5) + -22104) * 1);
    	a1241576728 = (a786258498 + -2);
    	a2087535773 = ((a190525986 + a4442917) - 15);
    	a1213722969 = ((a1830659124 - a1916853335) - -7);
    	a1210910088 = (a1959068056 - 7);
    	a26346326 = 32 ;
    	a709568404 = 32 ;
    	a1644957382 = 32 ;
    	a834646264 = ((a1213722969 / a778006913) + 3);
    	a1830659124 = ((a1249952537 + a1210910088) - -2);
    	a813082108 = ((((((a813082108 * a260539918) % 14999) * 2) * 1) % 15001) + -14997);
    	a2130183577 = (((((a1254983042 * a1254983042) % 14999) - 22220) + -4963) / 5);
    	a778006913 = (a786258498 + -7);
    	a620105235 = (((((a620105235 * a1826277115) - 12302) * 1) % 14909) + -15090);
    	a1151361287 = (((((((a1151361287 * a63333937) % 14999) % 86) - -161) + -241) + -14322) + 14563);
    	a260539918 = (((((a217799639 * a1254983042) % 14999) - 23637) - 6100) - 19);
    	a4442917 = a1478681170;
    	a1478681170 = ((a786258498 * a263219509) + -93);
    	a302110279 = 33 ;
    	a708839806 = 32 ;
    	a263151501 = 32 ;
    	a1018383389 = (((((((a1018383389 * a983758263) % 14999) / 5) - 22310) * 1) % 74) + 104); 
    	 printf("%d\n", 20); fflush(stdout); 
    } if(((((167 < a1018383389) && (211 >= a1018383389)) && (((371 < a1985899004) && (524 >= a1985899004)) && (a1125477212 == 34 && ((249 < a1151361287) && (291 >= a1151361287))))) && ((a786258498 == 10 && ((input == 9) &&  cf==1 )) && a601495656 == 34))) {
    	cf = 0;
    	a1700231631 = ((a2061425267 * a1959068056) + -113);
    	a721272783 = ((a190525986 - a1249952537) - -12);
    	a30494462 = (((((a1625516355 * a1625516355) + -5646) % 92) - -28) / 5);
    	a2130183577 = (((((a2130183577 * a1625516355) % 63) + 190) + 2) - -16);
    	a263151501 = 33 ;
    	a1916853335 = (a1700231631 - 1);
    	a601495656 = 33 ;
    	a1675035970 = (((((a1826277115 * a1826277115) % 17) - -190) + -1) + -1);
    	a1830659124 = ((a1916853335 + a721272783) - 13);
    	a786258498 = ((a778006913 / a1830659124) + 9);
    	a999024345 = (((((((a999024345 * a813082108) % 14999) / 5) / 5) - 2124) % 41) - -99);
    	a1018383389 = (((((((a1018383389 * a620105235) % 14999) - 12724) % 74) + 91) + -9399) - -9400);
    	a1241576728 = ((a263219509 * a2130193413) - 125);
    	a63333937 = ((((((a30494462 * a822442096) + -2761) % 81) + -53) + 24418) + -24417);
    	a1180594800 = 34 ;
    	a190525986 = (a786258498 + 1);
    	a834646264 = ((a1210910088 - a1478681170) + 11);
    	a1211013485 = 33 ;
    	a1983740902 = 33 ;
    	a2073482783 = 33 ;
    	a1895304149 = 33 ;
    	a1210910088 = (a1249952537 + -4);
    	a813082108 = ((((((a822442096 * a1675035970) % 14999) - -6100) + -18305) % 50) + 54);
    	a217799639 = ((((((a217799639 * a260539918) * 3) % 69) - 128) / 5) - 138);
    	a2061425267 = ((a778006913 - a2130193413) + 19);
    	a778006913 = (a4442917 - 5);
    	a76745981 = 34 ;
    	a1985899004 = (((((((a1985899004 * a1826277115) % 14999) * 2) % 98) - -273) - -22492) - 22491);
    	a709568404 = 33 ;
    	a1254983042 = ((((((a1625516355 * a2130183577) % 101) + 178) * 9) / 10) - -1);
    	a983758263 = (((((((a983758263 * a822442096) % 14999) + 13716) % 104) + 44) * 9) / 10);
    	a620105235 = (((((((a620105235 * a1254983042) % 14999) + -9382) + 17864) * 1) % 10) + -169);
    	a26346326 = 33 ;
    	a1125477212 = 33 ;
    	a1151361287 = (((((((a1151361287 * a1774184757) % 14999) % 86) + 144) * 5) % 86) + 132);
    	a1644957382 = 33 ;
    	a1774184757 = ((((((a1774184757 * a1675035970) % 14999) / 5) % 92) + -68) + 11);
    	a2130193413 = ((a721272783 + a1700231631) + -14);
    	a1249952537 = ((a721272783 * a1700231631) - 114); 
    	 printf("%d\n", 19); fflush(stdout); 
    } if(((a1983740902 == 34 && ((230 < a2130183577) && (255 >= a2130183577))) && (((((35 < a1774184757) && (169 >= a1774184757)) && (a1916853335 == 7 && ( cf==1  && (input == 13)))) && a1318526106 == 34) && ((-8 < a260539918) && (140 >= a260539918))))) {
    	cf = 0;
    	a1895304149 = 32 ;
    	a2026977784 = (a786258498 - 1);
    	a2073482783 = 32 ;
    	a1675035970 = (((((a1774184757 * a999024345) % 14999) + -15442) - 10529) - 2051);
    	a1625516355 = ((((((a260539918 * a260539918) * 1) % 13) + -94) / 5) + -71);
    	a1254983042 = (((((a1018383389 * a217799639) - 2413) * 10) / 9) + -3487);
    	a1180594800 = 32 ;
    	a76745981 = 32 ;
    	a30494462 = ((((((a1826277115 * a1985899004) % 14999) % 14969) + -15030) + -2) - 0);
    	a1211013485 = 32 ;
    	a63333937 = (((((a260539918 * a822442096) % 14932) - 15066) + -1) * 1); 
    	 printf("%d\n", 17); fflush(stdout); 
    } 
}
 void calculate_outputm22(int input) {
    if(((((202 < a1254983042) && (414 >= a1254983042)) && (( cf==1  && a263219509 == 5) && a26346326 == 34)) && (a708839806 == 34 && ((((104 < a813082108) && (243 >= a813082108)) && ((-8 < a260539918) && (140 >= a260539918))) && a190525986 == 11)))) {
    	if(((a1895304149 == 34 && (((-81 < a1625516355) && (-5 >= a1625516355)) && ( cf==1  && a1912617323 == 9))) && (a2087535773 == 5 && ((a1916853335 == 7 && a1210910088 == 3) && a2130193413 == 11)))) {
    		calculate_outputm229(input);
    	} 
    	if(((a1180594800 == 34 && (a2130193413 == 11 && (a1916853335 == 7 && a263151501 == 34))) && ((((202 < a1254983042) && (414 >= a1254983042)) && ( cf==1  && a1912617323 == 14)) && a302110279 == 34))) {
    		calculate_outputm231(input);
    	} 
    } 
    if((((((230 < a2130183577) && (255 >= a2130183577)) && ( cf==1  && a263219509 == 7)) && a1644957382 == 34) && (((-8 < a260539918) && (140 >= a260539918)) && ((a1210910088 == 3 && a1895304149 == 34) && a1249952537 == 6)))) {
    	if(((((-81 < a1625516355) && (-5 >= a1625516355)) && (((207 < a1675035970) && (311 >= a1675035970)) && (a1241576728 == 8 && ((104 < a813082108) && (243 >= a813082108))))) && (a1125477212 == 34 && (( cf==1  && a1942901885 == 33) && ((29 < a63333937) && (243 >= a63333937)))))) {
    		calculate_outputm234(input);
    	} 
    } 
    if(((a1478681170 == 5 && ((a302110279 == 34 && (a1959068056 == 10 && ( cf==1  && a263219509 == 8))) && a1318526106 == 34)) && (a601495656 == 34 && ((230 < a2130183577) && (255 >= a2130183577))))) {
    	if(((((a4442917 == 7 && (a1644957382 == 34 && (a2087535773 == 5 && a190525986 == 11))) && a786258498 == 10) && a708839806 == 34) && (a369798198 == 35 &&  cf==1 ))) {
    		calculate_outputm236(input);
    	} 
    } 
    if(((a709568404 == 34 && (a263219509 == 9 &&  cf==1 )) && (a190525986 == 11 && (((249 < a1151361287) && (291 >= a1151361287)) && ((a26346326 == 34 && a1983740902 == 34) && a2087535773 == 5))))) {
    	if(((a1644957382 == 34 && (((a2140773614 == 35 &&  cf==1 ) && a709568404 == 34) && a778006913 == 3)) && ((a1318526106 == 34 && a601495656 == 34) && a708839806 == 34))) {
    		calculate_outputm237(input);
    	} 
    	if((((a26346326 == 34 && a2073482783 == 34) && a302110279 == 34) && (((29 < a63333937) && (243 >= a63333937)) && ((a2130193413 == 11 && ( cf==1  && a2140773614 == 36)) && a786258498 == 10)))) {
    		calculate_outputm238(input);
    	} 
    } 
    if(((((-81 < a1625516355) && (-5 >= a1625516355)) && a263151501 == 34) && ((a2130193413 == 11 && (a2087535773 == 5 && (a1125477212 == 34 && (a263219509 == 10 &&  cf==1 )))) && ((371 < a1985899004) && (524 >= a1985899004))))) {
    	if(((a302110279 == 34 && ((a1318526106 == 34 && a1830659124 == 11) && ((-59 < a217799639) && (-1 >= a217799639)))) && (((((118 < a160322672) && (219 >= a160322672)) &&  cf==1 ) && ((167 < a1018383389) && (211 >= a1018383389))) && ((29 < a63333937) && (243 >= a63333937))))) {
    		calculate_outputm239(input);
    	} 
    } 
    if(((a1249952537 == 6 && ((a1241576728 == 8 && ( cf==1  && a263219509 == 11)) && a1916853335 == 7)) && ((((371 < a1985899004) && (524 >= a1985899004)) && a263151501 == 34) && ((-81 < a1625516355) && (-5 >= a1625516355))))) {
    	if(((((249 < a1151361287) && (291 >= a1151361287)) && ( cf==1  && a661990791 == 6)) && (a1249952537 == 6 && (((a1180594800 == 34 && a1210910088 == 3) && ((167 < a1018383389) && (211 >= a1018383389))) && a2026977784 == 9)))) {
    		calculate_outputm240(input);
    	} 
    	if(((((( cf==1  && a661990791 == 10) && ((207 < a1675035970) && (311 >= a1675035970))) && a2073482783 == 34) && ((124 < a30494462) && (296 >= a30494462))) && ((((131 < a999024345) && (260 >= a999024345)) && a1180594800 == 34) && a1959068056 == 10))) {
    		calculate_outputm242(input);
    	} 
    } 
    if(((a302110279 == 34 && (((35 < a1774184757) && (169 >= a1774184757)) && a1830659124 == 11)) && (((167 < a1018383389) && (211 >= a1018383389)) && (((131 < a999024345) && (260 >= a999024345)) && (a2087535773 == 5 && (a263219509 == 12 &&  cf==1 )))))) {
    	if((((((249 < a1151361287) && (291 >= a1151361287)) && (a2087535773 == 5 && (((13 < a822442096) && (214 >= a822442096)) &&  cf==1 ))) && ((371 < a1985899004) && (524 >= a1985899004))) && (((-160 < a620105235) && (30 >= a620105235)) && (((167 < a1018383389) && (211 >= a1018383389)) && a1241576728 == 8)))) {
    		calculate_outputm244(input);
    	} 
    } 
}
 void calculate_outputm247(int input) {
    if((((((230 < a2130183577) && (255 >= a2130183577)) && ( cf==1  && (input == 2))) && a1478681170 == 5) && (((a263151501 == 34 && a1241576728 == 8) && a709568404 == 34) && ((207 < a1675035970) && (311 >= a1675035970))))) {
    	cf = 0;
    	a708839806 = 33 ;
    	a1478681170 = ((a1241576728 + a1249952537) - 9);
    	a803418896 = ((((((a1826277115 * a1826277115) % 14999) / 5) + 4318) % 89) + -119);
    	a1895304149 = 33 ;
    	a1644957382 = 34 ;
    	a1241576728 = ((a2061425267 * a1478681170) + -37);
    	a709568404 = 33 ;
    	a1318526106 = 33 ;
    	a1348848030 = (a2130193413 + -2);
    	a983758263 = ((((((a983758263 * a1985899004) % 14999) % 104) + -4) - -6574) + -6549);
    	a1211013485 = 33 ;
    	a1210910088 = (a190525986 - 8);
    	a1180594800 = 33 ;
    	a4442917 = (a2087535773 - -2);
    	a30494462 = ((((((a30494462 * a1254983042) % 14999) - 1946) % 92) - -32) / 5);
    	a1125477212 = 34 ;
    	a263151501 = 33 ;
    	a721272783 = a1959068056;
    	a2130193413 = (a1959068056 + 1);
    	a217799639 = ((((((a1018383389 * a1254983042) % 14999) - 6961) % 28) - 28) - 2);
    	a786258498 = ((a1830659124 / a1348848030) - -8);
    	a999024345 = (((((((a999024345 * a1675035970) % 14999) % 41) - -71) * 10) / 9) + -29);
    	a63333937 = ((((((a63333937 * a620105235) % 14999) % 81) + -52) + 17233) - 17233);
    	a2130183577 = (((((((a2130183577 * a260539918) % 14999) - -13494) / 5) - -21291) % 63) + 140);
    	a778006913 = (a1521644128 - 5);
    	a26346326 = 33 ;
    	a601495656 = 34 ;
    	a1959068056 = ((a721272783 / a1348848030) - -8);
    	a1985899004 = ((((((((a1985899004 * a803418896) % 14999) % 76) - -447) * 5) + 26022) % 76) - -441);
    	a813082108 = ((((((a813082108 * a1675035970) % 14999) + -3655) % 50) - -53) * 1);
    	a1675035970 = ((((((((a1675035970 * a983758263) % 14999) % 17) - -188) * 5) * 5) % 17) + 174); 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a1210910088 == 3 && ((-8 < a260539918) && (140 >= a260539918))) && ((((131 < a999024345) && (260 >= a999024345)) && (a1125477212 == 34 && (a709568404 == 34 && ((input == 5) &&  cf==1 )))) && a1895304149 == 34))) {
    	cf = 0;
    	a26346326 = 32 ;
    	a1625516355 = (((((a1774184757 * a1774184757) % 14999) + -24091) * 1) - 2017);
    	a1916853335 = (a2130193413 - 6);
    	a1830659124 = (a2130193413 + -2);
    	a2130183577 = ((((((a1625516355 * a999024345) % 14999) + -5086) * 10) / 9) - 5369);
    	a341216798 = (((((a1826277115 * a983758263) % 14999) - -5083) * 1) - -859);
    	a1210910088 = ((a1830659124 * a1916853335) + -44);
    	a1125477212 = 34 ;
    	a2026977784 = ((a2130193413 + a2130193413) + -15);
    	a1521644128 = (a1478681170 + 3);
    	a983758263 = (((((a983758263 * a63333937) % 14999) + -15362) / 5) - 26147);
    	a601495656 = 32 ;
    	a1895304149 = 32 ;
    	a1151361287 = ((((((a1985899004 * a260539918) % 14999) * 2) + -1) % 15037) + -14961);
    	a260339255 = (((((((a1826277115 * a1826277115) % 14999) % 24) - -34) + 1) - -11696) + -11714);
    	a1211013485 = 32 ;
    	a76745981 = 32 ;
    	a709568404 = 34 ;
    	a2087535773 = (a2130193413 + -8);
    	a1018383389 = (((((a1018383389 * a999024345) % 14999) - 20759) - 7736) - 999);
    	a217799639 = (((((((a1018383389 * a1774184757) % 14999) % 28) - 30) - 1) / 5) - 39);
    	a1254983042 = (((((a1625516355 * a1774184757) % 14999) - 17049) - 12866) + -42);
    	a1959068056 = (a2130193413 + -3);
    	a263151501 = 32 ;
    	a778006913 = (a2087535773 - 2);
    	a1249952537 = (a2130193413 + -7);
    	a1180594800 = 32 ;
    	a786258498 = (a2087535773 - -5);
    	a30494462 = ((((((a30494462 * a2130183577) % 14999) % 14969) + -15030) - 1) - 1);
    	a813082108 = ((((((a813082108 * a2130183577) % 14999) * 2) * 1) % 15001) + -14997);
    	a190525986 = ((a2130193413 * a2130193413) + -112);
    	a708839806 = 34 ;
    	a4442917 = (a1241576728 - 3);
    	a1241576728 = ((a2026977784 / a1521644128) + 6);
    	a63333937 = ((((((a1151361287 * a1151361287) % 14999) % 14932) - 15066) - 3) - 0);
    	a1675035970 = (((((a1675035970 * a2130183577) % 14999) + -14990) + -5) + -1);
    	a620105235 = (((((a1625516355 * a1625516355) % 14999) + -26445) * 1) / 5);
    	a1983740902 = 33 ;
    	a1478681170 = (a2026977784 + -4);
    	a2061425267 = (a2130193413 + 1);
    	a999024345 = (((((a999024345 * a620105235) % 14999) / 5) - 13784) * 1);
    	a1644957382 = 34 ;
    	a1985899004 = ((((((((a1985899004 * a260339255) % 14999) % 76) - -439) * 9) / 10) * 10) / 9);
    	a2130193413 = ((a190525986 / a1249952537) + 7); 
    	 printf("%d\n", 20); fflush(stdout); 
    } 
}
 void calculate_outputm248(int input) {
    if(((a1895304149 == 34 && a1916853335 == 7) && (((-8 < a260539918) && (140 >= a260539918)) && (a190525986 == 11 && ((((input == 14) &&  cf==1 ) && a1249952537 == 6) && a709568404 == 34))))) {
    	cf = 0;
    	a983758263 = (((((((a983758263 * a1826277115) % 14999) % 101) - -204) / 5) - -6014) - 5709);
    	a1895857334 = (a1959068056 - 3);
    	a2004613952 = (a1895857334 + -1);
    	a566060042 = (((((a1826277115 * a1625516355) - -20917) * -1) / 10) + -23171);
    	a76745981 = 32 ;
    	a63333937 = ((((((a63333937 * a999024345) % 14999) + -15791) * 10) / 9) / 5); 
    	 printf("%d\n", 16); fflush(stdout); 
    } 
}
 void calculate_outputm249(int input) {
    if(((a76745981 == 34 && (( cf==1  && (input == 7)) && a708839806 == 34)) && (((((-160 < a620105235) && (30 >= a620105235)) && a2026977784 == 9) && a1830659124 == 11) && ((131 < a999024345) && (260 >= a999024345))))) {
    	cf = 0;
    	a1895857334 = (a1916853335 + 6);
    	a1985899004 = (((((((((a1254983042 * a1018383389) % 14999) % 76) - -425) * 9) / 10) * 5) % 76) + 398);
    	a983758263 = ((((((a983758263 * a999024345) % 14999) % 101) - -211) - -1526) + -1466);
    	a1895304149 = 34 ;
    	a4442917 = (a190525986 - 4);
    	a1318526106 = 34 ;
    	a708839806 = 34 ;
    	a63333937 = ((((((a63333937 * a2130183577) % 14999) - 14101) * 2) % 106) - -137);
    	a2087632595 = 36 ;
    	a1151361287 = ((((((a1151361287 * a620105235) % 14999) - -6303) + 5413) % 20) + 271);
    	a1018383389 = ((((((a30494462 * a1675035970) % 14999) + 6343) / 5) % 21) + 174);
    	a2026977784 = ((a1916853335 + a2130193413) - 9);
    	a709568404 = 34 ;
    	a263151501 = 34 ;
    	a2130193413 = ((a1830659124 + a1895857334) - 13);
    	a1478681170 = ((a2061425267 + a1959068056) - 17);
    	a1180594800 = 34 ;
    	a1125477212 = 34 ;
    	a2130183577 = (((((((a2130183577 * a1826277115) % 14999) % 12) - -237) + -1085) * -3) / 10);
    	a2104091782 = (a1895857334 - 5);
    	a1241576728 = ((a1916853335 - a778006913) - -4); 
    	 printf("%d\n", 16); fflush(stdout); 
    } if((((( cf==1  && (input == 9)) && a190525986 == 11) && a2087535773 == 5) && ((a302110279 == 34 && (((249 < a1151361287) && (291 >= a1151361287)) && a1478681170 == 5)) && ((29 < a63333937) && (243 >= a63333937))))) {
    	cf = 0;
    	a1895857334 = (a778006913 - -8);
    	a1478681170 = (a2130193413 + -8);
    	a1569588614 = (((((a1625516355 * a999024345) - -4729) - -12138) % 80) - 8);
    	a1675035970 = (((((a1675035970 * a1151361287) % 14999) - -10401) * 1) - 32240);
    	a2073482783 = 32 ;
    	a76745981 = 32 ;
    	a63333937 = (((((((a63333937 * a1826277115) % 14999) - 29516) + 35616) - -3042) * -1) / 10);
    	a709568404 = 32 ;
    	a4442917 = (a1241576728 + -3);
    	a1249952537 = (a1521644128 - 4);
    	a983758263 = (((((((a983758263 * a1569588614) % 14999) % 101) - -305) / 5) + -15288) + 15583);
    	a1574467713 = ((a190525986 - a1916853335) - -2);
    	a1983740902 = 34 ;
    	a1125477212 = 34 ;
    	a786258498 = (a2026977784 + -1);
    	a2026977784 = (a1959068056 + -1); 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a1210910088 == 3 && ((((-59 < a217799639) && (-1 >= a217799639)) && ( cf==1  && (input == 11))) && a263151501 == 34)) && (a2130193413 == 11 && (a1895304149 == 34 && ((-160 < a620105235) && (30 >= a620105235)))))) {
    	cf = 0;
    	a2130183577 = ((((((a2130183577 * a217799639) + -8781) / 5) / 5) % 63) - -207);
    	a1249952537 = (a778006913 + 3);
    	a834646264 = ((a1210910088 + a190525986) - 5);
    	a601495656 = 33 ;
    	a965340096 = 35 ;
    	a1211013485 = 33 ;
    	a302110279 = 33 ;
    	a1180594800 = 34 ;
    	a76745981 = 34 ;
    	a1241576728 = ((a2061425267 / a1916853335) + 7);
    	a708839806 = 33 ;
    	a1210910088 = ((a1521644128 * a2061425267) - 118);
    	a217799639 = ((((((a1018383389 * a620105235) % 14999) - -12852) - 21955) % 28) - 30);
    	a1830659124 = (a1521644128 - -1);
    	a813082108 = (((((((a813082108 * a999024345) % 14999) % 50) - -31) * 9) / 10) + -15);
    	a2061425267 = (a2087535773 + 6); 
    	 printf("%d\n", 16); fflush(stdout); 
    } if(((((((230 < a2130183577) && (255 >= a2130183577)) && a1959068056 == 10) && ((-81 < a1625516355) && (-5 >= a1625516355))) && a2061425267 == 12) && ((a708839806 == 34 && ( cf==1  && (input == 14))) && a2026977784 == 9))) {
    	cf = 0;
    	a1895857334 = (a2087535773 + 8);
    	a2087632595 = 35 ;
    	a1644957382 = 33 ;
    	a1875686186 = ((a190525986 - a2026977784) - -8);
    	a1895304149 = 33 ;
    	a620105235 = ((((((a620105235 * a999024345) % 14999) - 8615) - -19669) % 10) + -169);
    	a1151361287 = (((((((((a1151361287 * a1774184757) % 14999) % 86) - -145) * 9) / 10) * 5) % 86) - -157);
    	a1018383389 = (((((a1018383389 * a217799639) * 2) - -20511) % 74) + 91);
    	a1210910088 = (a1521644128 - 8);
    	a983758263 = (((((((a983758263 * a63333937) % 14999) % 101) - -214) - 30110) * 1) + 30163);
    	a302110279 = 33 ;
    	a778006913 = (a1478681170 + -3); 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm250(int input) {
    if(((a26346326 == 34 && ( cf==1  && (input == 5))) && ((((a778006913 == 3 && a1644957382 == 34) && ((124 < a30494462) && (296 >= a30494462))) && a601495656 == 34) && a76745981 == 34))) {
    	cf = 0;
    	a813082108 = ((((((a1018383389 * a260539918) * 1) + 207) + -13695) % 69) + 174);
    	a1895304149 = 34 ;
    	a404763935 = ((a778006913 + a2061425267) - 4);
    	a1180594800 = 34 ;
    	a350392085 = ((a4442917 / a1240243570) - -9);
    	a1826277115 = (((((a1826277115 * a983758263) % 14999) + 6641) / 5) + 12124);
    	a26346326 = 34 ;
    	a1211013485 = 34 ;
    	a1625516355 = ((((((((a999024345 * a1018383389) % 14999) % 37) + -51) * 9) / 10) + -3655) - -3637);
    	a1985899004 = (((((((a983758263 * a1018383389) % 14999) % 76) - -424) * 9) / 10) - 6); 
    	 printf("%d\n", 18); fflush(stdout); 
    } if(((((input == 8) &&  cf==1 ) && a1830659124 == 11) && ((((207 < a1675035970) && (311 >= a1675035970)) && ((a190525986 == 11 && a1125477212 == 34) && a1318526106 == 34)) && ((29 < a63333937) && (243 >= a63333937))))) {
    	a1785777793 -= (a1785777793 - 20) < a1785777793 ? 4 : 0;
    	cf = 0;
    	a2004613952 = (a1210910088 + 4);
    	a260539918 = ((((((a260539918 * a983758263) % 14999) / 5) % 73) + 66) / 5);
    	a1916853335 = ((a778006913 - a190525986) - -15);
    	a1151361287 = (((((((a1254983042 * a1254983042) % 14999) + -2941) % 20) + 270) / 5) - -232);
    	a1644957382 = 34 ;
    	a1675035970 = (((((((a1675035970 * a30494462) % 14999) + 2814) % 51) - -218) + -28550) - -28565);
    	a217799639 = ((((((((a63333937 * a1254983042) % 14999) % 28) + -34) * 10) / 9) * 9) / 10);
    	a983758263 = (((((((a983758263 * a999024345) % 14999) % 101) - -279) / 5) * 39) / 10);
    	a1180594800 = 34 ;
    	a76745981 = 34 ;
    	a1210910088 = a778006913;
    	a1895857334 = (a1210910088 + 4);
    	a813082108 = ((((((a1254983042 * a1774184757) % 14999) + 10034) - -4680) % 50) - -8);
    	a1895304149 = 34 ;
    	a1357285245 = (a1249952537 - -6);
    	a1625516355 = (((((((a1774184757 * a1774184757) - 27348) % 13) - 94) * 5) % 13) + -84); 
    	 printf("%d\n", 26); fflush(stdout); 
    } if(((a708839806 == 34 && (a1478681170 == 5 && (a1830659124 == 11 && a1249952537 == 6))) && ((( cf==1  && (input == 9)) && a1318526106 == 34) && a601495656 == 34))) {
    	a698359753 += (a698359753 + 20) > a698359753 ? 2 : 0;
    	cf = 0;
    	a2041520547 = 35 ;
    	a983758263 = (((((((a983758263 * a1826277115) % 14999) % 101) - -305) / 5) * 39) / 10);
    	a302110279 = 34 ;
    	a709568404 = 32 ;
    	a813082108 = ((((((a1774184757 * a1774184757) % 50) - -5) / 5) * 89) / 10);
    	a601495656 = 32 ;
    	a4442917 = (a2130193413 - 6);
    	a1895857334 = (a778006913 + 9);
    	a1783229935 = ((a2087535773 - a1241576728) - -12);
    	a1210910088 = (a786258498 - 7);
    	a1625516355 = (((((((a983758263 * a1985899004) % 14999) % 13) + -95) + -26536) + 43303) - 16775);
    	a1478681170 = (a2130193413 + -6);
    	a1644957382 = 34 ;
    	a620105235 = (((((((a620105235 * a1151361287) % 14999) / 5) % 94) + -64) + 13477) + -13478);
    	a1895304149 = 32 ;
    	a1318526106 = 32 ;
    	a2087535773 = (a2061425267 - 7); 
    	 printf("%d\n", 19); fflush(stdout); 
    } if((((((29 < a63333937) && (243 >= a63333937)) && (((-8 < a260539918) && (140 >= a260539918)) && ((167 < a1018383389) && (211 >= a1018383389)))) && a786258498 == 10) && ((( cf==1  && (input == 12)) && a76745981 == 34) && a1959068056 == 10))) {
    	cf = 0;
    	a302110279 = 33 ;
    	a708839806 = 32 ;
    	a1151361287 = (((((a1826277115 * a260539918) % 86) - -161) + -23255) + 23257);
    	a1211013485 = 33 ;
    	a786258498 = (a4442917 + 2);
    	a30494462 = ((((((((a1151361287 * a1151361287) % 14999) % 92) + -9) + -4508) * 5) % 92) - -44);
    	a1895304149 = 33 ;
    	a1012466188 = 34 ;
    	a1210910088 = ((a1478681170 / a1478681170) - -1);
    	a778006913 = (a1240243570 - 5);
    	a76745981 = 32 ;
    	a4442917 = (a1241576728 - 2);
    	a1774184757 = (((((((a1826277115 * a63333937) % 14999) % 92) + -136) - -64) + 23868) - 23925);
    	a721272783 = ((a1959068056 - a1959068056) + 17);
    	a1700231631 = ((a2061425267 - a721272783) + 8);
    	a1985899004 = (((((((a260539918 * a1625516355) % 98) - -273) + -13796) * 2) % 98) - -305);
    	a190525986 = (a1249952537 + 4);
    	a63333937 = (((((a63333937 * a999024345) % 14999) - 20433) / 5) * 5);
    	a2130183577 = (((((((a1985899004 * a1151361287) % 14999) % 63) - -153) + -48) - 7119) - -7157);
    	a1318526106 = 32 ;
    	a1018383389 = ((((((a1625516355 * a1774184757) % 74) + 92) + -1) - -14054) - 14053);
    	a2087535773 = ((a1240243570 + a1830659124) - 14);
    	a26346326 = 33 ;
    	a1644957382 = 33 ;
    	a217799639 = ((((((a1151361287 * a1151361287) % 14999) % 69) - 161) - -28130) - 28123);
    	a1249952537 = ((a1241576728 * a1478681170) - 35);
    	a2061425267 = ((a1210910088 / a1830659124) + 11);
    	a601495656 = 33 ;
    	a1180594800 = 33 ;
    	a983758263 = ((((((a983758263 * a999024345) % 14999) / 5) % 104) + 20) + -9);
    	a620105235 = ((((((a620105235 * a217799639) % 14999) + -8773) / 5) % 10) + -169);
    	a999024345 = ((((((a999024345 * a30494462) % 14999) * 2) % 41) + 89) - -1);
    	a1254983042 = (((((a813082108 * a1625516355) % 101) - -111) / 5) - -30);
    	a1675035970 = ((((((a1675035970 * a1018383389) % 14999) % 17) + 181) - 7) * 1);
    	a1916853335 = (a1241576728 + -2);
    	a263151501 = 33 ;
    	a2073482783 = 33 ;
    	a1959068056 = a786258498;
    	a709568404 = 32 ;
    	a1830659124 = (a1478681170 + 5);
    	a1241576728 = ((a786258498 - a786258498) + 6); 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm256(int input) {
    if(((a2130193413 == 11 && a1895304149 == 34) && (((249 < a1151361287) && (291 >= a1151361287)) && (((202 < a1254983042) && (414 >= a1254983042)) && (a778006913 == 3 && (( cf==1  && (input == 11)) && a2073482783 == 34)))))) {
    	cf = 0;
    	a2073482783 = 33 ;
    	a2087535773 = (a2061425267 + -7);
    	a1348848030 = ((a1959068056 / a4442917) + 13);
    	a4442917 = (a1210910088 + 4);
    	a803418896 = ((((((((a1826277115 * a1826277115) % 14999) + -14570) % 89) - 84) * 5) % 89) + -83);
    	a1254983042 = (((((((a63333937 * a63333937) % 14999) - -13039) % 101) - -48) * 10) / 9);
    	a786258498 = ((a2087535773 / a1210910088) + 7);
    	a709568404 = 33 ;
    	a721272783 = ((a1916853335 - a190525986) + 14);
    	a1895304149 = 33 ;
    	a1916853335 = (a778006913 + 3);
    	a302110279 = 34 ;
    	a983758263 = ((((((a983758263 * a803418896) % 14999) * 2) % 104) - -99) - -1);
    	a1478681170 = (a1916853335 + -2);
    	a190525986 = ((a2061425267 + a2061425267) - 12);
    	a30494462 = ((((((a30494462 * a1625516355) - -15980) / 5) + -21972) % 92) - -51);
    	a1625516355 = ((((((a1625516355 * a1254983042) % 13) + -95) + -6299) / 5) + 1177);
    	a26346326 = 33 ;
    	a1675035970 = ((((((a1675035970 * a1985899004) % 14999) % 17) + 182) / 5) - -139);
    	a999024345 = (((((((a999024345 * a1151361287) % 14999) % 41) - -66) * 5) % 41) + 78);
    	a1644957382 = 33 ;
    	a1151361287 = ((((((((a1151361287 * a1985899004) % 14999) % 86) + 77) - 1) * 5) % 86) - -100);
    	a260539918 = (((((a260539918 * a1018383389) * 1) % 17) - 24) * 1);
    	a1318526106 = 33 ;
    	a1959068056 = (a778006913 + 6);
    	a63333937 = (((((((a63333937 * a620105235) % 14999) % 81) + -53) + -1) - 27743) + 27745); 
    	 printf("%d\n", 18); fflush(stdout); 
    } if((((((input == 15) &&  cf==1 ) && a1895304149 == 34) && ((35 < a1774184757) && (169 >= a1774184757))) && (((167 < a1018383389) && (211 >= a1018383389)) && (((-160 < a620105235) && (30 >= a620105235)) && (a263151501 == 34 && a709568404 == 34))))) {
    	cf = 0;
    	a1345687529 = ((((a1774184757 * a1774184757) + 1148) + 34) * 1);
    	a4442917 = (a834646264 - 3);
    	a620105235 = ((((((((a1345687529 * a1345687529) % 14999) - -7970) % 10) + -173) * 5) % 10) + -165);
    	a1644957382 = 33 ;
    	a1018383389 = (((((a1018383389 * a260539918) % 74) - -93) + -8223) - -8222);
    	a999024345 = (((((((a2130183577 * a620105235) % 14999) % 41) - -90) + 1) + 20141) + -20141);
    	a2073482783 = 33 ;
    	a63333937 = ((((((a63333937 * a1018383389) % 14999) % 81) - 60) + -3557) + 3560);
    	a1675035970 = (((((((a999024345 * a30494462) % 14999) % 17) + 189) - -2) + 20471) - 20484);
    	a1151361287 = (((((((a1826277115 * a1826277115) % 14999) + -20094) * 1) / 5) % 86) + 180);
    	a983758263 = ((((((a983758263 * a1985899004) % 14999) % 104) + -2) - -100) + 1);
    	a778006913 = ((a190525986 - a786258498) + 1);
    	a721272783 = (a2087535773 + 9);
    	a26346326 = 33 ;
    	a1625516355 = ((((((a1625516355 * a1151361287) % 13) - 86) / 5) + -8276) - -8187);
    	a30494462 = (((((((a30494462 * a1675035970) % 14999) % 92) - -15) + -52) - -15156) - 15088);
    	a1478681170 = (a1959068056 + -6);
    	a1891437507 = 35 ;
    	a1895304149 = 33 ;
    	a1254983042 = (((((((a1254983042 * a2130183577) % 14999) % 101) + 29) / 5) * 9) / 10); 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm259(int input) {
    if(((((a1318526106 == 34 && ( cf==1  && (input == 6))) && a1180594800 == 34) && a601495656 == 34) && ((((230 < a2130183577) && (255 >= a2130183577)) && a1210910088 == 3) && a1241576728 == 8))) {
    	a1785777793 += (a1785777793 + 20) > a1785777793 ? 1 : 0;
    	cf = 0;
    	a778006913 = ((a1916853335 - a2087535773) + -3);
    	a999024345 = ((((((a1254983042 * a1151361287) % 14999) - 14990) + 17372) * 1) - 17378);
    	a76745981 = 32 ;
    	a1521644128 = ((a1241576728 - a1959068056) - -6);
    	a1318526106 = 33 ;
    	a217799639 = (((((a217799639 * a1018383389) / 5) - 2096) * 10) / 9);
    	a1550739565 = ((a1478681170 * a2061425267) + -49);
    	a30494462 = ((((((a30494462 * a1675035970) % 14999) - 2383) - 14848) * 10) / 9);
    	a813082108 = ((((((a813082108 * a999024345) % 14999) + 2718) / 5) - -14738) + -41042);
    	a1895304149 = 32 ;
    	a341216798 = ((((a1625516355 * a1774184757) - 5257) - -35284) + 12);
    	a983758263 = (((((((a983758263 * a341216798) % 14999) + -17489) + 5905) * 2) % 14997) - 15002);
    	a1644957382 = 33 ;
    	a4442917 = ((a1241576728 + a1916853335) + -10);
    	a1959068056 = (a190525986 - 1);
    	a1625516355 = ((((((a1985899004 * a63333937) % 14999) / 5) * 5) % 14945) - 15053);
    	a260539918 = ((((((a260539918 * a30494462) % 14999) + 9426) - 6031) % 14978) - 15021);
    	a1774184757 = (((((a1826277115 * a1151361287) % 14999) / 5) - 23356) * 1);
    	a263151501 = 32 ;
    	a2073482783 = 32 ;
    	a1675035970 = (((((a1675035970 * a217799639) % 14999) + -434) - 9712) + -1906);
    	a63333937 = (((((((a260539918 * a217799639) % 14999) / 5) + -25187) - -37006) * -1) / 10);
    	a2130183577 = (((((a2130183577 * a341216798) % 14999) + -15441) + -14043) - 496);
    	a1180594800 = 32 ;
    	a1241576728 = ((a786258498 - a2130193413) + 5);
    	a786258498 = (a1830659124 - 1); 
    	 printf("%d\n", 18); fflush(stdout); 
    } 
}
 void calculate_outputm23(int input) {
    if(((a76745981 == 34 && ((a786258498 == 10 && a1895304149 == 34) && a1318526106 == 34)) && (a708839806 == 34 && (((104 < a813082108) && (243 >= a813082108)) && ( cf==1  && a965340096 == 32))))) {
    	if(((a1959068056 == 10 && (a26346326 == 34 && (a1211013485 == 34 && (( cf==1  && a1521644128 == 7) && ((131 < a999024345) && (260 >= a999024345)))))) && (a601495656 == 34 && a1180594800 == 34))) {
    		calculate_outputm247(input);
    	} 
    	if(((a26346326 == 34 && (((35 < a1774184757) && (169 >= a1774184757)) && ((a1521644128 == 8 &&  cf==1 ) && a1959068056 == 10))) && ((((202 < a1254983042) && (414 >= a1254983042)) && a1916853335 == 7) && ((-81 < a1625516355) && (-5 >= a1625516355))))) {
    		calculate_outputm248(input);
    	} 
    	if((((((35 < a1774184757) && (169 >= a1774184757)) && (( cf==1  && a1521644128 == 10) && ((29 < a63333937) && (243 >= a63333937)))) && ((207 < a1675035970) && (311 >= a1675035970))) && ((((202 < a1254983042) && (414 >= a1254983042)) && a1125477212 == 34) && a76745981 == 34))) {
    		calculate_outputm249(input);
    	} 
    } 
    if(((((a1180594800 == 34 && (a965340096 == 33 &&  cf==1 )) && a778006913 == 3) && a2087535773 == 5) && (((-160 < a620105235) && (30 >= a620105235)) && (a601495656 == 34 && ((207 < a1675035970) && (311 >= a1675035970)))))) {
    	if((((((131 < a999024345) && (260 >= a999024345)) && a1478681170 == 5) && a1211013485 == 34) && (a1895304149 == 34 && (a263151501 == 34 && (( cf==1  && a1240243570 == 7) && a1241576728 == 8))))) {
    		calculate_outputm250(input);
    	} 
    } 
    if(((((167 < a1018383389) && (211 >= a1018383389)) && ((a1478681170 == 5 && a2087535773 == 5) && a2130193413 == 11)) && (a26346326 == 34 && (( cf==1  && a965340096 == 35) && a1983740902 == 34)))) {
    	if(((a1318526106 == 34 && (a834646264 == 9 &&  cf==1 )) && ((((167 < a1018383389) && (211 >= a1018383389)) && (a1125477212 == 34 && (((371 < a1985899004) && (524 >= a1985899004)) && ((-81 < a1625516355) && (-5 >= a1625516355))))) && a2026977784 == 9))) {
    		calculate_outputm256(input);
    	} 
    } 
    if((((( cf==1  && a965340096 == 36) && a2061425267 == 12) && ((207 < a1675035970) && (311 >= a1675035970))) && ((((104 < a813082108) && (243 >= a813082108)) && (((-81 < a1625516355) && (-5 >= a1625516355)) && a1241576728 == 8)) && a76745981 == 34))) {
    	if((((a601495656 == 34 && ( cf==1  && a358386401 == 2)) && a1895304149 == 34) && ((a1916853335 == 7 && (((-59 < a217799639) && (-1 >= a217799639)) && ((230 < a2130183577) && (255 >= a2130183577)))) && a1959068056 == 10))) {
    		calculate_outputm259(input);
    	} 
    } 
}
 void calculate_outputm261(int input) {
    if(((((-160 < a620105235) && (30 >= a620105235)) && (((104 < a813082108) && (243 >= a813082108)) && ((a1249952537 == 6 && ( cf==1  && (input == 2))) && ((35 < a1774184757) && (169 >= a1774184757))))) && (a2026977784 == 9 && a1830659124 == 11))) {
    	cf = 0;
    	a2130193413 = (a1210910088 - -7);
    	a1249952537 = (a1830659124 - 5);
    	a1318526106 = 32 ;
    	a1895857334 = ((a2061425267 - a1959068056) + 6);
    	a813082108 = (((((a813082108 * a999024345) % 14999) + -11168) / 5) + -11613);
    	a601495656 = 32 ;
    	a369798198 = 36 ;
    	a983758263 = (((((((a983758263 * a1774184757) % 14999) - -5980) / 5) * 5) % 101) + 270);
    	a190525986 = (a1895857334 - -2);
    	a1260876233 = (((((a1254983042 * a1018383389) % 14999) - 26025) + -748) - 2883);
    	a1675035970 = (((((a1675035970 * a983758263) % 14999) + -22045) - 3260) + -1377); 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm262(int input) {
    if((((input == 7) &&  cf==1 ) && ((((202 < a1254983042) && (414 >= a1254983042)) && (((249 < a1151361287) && (291 >= a1151361287)) && (((-160 < a620105235) && (30 >= a620105235)) && (((230 < a2130183577) && (255 >= a2130183577)) && a1895304149 == 34)))) && ((29 < a63333937) && (243 >= a63333937))))) {
    	cf = 0;
    	a1959068056 = (a1478681170 - -5);
    	a548050643 = 35 ;
    	a1830659124 = ((a1916853335 * a786258498) - 59);
    	a1895304149 = 34 ;
    	a709568404 = 34 ;
    	a620105235 = ((((((a620105235 * a1985899004) % 14999) % 94) - 64) / 5) + 22);
    	a1125477212 = 34 ;
    	a404763935 = ((a2130193413 + a1241576728) + -5);
    	a2130193413 = (a1478681170 + 6);
    	a2061425267 = ((a778006913 + a786258498) + -1);
    	a1249952537 = (a786258498 + -4);
    	a601495656 = 34 ;
    	a1318526106 = 34 ;
    	a2073482783 = 34 ;
    	a26346326 = 34 ;
    	a217799639 = (((((((a30494462 * a1625516355) - -16612) % 28) - 28) * 5) % 28) - 26);
    	a1211013485 = 34 ;
    	a30494462 = (((((((a30494462 * a1675035970) % 14999) % 85) - -196) - -4) + 11307) - 11313);
    	a1241576728 = (a2026977784 + -1); 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((((207 < a1675035970) && (311 >= a1675035970)) && (a1644957382 == 34 && a1318526106 == 34)) && (a190525986 == 11 && (a1249952537 == 6 && (( cf==1  && (input == 15)) && a1830659124 == 11))))) {
    	cf = 0;
    	a620105235 = ((((((a620105235 * a1826277115) % 14999) % 94) + -64) - -1) + -1);
    	a1574467713 = (a1916853335 + -6);
    	a1210910088 = (a2130193413 - 8);
    	a1983740902 = 34 ;
    	a983758263 = ((((((a983758263 * a999024345) % 14999) % 101) + 262) + -14597) - -14558);
    	a1318526106 = 34 ;
    	a263638061 = ((a1574467713 + a1478681170) + 5);
    	a2026977784 = (a4442917 - -2);
    	a709568404 = 34 ;
    	a1478681170 = (a4442917 + -2);
    	a1895857334 = (a2061425267 - 1);
    	a1249952537 = (a778006913 - -3);
    	a63333937 = (((((((a63333937 * a1254983042) % 14999) - 8401) % 106) - -137) + 14189) - 14188);
    	a778006913 = (a786258498 + -7);
    	a708839806 = 34 ;
    	a302110279 = 34 ;
    	a1625516355 = (((((((a1625516355 * a1675035970) % 37) + -34) * 10) / 9) * 9) / 10);
    	a260539918 = ((((((a1151361287 * a217799639) % 73) - -77) / 5) - 19389) - -19447);
    	a190525986 = (a1241576728 - -3);
    	a813082108 = (((((((a2130183577 * a1151361287) % 14999) - -12102) % 69) - -164) / 5) + 82); 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm263(int input) {
    if(((a1210910088 == 3 && a190525986 == 11) && ((((230 < a2130183577) && (255 >= a2130183577)) && ((a1125477212 == 34 && ( cf==1  && (input == 11))) && a1830659124 == 11)) && a2026977784 == 9))) {
    	a419312954 -= (a419312954 - 20) < a419312954 ? 4 : 0;
    	cf = 0;
    	a1895857334 = (a1210910088 - -8);
    	a302110279 = 34 ;
    	a263638061 = (a778006913 - -8);
    	a1574467713 = ((a1916853335 + a1210910088) - 9);
    	a983758263 = (((((((a983758263 * a1826277115) % 14999) - 17649) - -24669) + -14359) % 101) - -305);
    	a708839806 = 34 ;
    	a260539918 = ((((((a1985899004 * a217799639) % 14999) % 73) - -66) - 14753) + 14754);
    	a709568404 = 34 ;
    	a1249952537 = ((a1241576728 / a1478681170) + 5);
    	a1478681170 = (a1895857334 - 6);
    	a778006913 = (a786258498 + -7);
    	a813082108 = ((((((((a813082108 * a1675035970) % 14999) + 7717) % 69) - -169) * 5) % 69) - -140);
    	a63333937 = (((((((a983758263 * a1151361287) % 14999) + -21897) / 5) + -9491) % 106) + 204);
    	a620105235 = ((((((a1254983042 * a2130183577) % 14999) / 5) % 94) - 144) + 69);
    	a1625516355 = (((((((a1625516355 * a30494462) % 37) - 29) * 5) - 8397) % 37) + -34);
    	a190525986 = ((a1241576728 * a1830659124) + -77);
    	a2026977784 = (a1895857334 - 2);
    	a1983740902 = 34 ;
    	a1318526106 = 34 ;
    	a1210910088 = (a786258498 + -7); 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((((((124 < a30494462) && (296 >= a30494462)) && ((input == 6) &&  cf==1 )) && a2061425267 == 12) && a1895304149 == 34) && (((104 < a813082108) && (243 >= a813082108)) && (a76745981 == 34 && a709568404 == 34)))) {
    	cf = 0;
    	a1683451995 = ((a1241576728 / a404763935) - -6);
    	a2004613952 = ((a4442917 * a1478681170) - 23);
    	a1895857334 = ((a1830659124 - a1683451995) + 2);
    	a983758263 = (((((((a983758263 * a2130183577) % 14999) - 17578) - -3999) * 2) % 101) + 304); 
    	 printf("%d\n", 19); fflush(stdout); 
    } 
}
 void calculate_outputm266(int input) {
    if(((a1959068056 == 10 && (((-8 < a260539918) && (140 >= a260539918)) && a1210910088 == 3)) && (a1241576728 == 8 && ((( cf==1  && (input == 2)) && a76745981 == 34) && a2073482783 == 34)))) {
    	a1785777793 += (a1785777793 + 20) > a1785777793 ? 3 : 0;
    	cf = 0;
    	a1574467713 = ((a404763935 + a2061425267) - 22);
    	a1983740902 = 34 ;
    	a302110279 = 34 ;
    	a263638061 = ((a4442917 * a1916853335) + -38);
    	a1478681170 = (a404763935 - 6);
    	a63333937 = ((((((((a1151361287 * a813082108) % 14999) % 106) + 60) * 10) / 9) + 14194) + -14193);
    	a1625516355 = ((((((a1625516355 * a30494462) % 37) - 13) - 16) - -27675) + -27673);
    	a1895857334 = ((a2026977784 * a1249952537) + -43);
    	a708839806 = 34 ;
    	a1249952537 = ((a1241576728 * a350392085) + -74);
    	a709568404 = 34 ;
    	a1210910088 = (a1916853335 - 4);
    	a1318526106 = 34 ;
    	a983758263 = (((((((a983758263 * a999024345) % 14999) + 7588) / 5) / 5) % 101) - -280);
    	a190525986 = a2130193413;
    	a620105235 = (((((((a999024345 * a1675035970) % 14999) / 5) - -531) + 12645) % 94) - 106);
    	a778006913 = ((a786258498 / a2087535773) - -1);
    	a2026977784 = (a2061425267 - 3);
    	a813082108 = ((((((((a813082108 * a260539918) % 14999) + -12271) % 69) + 173) * 5) % 69) - -112);
    	a260539918 = ((((((a260539918 * a1826277115) % 14999) + 8857) % 73) - -65) + 2); 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((((230 < a2130183577) && (255 >= a2130183577)) && (( cf==1  && (input == 7)) && a1125477212 == 34)) && a2087535773 == 5) && ((a1916853335 == 7 && a2061425267 == 12) && a601495656 == 34))) {
    	cf = 0;
    	a1895857334 = (a2061425267 - 1);
    	a983758263 = ((((((a983758263 * a1826277115) % 14999) - 14476) * 2) % 101) + 304);
    	a1625516355 = (((((a1625516355 * a260539918) * 2) + -885) % 37) - 43);
    	a778006913 = ((a1210910088 * a2130193413) - 30);
    	a263638061 = (a350392085 - -1);
    	a1574467713 = (a404763935 + -10);
    	a1478681170 = (a1895857334 - 6);
    	a1249952537 = (a4442917 + -1);
    	a620105235 = ((((((a813082108 * a983758263) % 14999) - 25370) % 94) - -3) - -6);
    	a813082108 = ((((((a217799639 * a30494462) / 5) * 5) * 1) % 69) - -178);
    	a63333937 = ((((((a217799639 * a1985899004) % 14999) / 5) % 106) - -135) - 0);
    	a1983740902 = 34 ;
    	a190525986 = (a1959068056 + 1);
    	a2026977784 = (a1210910088 + 6);
    	a708839806 = 34 ;
    	a302110279 = 34 ;
    	a260539918 = (((((((a999024345 * a1985899004) % 14999) - 14934) % 73) - -67) + -28205) + 28205);
    	a1318526106 = 34 ;
    	a709568404 = 34 ;
    	a1210910088 = (a2087535773 + -2); 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((((a1478681170 == 5 && (a302110279 == 34 && a1959068056 == 10)) && ((-59 < a217799639) && (-1 >= a217799639))) && ((a2061425267 == 12 && ((input == 12) &&  cf==1 )) && a1830659124 == 11))) {
    	a1785777793 += (a1785777793 + 20) > a1785777793 ? 4 : 0;
    	cf = 0;
    	a965340096 = 36 ;
    	a1826277115 = (((((((a1826277115 * a1254983042) % 14999) + 631) + -8720) / 5) % 62) + 116);
    	a358386401 = (a2130193413 + -4); 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm268(int input) {
    if(((a1959068056 == 10 && (((249 < a1151361287) && (291 >= a1151361287)) && ((207 < a1675035970) && (311 >= a1675035970)))) && (a1830659124 == 11 && ((((input == 2) &&  cf==1 ) && a1916853335 == 7) && ((230 < a2130183577) && (255 >= a2130183577)))))) {
    	cf = 0;
    	a1774184757 = (((((((a30494462 * a30494462) % 14999) % 92) - 104) - -1477) * -1) / 10);
    	a1210910088 = (a404763935 + -10);
    	a601495656 = 32 ;
    	a1354435613 = 34 ;
    	a786258498 = ((a1959068056 / a2087535773) + 7);
    	a1318526106 = 33 ;
    	a709568404 = 32 ;
    	a1241576728 = (a786258498 - 2);
    	a721272783 = ((a2026977784 + a4442917) + -5);
    	a76745981 = 33 ;
    	a708839806 = 33 ;
    	a1675035970 = (((((((a1985899004 * a2130183577) % 14999) % 17) + 180) / 5) * 10) / 2);
    	a1254983042 = (((((((a1254983042 * a999024345) % 14999) - 15023) - 4110) - -32284) * -1) / 10);
    	a26346326 = 33 ;
    	a30494462 = ((((((a30494462 * a1826277115) % 14999) % 92) - -24) + -55) / 5);
    	a813082108 = ((((((a813082108 * a999024345) % 14999) + 10561) * 1) / 5) * -5);
    	a190525986 = ((a1241576728 + a1241576728) - 4);
    	a1625516355 = (((((a1625516355 * a1151361287) * 1) + -542) % 13) - 90);
    	a983758263 = ((((((a983758263 * a999024345) % 14999) % 104) + 19) / 5) / 5);
    	a1916853335 = (a786258498 + -3);
    	a1151361287 = (((((((a260539918 * a63333937) / 5) % 86) + 199) / 5) * 49) / 10);
    	a1830659124 = (a1478681170 - -5);
    	a2087535773 = (a1241576728 - 4);
    	a620105235 = (((((a1774184757 * a1774184757) + 4265) + 724) * 1) + -28645);
    	a524719993 = 34 ;
    	a2061425267 = (a1959068056 - -1);
    	a1644957382 = 32 ;
    	a1895304149 = 33 ;
    	a2130183577 = (((((a2130183577 * a999024345) % 14999) + -10941) / 5) + -16310);
    	a63333937 = (((((a1774184757 * a260539918) % 81) - 51) / 5) + -54);
    	a999024345 = (((((((a217799639 * a1675035970) % 14999) % 41) + 89) * 5) % 41) - -62);
    	a4442917 = ((a1210910088 / a2061425267) - -6);
    	a2130193413 = (a1478681170 + 5);
    	a1478681170 = ((a778006913 + a1830659124) - 9);
    	a778006913 = (a1959068056 + -8);
    	a1211013485 = 32 ;
    	a263151501 = 32 ;
    	a2073482783 = 32 ;
    	a1180594800 = 32 ;
    	a1959068056 = (a190525986 + -1); 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a1180594800 == 34 && ((((((249 < a1151361287) && (291 >= a1151361287)) && ((124 < a30494462) && (296 >= a30494462))) && ((207 < a1675035970) && (311 >= a1675035970))) && ((29 < a63333937) && (243 >= a63333937))) && a778006913 == 3)) && ( cf==1  && (input == 14)))) {
    	cf = 0;
    	a620105235 = (((((a999024345 * a1675035970) % 14999) + -18431) + 32687) - 38805);
    	a1644957382 = 32 ;
    	a63333937 = (((((a1774184757 * a1474668405) % 14999) + -11406) - 6216) * 1);
    	a601495656 = 32 ;
    	a1830659124 = ((a1916853335 / a1210910088) + 2);
    	a217799639 = ((((((a1985899004 * a1985899004) % 14999) - 20344) / 5) * 10) / 9);
    	a1478681170 = (a1241576728 + -3);
    	a778006913 = ((a190525986 * a1210910088) + -10);
    	a1983740902 = 34 ;
    	a1959068056 = (a1830659124 - 1);
    	a983758263 = (((((a983758263 * a1826277115) % 14999) + -23662) - -30777) - 30692);
    	a2130193413 = ((a1959068056 + a1830659124) + -8);
    	a1018383389 = (((((((a1474668405 * a999024345) % 14999) + 22884) % 74) + 69) * 10) / 9);
    	a2073482783 = 32 ;
    	a302110279 = 33 ;
    	a2026977784 = ((a404763935 - a778006913) + -4);
    	a1254983042 = (((((a1254983042 * a2130183577) % 14999) - 13344) + -9701) * 1);
    	a1180594800 = 32 ;
    	a1151361287 = (((((a1151361287 * a63333937) % 14999) / 5) + -2561) - 23702);
    	a834646264 = ((a2087535773 / a1916853335) - -12);
    	a263151501 = 32 ;
    	a2130183577 = (((((a1474668405 * a1985899004) % 14999) - 4973) + 21167) + -19274);
    	a260539918 = ((((((a1985899004 * a999024345) % 14999) - 18984) + 8059) + 14156) - 30997);
    	a4442917 = (a404763935 + -7);
    	a786258498 = (a2130193413 + -1);
    	a190525986 = ((a404763935 + a404763935) - 13);
    	a341216798 = (((((a1985899004 * a813082108) % 14999) + -25384) - 3778) - 765);
    	a2087535773 = ((a1210910088 / a1210910088) - -2);
    	a1625516355 = ((((a1625516355 * a813082108) - -9965) + -18046) - 688);
    	a1166237008 = ((((((a341216798 * a1675035970) % 14999) % 14941) + 15057) + 1) - 0);
    	a30494462 = (((((((a30494462 * a999024345) % 14999) - 8753) - -18191) - -2159) * -1) / 10);
    	a1916853335 = (a1241576728 + -1);
    	a1675035970 = (((((a1675035970 * a1166237008) % 14999) + -29351) / 5) * 5);
    	a999024345 = (((((a999024345 * a1474668405) % 14999) + -13332) + -225) - 159);
    	a813082108 = (((((a813082108 * a30494462) % 14999) / 5) + -9485) - 10934);
    	a1985899004 = ((((((a1985899004 * 5) % 76) + 418) * 5) % 76) + 426); 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm270(int input) {
    if((((((249 < a1151361287) && (291 >= a1151361287)) && (a1125477212 == 34 && a1895304149 == 34)) && a1983740902 == 34) && (a778006913 == 3 && (a190525986 == 11 && ( cf==1  && (input == 4)))))) {
    	cf = 0;
    	a1210910088 = ((a1241576728 - a1249952537) - -1);
    	a1625516355 = (((((((a1625516355 * a30494462) % 37) - 19) * 10) / 9) * 10) / 9);
    	a190525986 = (a2087535773 - -6);
    	a2104091782 = ((a786258498 / a2130193413) - -4);
    	a1895857334 = (a1959068056 + 3);
    	a1180594800 = 34 ;
    	a1983740902 = 34 ;
    	a2026977784 = (a778006913 + 6);
    	a2087632595 = 36 ;
    	a1916853335 = ((a786258498 + a1241576728) - 11);
    	a1151361287 = ((((((a1151361287 * a999024345) % 14999) / 5) % 20) - -259) * 1);
    	a1985899004 = ((((((((a2130183577 * a1254983042) % 14999) % 76) + 417) / 5) / 5) * 239) / 10);
    	a708839806 = 34 ;
    	a983758263 = ((((((a983758263 * a2130183577) % 14999) % 101) - -256) - -27974) - 27945);
    	a263151501 = 34 ;
    	a1478681170 = (a2061425267 - 7); 
    	 printf("%d\n", 17); fflush(stdout); 
    } if((((((230 < a2130183577) && (255 >= a2130183577)) && ((a1125477212 == 34 && ( cf==1  && (input == 9))) && a1959068056 == 10)) && a2061425267 == 12) && (a2130193413 == 11 && a1211013485 == 34))) {
    	cf = 0;
    	a1180594800 = 32 ;
    	a302110279 = 34 ;
    	a1318526106 = 32 ;
    	a1478681170 = a778006913;
    	a1675035970 = (((((a1675035970 * a813082108) % 14999) / 5) - -22710) + -45176);
    	a1644957382 = 32 ;
    	a76745981 = 32 ;
    	a708839806 = 32 ;
    	a2004613952 = (a4442917 + 5);
    	a260539918 = ((((((a1774184757 * a1151361287) % 14999) - -13818) - 32019) * 10) / 9);
    	a1683451995 = (a1830659124 - 3);
    	a983758263 = ((((((a983758263 * a1826277115) % 14999) / 5) + 15179) % 101) - -273);
    	a620105235 = (((((((a620105235 * a1018383389) % 14999) - -1854) % 14909) + -15090) / 5) - 4002);
    	a1625516355 = ((((((a1625516355 * a2130183577) - -12343) % 37) - 42) / 5) + -33);
    	a2087535773 = a778006913;
    	a1895857334 = ((a786258498 + a1830659124) + -14);
    	a1241576728 = a1249952537; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((((35 < a1774184757) && (169 >= a1774184757)) && ((-160 < a620105235) && (30 >= a620105235))) && ((a601495656 == 34 && ((a1830659124 == 11 && ((input == 14) &&  cf==1 )) && ((249 < a1151361287) && (291 >= a1151361287)))) && a76745981 == 34))) {
    	cf = 0;
    	a708839806 = 33 ;
    	a1916853335 = (a2087535773 + 1);
    	a1644957382 = 33 ;
    	a1830659124 = ((a1916853335 * a778006913) + -8);
    	a983758263 = ((((((a983758263 * a2130183577) % 14999) + -25132) % 104) - -102) - 4);
    	a1895304149 = 33 ;
    	a63333937 = (((((((a1254983042 * a620105235) % 14999) / 5) + 17468) / 5) % 81) + -90);
    	a1675035970 = ((((((a1675035970 * a999024345) % 14999) % 17) + 179) - -10) + -2);
    	a1125477212 = 33 ;
    	a30494462 = ((((((a63333937 * a1254983042) % 14999) % 92) + 31) - 1) - 0);
    	a1249952537 = ((a786258498 * a786258498) - 95);
    	a1474668405 = (((((((a983758263 * a1826277115) % 14999) * 2) % 14920) + -15079) + 19496) + -19497);
    	a26346326 = 33 ;
    	a1985899004 = (((((((a1254983042 * a1254983042) % 14999) + 3640) - 1337) / 5) % 98) + 253);
    	a709568404 = 33 ;
    	a1241576728 = (a1959068056 + -3);
    	a1318526106 = 33 ;
    	a1240243570 = (a404763935 - 4);
    	a263151501 = 33 ;
    	a721272783 = (a1478681170 + 11);
    	a2130183577 = (((((a2130183577 * a34679179) * 1) % 63) - -167) - -1);
    	a1210910088 = ((a1830659124 * a786258498) - 98);
    	a2061425267 = ((a1830659124 / a1249952537) + 9);
    	a1774184757 = (((((((a1774184757 * a1151361287) % 14999) % 92) - 66) + 25283) - 7853) - 17425);
    	a1959068056 = (a190525986 - 2);
    	a1625516355 = (((((((a1625516355 * a1675035970) % 13) + -84) * 10) / 9) - -29721) - 29709);
    	a999024345 = ((((((a999024345 * a30494462) % 14999) - -11628) % 41) + 89) + 1);
    	a1211013485 = 33 ;
    	a620105235 = ((((((a620105235 * a1254983042) % 14999) % 10) - 169) - 12186) - -12184); 
    	 printf("%d\n", 26); fflush(stdout); 
    } 
}
 void calculate_outputm273(int input) {
    if((((-8 < a260539918) && (140 >= a260539918)) && (a1983740902 == 34 && ((a302110279 == 34 && ((( cf==1  && (input == 11)) && ((29 < a63333937) && (243 >= a63333937))) && ((104 < a813082108) && (243 >= a813082108)))) && a708839806 == 34)))) {
    	cf = 0;
    	a1337636546 = ((((((a999024345 * a983758263) % 14999) - 27645) / 5) * 10) / 9);
    	a404763935 = (a1478681170 - -3); 
    	 printf("%d\n", 18); fflush(stdout); 
    } 
}
 void calculate_outputm274(int input) {
    if(((a1180594800 == 34 && a302110279 == 34) && (a709568404 == 34 && (a190525986 == 11 && (a4442917 == 7 && (( cf==1  && (input == 1)) && ((35 < a1774184757) && (169 >= a1774184757)))))))) {
    	cf = 0;
    	a2130183577 = (((((((a2130183577 * a63333937) % 14999) % 63) + 167) - -26779) * 1) - 26779);
    	a999024345 = ((((((a999024345 * a1774184757) % 14999) + 11538) % 41) - -50) - -18);
    	a1774184757 = (((((((a1826277115 * a1985899004) % 14999) - 20863) % 92) - 4) - -19724) - 19705);
    	a263151501 = 33 ;
    	a786258498 = (a778006913 + 6);
    	a721272783 = ((a2026977784 - a190525986) + 12);
    	a620105235 = (((((a620105235 * a63333937) + -17369) % 10) + -170) * 1);
    	a709568404 = 33 ;
    	a1180594800 = 33 ;
    	a983758263 = ((((((a983758263 * a1254983042) % 14999) + 10532) % 104) - 2) + -1);
    	a803418896 = (((((((((a1985899004 * a813082108) % 14999) % 89) + -130) * 10) / 9) * 5) % 89) - 4);
    	a813082108 = (((((((a1018383389 * a1018383389) - -340) % 50) - -9) * 5) % 50) - -49);
    	a601495656 = 33 ;
    	a1625516355 = ((((((a1625516355 * a2130183577) % 13) + -88) + 3) * 10) / 9);
    	a1151361287 = (((((((a1151361287 * a803418896) % 14999) % 86) + 161) / 5) * 5) - -2);
    	a1210910088 = (a2087535773 + -3);
    	a4442917 = (a404763935 + -8);
    	a2026977784 = (a786258498 - 1);
    	a1348848030 = (a721272783 + 2);
    	a1254983042 = ((((((a63333937 * a30494462) - 1829) - -12154) + -20870) % 101) + 149);
    	a1478681170 = (a1210910088 + 2);
    	a2087535773 = ((a1241576728 / a1959068056) + 4);
    	a1644957382 = 33 ;
    	a1675035970 = ((((((a1675035970 * a217799639) % 14999) + 23637) / 5) % 17) - -186);
    	a190525986 = ((a786258498 / a404763935) - -10);
    	a1985899004 = ((((((a1985899004 * a1254983042) % 14999) - -5301) % 98) + 272) - -2); 
    	 printf("%d\n", 16); fflush(stdout); 
    } 
}
 void calculate_outputm24(int input) {
    if((((a1211013485 == 34 && (((371 < a1985899004) && (524 >= a1985899004)) && ((104 < a813082108) && (243 >= a813082108)))) && ((230 < a2130183577) && (255 >= a2130183577))) && (a1916853335 == 7 && (((131 < a999024345) && (260 >= a999024345)) && (a404763935 == 7 &&  cf==1 ))))) {
    	if(((((230 < a2130183577) && (255 >= a2130183577)) && ((a1916853335 == 7 && ((202 < a1254983042) && (414 >= a1254983042))) && a1249952537 == 6)) && ((( cf==1  && a247580515 == 34) && ((207 < a1675035970) && (311 >= a1675035970))) && ((-160 < a620105235) && (30 >= a620105235))))) {
    		calculate_outputm261(input);
    	} 
    } 
    if((((a190525986 == 11 && ((124 < a30494462) && (296 >= a30494462))) && a2061425267 == 12) && (((( cf==1  && a404763935 == 8) && a601495656 == 34) && ((-81 < a1625516355) && (-5 >= a1625516355))) && a1180594800 == 34))) {
    	if((((a709568404 == 34 && a1125477212 == 34) && a1644957382 == 34) && (a2087535773 == 5 && ((( cf==1  && a1337636546 <=  -1) && a26346326 == 34) && a1241576728 == 8)))) {
    		calculate_outputm262(input);
    	} 
    } 
    if(((a1478681170 == 5 && (((104 < a813082108) && (243 >= a813082108)) && (a76745981 == 34 && ((202 < a1254983042) && (414 >= a1254983042))))) && (((124 < a30494462) && (296 >= a30494462)) && ((a404763935 == 9 &&  cf==1 ) && ((131 < a999024345) && (260 >= a999024345)))))) {
    	if(((a4442917 == 7 && a708839806 == 34) && (a786258498 == 10 && ((a601495656 == 34 && (((124 < a30494462) && (296 >= a30494462)) && (a537754274 == 32 &&  cf==1 ))) && a302110279 == 34)))) {
    		calculate_outputm263(input);
    	} 
    } 
    if(((a786258498 == 10 && (a4442917 == 7 && a778006913 == 3)) && (a708839806 == 34 && (a263151501 == 34 && (a1644957382 == 34 && (a404763935 == 11 &&  cf==1 )))))) {
    	if(((a302110279 == 34 && (((104 < a813082108) && (243 >= a813082108)) && (((-81 < a1625516355) && (-5 >= a1625516355)) && (a4442917 == 7 && a1210910088 == 3)))) && (((230 < a2130183577) && (255 >= a2130183577)) && (a350392085 == 10 &&  cf==1 )))) {
    		calculate_outputm266(input);
    	} 
    } 
    if((((a1830659124 == 11 && (a2026977784 == 9 && (((371 < a1985899004) && (524 >= a1985899004)) && a263151501 == 34))) && a2130193413 == 11) && (a1478681170 == 5 && (a404763935 == 12 &&  cf==1 )))) {
    	if((((a601495656 == 34 && a2130193413 == 11) && ((-81 < a1625516355) && (-5 >= a1625516355))) && (((371 < a1985899004) && (524 >= a1985899004)) && ((( cf==1  && ((-160 < a1474668405) && (-6 >= a1474668405))) && a2073482783 == 34) && a786258498 == 10)))) {
    		calculate_outputm268(input);
    	} 
    } 
    if(((a2087535773 == 5 && (((230 < a2130183577) && (255 >= a2130183577)) && (a404763935 == 13 &&  cf==1 ))) && (((a1478681170 == 5 && a1211013485 == 34) && a786258498 == 10) && a4442917 == 7))) {
    	if(((a709568404 == 34 && (((207 < a1675035970) && (311 >= a1675035970)) && a1241576728 == 8)) && (((a302110279 == 34 && (((-65 < a34679179) && (29 >= a34679179)) &&  cf==1 )) && a708839806 == 34) && a1125477212 == 34))) {
    		calculate_outputm270(input);
    	} 
    } 
    if(((a1180594800 == 34 && (a2026977784 == 9 && ((a404763935 == 14 &&  cf==1 ) && a1478681170 == 5))) && (a786258498 == 10 && (a1210910088 == 3 && ((207 < a1675035970) && (311 >= a1675035970)))))) {
    	if(((((a2026977784 == 9 && ((a548050643 == 35 &&  cf==1 ) && ((207 < a1675035970) && (311 >= a1675035970)))) && ((371 < a1985899004) && (524 >= a1985899004))) && ((230 < a2130183577) && (255 >= a2130183577))) && (a190525986 == 11 && a1916853335 == 7))) {
    		calculate_outputm273(input);
    	} 
    	if(((((230 < a2130183577) && (255 >= a2130183577)) && (a548050643 == 36 &&  cf==1 )) && ((((249 < a1151361287) && (291 >= a1151361287)) && (a302110279 == 34 && (((-160 < a620105235) && (30 >= a620105235)) && a601495656 == 34))) && ((371 < a1985899004) && (524 >= a1985899004))))) {
    		calculate_outputm274(input);
    	} 
    } 
}

 void calculate_output(int input) {
        cf = 1;

    if(((a1241576728 == 6 && ((a4442917 == 5 && a30494462 <=  -62) && a1895304149 == 32)) && ((( cf==1  && a983758263 <=  -6) && a778006913 == 1) && a76745981 == 32))) {
    	if(((a601495656 == 32 && (a709568404 == 32 && ( cf==1  && a341216798 <=  197))) && (a778006913 == 1 && ((a1318526106 == 32 && a1895304149 == 32) && a63333937 <=  -135)))) {
    		calculate_outputm1(input);
    	} 
    	if(((a1625516355 <=  -109 && (a709568404 == 32 && (a26346326 == 32 && ( cf==1  && ((197 < a341216798) && (234 >= a341216798)))))) && ((a1241576728 == 6 && a1895304149 == 32) && a1125477212 == 32))) {
    		calculate_outputm2(input);
    	} 
    	if(((( cf==1  && ((234 < a341216798) && (298 >= a341216798))) && a2087535773 == 3) && (a217799639 <=  -198 && (a2130193413 == 9 && ((a260539918 <=  -44 && a1211013485 == 32) && a30494462 <=  -62))))) {
    		calculate_outputm3(input);
    	} 
    	if((((298 < a341216798 &&  cf==1 ) && a302110279 == 32) && (((a1151361287 <=  75 && (a1774184757 <=  -151 && a2130183577 <=  103)) && a1180594800 == 32) && a1211013485 == 32))) {
    		calculate_outputm4(input);
    	} 
    } 
    if(((((-109 < a1625516355) && (-81 >= a1625516355)) && (a26346326 == 33 && (((-6 < a983758263) && (203 >= a983758263)) &&  cf==1 ))) && (((171 < a1675035970) && (207 >= a1675035970)) && (((-62 < a30494462) && (124 >= a30494462)) && (a1895304149 == 33 && a1210910088 == 2))))) {
    	if((a190525986 == 10 && (((-135 < a63333937) && (29 >= a63333937)) && (((((a721272783 == 10 &&  cf==1 ) && a709568404 == 33) && ((103 < a2130183577) && (230 >= a2130183577))) && ((-2 < a1254983042) && (202 >= a1254983042))) && a1211013485 == 33)))) {
    		calculate_outputm5(input);
    	} 
    	if(((a708839806 == 33 && (a721272783 == 11 &&  cf==1 )) && (a26346326 == 33 && (a2061425267 == 11 && (a786258498 == 9 && (a1241576728 == 7 && a1210910088 == 2)))))) {
    		calculate_outputm6(input);
    	} 
    	if(((a1210910088 == 2 && ((((-44 < a260539918) && (-8 >= a260539918)) && a2130193413 == 10) && a1180594800 == 33)) && (a786258498 == 9 && (a263151501 == 33 && (a721272783 == 12 &&  cf==1 ))))) {
    		calculate_outputm7(input);
    	} 
    	if(((((((a721272783 == 13 &&  cf==1 ) && a4442917 == 6) && a1210910088 == 2) && a1916853335 == 6) && ((3 < a813082108) && (104 >= a813082108))) && (a786258498 == 9 && ((-109 < a1625516355) && (-81 >= a1625516355))))) {
    		calculate_outputm8(input);
    	} 
    	if((((((17 < a1018383389) && (167 >= a1018383389)) && (((-135 < a63333937) && (29 >= a63333937)) && (( cf==1  && a721272783 == 14) && ((-2 < a1254983042) && (202 >= a1254983042))))) && a1210910088 == 2) && (a1895304149 == 33 && a1478681170 == 4))) {
    		calculate_outputm9(input);
    	} 
    	if(((a2026977784 == 8 && (((-109 < a1625516355) && (-81 >= a1625516355)) && (a1241576728 == 7 && ((75 < a1151361287) && (249 >= a1151361287))))) && ((a1478681170 == 4 && (a721272783 == 15 &&  cf==1 )) && a601495656 == 33))) {
    		calculate_outputm10(input);
    	} 
    	if(((((-151 < a1774184757) && (35 >= a1774184757)) && ((((103 < a2130183577) && (230 >= a2130183577)) && a1959068056 == 9) && ((-109 < a1625516355) && (-81 >= a1625516355)))) && (a1830659124 == 10 && ((a721272783 == 16 &&  cf==1 ) && a1916853335 == 6)))) {
    		calculate_outputm11(input);
    	} 
    	if((((((75 < a1151361287) && (249 >= a1151361287)) && a1830659124 == 10) && a1644957382 == 33) && (a2073482783 == 33 && (a601495656 == 33 && (((-198 < a217799639) && (-59 >= a217799639)) && ( cf==1  && a721272783 == 17)))))) {
    		calculate_outputm12(input);
    	} 
    } 
    if(((a1830659124 == 11 && ((202 < a1254983042) && (414 >= a1254983042))) && (a1959068056 == 10 && ((((131 < a999024345) && (260 >= a999024345)) && ((((203 < a983758263) && (406 >= a983758263)) &&  cf==1 ) && a2061425267 == 12)) && ((124 < a30494462) && (296 >= a30494462)))))) {
    	if((((((249 < a1151361287) && (291 >= a1151361287)) && (a76745981 == 34 && (( cf==1  && a1895857334 == 6) && a786258498 == 10))) && a1211013485 == 34) && (a1180594800 == 34 && ((207 < a1675035970) && (311 >= a1675035970))))) {
    		calculate_outputm13(input);
    	} 
    	if(((((35 < a1774184757) && (169 >= a1774184757)) && ((a778006913 == 3 && (a1895857334 == 7 &&  cf==1 )) && a1211013485 == 34)) && ((a263151501 == 34 && a1249952537 == 6) && a2026977784 == 9))) {
    		calculate_outputm14(input);
    	} 
    	if(((((-59 < a217799639) && (-1 >= a217799639)) && (a2087535773 == 5 && ( cf==1  && a1895857334 == 8))) && (a1916853335 == 7 && (a1210910088 == 3 && (a1895304149 == 34 && ((202 < a1254983042) && (414 >= a1254983042))))))) {
    		calculate_outputm15(input);
    	} 
    	if(((a786258498 == 10 && ((124 < a30494462) && (296 >= a30494462))) && ((a1478681170 == 5 && ((( cf==1  && a1895857334 == 9) && a709568404 == 34) && a2073482783 == 34)) && ((-8 < a260539918) && (140 >= a260539918))))) {
    		calculate_outputm16(input);
    	} 
    	if(((a2087535773 == 5 && (a1644957382 == 34 && (a1895857334 == 11 &&  cf==1 ))) && (((202 < a1254983042) && (414 >= a1254983042)) && ((a1895304149 == 34 && a601495656 == 34) && a1180594800 == 34)))) {
    		calculate_outputm18(input);
    	} 
    	if(((a76745981 == 34 && a786258498 == 10) && (((202 < a1254983042) && (414 >= a1254983042)) && (a1180594800 == 34 && (((371 < a1985899004) && (524 >= a1985899004)) && ((a1895857334 == 12 &&  cf==1 ) && a26346326 == 34)))))) {
    		calculate_outputm19(input);
    	} 
    	if((((( cf==1  && a1895857334 == 13) && a2073482783 == 34) && a76745981 == 34) && (((a1249952537 == 6 && a26346326 == 34) && a786258498 == 10) && a1959068056 == 10))) {
    		calculate_outputm20(input);
    	} 
    } 
    if(((a1644957382 == 34 && (((406 < a983758263 &&  cf==1 ) && ((131 < a999024345) && (260 >= a999024345))) && a786258498 == 10)) && ((a263151501 == 34 && a778006913 == 3) && a4442917 == 7))) {
    	if((((((167 < a1018383389) && (211 >= a1018383389)) && a2061425267 == 12) && a1249952537 == 6) && (((a1125477212 == 34 && (a1826277115 <=  -158 &&  cf==1 )) && ((35 < a1774184757) && (169 >= a1774184757))) && a4442917 == 7))) {
    		calculate_outputm21(input);
    	} 
    	if(((a1125477212 == 34 && ((a26346326 == 34 && ( cf==1  && ((-158 < a1826277115) && (53 >= a1826277115)))) && ((104 < a813082108) && (243 >= a813082108)))) && (((249 < a1151361287) && (291 >= a1151361287)) && (((131 < a999024345) && (260 >= a999024345)) && ((-59 < a217799639) && (-1 >= a217799639)))))) {
    		calculate_outputm22(input);
    	} 
    	if(((((207 < a1675035970) && (311 >= a1675035970)) && ( cf==1  && ((53 < a1826277115) && (178 >= a1826277115)))) && (((124 < a30494462) && (296 >= a30494462)) && (((-8 < a260539918) && (140 >= a260539918)) && ((a2073482783 == 34 && ((29 < a63333937) && (243 >= a63333937))) && ((167 < a1018383389) && (211 >= a1018383389))))))) {
    		calculate_outputm23(input);
    	} 
    	if(((a2087535773 == 5 && ( cf==1  && 178 < a1826277115)) && ((((((-81 < a1625516355) && (-5 >= a1625516355)) && ((131 < a999024345) && (260 >= a999024345))) && ((249 < a1151361287) && (291 >= a1151361287))) && ((202 < a1254983042) && (414 >= a1254983042))) && a190525986 == 11))) {
    		calculate_outputm24(input);
    	} 
    } 
    errorCheck();

    if( cf==1 ) 
    	fprintf(stderr, "Invalid input: %d\n", input); 
}

int main()
{
    // main i/o-loop
    while(1)
    {
        // read input
        int input;
        scanf("%d", &input);        
        // operate eca engine
        if((input != 4) && (input != 5) && (input != 2) && (input != 14) && (input != 8) && (input != 10) && (input != 3) && (input != 6) && (input != 7) && (input != 9) && (input != 12) && (input != 13) && (input != 11) && (input != 15) && (input != 1))
          return -2;
        calculate_output(input);
    }
}